Antenna Calculator PRO 1.8.5 — 3D validated

Что исправлено:
- Проверена цепочка FFS: Re/Im(Etheta,Ephi) -> U=|Etheta|^2+|Ephi|^2 -> dB=10 log10(U/Umax).
- Для последнего UA1FAD_23cm_FEED.ffs на 1.300 GHz: максимум theta=33 deg, phi=241 deg.
- На theta=33 deg диаграмма почти осесимметрична по phi; поэтому гладкая кольцевая/объемная форма FFS является свойством файла, а не ошибкой triangulation.
- FFS открывается по умолчанию в линейном амплитудном радиусе r=10^(dB/20).
- Система открывается в dB-радиусе, чтобы были заметны боковые лепестки.
- Кнопки Surface/Grid/Points и Reset/+/-/PNG переразмечены с weight, чтобы не сжиматься на узких экранах.
- 3D-Canvas квадратный и лучше помещается на телефоне.

Проверенные формулы:
- lambda=c/f
- F=D*(F/D)
- depth=D^2/(16F)
- theta_edge=2 atan(D/(4F))
- D_ideal=(pi D/lambda)^2
- Ruze=exp[-(4 pi sigma/lambda)^2]
- Spillover=P(theta<=theta_edge)/P_total
- rho=2F tan(theta/2)
- aperture amplitude proportional sqrt(U)*cos^2(theta/2) from power conservation dOmega/dA
- taper=|int_A E_a dA|^2/(A int_A |E_a|^2 dA)
- eta_ap=eta_spill*eta_taper*eta_Ruze (phase, blockage, cross-pol excluded)
- D_system=D_ideal*eta_ap; Gain adds feed radiation efficiency.
