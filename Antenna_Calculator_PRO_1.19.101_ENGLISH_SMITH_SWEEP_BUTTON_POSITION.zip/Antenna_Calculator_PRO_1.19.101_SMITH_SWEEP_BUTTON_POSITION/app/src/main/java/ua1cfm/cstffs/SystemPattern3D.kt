package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

private const val SYSTEM_MIN_DB = -40.0

/**
 * Axisymmetric aperture model of the feed + parabolic reflector system.
 *
 * 1) The actual FFS inside the dish edge angle is averaged over azimuth.
 * 2) The field is mapped to the aperture: rho = 2 F tan(theta/2).
 * 3) The far field of the circular aperture is calculated using a Hankel integral:
 *    E(q) = integral A(rho) J0(q rho) rho d rho.
 *
 * The shape depends on the actual feed amplitude taper. Phase errors,
 * blockage, and cross-polarization are intentionally not modeled here.
 */
fun buildSystemPattern3D(dish: DishResult, ffs: FfsResult): List<Pattern3DPoint> {
    val profile = ffs.apertureIllumination.sortedBy { it.thetaDeg }
    val lambda = dish.wavelengthM
    val f = dish.focalM
    val apertureRadius = dish.diameterM / 2.0
    if (profile.size < 3 || lambda <= 0.0 || f <= 0.0 || apertureRadius <= 0.0) return emptyList()

    val radial = profile.mapNotNull { p ->
        val rho = 2.0 * f * tan(Math.toRadians(p.thetaDeg) / 2.0)
        if (rho.isFinite() && rho in 0.0..(apertureRadius * 1.02) && p.amplitude.isFinite()) {
            rho to p.amplitude
        } else null
    }.sortedBy { it.first }
    if (radial.size < 3) return emptyList()

    fun field(thetaDeg: Double): Double {
        val q = 2.0 * PI / lambda * sin(Math.toRadians(thetaDeg))
        var sum = 0.0
        for (i in 0 until radial.size - 1) {
            val (r0, a0) = radial[i]
            val (r1, a1) = radial[i + 1]
            val dr = r1 - r0
            if (dr <= 0.0) continue
            val rm = (r0 + r1) * 0.5
            val am = (a0 + a1) * 0.5
            sum += am * besselJ0(q * rm) * rm * dr
        }
        return sum
    }

    val thetaStep = 0.5
    val phiStep = 8
    val e0 = abs(field(0.0)).coerceAtLeast(1e-30)
    val thetaDb = ArrayList<Pair<Double, Double>>(181)
    var theta = 0.0
    while (theta <= 90.0001) {
        val normalizedField = abs(field(theta)) / e0
        val db = (20.0 * kotlin.math.log10(normalizedField.coerceAtLeast(1e-12)))
            .coerceAtLeast(SYSTEM_MIN_DB)
        thetaDb += theta to db
        theta += thetaStep
    }

    val result = ArrayList<Pattern3DPoint>(thetaDb.size * (360 / phiStep))
    for (phi in 0 until 360 step phiStep) {
        for ((th, db) in thetaDb) result += Pattern3DPoint(th, phi.toDouble(), db)
    }
    return result
}

private fun besselJ0(x: Double): Double {
    val ax = abs(x)
    return if (ax < 8.0) {
        val y = x * x
        val ans1 = 57568490574.0 + y * (-13362590354.0 + y * (651619640.7 + y * (-11214424.18 + y * (77392.33017 + y * -184.9052456))))
        val ans2 = 57568490411.0 + y * (1029532985.0 + y * (9494680.718 + y * (59272.64853 + y * (267.8532712 + y))))
        ans1 / ans2
    } else {
        val z = 8.0 / ax
        val y = z * z
        val xx = ax - 0.785398164
        val ans1 = 1.0 + y * (-0.001098628627 + y * (0.00002734510407 + y * (-0.000002073370639 + y * 0.0000002093887211)))
        val ans2 = -0.01562499995 + y * (0.0001430488765 + y * (-0.000006911147651 + y * (0.0000007621095161 - y * 0.0000000934945152)))
        sqrt(0.636619772 / ax) * (cos(xx) * ans1 - z * sin(xx) * ans2)
    }
}
