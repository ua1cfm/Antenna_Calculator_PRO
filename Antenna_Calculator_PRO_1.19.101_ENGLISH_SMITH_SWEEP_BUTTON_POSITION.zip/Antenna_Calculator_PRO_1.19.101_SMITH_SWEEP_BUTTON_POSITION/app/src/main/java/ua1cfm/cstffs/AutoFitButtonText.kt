package ua1cfm.cstffs

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * Button label that progressively reduces its font size until it fits.
 * Keeps short labels large, permits two lines for long labels and avoids clipping.
 */
@Composable
fun AutoFitButtonText(
    text: String,
    maxLines: Int = 1,
    maxFontSize: TextUnit = 16.sp,
    minFontSize: TextUnit = 9.sp,
    style: TextStyle = TextStyle.Default
) {
    var fontSize by remember(text, maxLines, maxFontSize, minFontSize) { mutableStateOf(maxFontSize) }
    Text(
        text = text,
        style = style,
        fontSize = fontSize,
        maxLines = maxLines,
        softWrap = maxLines > 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        onTextLayout = { result ->
            if ((result.didOverflowWidth || result.didOverflowHeight) && fontSize.value > minFontSize.value) {
                fontSize = (fontSize.value - 0.5f).coerceAtLeast(minFontSize.value).sp
            }
        }
    )
}
