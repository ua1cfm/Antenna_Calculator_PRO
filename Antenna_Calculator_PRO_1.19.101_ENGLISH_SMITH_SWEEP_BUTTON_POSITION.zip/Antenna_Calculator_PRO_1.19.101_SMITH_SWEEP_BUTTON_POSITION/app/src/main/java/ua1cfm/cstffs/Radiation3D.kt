package ua1cfm.cstffs

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

private const val MIN_DB_3D = -40.0
private val NAVY = Color(0xFF031A36)
private val NAVY_GRID = Color(0xFF16466F)

enum class Render3DMode { SURFACE, WIREFRAME, VECTORS, POINTS }
enum class Radius3DScale { DB, LINEAR }
enum class Level3DMode { ABSOLUTE_DBI, NORMALIZED_DB }

data class View3DState(
    val qW: Float,
    val qX: Float,
    val qY: Float,
    val qZ: Float,
    val zoom: Float,
    val panX: Float,
    val panY: Float,
    val mode: Render3DMode,
    val radiusScale: Radius3DScale
)

private data class Vec3(val x: Double, val y: Double, val z: Double)
private data class Quat(val w: Double, val x: Double, val y: Double, val z: Double)
private data class Projected(val x: Float, val y: Float, val z: Double, val db: Double)
private data class Tri(val a: Int, val b: Int, val c: Int)
private data class Mesh(val vertices: List<Pattern3DPoint>, val triangles: List<Tri>)
private data class RenderTri(val a: Projected, val b: Projected, val c: Projected, val depth: Double, val db: Double)

@Composable
fun Radiation3DCard(
    title: String,
    points: List<Pattern3DPoint>,
    subtitle: String,
    initialRadiusScale: Radius3DScale = Radius3DScale.LINEAR,
    absolutePeakDbi: Double? = null,
    absolutePeakLabel: String = "Dmax",
    peakThetaDeg: Double? = null,
    peakPhiDeg: Double? = null,
    geometryViewYawDeg: Float? = null,
    geometryViewPitchDeg: Float? = null,
    onExportPng: ((View3DState) -> Unit)? = null
) {
    val alignedDefaultOrientation = remember(points, geometryViewYawDeg, geometryViewPitchDeg) {
        if (geometryViewYawDeg != null && geometryViewPitchDeg != null) {
            geometryProjectionOrientation(geometryViewYawDeg.toDouble(), geometryViewPitchDeg.toDouble())
        } else {
            defaultOrientation()
        }
    }
    var orientation by remember(points, geometryViewYawDeg, geometryViewPitchDeg) { mutableStateOf(alignedDefaultOrientation) }
    var zoom by remember { mutableFloatStateOf(1.02f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var mode by remember { mutableStateOf(Render3DMode.SURFACE) }
    var radiusScale by remember(points, initialRadiusScale) { mutableStateOf(initialRadiusScale) }
    var levelMode by remember(points, absolutePeakDbi) {
        mutableStateOf(if (absolutePeakDbi != null) Level3DMode.ABSOLUTE_DBI else Level3DMode.NORMALIZED_DB)
    }
    var inertiaJob by remember { mutableStateOf<Job?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val mesh = remember(points) { buildMesh(points) }
    val peakPoint = remember(points) { points.maxByOrNull { it.db } }
    val shownTheta = peakThetaDeg ?: peakPoint?.thetaDeg
    val shownPhi = peakPhiDeg ?: peakPoint?.phiDeg

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
            if (absolutePeakDbi != null) {
                Text(
                    buildString {
                        append("$absolutePeakLabel = ${format3DNumber(absolutePeakDbi, 2)} dBi")
                        if (shownTheta != null) append("   θmax = ${format3DNumber(shownTheta, 1)}°")
                        if (shownPhi != null) append("   φmax = ${format3DNumber(shownPhi, 1)}°")
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (points.isEmpty()) {
                Text("No data for the 3D pattern.")
            } else {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .background(NAVY)
                        .pointerInput(points) {
                            var previousPointerCount = 0
                            var lastSingleDelta = Offset.Zero
                            awaitPointerEventScope {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val pressed = event.changes.filter { it.pressed }

                                    if (pressed.isNotEmpty()) {
                                        inertiaJob?.cancel()
                                        inertiaJob = null
                                    }

                                    when {
                                        pressed.size == 1 -> {
                                            val c = pressed[0]
                                            if (c.previousPressed) {
                                                val from = mapToTrackball(c.previousPosition, size.width.toFloat(), size.height.toFloat())
                                                val to = mapToTrackball(c.position, size.width.toFloat(), size.height.toFloat())
                                                val dq = quatFromVectors(from, to)
                                                orientation = normalizeQuat(dq * orientation)
                                                lastSingleDelta = c.position - c.previousPosition
                                                c.consume()
                                            }
                                        }

                                        pressed.size >= 2 -> {
                                            val a = pressed[0]
                                            val b = pressed[1]
                                            if (a.previousPressed && b.previousPressed) {
                                                val prevCentroid = Offset(
                                                    (a.previousPosition.x + b.previousPosition.x) * 0.5f,
                                                    (a.previousPosition.y + b.previousPosition.y) * 0.5f
                                                )
                                                val curCentroid = Offset(
                                                    (a.position.x + b.position.x) * 0.5f,
                                                    (a.position.y + b.position.y) * 0.5f
                                                )
                                                val prevDistance = distance(a.previousPosition, b.previousPosition)
                                                val curDistance = distance(a.position, b.position)
                                                if (prevDistance > 1f && curDistance > 1f) {
                                                    zoom = (zoom * (curDistance / prevDistance)).coerceIn(0.35f, 3.2f)
                                                }
                                                val pan = curCentroid - prevCentroid
                                                panX = (panX + pan.x / size.width).coerceIn(-0.45f, 0.45f)
                                                panY = (panY + pan.y / size.height).coerceIn(-0.45f, 0.45f)
                                                a.consume()
                                                b.consume()
                                            }
                                            lastSingleDelta = Offset.Zero
                                        }

                                        pressed.isEmpty() && previousPointerCount == 1 && sqrt(lastSingleDelta.x * lastSingleDelta.x + lastSingleDelta.y * lastSingleDelta.y) > 1.5f -> {
                                            val initial = lastSingleDelta
                                            inertiaJob = coroutineScope.launch {
                                                var vx = initial.x
                                                var vy = initial.y
                                                repeat(42) {
                                                    val speed = sqrt(vx * vx + vy * vy)
                                                    if (speed < 0.12f) return@launch
                                                    val dq = inertiaQuaternion(vx, vy, size.width.toFloat(), size.height.toFloat())
                                                    orientation = normalizeQuat(dq * orientation)
                                                    vx *= 0.88f
                                                    vy *= 0.88f
                                                    delay(16L)
                                                }
                                            }
                                            lastSingleDelta = Offset.Zero
                                        }
                                    }
                                    previousPointerCount = pressed.size
                                }
                            }
                        }
                ) {
                    drawRect(NAVY)
                    val cx = size.width * (0.5f + panX)
                    val cy = size.height * (0.5f + panY)
                    val scale = minOf(size.width, size.height) * 0.43f * zoom

                    for (r in listOf(0.25f, 0.5f, 0.75f, 1f)) {
                        drawCircle(
                            NAVY_GRID.copy(alpha = 0.34f),
                            radius = scale * r,
                            center = Offset(cx, cy),
                            style = Stroke(1f)
                        )
                    }

                    val projected = mesh.vertices.map { project(it, orientation, cx, cy, scale, radiusScale) }

                    when (mode) {
                        Render3DMode.SURFACE -> {
                            val render = mesh.triangles.map { t ->
                                val a = projected[t.a]; val b = projected[t.b]; val c = projected[t.c]
                                RenderTri(a, b, c, (a.z + b.z + c.z) / 3.0, (a.db + b.db + c.db) / 3.0)
                            }.sortedBy { it.depth }
                            render.forEach { t ->
                                val p = Path().apply {
                                    moveTo(t.a.x, t.a.y)
                                    lineTo(t.b.x, t.b.y)
                                    lineTo(t.c.x, t.c.y)
                                    close()
                                }
                                val depthShade = ((t.depth + 1.0) * 0.16).coerceIn(0.0, 0.28).toFloat()
                                drawPath(p, shade(colorForDb(t.db), 0.72f + depthShade))
                            }
                        }

                        Render3DMode.WIREFRAME -> {
                            mesh.triangles.forEach { t ->
                                val a = projected[t.a]; val b = projected[t.b]; val c = projected[t.c]
                                val col = colorForDb((a.db + b.db + c.db) / 3.0).copy(alpha = 0.66f)
                                drawLine(col, Offset(a.x, a.y), Offset(b.x, b.y), 0.8f)
                                drawLine(col, Offset(b.x, b.y), Offset(c.x, c.y), 0.8f)
                                drawLine(col, Offset(c.x, c.y), Offset(a.x, a.y), 0.8f)
                            }
                        }

                        Render3DMode.VECTORS -> {
                            // Visualization only: draw radial vectors from the antenna origin
                            // to the already calculated 3D-pattern samples.  No NEC/OpenNEC
                            // coordinates, gain values, ground model or field summation are changed.
                            val origin = projectXYZ(Vec3(0.0, 0.0, 0.0), orientation, cx, cy, scale)
                            val step = vectorDisplayStep(projected.size)
                            projected
                                .asSequence()
                                .filterIndexed { index, _ -> index % step == 0 }
                                .sortedBy { it.z }
                                .forEach { p ->
                                    val col = colorForDb(p.db).copy(alpha = 0.62f)
                                    drawLine(
                                        color = col,
                                        start = Offset(origin.x, origin.y),
                                        end = Offset(p.x, p.y),
                                        strokeWidth = 0.9f
                                    )
                                    drawCircle(
                                        color = colorForDb(p.db),
                                        radius = 1.45f,
                                        center = Offset(p.x, p.y)
                                    )
                                }
                        }

                        Render3DMode.POINTS -> {
                            projected.sortedBy { it.z }.forEach { p ->
                                drawCircle(colorForDb(p.db), radius = 1.8f, center = Offset(p.x, p.y))
                            }
                        }
                    }

                    val o = projectXYZ(Vec3(0.0, 0.0, 0.0), orientation, cx, cy, scale)
                    val ax = projectXYZ(Vec3(1.05, 0.0, 0.0), orientation, cx, cy, scale)
                    val ay = projectXYZ(Vec3(0.0, 1.05, 0.0), orientation, cx, cy, scale)
                    val az = projectXYZ(Vec3(0.0, 0.0, 1.05), orientation, cx, cy, scale)
                    drawLine(Color(0xFFFF5353), Offset(o.x, o.y), Offset(ax.x, ax.y), 2.4f)
                    drawLine(Color(0xFF63E572), Offset(o.x, o.y), Offset(ay.x, ay.y), 2.4f)
                    drawLine(Color(0xFF6695FF), Offset(o.x, o.y), Offset(az.x, az.y), 2.4f)
                }

                Text(
                    "Controls: 1 finger — free 3D rotation; 2 fingers — zoom and pan; after release — smooth inertia.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (geometryViewYawDeg != null && geometryViewPitchDeg != null) {
                    Text(
                        "View aligned with the 3D antenna model. Reset restores the geometry-model camera.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RenderModeButton("Surface", mode == Render3DMode.SURFACE) { mode = Render3DMode.SURFACE }
                    RenderModeButton("Grid", mode == Render3DMode.WIREFRAME) { mode = Render3DMode.WIREFRAME }
                    RenderModeButton("Vectors", mode == Render3DMode.VECTORS) { mode = Render3DMode.VECTORS }
                    RenderModeButton("Points", mode == Render3DMode.POINTS) { mode = Render3DMode.POINTS }
                }

                Text("Radius scale", style = MaterialTheme.typography.bodySmall)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RenderModeButton("dB", radiusScale == Radius3DScale.DB) { radiusScale = Radius3DScale.DB }
                    RenderModeButton("Linear", radiusScale == Radius3DScale.LINEAR) { radiusScale = Radius3DScale.LINEAR }
                }

                if (absolutePeakDbi != null) {
                    Text("Level scale", style = MaterialTheme.typography.bodySmall)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        RenderModeButton("Absolute dBi", levelMode == Level3DMode.ABSOLUTE_DBI) { levelMode = Level3DMode.ABSOLUTE_DBI }
                        RenderModeButton("Normalized dB", levelMode == Level3DMode.NORMALIZED_DB) { levelMode = Level3DMode.NORMALIZED_DB }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF143DFF), Color(0xFF00CFFF), Color(0xFF00E676),
                                    Color(0xFFFFE600), Color(0xFFFF3B1F)
                                )
                            )
                        )
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (levelMode == Level3DMode.ABSOLUTE_DBI && absolutePeakDbi != null) {
                        Text("${format3DNumber(absolutePeakDbi - 40.0, 1)} dBi", style = MaterialTheme.typography.bodySmall)
                        Text("${format3DNumber(absolutePeakDbi - 20.0, 1)} dBi", style = MaterialTheme.typography.bodySmall)
                        Text("${format3DNumber(absolutePeakDbi, 1)} dBi", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("−40 dB", style = MaterialTheme.typography.bodySmall)
                        Text("−20 dB", style = MaterialTheme.typography.bodySmall)
                        Text("0 dB", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            inertiaJob?.cancel()
                            orientation = alignedDefaultOrientation
                            zoom = 1.02f
                            panX = 0f
                            panY = 0f
                        },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) { Text("Reset", maxLines = 1) }
                    Button(
                        onClick = { zoom = (zoom * 1.15f).coerceAtMost(3.2f) },
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)
                    ) { Text("+") }
                    Button(
                        onClick = { zoom = (zoom / 1.15f).coerceAtLeast(.35f) },
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)
                    ) { Text("−") }
                    if (onExportPng != null) {
                        Button(
                            onClick = {
                                onExportPng(
                                    View3DState(
                                        orientation.w.toFloat(), orientation.x.toFloat(), orientation.y.toFloat(), orientation.z.toFloat(),
                                        zoom, panX, panY, mode, radiusScale
                                    )
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)
                        ) { Text("PNG", maxLines = 1) }
                    }
                }
            }
        }
    }
}

/**
 * Estimates maximum directivity from the normalized 3D radiation pattern.
 * For a regular NEC-2 grid, P/Pmax is integrated over the entire sphere:
 * Dmax = 4π / ∫(P/Pmax)dΩ.
 */
fun estimatePattern3DDirectivityDbi(points: List<Pattern3DPoint>): Double? {
    if (points.size < 12) return null
    val thetaValues = points.map { quant(it.thetaDeg) }.distinct().sorted().map { it / 1000.0 }
    val phiValues = points.map { quant(it.phiDeg) }.distinct().sorted().map { it / 1000.0 }
    if (thetaValues.size < 3 || phiValues.size < 3) return null

    fun medianPositiveStep(values: List<Double>): Double? {
        val steps = values.zipWithNext { a, b -> b - a }.filter { it > 1.0e-9 }.sorted()
        if (steps.isEmpty()) return null
        return steps[steps.size / 2]
    }

    val dThetaDeg = medianPositiveStep(thetaValues) ?: return null
    val dPhiDeg = if (phiValues.size >= 3) 360.0 / phiValues.size.toDouble() else return null
    val dTheta = Math.toRadians(dThetaDeg)
    val dPhi = Math.toRadians(dPhiDeg)
    var integral = 0.0
    for (p in points) {
        val theta = Math.toRadians(p.thetaDeg)
        val relativePower = 10.0.pow(p.db.coerceAtLeast(-120.0) / 10.0)
        integral += relativePower * sin(theta).coerceAtLeast(0.0) * dTheta * dPhi
    }
    if (!integral.isFinite() || integral <= 0.0) return null
    val dMax = 4.0 * PI / integral
    if (!dMax.isFinite() || dMax <= 0.0) return null
    return 10.0 * kotlin.math.log10(dMax)
}

private fun format3DNumber(v: Double, digits: Int): String =
    java.lang.String.format(java.util.Locale.US, "% .${digits}f", v).trim()

@Composable
private fun RenderModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val padding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
    if (selected) {
        Button(onClick = onClick, contentPadding = padding) {
            Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    } else {
        OutlinedButton(onClick = onClick, contentPadding = padding) {
            Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun buildMesh(points: List<Pattern3DPoint>): Mesh {
    if (points.size < 4) return Mesh(points, emptyList())

    val phiRows = points
        .groupBy { quant(it.phiDeg) }
        .toSortedMap()
        .mapValues { (_, row) -> row.associateBy { quant(it.thetaDeg) } }

    if (phiRows.size < 2) return Mesh(points, emptyList())

    var commonTheta: Set<Int>? = null
    phiRows.values.forEach { row ->
        commonTheta = if (commonTheta == null) row.keys.toSet() else commonTheta!!.intersect(row.keys)
    }
    val thetaKeys = commonTheta.orEmpty().sorted()
    if (thetaKeys.size < 2) return Mesh(points, emptyList())

    val vertices = ArrayList<Pattern3DPoint>(phiRows.size * thetaKeys.size)
    val rows = ArrayList<IntArray>(phiRows.size)
    for ((_, rowMap) in phiRows) {
        val row = IntArray(thetaKeys.size)
        for ((i, tk) in thetaKeys.withIndex()) {
            val point = rowMap[tk] ?: continue
            row[i] = vertices.size
            vertices += point
        }
        rows += row
    }

    val triangles = ArrayList<Tri>(rows.size * (thetaKeys.size - 1) * 2)
    for (r in rows.indices) {
        val next = (r + 1) % rows.size
        val a = rows[r]
        val b = rows[next]
        for (i in 0 until thetaKeys.size - 1) {
            triangles += Tri(a[i], b[i], b[i + 1])
            triangles += Tri(a[i], b[i + 1], a[i + 1])
        }
    }
    return Mesh(vertices, triangles)
}

private fun quant(v: Double): Int = kotlin.math.round(v * 1000.0).toInt()

private fun mapToTrackball(p: Offset, width: Float, height: Float): Vec3 {
    val d = minOf(width, height).coerceAtLeast(1f)
    var x = (2.0 * p.x - width) / d
    var y = (height - 2.0 * p.y) / d
    val r2 = x * x + y * y
    val z: Double
    if (r2 <= 1.0) {
        z = sqrt(1.0 - r2)
    } else {
        val inv = 1.0 / sqrt(r2)
        x *= inv
        y *= inv
        z = 0.0
    }
    return Vec3(x, y, z)
}

private fun quatFromVectors(a0: Vec3, b0: Vec3): Quat {
    val a = normalizeVec(a0)
    val b = normalizeVec(b0)
    val dot = (a.x * b.x + a.y * b.y + a.z * b.z).coerceIn(-1.0, 1.0)
    if (dot < -0.999999) {
        val axis = if (abs(a.x) < 0.8) normalizeVec(Vec3(0.0, -a.z, a.y))
        else normalizeVec(Vec3(-a.y, a.x, 0.0))
        return axisAngleQuat(axis, PI)
    }
    val c = Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )
    return normalizeQuat(Quat(1.0 + dot, c.x, c.y, c.z))
}

private fun inertiaQuaternion(dx: Float, dy: Float, width: Float, height: Float): Quat {
    val d = minOf(width, height).coerceAtLeast(1f)
    val magnitude = sqrt(dx * dx + dy * dy)
    if (magnitude < 1.0e-4f) return Quat(1.0, 0.0, 0.0, 0.0)
    val axis = normalizeVec(Vec3(-dy.toDouble(), dx.toDouble(), 0.0))
    val angle = (magnitude / d * PI * 1.55).coerceAtMost(0.22)
    return axisAngleQuat(axis, angle)
}

private fun axisAngleQuat(axis: Vec3, angle: Double): Quat {
    val half = angle * 0.5
    val s = sin(half)
    return normalizeQuat(Quat(cos(half), axis.x * s, axis.y * s, axis.z * s))
}

private operator fun Quat.times(o: Quat): Quat = Quat(
    w * o.w - x * o.x - y * o.y - z * o.z,
    w * o.x + x * o.w + y * o.z - z * o.y,
    w * o.y - x * o.z + y * o.w + z * o.x,
    w * o.z + x * o.y - y * o.x + z * o.w
)

private fun normalizeQuat(q: Quat): Quat {
    val n = sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z)
    if (n < 1.0e-12) return Quat(1.0, 0.0, 0.0, 0.0)
    return Quat(q.w / n, q.x / n, q.y / n, q.z / n)
}

private fun normalizeVec(v: Vec3): Vec3 {
    val n = sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    if (n < 1.0e-12) return Vec3(0.0, 0.0, 1.0)
    return Vec3(v.x / n, v.y / n, v.z / n)
}

private fun rotate(v: Vec3, q0: Quat): Vec3 {
    val q = normalizeQuat(q0)
    val u = Vec3(q.x, q.y, q.z)
    val s = q.w
    val dotUV = u.x * v.x + u.y * v.y + u.z * v.z
    val dotUU = u.x * u.x + u.y * u.y + u.z * u.z
    val cross = Vec3(
        u.y * v.z - u.z * v.y,
        u.z * v.x - u.x * v.z,
        u.x * v.y - u.y * v.x
    )
    return Vec3(
        2.0 * dotUV * u.x + (s * s - dotUU) * v.x + 2.0 * s * cross.x,
        2.0 * dotUV * u.y + (s * s - dotUU) * v.y + 2.0 * s * cross.y,
        2.0 * dotUV * u.z + (s * s - dotUU) * v.z + 2.0 * s * cross.z
    )
}

private fun defaultOrientation(): Quat {
    val yaw = axisAngleQuat(Vec3(0.0, 1.0, 0.0), Math.toRadians(-35.0))
    val pitch = axisAngleQuat(Vec3(1.0, 0.0, 0.0), Math.toRadians(22.0))
    return normalizeQuat(pitch * yaw)
}

/**
 * Converts the MAA geometry canvas camera to the quaternion used by the radiation renderer.
 *
 * MaaGeometryCanvas first rotates the model around Z by yaw, then projects its vertical screen
 * coordinate as z*cos(pitch) - y'*sin(pitch).  The same orthographic view is obtained here by
 * Rz(yaw) followed by Rx(-(90° + pitch)).  Keeping this conversion in the renderer avoids any
 * change to NEC spherical coordinates (theta/phi) or to the radiation data itself.
 */
private fun geometryProjectionOrientation(yawDeg: Double, pitchDeg: Double): Quat {
    val yaw = axisAngleQuat(Vec3(0.0, 0.0, 1.0), Math.toRadians(yawDeg))
    val screenPitch = axisAngleQuat(Vec3(1.0, 0.0, 0.0), Math.toRadians(-(90.0 + pitchDeg)))
    return normalizeQuat(screenPitch * yaw)
}

private fun distance(a: Offset, b: Offset): Float {
    val dx = a.x - b.x
    val dy = a.y - b.y
    return sqrt(dx * dx + dy * dy)
}

private fun project(
    p: Pattern3DPoint,
    orientation: Quat,
    cx: Float,
    cy: Float,
    scale: Float,
    radiusScale: Radius3DScale
): Projected {
    val theta = Math.toRadians(p.thetaDeg)
    val phi = Math.toRadians(p.phiDeg)
    val db = p.db.coerceIn(MIN_DB_3D, 0.0)
    val radius = when (radiusScale) {
        Radius3DScale.LINEAR -> 10.0.pow(db / 20.0)
        Radius3DScale.DB -> ((db - MIN_DB_3D) / -MIN_DB_3D).coerceIn(0.0, 1.0)
    }
    return projectXYZ(
        Vec3(
            radius * sin(theta) * cos(phi),
            radius * sin(theta) * sin(phi),
            radius * cos(theta)
        ),
        orientation, cx, cy, scale, p.db
    )
}

private fun projectXYZ(v: Vec3, orientation: Quat, cx: Float, cy: Float, scale: Float, db: Double = 0.0): Projected {
    val r = rotate(v, orientation)
    return Projected(
        cx + (r.x * scale).toFloat(),
        cy - (r.y * scale).toFloat(),
        r.z,
        db
    )
}

private fun colorForDb(db: Double): Color {
    val t = ((db.coerceIn(MIN_DB_3D, 0.0) - MIN_DB_3D) / -MIN_DB_3D).toFloat()
    return when {
        t < .25f -> lerp(Color(0xFF143DFF), Color(0xFF00CFFF), t / .25f)
        t < .50f -> lerp(Color(0xFF00CFFF), Color(0xFF00E676), (t - .25f) / .25f)
        t < .75f -> lerp(Color(0xFF00E676), Color(0xFFFFE600), (t - .50f) / .25f)
        else -> lerp(Color(0xFFFFE600), Color(0xFFFF3B1F), (t - .75f) / .25f)
    }
}

private fun shade(c: Color, factor: Float): Color = Color(c.red * factor, c.green * factor, c.blue * factor, 1f)
private fun lerp(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = 1f
)

fun renderRadiation3DPng(points: List<Pattern3DPoint>, state: View3DState, width: Int = 1600, height: Int = 1600): Bitmap {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(AndroidColor.rgb(3, 26, 54))
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val cx = width * (0.5f + state.panX)
    val cy = height * (0.5f + state.panY)
    val scale = minOf(width, height) * .43f * state.zoom
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 2f
    paint.color = AndroidColor.rgb(22, 70, 111)
    for (r in listOf(.25f, .5f, .75f, 1f)) canvas.drawCircle(cx, cy, scale * r, paint)

    val mesh = buildMesh(points)
    val q = normalizeQuat(Quat(state.qW.toDouble(), state.qX.toDouble(), state.qY.toDouble(), state.qZ.toDouble()))
    val projected = mesh.vertices.map { project(it, q, cx, cy, scale, state.radiusScale) }
    when (state.mode) {
        Render3DMode.SURFACE -> {
            val render = mesh.triangles.map { t ->
                val a = projected[t.a]; val b = projected[t.b]; val c = projected[t.c]
                RenderTri(a, b, c, (a.z + b.z + c.z) / 3.0, (a.db + b.db + c.db) / 3.0)
            }.sortedBy { it.depth }
            paint.style = Paint.Style.FILL
            render.forEach { t ->
                paint.color = androidColorForDb(t.db, ((t.depth + 1.0) * .16 + .72).coerceIn(.72, 1.0).toFloat())
                val path = AndroidPath()
                path.moveTo(t.a.x, t.a.y)
                path.lineTo(t.b.x, t.b.y)
                path.lineTo(t.c.x, t.c.y)
                path.close()
                canvas.drawPath(path, paint)
            }
        }

        Render3DMode.WIREFRAME -> {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.1f
            mesh.triangles.forEach { t ->
                val a = projected[t.a]; val b = projected[t.b]; val c = projected[t.c]
                paint.color = androidColorForDb((a.db + b.db + c.db) / 3.0, .78f)
                val path = AndroidPath()
                path.moveTo(a.x, a.y)
                path.lineTo(b.x, b.y)
                path.lineTo(c.x, c.y)
                path.close()
                canvas.drawPath(path, paint)
            }
        }

        Render3DMode.VECTORS -> {
            val origin = projectXYZ(Vec3(0.0, 0.0, 0.0), q, cx, cy, scale)
            val step = vectorDisplayStep(projected.size)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f
            projected
                .asSequence()
                .filterIndexed { index, _ -> index % step == 0 }
                .sortedBy { it.z }
                .forEach { p ->
                    paint.color = androidColorForDb(p.db, .68f)
                    canvas.drawLine(origin.x, origin.y, p.x, p.y, paint)
                }
            paint.style = Paint.Style.FILL
            projected
                .asSequence()
                .filterIndexed { index, _ -> index % step == 0 }
                .forEach { p ->
                    paint.color = androidColorForDb(p.db, 1f)
                    canvas.drawCircle(p.x, p.y, 2.5f, paint)
                }
        }

        Render3DMode.POINTS -> {
            paint.style = Paint.Style.FILL
            projected.sortedBy { it.z }.forEach { p ->
                paint.color = androidColorForDb(p.db, 1f)
                canvas.drawCircle(p.x, p.y, 3.0f, paint)
            }
        }
    }
    return bitmap
}

private fun vectorDisplayStep(pointCount: Int, maxVectors: Int = 1400): Int {
    if (pointCount <= maxVectors) return 1
    return kotlin.math.ceil(pointCount.toDouble() / maxVectors.toDouble()).toInt().coerceAtLeast(1)
}

private fun androidColorForDb(db: Double, factor: Float): Int {
    val t = ((db.coerceIn(MIN_DB_3D, 0.0) - MIN_DB_3D) / -MIN_DB_3D).toFloat()
    val stops = arrayOf(
        floatArrayOf(20f, 61f, 255f), floatArrayOf(0f, 207f, 255f), floatArrayOf(0f, 230f, 118f),
        floatArrayOf(255f, 230f, 0f), floatArrayOf(255f, 59f, 31f)
    )
    val q = (t * 4f).coerceIn(0f, 4f)
    val i = q.toInt().coerceAtMost(3)
    val f = q - i
    val a = stops[i]; val b = stops[i + 1]
    return AndroidColor.rgb(
        ((a[0] + (b[0] - a[0]) * f) * factor).toInt().coerceIn(0, 255),
        ((a[1] + (b[1] - a[1]) * f) * factor).toInt().coerceIn(0, 255),
        ((a[2] + (b[2] - a[2]) * f) * factor).toInt().coerceIn(0, 255)
    )
}
