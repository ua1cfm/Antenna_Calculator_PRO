package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

object HamTools {
    const val C = 299792458.0
    const val K_B = 1.380649e-23
    const val E_CHARGE = 1.602176634e-19
    const val MU_0 = 1.25663706212e-6
    const val EPSILON_0 = 8.8541878128e-12
    const val Z_0 = 376.730313668
    const val T0 = 290.0

    fun dbmToW(dbm: Double) = 10.0.pow((dbm - 30.0) / 10.0)
    fun wToDbm(w: Double) = if (w > 0.0) 10.0 * log10(w * 1000.0) else Double.NEGATIVE_INFINITY
    fun dbToPowerRatio(db: Double) = 10.0.pow(db / 10.0)
    fun powerRatioToDb(ratio: Double) = if (ratio > 0.0) 10.0 * log10(ratio) else Double.NEGATIVE_INFINITY
    fun dbToVoltageRatio(db: Double) = 10.0.pow(db / 20.0)
    fun voltageRatioToDb(ratio: Double) = if (ratio > 0.0) 20.0 * log10(ratio) else Double.NEGATIVE_INFINITY

    fun wavelengthM(freqMHz: Double) = C / (freqMHz * 1e6)
    fun fsplDb(freqMHz: Double, distanceKm: Double): Double =
        32.4477832219 + 20.0 * log10(freqMHz) + 20.0 * log10(distanceKm)

    fun eirpDbm(txDbm: Double, gainDbi: Double, cableLossDb: Double) = txDbm + gainDbi - cableLossDb
    fun erpDbmFromEirp(eirpDbm: Double) = eirpDbm - 2.15

    fun vrmsFromW(w: Double, ohm: Double) = sqrt(w * ohm)
    fun wFromVrms(vrms: Double, ohm: Double) = vrms * vrms / ohm
    fun vPeakFromVrms(vrms: Double) = vrms * sqrt(2.0)
    fun vPpFromVrms(vrms: Double) = 2.0 * vPeakFromVrms(vrms)

    fun gammaFromSwr(swr: Double) = if (swr >= 1.0) (swr - 1.0) / (swr + 1.0) else Double.NaN
    fun swrFromGamma(gamma: Double) =
        if (gamma >= 0.0 && gamma < 1.0) (1.0 + gamma) / (1.0 - gamma) else Double.NaN
    fun returnLossDbFromGamma(gamma: Double) =
        if (gamma > 0.0 && gamma < 1.0) -20.0 * log10(gamma) else if (gamma == 0.0) Double.POSITIVE_INFINITY else Double.NaN
    fun mismatchLossDbFromGamma(gamma: Double) =
        if (gamma >= 0.0 && gamma < 1.0) -10.0 * log10(1.0 - gamma * gamma) else Double.NaN

    fun noisePowerW(bandwidthHz: Double, tempK: Double) = K_B * tempK * bandwidthHz
    fun noisePowerDbm(bandwidthHz: Double, tempK: Double) = wToDbm(noisePowerW(bandwidthHz, tempK))
    fun noiseFactorFromNfDb(nfDb: Double) = 10.0.pow(nfDb / 10.0)
    fun nfDbFromNoiseFactor(f: Double) = if (f > 0.0) 10.0 * log10(f) else Double.NaN
    fun noiseTemperatureKFromNfDb(nfDb: Double) = T0 * (noiseFactorFromNfDb(nfDb) - 1.0)

    fun skinDepthM(freqMHz: Double, conductivitySm: Double, muRelative: Double = 1.0): Double {
        val omega = 2.0 * PI * freqMHz * 1e6
        return sqrt(2.0 / (omega * MU_0 * muRelative * conductivitySm))
    }
}

data class HamBand(val name: String, val referenceMHz: Double)
val COMMON_HAM_BANDS = listOf(
    HamBand("160 m", 1.85), HamBand("80 m", 3.65), HamBand("40 m", 7.10),
    HamBand("30 m", 10.125), HamBand("20 m", 14.20), HamBand("17 m", 18.10),
    HamBand("15 m", 21.20), HamBand("12 m", 24.94), HamBand("10 m", 28.50),
    HamBand("6 m", 50.10), HamBand("2 m", 145.0), HamBand("70 cm", 435.0),
    HamBand("23 cm", 1296.0), HamBand("13 cm", 2320.0), HamBand("6 cm", 5760.0),
    HamBand("3 cm", 10368.0), HamBand("1.2 cm", 24048.0)
)
