package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Lightweight time-domain transform for VNA S11 sweeps.
 * Uses linear re-sampling to an equally spaced grid, Hann windowing and an in-place radix-2 IFFT.
 * The result is intended as a practical cable/fault locator, not as a calibrated laboratory TDR.
 */
data class TdrResult(
    val distanceM: List<Double>,
    val relativeDb: List<Double>,
    val peakIndex: Int,
    val peakDistanceM: Double,
    val peakRelativeDb: Double,
    val distanceResolutionM: Double,
    val unambiguousDistanceM: Double,
    val fftSize: Int,
    val frequencySpanHz: Double,
    val frequencyStepHz: Double
)

object TdrMath {
    const val C = 299792458.0

    fun fromS11(data: TouchstoneData, velocityFactor: Double): TdrResult? {
        if (data.points.size < 16) return null
        val vf = velocityFactor.coerceIn(0.05, 1.0)
        val pts = data.points.sortedBy { it.frequencyHz }
        val f0 = pts.first().frequencyHz
        val f1 = pts.last().frequencyHz
        val span = f1 - f0
        if (!span.isFinite() || span <= 0.0) return null

        val targetN = pts.size.coerceIn(256, 8192)
        val n = nextPowerOfTwo(targetN).coerceAtMost(8192)
        val df = span / n.toDouble()
        if (df <= 0.0) return null

        val re = DoubleArray(n)
        val im = DoubleArray(n)
        var src = 0
        for (k in 0 until n) {
            val f = f0 + k * df
            while (src + 1 < pts.lastIndex && pts[src + 1].frequencyHz < f) src++
            val a = pts[src]
            val b = pts[(src + 1).coerceAtMost(pts.lastIndex)]
            val denom = b.frequencyHz - a.frequencyHz
            val t = if (denom > 0.0) ((f - a.frequencyHz) / denom).coerceIn(0.0, 1.0) else 0.0
            val sr = a.s11.re + (b.s11.re - a.s11.re) * t
            val si = a.s11.im + (b.s11.im - a.s11.im) * t
            val w = if (n > 1) 0.5 - 0.5 * cos(2.0 * PI * k / (n - 1).toDouble()) else 1.0
            re[k] = sr * w
            im[k] = si * w
        }

        ifftInPlace(re, im)

        // Only the first half of the periodic IFFT is useful as the positive-distance display range.
        val count = n / 2
        val mags = DoubleArray(count)
        var maxMag = 1e-300
        for (i in 0 until count) {
            val m = kotlin.math.hypot(re[i], im[i])
            mags[i] = m
            if (m > maxMag) maxMag = m
        }
        val dt = 1.0 / (n * df)
        val distance = List(count) { i -> C * vf * (i * dt) / 2.0 }
        val db = List(count) { i ->
            val ratio = (mags[i] / maxMag).coerceAtLeast(1e-12)
            (20.0 * log10(ratio)).coerceAtLeast(-90.0)
        }

        // Ignore the launch/connector at t=0 when estimating the dominant remote reflection.
        val ignoreBins = max(2, min(12, count / 20))
        val peak = (ignoreBins until count).maxByOrNull { mags[it] } ?: 0
        val resolution = C * vf / (2.0 * span)
        val unambiguous = C * vf / (2.0 * df)
        return TdrResult(
            distanceM = distance,
            relativeDb = db,
            peakIndex = peak,
            peakDistanceM = distance[peak],
            peakRelativeDb = db[peak],
            distanceResolutionM = resolution,
            unambiguousDistanceM = unambiguous,
            fftSize = n,
            frequencySpanHz = span,
            frequencyStepHz = df
        )
    }

    private fun nextPowerOfTwo(v: Int): Int {
        var n = 1
        while (n < v && n < 8192) n = n shl 1
        return n
    }

    private fun ifftInPlace(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = 2.0 * PI / len.toDouble() // positive sign = inverse transform
            val wLenR = cos(ang)
            val wLenI = sin(ang)
            var i = 0
            while (i < n) {
                var wr = 1.0
                var wi = 0.0
                val half = len / 2
                for (k in 0 until half) {
                    val uR = re[i + k]
                    val uI = im[i + k]
                    val vR0 = re[i + k + half]
                    val vI0 = im[i + k + half]
                    val vR = vR0 * wr - vI0 * wi
                    val vI = vR0 * wi + vI0 * wr
                    re[i + k] = uR + vR
                    im[i + k] = uI + vI
                    re[i + k + half] = uR - vR
                    im[i + k + half] = uI - vI
                    val nextWr = wr * wLenR - wi * wLenI
                    wi = wr * wLenI + wi * wLenR
                    wr = nextWr
                }
                i += len
            }
            len = len shl 1
        }
        for (i in 0 until n) {
            re[i] /= n.toDouble()
            im[i] /= n.toDouble()
        }
    }
}
