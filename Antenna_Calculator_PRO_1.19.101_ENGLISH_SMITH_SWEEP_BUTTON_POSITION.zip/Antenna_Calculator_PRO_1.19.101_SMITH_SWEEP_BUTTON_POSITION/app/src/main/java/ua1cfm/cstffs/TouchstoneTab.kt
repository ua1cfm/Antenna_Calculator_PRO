package ua1cfm.cstffs

import android.graphics.Paint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.log10

private const val LITEVNA_USB_PERMISSION_ACTION = "ua1cfm.cstffs.action.LITEVNA_USB_PERMISSION"

private enum class LiteVnaRunMode { ONE_SHOT, CONTINUOUS }
private enum class LiteVnaCalibrationCapture { OPEN, SHORT, LOAD, THRU }

private data class BandResult(val lowHz: Double, val highHz: Double) {
    val widthHz: Double get() = highHz - lowHz
    val centerHz: Double get() = (highHz + lowHz) / 2.0
}

private enum class FilterKind { LOW_PASS, HIGH_PASS, BAND_PASS, BAND_STOP, FULL_SPAN, UNKNOWN }

private data class FilterCharacterization(
    val kind: FilterKind,
    val levelDb: Double,
    val peakDb: Double,
    val peakHz: Double,
    val thresholdDb: Double,
    val lowHz: Double?,
    val highHz: Double?
) {
    val bandwidthHz: Double? get() = if (lowHz != null && highHz != null) highHz - lowHz else null
    val centerHz: Double? get() = if (lowHz != null && highHz != null && lowHz > 0.0 && highHz > 0.0) kotlin.math.sqrt(lowHz * highHz) else null
    val q: Double? get() = if (bandwidthHz != null && bandwidthHz!! > 0.0 && centerHz != null) centerHz!! / bandwidthHz!! else null
}

private fun interpolateThresholdHz(f0: Double, y0: Double, f1: Double, y1: Double, threshold: Double): Double {
    if (!y0.isFinite() || !y1.isFinite() || kotlin.math.abs(y1 - y0) < 1e-15) return (f0 + f1) * 0.5
    val u = ((threshold - y0) / (y1 - y0)).coerceIn(0.0, 1.0)
    return f0 + (f1 - f0) * u
}

private fun characterizeFilter(data: TouchstoneData, levelDb: Double): FilterCharacterization? {
    if (data.ports < 2 || data.points.size < 3) return null
    val values = data.points.map { it.s21?.let(TouchstoneMath::db) ?: Double.NaN }
    val valid = values.indices.filter { values[it].isFinite() }
    if (valid.size < 3) return null

    val peakIndex = valid.maxByOrNull { values[it] } ?: return null
    val peakDb = values[peakIndex]
    val threshold = peakDb - levelDb.coerceAtLeast(0.01)
    val pass = values.map { it.isFinite() && it >= threshold }

    // If both sweep edges are in the passband but an interior region falls below the
    // selected level, characterize the deepest rejected region as a band-stop/notch.
    if (pass.first() && pass.last() && pass.indices.any { !pass[it] }) {
        val minIndex = valid.minByOrNull { values[it] } ?: peakIndex
        if (!pass[minIndex]) {
            var leftStop = minIndex
            while (leftStop > 0 && !pass[leftStop - 1]) leftStop--
            var rightStop = minIndex
            while (rightStop < pass.lastIndex && !pass[rightStop + 1]) rightStop++
            val lowHz = if (leftStop > 0) interpolateThresholdHz(
                data.points[leftStop - 1].frequencyHz, values[leftStop - 1],
                data.points[leftStop].frequencyHz, values[leftStop], threshold
            ) else null
            val highHz = if (rightStop < values.lastIndex) interpolateThresholdHz(
                data.points[rightStop].frequencyHz, values[rightStop],
                data.points[rightStop + 1].frequencyHz, values[rightStop + 1], threshold
            ) else null
            return FilterCharacterization(
                kind = FilterKind.BAND_STOP, levelDb = levelDb, peakDb = peakDb,
                peakHz = data.points[peakIndex].frequencyHz, thresholdDb = threshold,
                lowHz = lowHz, highHz = highHz
            )
        }
    }

    var left = peakIndex
    while (left > 0 && pass[left - 1]) left--
    var right = peakIndex
    while (right < values.lastIndex && pass[right + 1]) right++

    val touchesLow = left == 0
    val touchesHigh = right == values.lastIndex
    val lowHz = if (!touchesLow && left > 0) interpolateThresholdHz(
        data.points[left - 1].frequencyHz, values[left - 1],
        data.points[left].frequencyHz, values[left], threshold
    ) else null
    val highHz = if (!touchesHigh && right < values.lastIndex) interpolateThresholdHz(
        data.points[right].frequencyHz, values[right],
        data.points[right + 1].frequencyHz, values[right + 1], threshold
    ) else null

    val kind = when {
        lowHz != null && highHz != null -> FilterKind.BAND_PASS
        lowHz == null && highHz != null -> FilterKind.LOW_PASS
        lowHz != null && highHz == null -> FilterKind.HIGH_PASS
        lowHz == null && highHz == null -> FilterKind.FULL_SPAN
        else -> FilterKind.UNKNOWN
    }

    return FilterCharacterization(
        kind = kind, levelDb = levelDb, peakDb = peakDb, peakHz = data.points[peakIndex].frequencyHz,
        thresholdDb = threshold, lowHz = lowHz, highHz = highHz
    )
}

private fun filterKindLabel(kind: FilterKind): String = when (kind) {
    FilterKind.LOW_PASS -> "LOW-PASS"
    FilterKind.HIGH_PASS -> "HIGH-PASS"
    FilterKind.BAND_PASS -> "BAND-PASS"
    FilterKind.BAND_STOP -> "BAND-STOP / NOTCH"
    FilterKind.FULL_SPAN -> "PASSBAND > SWEEP"
    FilterKind.UNKNOWN -> "UNKNOWN"
}

@Composable
fun TouchstoneTab() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<TouchstoneData?>(null) }
    var fileName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Open a Touchstone .s1p or .s2p file") }
    var markers by remember { mutableStateOf(listOf(0, 0)) }
    var activeMarker by remember { mutableIntStateOf(0) }
    var focusedPlot by remember { mutableStateOf<String?>(null) }
    var livePlot by remember { mutableStateOf("S11") }
    var liveRawPoints by remember { mutableStateOf(false) }
    // 1.19.98: dedicated measured-antenna S1P → Smith + synchronized antenna sonification.
    var antennaS1pAudioMode by remember { mutableStateOf(false) }
    var audioSmithPosition by remember { mutableStateOf<Double?>(null) }
    var compareData by remember { mutableStateOf<TouchstoneData?>(null) }
    var compareName by remember { mutableStateOf("") }
    var exportCsv by remember { mutableStateOf("") }
    var exportS2p by remember { mutableStateOf("") }
    var s2pPassesText by remember { mutableStateOf("5") }
    var pendingS2pSaveName by remember { mutableStateOf("litevna_scan.s2p") }
    var usbStartMHz by remember { mutableStateOf("144") }
    var usbStopMHz by remember { mutableStateOf("146") }
    var usbPointsText by remember { mutableStateOf("201") }
    var usbAverageText by remember { mutableStateOf("4") }
    var filterLevelText by remember { mutableStateOf("3.0") }
    var usbBusy by remember { mutableStateOf(false) }
    var usbProgress by remember { mutableStateOf("") }
    var usbStatus by remember { mutableStateOf("LiteVNA not connected") }
    var usbDiagnostics by remember { mutableStateOf("") }
    var usbGrantedDevice by remember { mutableStateOf<UsbDevice?>(null) }
    var usbRunMode by remember { mutableStateOf<LiteVnaRunMode?>(null) }
    var calibrationPanelOpen by remember { mutableStateOf(false) }
    var calibrationEnabled by remember { mutableStateOf(false) }
    var pendingCalibrationCapture by remember { mutableStateOf<LiteVnaCalibrationCapture?>(null) }
    var calOpen by remember { mutableStateOf<TouchstoneData?>(null) }
    var calShort by remember { mutableStateOf<TouchstoneData?>(null) }
    var calLoad by remember { mutableStateOf<TouchstoneData?>(null) }
    var calThru by remember { mutableStateOf<TouchstoneData?>(null) }
    val usbManager = remember(context) { LiteVnaUsb.manager(context) }
    val liveState by LiteVnaLiveController.state.collectAsState()
    val captureState by LiteVnaLiveController.captureState.collectAsState()
    var lastLiveSweepSeen by remember { mutableStateOf(0L) }


    // The controller already publishes a throttled immutable LIVE snapshot. Do NOT copy every
    // frame into a second mutable Compose state: that caused two full recompositions per frame.
    // This effect only maintains marker bounds and one-time UI metadata.
    LaunchedEffect(liveState.sweepNumber) {
        val liveData = liveState.data ?: return@LaunchedEffect
        if (liveState.sweepNumber <= 0L || liveState.sweepNumber == lastLiveSweepSeen) return@LaunchedEffect

        val firstVisibleLiveSweep = lastLiveSweepSeen == 0L || fileName != "LiteVNA USB LIVE"
        fileName = "LiteVNA USB LIVE"
        if (firstVisibleLiveSweep) {
            markers = listOf(0, 0)
            activeMarker = 0
            compareData = null
        } else {
            markers = markers.map { it.coerceIn(0, liveData.points.lastIndex) }
        }
        lastLiveSweepSeen = liveState.sweepNumber
        status = "LiteVNA LIVE: sweep #${liveState.sweepNumber} • UI ≤ 1 Hz • ${liveData.points.size} points"
    }

    val usbPermissionReceiver = remember {
        object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != LITEVNA_USB_PERMISSION_ACTION) return
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                @Suppress("DEPRECATION")
                val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                } else {
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                }
                if (granted && device != null) {
                    usbStatus = "USB permission granted: ${LiteVnaUsb.deviceLabel(device)}"
                    usbGrantedDevice = device
                } else {
                    usbStatus = "USB access denied"
                    usbRunMode = null
                    usbGrantedDevice = null
                }
            }
        }
    }

    DisposableEffect(context, usbPermissionReceiver) {
        val filter = IntentFilter(LITEVNA_USB_PERMISSION_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(usbPermissionReceiver, filter)
        }
        onDispose { runCatching { context.unregisterReceiver(usbPermissionReceiver) } }
    }

    LaunchedEffect(usbGrantedDevice, usbRunMode) {
        val device = usbGrantedDevice ?: return@LaunchedEffect
        val mode = usbRunMode ?: return@LaunchedEffect
        val startMHz = usbStartMHz.replace(',', '.').toDoubleOrNull()
        val stopMHz = usbStopMHz.replace(',', '.').toDoubleOrNull()
        val points = usbPointsText.toIntOrNull()
        if (startMHz == null || stopMHz == null || points == null) {
            usbStatus = "Check START, STOP, and point count"
            usbRunMode = null
            usbGrantedDevice = null
            return@LaunchedEffect
        }
        val cfgResult = runCatching {
            LiteVnaProtocol.SweepConfig(
                startHz = (startMHz * 1e6).toLong(),
                stopHz = (stopMHz * 1e6).toLong(),
                points = points,
                average = usbAverageText.toIntOrNull() ?: 4
            )
        }
        val cfg = cfgResult.getOrElse {
            usbStatus = "Sweep parameter error: ${it.message}"
            usbRunMode = null
            usbGrantedDevice = null
            return@LaunchedEffect
        }

        usbBusy = true
        usbProgress = "0/${cfg.points}"

        if (mode == LiteVnaRunMode.ONE_SHOT) {
            usbStatus = "LiteVNA: checking communication and reading one sweep…"
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    LiteVnaUsb.measure(usbManager, device, cfg) { done, total ->
                        scope.launch { usbProgress = "$done/$total" }
                    }
                }
            }
            result.onSuccess { measurement ->
                val capture = pendingCalibrationCapture
                if (capture != null) {
                    when (capture) {
                        LiteVnaCalibrationCapture.OPEN -> calOpen = measurement.data
                        LiteVnaCalibrationCapture.SHORT -> calShort = measurement.data
                        LiteVnaCalibrationCapture.LOAD -> calLoad = measurement.data
                        LiteVnaCalibrationCapture.THRU -> calThru = measurement.data
                    }
                    pendingCalibrationCapture = null
                    calibrationEnabled = calOpen != null && calShort != null && calLoad != null
                    data = measurement.data
                    fileName = "LiteVNA USB RAW"
                    status = "Calibration ${capture.name}: captured ${measurement.data.points.size} points"
                    usbStatus = "${capture.name} captured • ${measurement.info.shortText}"
                } else {
                    data = measurement.data
                    fileName = "LiteVNA USB RAW"
                    val m = TouchstoneMath.summarize(measurement.data).minS11Index
                    markers = listOf(m, m)
                    activeMarker = 0
                    focusedPlot = null
                    compareData = null
                    status = "LiteVNA USB: ${measurement.data.points.size} points"
                    usbStatus = "Connected: ${measurement.info.shortText}"
                }
                usbProgress = "Done: ${measurement.data.points.size}/${measurement.data.points.size}"
            }.onFailure { e ->
                pendingCalibrationCapture = null
                usbStatus = "LiteVNA USB: ${e.message ?: e::class.simpleName}"
            }
            usbBusy = false
            if (usbRunMode == LiteVnaRunMode.ONE_SHOT) usbRunMode = null
            usbGrantedDevice = null
            return@LaunchedEffect
        }

        // Continuous mode must NOT live in this LaunchedEffect: it would be cancelled when
        // TouchstoneTab leaves composition. Hand ownership to the process-level controller.
        usbBusy = false
        usbStatus = "LiteVNA LIVE: handing the USB session to the background controller…"
        LiteVnaLiveController.start(context.applicationContext, device, cfg)
        usbRunMode = null
        usbGrantedDevice = null
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull() ?: "Touchstone"

            status = "Reading $name..."
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            BufferedReader(InputStreamReader(input), 128 * 1024).use { reader ->
                                TouchstoneParser.parse(reader, name)
                            }
                        } ?: error("Failed to open file.")
                    }
                }
                result.onSuccess {
                    data = it
                    fileName = name
                    antennaS1pAudioMode = false
                    audioSmithPosition = null
                    val m = TouchstoneMath.summarize(it).minS11Index
                    markers = listOf(m, m)
                    activeMarker = 0
                    focusedPlot = null
                    status = "Done: ${it.points.size} points, ${it.ports} port(s)"
                }.onFailure {
                    data = null
                    status = "Error: ${it.message}"
                }
            }
        }
    }

    val antennaS1pLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull() ?: "antenna.s1p"

            status = "Reading measured antenna S1P: $name..."
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            BufferedReader(InputStreamReader(input), 128 * 1024).use { reader ->
                                TouchstoneParser.parse(reader, name)
                            }
                        } ?: error("Failed to open S1P file.")
                    }
                }
                result.onSuccess { loaded ->
                    if (loaded.ports != 1) {
                        status = "Antenna Audio Smith requires a 1-port S1P file. Use Open S1P / S2P for this file."
                        antennaS1pAudioMode = false
                        audioSmithPosition = null
                    } else {
                        data = loaded
                        fileName = name
                        val m = TouchstoneMath.summarize(loaded).minS11Index
                        markers = listOf(m, m)
                        activeMarker = 0
                        compareData = null
                        focusedPlot = "SMITH"
                        antennaS1pAudioMode = true
                        audioSmithPosition = null
                        status = "ANTENNA S1P AUDIO SMITH: ${loaded.points.size} measured points • ready"
                    }
                }.onFailure {
                    status = "S1P error: ${it.message}"
                    antennaS1pAudioMode = false
                    audioSmithPosition = null
                }
            }
        }
    }

    val compareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val name = runCatching { context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "Compare"
            val result = withContext(Dispatchers.IO) { runCatching { context.contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input), 128 * 1024).use { TouchstoneParser.parse(it, name) } } ?: error("Failed to open comparison file") } }
            result.onSuccess { compareData = it; compareName = name; status = "Comparison loaded: $name" }.onFailure { status = "Comparison error: ${it.message}" }
        }
    }
    val saveCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null && exportCsv.isNotEmpty()) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportCsv) } }.onSuccess { status = "CSV saved" }.onFailure { status = "CSV error: ${it.message}" }
    }
    val saveS2pLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null && exportS2p.isNotEmpty()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer -> writer.write(exportS2p) }
                    ?: error("Failed to open destination file")
            }.onSuccess {
                status = "S2P saved: ${captureState.completedPasses.coerceAtLeast(1)} pass(es)"
                exportS2p = ""
                LiteVnaLiveController.clearS2pCaptureResult()
            }.onFailure {
                status = "S2P save error: ${it.message}"
            }
        }
    }


    LaunchedEffect(captureState.result) {
        val rawCapture = captureState.result ?: return@LaunchedEffect
        val calibratedCapture = if (calibrationEnabled) {
            LiteVnaCalibrationMath.applyOrRaw(rawCapture, calOpen, calShort, calLoad, calThru)
        } else rawCapture
        exportS2p = buildLiteVnaS2p(calibratedCapture, captureState.completedPasses)
        pendingS2pSaveName = "litevna_${tsFileFreq(rawCapture.points.first().frequencyHz)}_${tsFileFreq(rawCapture.points.last().frequencyHz)}_${captureState.completedPasses}avg.s2p"
        status = "S2P capture ready: ${captureState.completedPasses}/${captureState.targetPasses} complete sweeps"
        saveS2pLauncher.launch(pendingS2pSaveName)
    }

    fun requestLiteVnaRun(mode: LiteVnaRunMode) {
        val start = usbStartMHz.replace(',', '.').toDoubleOrNull()
        val stop = usbStopMHz.replace(',', '.').toDoubleOrNull()
        val pts = usbPointsText.toIntOrNull()
        val valid = runCatching {
            require(start != null && stop != null && pts != null)
            LiteVnaProtocol.SweepConfig((start * 1e6).toLong(), (stop * 1e6).toLong(), pts, usbAverageText.toIntOrNull() ?: 4)
        }.getOrNull()
        if (valid == null) {
            usbStatus = "Check range: 0.05…6300 MHz, STOP>START, points 2…65535, average 1…80"
            return
        }

        val scan = LiteVnaUsb.scan(usbManager)
        val device = scan.device
        usbDiagnostics = scan.details
        if (device == null) {
            usbStatus = scan.message
            return
        }

        usbRunMode = mode
        if (usbManager.hasPermission(device)) {
            usbStatus = scan.message
            usbGrantedDevice = device
        } else {
            val permissionIntent = PendingIntent.getBroadcast(
                context,
                27,
                Intent(LITEVNA_USB_PERMISSION_ACTION).setPackage(context.packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            usbStatus = "Requesting Android permission for ${LiteVnaUsb.deviceLabel(device)}"
            usbManager.requestPermission(device, permissionIntent)
        }
    }

    fun captureCalibrationStandard(standard: LiteVnaCalibrationCapture) {
        if (liveState.running || liveState.starting || usbBusy) {
            usbStatus = "Stop LIVE before capturing a calibration standard"
            return
        }
        pendingCalibrationCapture = standard
        usbStatus = "Connect ${standard.name} standard, then measuring…"
        requestLiteVnaRun(LiteVnaRunMode.ONE_SHOT)
    }

    val calibrationReady = calOpen != null && calShort != null && calLoad != null

    val liveBusy = liveState.running || liveState.starting
    val anyUsbBusy = usbBusy || liveBusy
    val displayedUsbStatus = when {
        usbBusy -> usbStatus
        liveState.error != null -> "${liveState.status}: ${liveState.error}"
        liveBusy -> liveState.deviceInfo?.let { "${liveState.status} • ${it.shortText}" } ?: liveState.status
        liveState.sweepNumber > 0L && fileName == "LiteVNA USB LIVE" -> liveState.deviceInfo?.let { "${liveState.status} • ${it.shortText}" } ?: liveState.status
        else -> usbStatus
    }
    val displayedUsbProgress = when {
        usbBusy -> usbProgress
        liveBusy || (liveState.sweepNumber > 0L && fileName == "LiteVNA USB LIVE") ->
            if (liveState.progressTotal > 0) "${liveState.progressDone}/${liveState.progressTotal}" else usbProgress
        else -> usbProgress
    }

    Text("VNA PRO / Touchstone Analyzer", style = MaterialTheme.typography.titleLarge)
    Text(if (liveState.running || liveState.starting) "LIVE LIGHT: S11 • S21 • SWR • Smith" else "M1–M2 • S11/S21/S12/S22 • Smith")

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("LiteVNA64 USB", style = MaterialTheme.typography.titleMedium)
            Text("Direct phone connection via USB OTG/Host. LIVE S11 + S21 with hardware Average/IFBW control; FAST/NORMAL/LOW NOISE presets write LiteVNA register 0x40 directly.", style = MaterialTheme.typography.bodySmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = usbStartMHz,
                    onValueChange = { usbStartMHz = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(12) },
                    label = { Text("START MHz") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    enabled = !anyUsbBusy
                )
                OutlinedTextField(
                    value = usbStopMHz,
                    onValueChange = { usbStopMHz = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(12) },
                    label = { Text("STOP MHz") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    enabled = !anyUsbBusy
                )
            }
            OutlinedTextField(
                value = usbPointsText,
                onValueChange = { usbPointsText = it.filter(Char::isDigit).take(5) },
                label = { Text("Sweep points") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                enabled = !anyUsbBusy
            )
            OutlinedTextField(
                value = usbAverageText,
                onValueChange = { usbAverageText = it.filter(Char::isDigit).take(2) },
                label = { Text("Average / IFBW multiplier (1…80)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                enabled = !anyUsbBusy
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !anyUsbBusy,
                    onClick = { usbAverageText = "1" }
                ) { Text("FAST ×1", maxLines = 1) }
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !anyUsbBusy,
                    onClick = { usbAverageText = "4" }
                ) { Text("NORMAL ×4", maxLines = 1) }
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !anyUsbBusy,
                    onClick = { usbAverageText = "16" }
                ) { Text("LOW NOISE ×16", maxLines = 1) }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !anyUsbBusy,
                    onClick = { requestLiteVnaRun(LiteVnaRunMode.ONE_SHOT) }
                ) { Text("ONE SWEEP", maxLines = 1) }

                Button(
                    modifier = Modifier.weight(1f),
                    enabled = liveBusy || !anyUsbBusy,
                    onClick = {
                        if (liveBusy) {
                            LiteVnaLiveController.stop()
                        } else {
                            requestLiteVnaRun(LiteVnaRunMode.CONTINUOUS)
                        }
                    }
                ) {
                    Text(
                        when {
                            liveBusy -> "■ STOP LIVE"
                            anyUsbBusy -> "STOPPING…"
                            else -> "▶ LIVE SWEEP"
                        },
                        maxLines = 1
                    )
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = s2pPassesText,
                    onValueChange = { s2pPassesText = it.filter(Char::isDigit).take(3) },
                    label = { Text("S2P avg passes") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    enabled = !captureState.active
                )
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = liveState.running && !captureState.active,
                    onClick = {
                        val n = s2pPassesText.toIntOrNull()
                        if (n == null || n !in 1..100) {
                            status = "S2P averaging passes must be 1…100"
                        } else if (LiteVnaLiveController.beginS2pCapture(n)) {
                            status = "S2P capture started: waiting for $n complete LIVE sweeps"
                        }
                    }
                ) { Text("SAVE S2P", maxLines = 1) }
            }
            if (captureState.active) {
                LinearProgressIndicator(
                    progress = { if (captureState.targetPasses > 0) captureState.completedPasses.toFloat() / captureState.targetPasses.toFloat() else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "S2P averaging: ${captureState.completedPasses}/${captureState.targetPasses} complete sweeps",
                    style = MaterialTheme.typography.bodySmall
                )
            } else if (captureState.error != null) {
                Text(captureState.error ?: "", style = MaterialTheme.typography.bodySmall)
            }

            if (anyUsbBusy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(displayedUsbProgress, style = MaterialTheme.typography.bodySmall)
            }
            Text(displayedUsbStatus, style = MaterialTheme.typography.bodySmall)
            if (usbDiagnostics.isNotBlank()) {
                Text("USB diagnostics:\n$usbDiagnostics", style = MaterialTheme.typography.bodySmall)
            }
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = !anyUsbBusy,
                onClick = { calibrationPanelOpen = !calibrationPanelOpen }
            ) {
                Text(if (calibrationPanelOpen) "HIDE CALIBRATION" else "CALIBRATION", maxLines = 1)
            }
            if (calibrationPanelOpen) {
                Text("OSL one-port calibration corrects S11. THRU additionally normalizes S21. Use the same START/STOP/points for all standards and measurements.", style = MaterialTheme.typography.bodySmall)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(modifier = Modifier.weight(1f), enabled = !anyUsbBusy, onClick = { captureCalibrationStandard(LiteVnaCalibrationCapture.OPEN) }) { Text(if (calOpen != null) "OPEN ✓" else "OPEN", maxLines = 1) }
                    Button(modifier = Modifier.weight(1f), enabled = !anyUsbBusy, onClick = { captureCalibrationStandard(LiteVnaCalibrationCapture.SHORT) }) { Text(if (calShort != null) "SHORT ✓" else "SHORT", maxLines = 1) }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(modifier = Modifier.weight(1f), enabled = !anyUsbBusy, onClick = { captureCalibrationStandard(LiteVnaCalibrationCapture.LOAD) }) { Text(if (calLoad != null) "LOAD ✓" else "LOAD", maxLines = 1) }
                    Button(modifier = Modifier.weight(1f), enabled = !anyUsbBusy, onClick = { captureCalibrationStandard(LiteVnaCalibrationCapture.THRU) }) { Text(if (calThru != null) "THRU ✓" else "THRU", maxLines = 1) }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        modifier = Modifier.weight(1f),
                        enabled = calibrationReady,
                        onClick = { calibrationEnabled = !calibrationEnabled }
                    ) { Text(if (calibrationEnabled) "CAL ON ✓" else "APPLY CAL", maxLines = 1) }
                    Button(
                        modifier = Modifier.weight(1f),
                        enabled = !anyUsbBusy,
                        onClick = {
                            calOpen = null; calShort = null; calLoad = null; calThru = null
                            calibrationEnabled = false; pendingCalibrationCapture = null
                            usbStatus = "In-app calibration cleared"
                        }
                    ) { Text("CLEAR CAL", maxLines = 1) }
                }
                Text(
                    when {
                        calibrationEnabled -> "Calibration ACTIVE: OSL S11" + if (calThru != null) " + THRU S21" else ""
                        calibrationReady -> "OSL captured. Tap APPLY CAL."
                        else -> "Capture OPEN, SHORT and LOAD to enable S11 calibration."
                    },
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text("USB FIFO provides RAW wave-ratio data; the optional in-app OSL/THRU calibration above is applied to displayed and exported LiteVNA measurements.", style = MaterialTheme.typography.bodySmall)
        }
    }

    Button(
        modifier = Modifier.fillMaxWidth(),
        onClick = { launcher.launch(arrayOf("*/*")) }
    ) { Text("Open S1P / S2P", maxLines = 1) }

    Button(
        modifier = Modifier.fillMaxWidth(),
        onClick = { antennaS1pLauncher.launch(arrayOf("*/*")) }
    ) { Text("OPEN ANTENNA S1P • AUDIO SMITH", maxLines = 1) }

    Text(status, style = MaterialTheme.typography.bodyMedium)

    // LIVE data is read directly from the controller's throttled immutable snapshot. File and
    // one-shot measurements continue to use the local data state.
    val isLiveData = fileName == "LiteVNA USB LIVE" && liveState.data != null
    val rawDisplayedData = if (isLiveData) {
        liveState.data!!
    } else {
        data ?: return
    }
    val isLiteVnaMeasurement = isLiveData || fileName == "LiteVNA USB RAW"
    val d = remember(rawDisplayedData, calibrationEnabled, calOpen, calShort, calLoad, calThru, isLiteVnaMeasurement) {
        if (calibrationEnabled && isLiteVnaMeasurement) {
            LiteVnaCalibrationMath.applyOrRaw(rawDisplayedData, calOpen, calShort, calLoad, calThru)
        } else rawDisplayedData
    }

    val filterLevelDb = filterLevelText.replace(',', '.').toDoubleOrNull()?.coerceIn(0.1, 60.0) ?: 3.0

    // 1.19.41: LIVE uses exactly ONE visible Canvas at a time.  The previous long page kept
    // S11 + S21 + VSWR + Smith active together; when the Smith chart became visible near the
    // bottom of the scroll, UI rendering could starve publication of subsequent LIVE frames.
    // Acquisition remains independent in LiteVnaLiveController; this branch keeps the UI cheap.
    if (isLiveData) {
        LiveLiteVnaSinglePlot(
            data = d,
            sweepNumber = liveState.sweepNumber,
            selectedPlot = livePlot,
            onSelectPlot = { livePlot = it },
            filterLevelText = filterLevelText,
            onFilterLevelTextChange = { filterLevelText = it },
            filterLevelDb = filterLevelDb,
            rawPoints = liveRawPoints,
            onRawPointsChange = { liveRawPoints = it }
        )
        return
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(modifier = Modifier.weight(1f), onClick = { compareLauncher.launch(arrayOf("*/*")) }) { Text("Compare", maxLines = 1) }
        Button(modifier = Modifier.weight(1f), onClick = {
            exportCsv = buildTouchstoneCsv(d)
            saveCsvLauncher.launch("touchstone_export.csv")
        }) { Text("CSV", maxLines = 1) }
    }
    val summary = remember(d) { TouchstoneMath.summarize(d) }
    val band10 = remember(d) { thresholdBand(d, -10.0) }
    val band3 = remember(d) { thresholdBand(d, -3.0) }
    fun updateActiveMarker(index: Int) {
        val safe = index.coerceIn(0, d.points.lastIndex)
        markers = markers.mapIndexed { i, old -> if (i == activeMarker) safe else old.coerceIn(0, d.points.lastIndex) }
    }
    val safeMarkers = markers.map { it.coerceIn(0, d.points.lastIndex) }
    val markerIndex = safeMarkers[activeMarker.coerceIn(0, 1)]
    val freqs = d.points.map { it.frequencyHz }
    val phaseS11 = remember(d, isLiveData) { if (isLiveData) emptyList() else unwrapPhase(d.points.map { TouchstoneMath.phaseDeg(it.s11) }) }
    val phaseS21 = remember(d, isLiveData) { if (isLiveData) emptyList() else unwrapPhase(d.points.map { it.s21?.let(TouchstoneMath::phaseDeg) ?: Double.NaN }) }
    val groupDelayNs = remember(d, isLiveData) { if (isLiveData) emptyList() else groupDelayNs(d.points.map { it.frequencyHz }, phaseS21) }
    val qEstimate = remember(d, band3) { band3?.takeIf { it.widthHz > 0.0 }?.let { it.centerHz / it.widthHz } }

    compareData?.let { cd ->
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Measurement comparison", style = MaterialTheme.typography.titleMedium)
                Text("A: $fileName")
                Text("B: $compareName")
                if (cd.points.size == d.points.size) {
                    val delta = TouchstoneMath.db(d.points[markerIndex].s11) - TouchstoneMath.db(cd.points[markerIndex.coerceAtMost(cd.points.lastIndex)].s11)
                    Text("M1: ΔS11(A−B) = ${tsFmt(delta, 2)} dB")
                } else Text("Grids differ: marker comparison by index is disabled.")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(fileName, style = MaterialTheme.typography.titleMedium)
            Text("${if (d.ports == 1) "S1P" else "S2P"} • ${d.format} • Z₀ = ${tsFmt(d.referenceOhm, 3)} Ω")
            Text("Range: ${tsFreq(d.points.first().frequencyHz)} … ${tsFreq(d.points.last().frequencyHz)}")
            Text("Points: ${d.points.size}")
        }
    }

    // 1.19.98: measured antenna S1P can use the SAME 8-mode antenna audio engine as
    // the NEC Smith sweep. S11 is converted to Z using the file's own reference impedance.
    // No solver/acquisition data are modified.
    val measuredAntennaSweep = remember(d, antennaS1pAudioMode) {
        if (antennaS1pAudioMode && d.ports == 1) {
            d.points.mapNotNull { p ->
                val z = TouchstoneMath.impedance(p.s11, d.referenceOhm)
                if (p.frequencyHz.isFinite() && z.re.isFinite() && z.im.isFinite()) {
                    OpenNecFull.SweepPoint(
                        frequencyMHz = p.frequencyHz / 1.0e6,
                        inputs = listOf(OpenNecFull.InputImpedance(1, 1, z.re, z.im))
                    )
                } else null
            }
        } else emptyList()
    }

    if (antennaS1pAudioMode && d.ports == 1) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("MEASURED ANTENNA S1P • AUDIO SMITH", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Measured S11 → Z → Smith. Audio playback and the moving Smith marker are synchronized to the same sweep position.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        AntennaSonificationCard(
            sweepPoints = measuredAntennaSweep,
            z0Ohm = d.referenceOhm,
            sweepRunning = false,
            onSweepAudioPosition = { audioSmithPosition = it }
        )
    } else {
        // 1.19.52 generic Touchstone complex I/Q sonification remains available unchanged.
        RfSonificationCard(d)
    }

    if (!isLiveData) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Automatic analysis", style = MaterialTheme.typography.titleMedium)
                Text("Minimum S11: ${tsFmt(summary.minS11Db, 2)} dB @ ${tsFreq(summary.minS11FrequencyHz)}")
                Text("SWR at minimum: ${tsFinite(summary.minVswr, 3)}")
                Text("Z at minimum: ${tsComplex(summary.minImpedance)} Ω")
                BandLine("S11 ≤ −10 dB bandwidth", band10)
                BandLine("S11 ≤ −3 dB bandwidth", band3)
                qEstimate?.let { Text("Estimated loaded Q from −3 dB bandwidth ≈ ${tsFmt(it, 2)}") }
                if (summary.maxS21Db != null && summary.maxS21FrequencyHz != null) {
                    Text("Maximum S21: ${tsFmt(summary.maxS21Db, 2)} dB @ ${tsFreq(summary.maxS21FrequencyHz)}")
                }
            }
        }
    }

    if (d.ports == 2 && d.points.any { it.s21 != null }) {
        val filter = remember(d, filterLevelDb) { characterizeFilter(d, filterLevelDb) }
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Automatic filter characterization", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = filterLevelText,
                    onValueChange = { filterLevelText = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(6) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Level below S21 peak, dB") },
                    singleLine = true
                )
                filter?.let { f ->
                    Text("${filterKindLabel(f.kind)}   •   peak ${tsFmt(f.peakDb, 2)} dB @ ${tsFreq(f.peakHz)}   •   ILmin ${tsFmt((-f.peakDb).coerceAtLeast(0.0), 2)} dB")
                    Text("Threshold: peak − ${tsFmt(f.levelDb, 2)} dB = ${tsFmt(f.thresholdDb, 2)} dB")
                    f.lowHz?.let { Text("fL = ${tsFreq(it)}") }
                    f.highHz?.let { Text("fH = ${tsFreq(it)}") }
                    f.bandwidthHz?.let { bw ->
                        Text("BW = ${tsSignedFreqSpan(bw)}" + (f.centerHz?.let { c -> "   •   f0 = ${tsFreq(c)}" } ?: ""))
                    }
                    f.q?.let { Text("Loaded Q ≈ ${tsFmt(it, 3)}") }
                    if (f.kind == FilterKind.FULL_SPAN) Text("The selected level is not crossed inside the current sweep; widen the frequency span.")
                } ?: Text("S21 data are insufficient for automatic characterization.")
            }
        }
    }

    // LIVE diagnostic/lightweight mode: do not compose the marker panel at all.
    // Marker UI and marker overlays remain available for file/one-shot measurements.
    if (!isLiveData) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Markers M1–M2", style = MaterialTheme.typography.titleMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..1).forEach { mi ->
                        Button(modifier = Modifier.weight(1f), onClick = { activeMarker = mi }) {
                            Text(if (activeMarker == mi) "● M${mi + 1}" else "M${mi + 1}", maxLines = 1)
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(modifier = Modifier.weight(1f), onClick = { updateActiveMarker(summary.minS11Index) }) { Text("MIN S11", maxLines = 1) }
                    Button(modifier = Modifier.weight(1f), onClick = {
                        val idx = d.points.indices.maxByOrNull { i -> d.points[i].s21?.let(TouchstoneMath::db) ?: Double.NEGATIVE_INFINITY } ?: markerIndex
                        updateActiveMarker(idx)
                    }) { Text("MAX S21", maxLines = 1) }
                }
                val activeP = d.points[markerIndex]
                val activeZ = TouchstoneMath.impedance(activeP.s11, d.referenceOhm)
                val activeS11Db = TouchstoneMath.db(activeP.s11)
                Text("M${activeMarker + 1}: f = ${tsFreq(activeP.frequencyHz)}")
                Text("S11 = ${tsFmt(activeS11Db, 2)} dB   ∠${tsFmt(TouchstoneMath.phaseDeg(activeP.s11), 1)}°")
                Text("RL = ${tsFmt(-activeS11Db, 2)} dB   SWR = ${tsFinite(TouchstoneMath.vswr(activeP.s11), 3)}")
                Text("Z = ${tsComplex(activeZ)} Ω   |Γ| = ${tsFmt(activeP.s11.mag, 5)}")
                Text("R = ${tsFinite(activeZ.re, 2)} Ω   •   X = ${tsSignedOhm(activeZ.im)}   •   ${tsEquivalentReactiveComponent(activeZ.im, activeP.frequencyHz)}")
                activeP.s21?.let { Text("S21 = ${tsFmt(TouchstoneMath.db(it), 2)} dB   ∠${tsFmt(TouchstoneMath.phaseDeg(it), 1)}°") }
                if (markerIndex in groupDelayNs.indices && groupDelayNs[markerIndex].isFinite()) Text("Group Delay S21 ≈ ${tsFmt(groupDelayNs[markerIndex], 3)} ns")
                if (safeMarkers[0] != safeMarkers[1]) {
                    val p1 = d.points[safeMarkers[0]]
                    val p2 = d.points[safeMarkers[1]]
                    Text("Δ(M2−M1): Δf = ${tsSignedFreqSpan(p2.frequencyHz - p1.frequencyHz)}   ΔS11 = ${tsFmt(TouchstoneMath.db(p2.s11) - TouchstoneMath.db(p1.s11), 2)} dB")
                    if (p1.s21 != null && p2.s21 != null) Text("ΔS21 = ${tsFmt(TouchstoneMath.db(p2.s21) - TouchstoneMath.db(p1.s21), 2)} dB")
                } else {
                    Text("Δ-marker: set M1 and M2 to different points.")
                }
            }
        }
    }

    // 1.19.40: automatic resonance search and Cable Analyzer/TDR are temporarily disabled.
    // In LIVE mode they are not calculated and do not create Compose/FFT load.

    if (liveState.sweepNumber > 0L && fileName == "LiteVNA USB LIVE") {
        Text(
            "● LIVE plots • UI ≤ 1 Hz • sweep #${liveState.sweepNumber}",
            style = MaterialTheme.typography.titleMedium
        )
    }

    val audioPlotPosition = if (antennaS1pAudioMode) audioSmithPosition else null

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(modifier = Modifier.weight(1f), onClick = { focusedPlot = if (focusedPlot == "S11") null else "S11" }) {
            Text(if (focusedPlot == "S11") "All plots" else "Large S11", maxLines = 1)
        }
        Button(modifier = Modifier.weight(1f), onClick = { focusedPlot = if (focusedPlot == "SMITH") null else "SMITH" }) {
            Text(if (focusedPlot == "SMITH") "All plots" else "Large Smith", maxLines = 1)
        }
    }

    compareData?.takeIf { it.points.size == d.points.size }?.let { cd ->
        Text("ΔS11: A − B", style = MaterialTheme.typography.titleMedium)
        TouchstoneLinePlot(freqs, d.points.indices.map { i -> TouchstoneMath.db(d.points[i].s11) - TouchstoneMath.db(cd.points[i].s11) }, markerIndex, "dB", showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
    }

    Text("S11 / Return Loss", style = MaterialTheme.typography.titleMedium)
    TouchstoneLinePlot(
        frequencies = freqs,
        values = d.points.map { TouchstoneMath.db(it.s11) },
        markerIndex = markerIndex,
        markerIndices = safeMarkers,
        activeMarker = activeMarker,
        yUnit = "dB",
        preferredTop = 0.0,
        threshold = -10.0,
        chartHeightDp = if (focusedPlot == "S11") 520 else 300,
        showMarkers = !isLiveData,
        audioPosition = audioPlotPosition,
        onMarker = { updateActiveMarker(it) }
    )

    if (d.ports == 2 && d.points.any { it.s21 != null }) {
        Text("S21 / Insertion Loss", style = MaterialTheme.typography.titleMedium)
        TouchstoneLinePlot(
            frequencies = freqs,
            values = d.points.map { it.s21?.let(TouchstoneMath::db) ?: Double.NaN },
            markerIndex = markerIndex,
            yUnit = "dB",
            preferredTop = null,
            threshold = characterizeFilter(d, filterLevelDb)?.thresholdDb,
            showMarkers = !isLiveData,
            audioPosition = audioPlotPosition,
            onMarker = { updateActiveMarker(it) }
        )
    }

    if (!isLiveData) {
        if (d.ports == 2) {
            d.points.firstOrNull()?.s12?.let {
                Text("S12 / Reverse Transmission", style = MaterialTheme.typography.titleMedium)
                TouchstoneLinePlot(freqs, d.points.map { q -> q.s12?.let(TouchstoneMath::db) ?: Double.NaN }, markerIndex, "dB", showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
            }
            d.points.firstOrNull()?.s22?.let {
                Text("S22 / Output Match", style = MaterialTheme.typography.titleMedium)
                TouchstoneLinePlot(freqs, d.points.map { q -> q.s22?.let(TouchstoneMath::db) ?: Double.NaN }, markerIndex, "dB", preferredTop = 0.0, threshold = -10.0, showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
            }
        }

        Text("Phase S11", style = MaterialTheme.typography.titleMedium)
        TouchstoneLinePlot(freqs, phaseS11, markerIndex, "deg", showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
        if (d.ports == 2 && phaseS21.any { it.isFinite() }) {
            Text("Phase S21", style = MaterialTheme.typography.titleMedium)
            TouchstoneLinePlot(freqs, phaseS21, markerIndex, "deg", showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
            Text("Group Delay S21", style = MaterialTheme.typography.titleMedium)
            TouchstoneLinePlot(freqs, groupDelayNs, markerIndex, "ns", showMarkers = !isLiveData, audioPosition = audioPlotPosition, onMarker = { updateActiveMarker(it) })
        }

    }

    Text("SWR (VSWR)", style = MaterialTheme.typography.titleMedium)
    TouchstoneLinePlot(
        frequencies = freqs,
        values = d.points.map { TouchstoneMath.vswr(it.s11).coerceIn(1.0, 10.0) },
        markerIndex = markerIndex,
        markerIndices = safeMarkers,
        activeMarker = activeMarker,
        yUnit = "VSWR",
        preferredBottom = 1.0,
        preferredTop = 10.0,
        threshold = 2.0,
        showMarkers = !isLiveData,
        audioPosition = audioPlotPosition,
        onMarker = { updateActiveMarker(it) }
    )

    Text("Smith Chart — S11", style = MaterialTheme.typography.titleMedium)
    if (antennaS1pAudioMode) {
        audioSmithPosition?.let { u ->
            val pos = (u.coerceIn(0.0, 1.0) * d.points.lastIndex.toDouble())
            val i0 = kotlin.math.floor(pos).toInt().coerceIn(0, d.points.lastIndex)
            val p = d.points[i0]
            val z = TouchstoneMath.impedance(p.s11, d.referenceOhm)
            Text(
                "AUDIO MARKER • ${tsFreq(p.frequencyHz)} • Z=${tsComplex(z)} Ω • SWR=${tsFinite(TouchstoneMath.vswr(p.s11), 3)} • ∠Γ=${tsFmt(TouchstoneMath.phaseDeg(p.s11), 1)}°",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
    SmithChart(
        points = d.points.map { it.s11 },
        markerIndex = markerIndex,
        markerIndices = safeMarkers,
        activeMarker = activeMarker,
        chartHeightDp = if (focusedPlot == "SMITH") 520 else 360,
        showMarkers = !isLiveData,
        audioPosition = if (antennaS1pAudioMode) audioSmithPosition else null,
        onMarker = { updateActiveMarker(it) }
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Format support", style = MaterialTheme.typography.titleMedium)
            Text("Touchstone S1P/S2P; RI, MA, DB; Hz, kHz, MHz, GHz.")
            Text("LIVE LIGHT: S11, S21, SWR and Smith. Automatic resonance search and Cable Analyzer are temporarily disabled.")
            Text("For S2P, the standard order is used: S11, S21, S12, S22.")
            Text("Touchstone 1.x and basic Touchstone 2.x sections.")
        }
    }
}


@Composable
private fun LiveLiteVnaSinglePlot(
    data: TouchstoneData,
    sweepNumber: Long,
    selectedPlot: String,
    onSelectPlot: (String) -> Unit,
    filterLevelText: String,
    onFilterLevelTextChange: (String) -> Unit,
    filterLevelDb: Double,
    rawPoints: Boolean,
    onRawPointsChange: (Boolean) -> Unit
) {
    val freqs = remember(data) { data.points.map { it.frequencyHz } }

    // Two lightweight LIVE markers. Their indices survive sweep updates as long as
    // the number of sweep points remains unchanged. Only the selected LIVE plot is drawn,
    // preserving the low UI load introduced in 1.19.41.
    var liveMarkers by remember(data.points.size) {
        val last = data.points.lastIndex.coerceAtLeast(0)
        mutableStateOf(listOf(last / 3, (last * 2) / 3))
    }
    var liveActiveMarker by remember { mutableIntStateOf(0) }

    val safeLiveMarkers = liveMarkers.map { it.coerceIn(0, data.points.lastIndex) }
    val liveMarkerIndex = safeLiveMarkers[liveActiveMarker.coerceIn(0, 1)]

    fun updateLiveMarker(index: Int) {
        val safe = index.coerceIn(0, data.points.lastIndex)
        liveMarkers = liveMarkers.mapIndexed { i, old ->
            if (i == liveActiveMarker) safe else old.coerceIn(0, data.points.lastIndex)
        }
    }

    val minSwrIndex = remember(data) {
        data.points.indices.minByOrNull { i -> TouchstoneMath.vswr(data.points[i].s11) } ?: 0
    }
    val resonanceIndex = remember(data) {
        data.points.indices.minByOrNull { i -> kotlin.math.abs(TouchstoneMath.impedance(data.points[i].s11, data.referenceOhm).im) } ?: 0
    }
    val minS11Index = remember(data) {
        data.points.indices.minByOrNull { i -> TouchstoneMath.db(data.points[i].s11) } ?: 0
    }
    val maxS21Index = remember(data) {
        data.points.indices.maxByOrNull { i -> data.points[i].s21?.let(TouchstoneMath::db) ?: Double.NEGATIVE_INFINITY } ?: 0
    }
    val filterChar = remember(data, filterLevelDb) { characterizeFilter(data, filterLevelDb) }

    Text(
        "● LIVE • single plot • UI ≤ 1 Hz • sweep #$sweepNumber",
        style = MaterialTheme.typography.titleMedium
    )
    Text(
        "${tsFreq(data.points.first().frequencyHz)} … ${tsFreq(data.points.last().frequencyHz)} • ${data.points.size} points",
        style = MaterialTheme.typography.bodySmall
    )

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onSelectPlot("S11") },
            enabled = selectedPlot != "S11"
        ) { Text("S11", maxLines = 1) }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onSelectPlot("S21") },
            enabled = selectedPlot != "S21" && data.ports == 2 && data.points.any { it.s21 != null }
        ) { Text("S21", maxLines = 1) }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onSelectPlot("VSWR") },
            enabled = selectedPlot != "VSWR"
        ) { Text("SWR", maxLines = 1) }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onSelectPlot("SMITH") },
            enabled = selectedPlot != "SMITH"
        ) { Text("Smith", maxLines = 1) }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onRawPointsChange(false) },
            enabled = rawPoints
        ) { Text("LINE", maxLines = 1) }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { onRawPointsChange(true) },
            enabled = !rawPoints
        ) { Text("RAW POINTS", maxLines = 1) }
    }

    if (data.ports == 2 && data.points.any { it.s21 != null }) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("AUTO FILTER", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = filterLevelText,
                    onValueChange = { onFilterLevelTextChange(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(6)) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Level below S21 peak, dB") },
                    singleLine = true
                )
                filterChar?.let { f ->
                    Text("${filterKindLabel(f.kind)} • peak ${tsFmt(f.peakDb, 2)} dB • ILmin ${tsFmt((-f.peakDb).coerceAtLeast(0.0), 2)} dB • level ${tsFmt(f.thresholdDb, 2)} dB", style = MaterialTheme.typography.bodySmall)
                    val edges = buildString {
                        f.lowHz?.let { append("fL ${tsFreq(it)}") }
                        if (f.lowHz != null && f.highHz != null) append("   •   ")
                        f.highHz?.let { append("fH ${tsFreq(it)}") }
                    }
                    if (edges.isNotBlank()) Text(edges, style = MaterialTheme.typography.bodySmall)
                    f.bandwidthHz?.let { bw ->
                        Text("BW ${tsSignedFreqSpan(bw)}" + (f.centerHz?.let { c -> "   •   f0 ${tsFreq(c)}" } ?: "") + (f.q?.let { q -> "   •   Q ${tsFmt(q, 2)}" } ?: ""), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    // Marker selector is intentionally tiny: two buttons only.
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (0..1).forEach { mi ->
            Button(
                modifier = Modifier.weight(1f),
                onClick = { liveActiveMarker = mi }
            ) {
                Text(if (liveActiveMarker == mi) "● M${mi + 1}" else "M${mi + 1}", maxLines = 1)
            }
        }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(1f),
            onClick = { updateLiveMarker(minSwrIndex) }
        ) { Text("MIN SWR", maxLines = 1) }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { updateLiveMarker(resonanceIndex) }
        ) { Text("X≈0", maxLines = 1) }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(1f),
            onClick = { updateLiveMarker(minS11Index) }
        ) { Text("MIN S11", maxLines = 1) }
        Button(
            modifier = Modifier.weight(1f),
            enabled = data.ports == 2 && data.points.any { it.s21 != null },
            onClick = { updateLiveMarker(maxS21Index) }
        ) { Text("MAX S21", maxLines = 1) }
    }

    if (filterChar != null && (filterChar.lowHz != null || filterChar.highHz != null)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                modifier = Modifier.weight(1f),
                enabled = filterChar.lowHz != null,
                onClick = { filterChar.lowHz?.let { target -> updateLiveMarker(data.points.indices.minByOrNull { i -> kotlin.math.abs(data.points[i].frequencyHz - target) } ?: liveMarkerIndex) } }
            ) { Text("fL", maxLines = 1) }
            Button(
                modifier = Modifier.weight(1f),
                enabled = filterChar.highHz != null,
                onClick = { filterChar.highHz?.let { target -> updateLiveMarker(data.points.indices.minByOrNull { i -> kotlin.math.abs(data.points[i].frequencyHz - target) } ?: liveMarkerIndex) } }
            ) { Text("fH", maxLines = 1) }
        }
    }

    when (selectedPlot) {
        "S21" -> {
            if (data.ports == 2 && data.points.any { it.s21 != null }) {
                val values = remember(data) { data.points.map { it.s21?.let(TouchstoneMath::db) ?: Double.NaN } }
                Text("S21 / Insertion Loss", style = MaterialTheme.typography.titleMedium)
                TouchstoneLinePlot(
                    frequencies = freqs,
                    values = values,
                    markerIndex = liveMarkerIndex,
                    markerIndices = safeLiveMarkers,
                    activeMarker = liveActiveMarker,
                    yUnit = "dB",
                    threshold = filterChar?.thresholdDb,
                    chartHeightDp = 360,
                    showMarkers = true,
                    rawPoints = rawPoints,
                    onMarker = { updateLiveMarker(it) }
                )
            } else {
                Text("S21 is unavailable for this sweep.")
            }
        }
        "VSWR" -> {
            val values = remember(data) { data.points.map { TouchstoneMath.vswr(it.s11).coerceIn(1.0, 10.0) } }
            Text("SWR (VSWR)", style = MaterialTheme.typography.titleMedium)
            TouchstoneLinePlot(
                frequencies = freqs,
                values = values,
                markerIndex = liveMarkerIndex,
                markerIndices = safeLiveMarkers,
                activeMarker = liveActiveMarker,
                yUnit = "VSWR",
                preferredBottom = 1.0,
                preferredTop = 10.0,
                threshold = 2.0,
                chartHeightDp = 360,
                showMarkers = true,
                rawPoints = rawPoints,
                onMarker = { updateLiveMarker(it) }
            )
        }
        "SMITH" -> {
            val points = remember(data) { data.points.map { it.s11 } }
            Text("Smith Chart — S11", style = MaterialTheme.typography.titleMedium)
            SmithChart(
                points = points,
                markerIndex = liveMarkerIndex,
                markerIndices = safeLiveMarkers,
                activeMarker = liveActiveMarker,
                chartHeightDp = 390,
                showMarkers = true,
                rawPoints = rawPoints,
                onMarker = { updateLiveMarker(it) }
            )
        }
        else -> {
            val values = remember(data) { data.points.map { TouchstoneMath.db(it.s11) } }
            Text("S11 / Return Loss", style = MaterialTheme.typography.titleMedium)
            TouchstoneLinePlot(
                frequencies = freqs,
                values = values,
                markerIndex = liveMarkerIndex,
                markerIndices = safeLiveMarkers,
                activeMarker = liveActiveMarker,
                yUnit = "dB",
                preferredTop = 0.0,
                threshold = -10.0,
                chartHeightDp = 360,
                showMarkers = true,
                rawPoints = rawPoints,
                onMarker = { updateLiveMarker(it) }
            )
        }
    }

    // Compact readout under the selected plot.
    val m1 = data.points[safeLiveMarkers[0]]
    val m2 = data.points[safeLiveMarkers[1]]
    val activePoint = data.points[liveMarkerIndex]
    val activeValue = when (selectedPlot) {
        "S21" -> activePoint.s21?.let { "${tsFmt(TouchstoneMath.db(it), 2)} dB" } ?: "n/a"
        "VSWR" -> tsFinite(TouchstoneMath.vswr(activePoint.s11), 3)
        "SMITH" -> {
            val z = TouchstoneMath.impedance(activePoint.s11, data.referenceOhm)
            "Z = ${tsComplex(z)} Ω"
        }
        else -> "${tsFmt(TouchstoneMath.db(activePoint.s11), 2)} dB"
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val activeZ = TouchstoneMath.impedance(activePoint.s11, data.referenceOhm)
            val activeLc = tsEquivalentReactiveComponent(activeZ.im, activePoint.frequencyHz)
            Text(
                "M${liveActiveMarker + 1}: ${tsFreq(activePoint.frequencyHz)}   $activeValue",
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                "Z = ${tsComplex(activeZ)} Ω   •   R = ${tsFinite(activeZ.re, 2)} Ω   •   X = ${tsSignedOhm(activeZ.im)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "$activeLc   •   SWR = ${tsFinite(TouchstoneMath.vswr(activePoint.s11), 3)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                buildString {
                    append("S11 = ${tsFmt(TouchstoneMath.db(activePoint.s11), 2)} dB")
                    activePoint.s21?.let { append("   •   S21 = ${tsFmt(TouchstoneMath.db(it), 2)} dB") }
                },
                style = MaterialTheme.typography.bodySmall
            )
            val best = data.points[minSwrIndex]
            val res = data.points[resonanceIndex]
            val resZ = TouchstoneMath.impedance(res.s11, data.referenceOhm)
            Text(
                "MIN SWR ${tsFinite(TouchstoneMath.vswr(best.s11), 3)} @ ${tsFreq(best.frequencyHz)}   •   X≈0 @ ${tsFreq(res.frequencyHz)} (${tsFmt(resZ.im, 2)} Ω)",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "M1 ${tsFreq(m1.frequencyHz)}   •   M2 ${tsFreq(m2.frequencyHz)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "Δf (M2−M1) = ${tsSignedFreqSpan(m2.frequencyHz - m1.frequencyHz)}",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "Tap M1 or M2, then tap the graph to move the selected marker.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("LIVE MEASUREMENT MODE", style = MaterialTheme.typography.titleSmall)
            Text("One selected plot only • M1/M2 • LINE/RAW POINTS • quick measurement markers.", style = MaterialTheme.typography.bodySmall)
            Text("Resonance search and Cable Analyzer remain disabled in LIVE mode.", style = MaterialTheme.typography.bodySmall)
            Text("USB runs on a dedicated high-priority thread and continues independently of scroll position.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun buildLiteVnaS2p(data: TouchstoneData, averagedPasses: Int): String = buildString {
    require(data.ports == 2) { "S2P export requires 2-port data" }
    require(data.points.isNotEmpty()) { "Cannot export an empty sweep" }
    appendLine("! Antenna Calculator PRO - LiteVNA64 LIVE export")
    appendLine("! ${averagedPasses.coerceAtLeast(1)} complete sweep(s) averaged in complex RI domain")
    appendLine("! S11 and S21 are measured forward-path values")
    appendLine("! S12 and S22 are unavailable in the current LiteVNA RAW forward sweep and are written as 0 0")
    data.comments.forEach { appendLine("! $it") }
    appendLine("# HZ S RI R ${tsPlain(data.referenceOhm)}")
    data.points.forEach { p ->
        val s21 = p.s21 ?: Cpx(0.0, 0.0)
        val s12 = p.s12 ?: Cpx(0.0, 0.0)
        val s22 = p.s22 ?: Cpx(0.0, 0.0)
        append(tsPlain(p.frequencyHz)); append(' ')
        append(tsPlain(p.s11.re)); append(' '); append(tsPlain(p.s11.im)); append(' ')
        append(tsPlain(s21.re)); append(' '); append(tsPlain(s21.im)); append(' ')
        append(tsPlain(s12.re)); append(' '); append(tsPlain(s12.im)); append(' ')
        append(tsPlain(s22.re)); append(' '); append(tsPlain(s22.im)); appendLine()
    }
}

private fun tsPlain(v: Double): String = java.lang.String.format(java.util.Locale.US, "%.12g", v)

private fun tsFileFreq(hz: Double): String = when {
    hz >= 1e9 -> java.lang.String.format(java.util.Locale.US, "%.3fG", hz / 1e9)
    hz >= 1e6 -> java.lang.String.format(java.util.Locale.US, "%.3fM", hz / 1e6)
    hz >= 1e3 -> java.lang.String.format(java.util.Locale.US, "%.3fk", hz / 1e3)
    else -> java.lang.String.format(java.util.Locale.US, "%.0fHz", hz)
}.replace('.', '_')

private fun buildTouchstoneCsv(data: TouchstoneData): String = buildString {
    appendLine("frequency_Hz,S11_dB,S11_phase_deg,VSWR,R_ohm,X_ohm,S21_dB,S21_phase_deg,S12_dB,S22_dB")
    data.points.forEach { p ->
        val z = TouchstoneMath.impedance(p.s11, data.referenceOhm)
        append(p.frequencyHz); append(','); append(TouchstoneMath.db(p.s11)); append(','); append(TouchstoneMath.phaseDeg(p.s11)); append(','); append(TouchstoneMath.vswr(p.s11)); append(','); append(z.re); append(','); append(z.im); append(',')
        append(p.s21?.let(TouchstoneMath::db) ?: ""); append(','); append(p.s21?.let(TouchstoneMath::phaseDeg) ?: ""); append(','); append(p.s12?.let(TouchstoneMath::db) ?: ""); append(','); append(p.s22?.let(TouchstoneMath::db) ?: ""); appendLine()
    }
}

private fun unwrapPhase(values: List<Double>): List<Double> {
    if (values.isEmpty()) return values
    val out = MutableList(values.size) { Double.NaN }
    var prev = Double.NaN
    var offset = 0.0
    values.forEachIndexed { i, raw ->
        if (!raw.isFinite()) return@forEachIndexed
        if (prev.isFinite()) {
            val delta = raw - prev
            if (delta > 180.0) offset -= 360.0
            else if (delta < -180.0) offset += 360.0
        }
        out[i] = raw + offset
        prev = raw
    }
    return out
}

private fun groupDelayNs(freqs: List<Double>, phaseDeg: List<Double>): List<Double> {
    if (freqs.size < 2 || freqs.size != phaseDeg.size) return List(freqs.size) { Double.NaN }
    return freqs.indices.map { i ->
        val a = (i - 1).coerceAtLeast(0); val b = (i + 1).coerceAtMost(freqs.lastIndex)
        val df = freqs[b] - freqs[a]
        if (df <= 0.0 || !phaseDeg[a].isFinite() || !phaseDeg[b].isFinite()) Double.NaN
        else -((phaseDeg[b] - phaseDeg[a]) * kotlin.math.PI / 180.0) / (2.0 * kotlin.math.PI * df) * 1e9
    }
}

@Composable
private fun BandLine(label: String, band: BandResult?) {
    if (band == null) {
        Text("$label: not found")
    } else {
        Text("$label: ${tsFreq(band.lowHz)} … ${tsFreq(band.highHz)}")
        Text("Width: ${tsFreqSpan(band.widthHz)}   Center: ${tsFreq(band.centerHz)}")
    }
}

private fun thresholdBand(data: TouchstoneData, thresholdDb: Double): BandResult? {
    val pts = data.points
    val db = pts.map { TouchstoneMath.db(it.s11) }
    val minIndex = db.indices.minByOrNull { db[it] } ?: return null
    if (db[minIndex] > thresholdDb) return null

    fun crossing(i0: Int, i1: Int): Double {
        val x0 = pts[i0].frequencyHz
        val x1 = pts[i1].frequencyHz
        val y0 = db[i0]
        val y1 = db[i1]
        if (y1 == y0) return x0
        val t = ((thresholdDb - y0) / (y1 - y0)).coerceIn(0.0, 1.0)
        return x0 + (x1 - x0) * t
    }

    var l = minIndex
    while (l > 0 && db[l - 1] <= thresholdDb) l--
    val low = if (l == 0) pts.first().frequencyHz else crossing(l - 1, l)

    var h = minIndex
    while (h < pts.lastIndex && db[h + 1] <= thresholdDb) h++
    val high = if (h == pts.lastIndex) pts.last().frequencyHz else crossing(h, h + 1)

    return BandResult(low, high)
}

@Composable
private fun TouchstoneLinePlot(
    frequencies: List<Double>,
    values: List<Double>,
    markerIndex: Int,
    yUnit: String,
    markerIndices: List<Int> = listOf(markerIndex),
    activeMarker: Int = 0,
    preferredBottom: Double? = null,
    preferredTop: Double? = null,
    threshold: Double? = null,
    chartHeightDp: Int = 300,
    showMarkers: Boolean = true,
    rawPoints: Boolean = false,
    audioPosition: Double? = null,
    onMarker: (Int) -> Unit
) {
    if (values.size < 2 || frequencies.size != values.size) return
    val finite = values.filter { it.isFinite() }
    if (finite.isEmpty()) return

    val rawMin = finite.minOrNull() ?: 0.0
    val rawMax = finite.maxOrNull() ?: 1.0
    var minY = preferredBottom ?: floor(rawMin / 5.0) * 5.0
    var maxY = preferredTop ?: ceil(rawMax / 5.0) * 5.0
    threshold?.let {
        val thresholdFloor = floor(it / 5.0) * 5.0
        val thresholdCeil = ceil(it / 5.0) * 5.0
        minY = if (preferredBottom != null) max(preferredBottom, min(minY, thresholdFloor)) else min(minY, thresholdFloor)
        maxY = if (preferredTop != null) min(preferredTop, max(maxY, thresholdCeil)) else max(maxY, thresholdCeil)
    }
    // Never let an explicitly requested physical lower bound (notably VSWR=1)
    // be pulled down by rounded threshold/grid expansion.
    preferredBottom?.let { minY = max(minY, it) }
    preferredTop?.let { maxY = min(maxY, it) }
    if (maxY - minY < 1.0) maxY = minY + 1.0

    val traceColor = MaterialTheme.colorScheme.primary
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val minorGridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.42f)
    val markerColor = MaterialTheme.colorScheme.secondary
    val thresholdColor = MaterialTheme.colorScheme.tertiary
    val chartBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)
    val surfaceColor = MaterialTheme.colorScheme.surface
    val labelArgb = axisColor.toArgb()

    Card(modifier = Modifier.fillMaxWidth()) {
        val baseModifier = Modifier
            .fillMaxWidth()
            .height(chartHeightDp.dp)
            .padding(horizontal = 4.dp, vertical = 4.dp)
        val canvasModifier = if (showMarkers) {
            baseModifier.pointerInput(values, frequencies) {
                detectTapGestures { pos ->
                    val left = 68f
                    val right = size.width.toFloat() - 16f
                    val x = pos.x.coerceIn(left, right)
                    val t = if (right > left) (x - left) / (right - left) else 0f
                    val targetF = frequencies.first() +
                        (frequencies.last() - frequencies.first()) * t
                    val best = frequencies.indices.minByOrNull { abs(frequencies[it] - targetF) } ?: 0
                    onMarker(best)
                }
            }
        } else baseModifier
        Canvas(modifier = canvasModifier) {
            val left = 68f
            val right = size.width - 16f
            val top = 18f
            val bottom = size.height - 46f
            val span = maxY - minY
            val f0 = frequencies.first()
            val f1 = frequencies.last()
            val fSpan = (f1 - f0).takeIf { it > 0.0 } ?: 1.0
            val paint = Paint().apply {
                color = labelArgb
                textSize = 23f
                isAntiAlias = true
            }
            val smallPaint = Paint().apply {
                color = labelArgb
                textSize = 20f
                isAntiAlias = true
            }

            drawRoundRect(
                color = chartBackground,
                topLeft = Offset(0f, 0f),
                size = size,
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
            )

            fun xFor(i: Int): Float =
                left + (right - left) * ((frequencies[i] - f0) / fSpan).toFloat()

            fun yFor(v: Double): Float {
                val clipped = v.coerceIn(minY, maxY)
                return bottom - (bottom - top) * ((clipped - minY) / span).toFloat()
            }

            // Minor grid first, then stronger major grid.
            for (g in 0..10) {
                val t = g / 10f
                val y = bottom - (bottom - top) * t
                drawLine(minorGridColor, Offset(left, y), Offset(right, y), strokeWidth = 0.65f)
            }
            for (g in 0..8) {
                val t = g / 8f
                val x = left + (right - left) * t
                drawLine(minorGridColor, Offset(x, top), Offset(x, bottom), strokeWidth = 0.6f)
            }

            for (g in 0..5) {
                val t = g / 5f
                val y = bottom - (bottom - top) * t
                val v = minY + span * t
                drawLine(gridColor, Offset(left, y), Offset(right, y), strokeWidth = 1.0f)
                drawContext.canvas.nativeCanvas.drawText(tsAxis(v), 5f, y + 7f, smallPaint)
            }

            for (g in 0..4) {
                val t = g / 4f
                val x = left + (right - left) * t
                val f = f0 + (f1 - f0) * t
                drawLine(gridColor, Offset(x, top), Offset(x, bottom), strokeWidth = 0.95f)
                val label = tsFreqShort(f)
                val tw = smallPaint.measureText(label)
                drawContext.canvas.nativeCanvas.drawText(
                    label,
                    (x - tw / 2f).coerceIn(2f, size.width - tw - 2f),
                    size.height - 10f,
                    smallPaint
                )
            }

            drawLine(axisColor, Offset(left, top), Offset(left, bottom), strokeWidth = 1.6f)
            drawLine(axisColor, Offset(left, bottom), Offset(right, bottom), strokeWidth = 1.6f)

            threshold?.takeIf { it in minY..maxY }?.let { th ->
                val y = yFor(th)
                drawLine(thresholdColor, Offset(left, y), Offset(right, y), strokeWidth = 2.0f)
                val label = "${tsAxis(th)} $yUnit"
                val tw = smallPaint.measureText(label)
                drawRoundRect(
                    thresholdColor.copy(alpha = 0.13f),
                    topLeft = Offset(right - tw - 16f, y - 25f),
                    size = androidx.compose.ui.geometry.Size(tw + 12f, 24f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
                drawContext.canvas.nativeCanvas.drawText(label, right - tw - 10f, y - 7f, smallPaint)
            }

            val linePath = Path()
            val fillPath = Path()
            var started = false
            var firstX = 0f
            var lastX = 0f
            values.indices.forEach { i ->
                val v = values[i]
                if (!v.isFinite()) return@forEach
                val x = xFor(i)
                val y = yFor(v)
                if (!started) {
                    linePath.moveTo(x, y)
                    fillPath.moveTo(x, bottom)
                    fillPath.lineTo(x, y)
                    firstX = x
                    started = true
                } else {
                    linePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
                lastX = x
            }
            if (started) {
                fillPath.lineTo(lastX, bottom)
                fillPath.lineTo(firstX, bottom)
                fillPath.close()
                if (!rawPoints) drawPath(fillPath, traceColor.copy(alpha = 0.11f))
                drawPath(linePath, traceColor, style = Stroke(width = if (rawPoints) 1.5f else 3.1f))
                if (rawPoints) {
                    values.indices.forEach { i ->
                        val v = values[i]
                        if (v.isFinite()) {
                            drawCircle(traceColor, radius = 3.0f, center = Offset(xFor(i), yFor(v)))
                        }
                    }
                }
            }

            // 1.19.100: one playback position drives the Smith marker and every
            // 2D frequency plot. This keeps the visual cursor phase-locked to audio.
            audioPosition?.let { rawU ->
                val u = rawU.coerceIn(0.0, 1.0)
                val xFloat = u * values.lastIndex.toDouble()
                val i0 = kotlin.math.floor(xFloat).toInt().coerceIn(0, values.lastIndex)
                val i1 = (i0 + 1).coerceAtMost(values.lastIndex)
                val t = xFloat - i0.toDouble()
                val v0 = values[i0]
                val v1 = values[i1]
                val vNow = when {
                    v0.isFinite() && v1.isFinite() -> v0 + (v1 - v0) * t
                    v0.isFinite() -> v0
                    v1.isFinite() -> v1
                    else -> Double.NaN
                }
                val fNow = frequencies[i0] + (frequencies[i1] - frequencies[i0]) * t
                val xNow = left + (right - left) * ((fNow - f0) / fSpan).toFloat()
                drawLine(surfaceColor, Offset(xNow, top), Offset(xNow, bottom), strokeWidth = 5.0f)
                drawLine(markerColor, Offset(xNow, top), Offset(xNow, bottom), strokeWidth = 2.2f)
                if (vNow.isFinite()) {
                    val q = Offset(xNow, yFor(vNow))
                    drawCircle(surfaceColor, radius = 10.0f, center = q)
                    drawCircle(markerColor.copy(alpha = 0.35f), radius = 8.0f, center = q)
                    drawCircle(markerColor, radius = 5.2f, center = q)
                    val audioText = "AUDIO  ${tsFreqShort(fNow)}"
                    val tw = smallPaint.measureText(audioText)
                    val bx = (xNow + 8f).coerceAtMost(right - tw - 12f).coerceAtLeast(left + 4f)
                    drawRoundRect(
                        markerColor.copy(alpha = 0.16f),
                        topLeft = Offset(bx, bottom - 30f),
                        size = androidx.compose.ui.geometry.Size(tw + 10f, 25f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                    )
                    drawContext.canvas.nativeCanvas.drawText(audioText, bx + 5f, bottom - 11f, smallPaint)
                }
            }

            if (showMarkers) markerIndices.take(2).forEachIndexed { mi, idxRaw ->
                val idx = idxRaw.coerceIn(0, values.lastIndex)
                if (!values[idx].isFinite()) return@forEachIndexed
                val q = Offset(xFor(idx), yFor(values[idx]))
                val isActive = mi == activeMarker
                drawLine(markerColor.copy(alpha = if (isActive) 0.80f else 0.35f), Offset(q.x, top), Offset(q.x, bottom), strokeWidth = if (isActive) 2.0f else 1.0f)
                drawCircle(surfaceColor, radius = if (isActive) 9.0f else 6.5f, center = q)
                drawCircle(markerColor.copy(alpha = if (isActive) 1f else 0.65f), radius = if (isActive) 6.5f else 4.2f, center = q)
                val markerText = "M${mi + 1}" + if (isActive) "  ${tsFreqShort(frequencies[idx])}   ${tsFmt(values[idx], 2)} $yUnit" else ""
                val tw = paint.measureText(markerText)
                val bx = (q.x - tw / 2f - 8f).coerceIn(left + 4f, right - tw - 20f)
                val by = top + 4f + mi * 30f
                drawRoundRect(
                    markerColor.copy(alpha = if (isActive) 0.18f else 0.08f),
                    topLeft = Offset(bx, by),
                    size = androidx.compose.ui.geometry.Size(tw + 16f, 27f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(9f, 9f)
                )
                drawContext.canvas.nativeCanvas.drawText(markerText, bx + 8f, by + 21f, smallPaint)
            }
        }
    }
}

@Composable
private fun SmithChart(
    points: List<Cpx>,
    markerIndex: Int,
    markerIndices: List<Int> = listOf(markerIndex),
    activeMarker: Int = 0,
    chartHeightDp: Int = 360,
    showMarkers: Boolean = true,
    rawPoints: Boolean = false,
    audioPosition: Double? = null,
    onMarker: (Int) -> Unit
) {
    if (points.isEmpty()) return
    val traceColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val axisColor = MaterialTheme.colorScheme.onSurface
    val markerColor = MaterialTheme.colorScheme.secondary
    val thresholdColor = MaterialTheme.colorScheme.tertiary
    val chartBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)
    val surfaceColor = MaterialTheme.colorScheme.surface
    val labelArgb = axisColor.toArgb()

    Card(modifier = Modifier.fillMaxWidth()) {
        val baseModifier = Modifier
            .fillMaxWidth()
            .height(chartHeightDp.dp)
            .padding(4.dp)
        val canvasModifier = if (showMarkers) {
            baseModifier.pointerInput(points) {
                detectTapGestures { pos ->
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val r = min(size.width, size.height).toFloat() * 0.42f
                    var best = 0
                    var bestD = Float.POSITIVE_INFINITY
                    points.forEachIndexed { i, g ->
                        val x = cx + (g.re * r).toFloat()
                        val y = cy - (g.im * r).toFloat()
                        val dx = x - pos.x
                        val dy = y - pos.y
                        val dd = dx * dx + dy * dy
                        if (dd < bestD) {
                            bestD = dd
                            best = i
                        }
                    }
                    onMarker(best)
                }
            }
        } else baseModifier
        Canvas(modifier = canvasModifier) {
            drawRoundRect(
                chartBackground,
                topLeft = Offset.Zero,
                size = size,
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
            )

            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = min(size.width, size.height) * 0.42f
            val paint = Paint().apply {
                color = labelArgb
                textSize = 21f
                isAntiAlias = true
            }

            drawCircle(surfaceColor.copy(alpha = 0.50f), r, Offset(cx, cy))
            drawCircle(axisColor, r, Offset(cx, cy), style = Stroke(width = 1.7f))
            val smithClip = Path().apply { addOval(Rect(cx - r, cy - r, cx + r, cy + r)) }

            clipPath(smithClip) {
                drawLine(axisColor, Offset(cx - r, cy), Offset(cx + r, cy), strokeWidth = 1.15f)

                listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { rv ->
                    val cr = r / (1.0 + rv).toFloat()
                    val ccx = cx + r * (rv / (1.0 + rv)).toFloat()
                    drawCircle(gridColor, cr, Offset(ccx, cy), style = Stroke(width = 0.85f))
                }

                listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { xv ->
                    val rr = r / xv.toFloat()
                    val ccx = cx + r
                    drawCircle(gridColor, rr, Offset(ccx, cy - rr), style = Stroke(width = 0.7f))
                    drawCircle(gridColor, rr, Offset(ccx, cy + rr), style = Stroke(width = 0.7f))
                }

                // VSWR = 2 circle: |Gamma| = 1/3.
                drawCircle(
                    thresholdColor.copy(alpha = 0.75f),
                    r / 3f,
                    Offset(cx, cy),
                    style = Stroke(width = 1.6f)
                )
            }

            drawCircle(axisColor.copy(alpha = 0.85f), 3.8f, Offset(cx, cy))
            drawContext.canvas.nativeCanvas.drawText("50 Ω", cx + 8f, cy - 8f, paint)
            drawContext.canvas.nativeCanvas.drawText("0", cx - r - 22f, cy - 8f, paint)
            drawContext.canvas.nativeCanvas.drawText("∞", cx + r - 8f, cy - 8f, paint)
            drawContext.canvas.nativeCanvas.drawText("+jX", cx - 16f, cy - r - 6f, paint)
            drawContext.canvas.nativeCanvas.drawText("−jX", cx - 16f, cy + r + 24f, paint)
            drawContext.canvas.nativeCanvas.drawText("VSWR 2", cx + r / 3f + 6f, cy - 8f, paint)

            fun pt(g: Cpx) = Offset(cx + (g.re * r).toFloat(), cy - (g.im * r).toFloat())

            val tracePath = Path()
            var started = false
            points.forEach { g ->
                if (!g.re.isFinite() || !g.im.isFinite()) return@forEach
                val q = pt(g)
                if (!started) {
                    tracePath.moveTo(q.x, q.y)
                    started = true
                } else {
                    tracePath.lineTo(q.x, q.y)
                }
            }
            if (started) {
                drawPath(tracePath, traceColor, style = Stroke(width = if (rawPoints) 1.4f else 3.0f))
                if (rawPoints) {
                    points.forEach { g ->
                        if (g.re.isFinite() && g.im.isFinite()) drawCircle(traceColor, 3.0f, pt(g))
                    }
                }
            }

            if (points.isNotEmpty()) {
                val startPt = pt(points.first())
                val endPt = pt(points.last())
                drawCircle(traceColor.copy(alpha = 0.70f), 4.5f, startPt)
                drawCircle(traceColor.copy(alpha = 0.70f), 4.5f, endPt)
            }

            // 1.19.98: synchronized audio sweep marker for a measured antenna S1P.
            audioPosition?.let { rawU ->
                if (points.size >= 2) {
                    val x = rawU.coerceIn(0.0, 1.0) * points.lastIndex.toDouble()
                    val i0 = kotlin.math.floor(x).toInt().coerceIn(0, points.lastIndex)
                    val i1 = (i0 + 1).coerceAtMost(points.lastIndex)
                    val t = x - i0.toDouble()
                    val g0 = points[i0]
                    val g1 = points[i1]
                    val gi = Cpx(
                        g0.re + (g1.re - g0.re) * t,
                        g0.im + (g1.im - g0.im) * t
                    )
                    if (gi.re.isFinite() && gi.im.isFinite()) {
                        val q = pt(gi)
                        drawCircle(surfaceColor, 13f, q)
                        drawCircle(markerColor.copy(alpha = 0.35f), 10f, q)
                        drawCircle(markerColor, 6.5f, q)
                        drawContext.canvas.nativeCanvas.drawText("AUDIO", q.x + 9f, q.y - 8f, paint)
                    }
                }
            }

            if (showMarkers) markerIndices.take(2).forEachIndexed { mi, idxRaw ->
                val idx = idxRaw.coerceIn(0, points.lastIndex)
                val q = pt(points[idx])
                val isActive = mi == activeMarker
                drawCircle(surfaceColor, if (isActive) 9f else 6f, q)
                drawCircle(markerColor.copy(alpha = if (isActive) 1f else 0.65f), if (isActive) 6.5f else 4f, q)
                drawContext.canvas.nativeCanvas.drawText("M${mi + 1}", q.x + 8f, q.y - 7f, paint)
            }
        }
    }
}



private fun tsSignedOhm(x: Double): String {
    if (!x.isFinite()) return "∞ Ω"
    val sign = if (x >= 0.0) "+" else "−"
    return "$sign${tsFinite(kotlin.math.abs(x), 2)} Ω"
}

private fun tsEquivalentReactiveComponent(xOhm: Double, frequencyHz: Double): String {
    if (!xOhm.isFinite() || !frequencyHz.isFinite() || frequencyHz <= 0.0) return "L/C = n/a"
    if (kotlin.math.abs(xOhm) < 0.05) return "X≈0 • resonance"
    val omega = 2.0 * Math.PI * frequencyHz
    return if (xOhm > 0.0) {
        val h = xOhm / omega
        "L ≈ ${tsEngineering(h, "H")}"
    } else {
        val f = 1.0 / (omega * kotlin.math.abs(xOhm))
        "C ≈ ${tsEngineering(f, "F")}"
    }
}

private fun tsEngineering(value: Double, unit: String): String {
    if (!value.isFinite() || value <= 0.0) return "n/a"
    val table = listOf(
        1e-12 to "p",
        1e-9 to "n",
        1e-6 to "µ",
        1e-3 to "m",
        1.0 to ""
    )
    val selected = table.lastOrNull { value >= it.first } ?: table.first()
    val scaled = value / selected.first
    val digits = when {
        scaled >= 100.0 -> 1
        scaled >= 10.0 -> 2
        else -> 3
    }
    return "${tsFmt(scaled, digits)} ${selected.second}$unit"
}

private fun tsAxis(v: Double): String = when {
    abs(v) >= 100.0 -> String.format(Locale.US, "%.0f", v)
    abs(v) >= 10.0 -> String.format(Locale.US, "%.1f", v)
    else -> String.format(Locale.US, "%.2f", v)
}

private fun tsFmt(v: Double, digits: Int): String =
    if (v.isFinite()) String.format(Locale.US, "% .${digits}f", v).trim() else "∞"

private fun tsFinite(v: Double, digits: Int): String =
    if (v.isFinite()) tsFmt(v, digits) else "∞"

private fun tsComplex(v: Cpx): String {
    val sign = if (v.im >= 0.0) "+" else "−"
    return "${tsFinite(v.re, 2)} $sign j${tsFinite(abs(v.im), 2)}"
}

private fun tsFreq(hz: Double): String = when {
    hz >= 1e9 -> "${tsFmt(hz / 1e9, 6)} GHz"
    hz >= 1e6 -> "${tsFmt(hz / 1e6, 6)} MHz"
    hz >= 1e3 -> "${tsFmt(hz / 1e3, 3)} kHz"
    else -> "${tsFmt(hz, 1)} Hz"
}

private fun tsFreqShort(hz: Double): String = when {
    hz >= 1e9 -> "${tsFmt(hz / 1e9, 3)}G"
    hz >= 1e6 -> "${tsFmt(hz / 1e6, 3)}M"
    hz >= 1e3 -> "${tsFmt(hz / 1e3, 1)}k"
    else -> tsFmt(hz, 0)
}

private fun tsFreqSpan(hz: Double): String = when {
    hz >= 1e9 -> "${tsFmt(hz / 1e9, 6)} GHz"
    hz >= 1e6 -> "${tsFmt(hz / 1e6, 6)} MHz"
    hz >= 1e3 -> "${tsFmt(hz / 1e3, 3)} kHz"
    else -> "${tsFmt(hz, 1)} Hz"
}

private fun tsSignedFreqSpan(hz: Double): String {
    val sign = if (hz >= 0.0) "+" else "−"
    return sign + tsFreqSpan(kotlin.math.abs(hz))
}
