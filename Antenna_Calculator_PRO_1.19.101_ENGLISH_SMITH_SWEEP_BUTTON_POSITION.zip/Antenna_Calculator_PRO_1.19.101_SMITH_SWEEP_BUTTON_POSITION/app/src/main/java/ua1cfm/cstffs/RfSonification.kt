package ua1cfm.cstffs

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * RF AUDIO / sonification
 *
 * Visualization/post-processing only. It consumes already-calculated Touchstone complex
 * samples and never changes LiteVNA acquisition, calibration, NEC/OpenNEC, impedance,
 * radiation-pattern, current, ground, or near-field calculations.
 *
 * Mapping:
 *   RF sweep frequency -> playback time (left to right)
 *   |Sxx|             -> audio amplitude (logarithmic, -60..0 dB)
 *   RF complex phase  -> instantaneous stereo I/Q angle
 *
 * A fixed audible carrier is added so that phase slope / group-delay changes become audible
 * as frequency/texture changes. Left = I, Right = Q.
 */
private class RfAudioPlayer {
    @Volatile private var generation = 0
    @Volatile private var track: AudioTrack? = null

    fun stop() {
        generation++
        val old = track
        track = null
        runCatching { old?.pause() }
        runCatching { old?.flush() }
        runCatching { old?.stop() }
        runCatching { old?.release() }
    }

    fun play(
        data: TouchstoneData,
        useS21: Boolean,
        durationSeconds: Double = 6.0,
        sampleRate: Int = 44_100,
        carrierHz: Double = 1_250.0,
        status: (String) -> Unit
    ) {
        stop()
        val myGeneration = generation
        val points = data.points
            .filter { p ->
                p.frequencyHz.isFinite() &&
                    (if (useS21) p.s21 else p.s11) != null
            }
            .sortedBy { it.frequencyHz }

        if (points.size < 2) {
            status(if (useS21) "S21 audio: not enough complex samples" else "S11 audio: not enough complex samples")
            return
        }

        status("Preparing ${if (useS21) "S21" else "S11"} RF AUDIO…")

        thread(name = "RF-Audio-Sonification", isDaemon = true) {
            try {
                val duration = durationSeconds.coerceIn(2.0, 15.0)
                val frames = (sampleRate * duration).roundToInt().coerceAtLeast(sampleRate)
                val stereo = ShortArray(frames * 2)

                val freq = DoubleArray(points.size) { points[it].frequencyHz }
                val magDb = DoubleArray(points.size)
                val phase = DoubleArray(points.size)

                for (i in points.indices) {
                    val c = if (useS21) points[i].s21!! else points[i].s11
                    val m = sqrt(c.re * c.re + c.im * c.im).coerceAtLeast(1e-15)
                    magDb[i] = (20.0 * kotlin.math.log10(m)).coerceIn(-60.0, 0.0)
                    phase[i] = atan2(c.im, c.re)
                }
                unwrapRadiansInPlace(phase)

                val f0 = freq.first()
                val f1 = freq.last()
                val span = (f1 - f0).takeIf { it > 0.0 } ?: 1.0

                // Convert -60..0 dB to a controlled audible amplitude. A small floor lets deep
                // nulls remain perceptible without allowing 0 dB points to clip.
                fun ampFromDb(db: Double): Double {
                    val linear = 10.0.pow(db / 20.0)
                    return (0.025 + 0.78 * linear).coerceIn(0.0, 0.82)
                }

                var idx = 0
                for (n in 0 until frames) {
                    if (myGeneration != generation) return@thread

                    val u = if (frames <= 1) 0.0 else n.toDouble() / (frames - 1).toDouble()
                    val targetF = f0 + span * u

                    while (idx + 1 < freq.size - 1 && freq[idx + 1] < targetF) idx++
                    val j = (idx + 1).coerceAtMost(freq.lastIndex)
                    val den = freq[j] - freq[idx]
                    val a = if (den > 0.0) ((targetF - freq[idx]) / den).coerceIn(0.0, 1.0) else 0.0

                    val db = magDb[idx] + (magDb[j] - magDb[idx]) * a
                    val rfPhase = phase[idx] + (phase[j] - phase[idx]) * a
                    val envelope = ampFromDb(db)

                    // 8 ms edge fade prevents clicks at start/stop.
                    val edgeFrames = (sampleRate * 0.008).roundToInt().coerceAtLeast(1)
                    val fadeIn = (n.toDouble() / edgeFrames).coerceIn(0.0, 1.0)
                    val fadeOut = ((frames - 1 - n).toDouble() / edgeFrames).coerceIn(0.0, 1.0)
                    val fade = minOf(fadeIn, fadeOut)

                    val carrierPhase = 2.0 * PI * carrierHz * n.toDouble() / sampleRate.toDouble()
                    val audiblePhase = carrierPhase + rfPhase

                    // I/Q stereo: the original complex RF phase becomes stereo rotation.
                    val left = envelope * fade * cos(audiblePhase)
                    val right = envelope * fade * sin(audiblePhase)

                    stereo[n * 2] = (left * Short.MAX_VALUE).roundToInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    stereo[n * 2 + 1] = (right * Short.MAX_VALUE).roundToInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                if (myGeneration != generation) return@thread

                val minBuffer = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(4096)

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(max(minBuffer, 16_384))
                    .build()

                if (myGeneration != generation) {
                    audioTrack.release()
                    return@thread
                }

                track = audioTrack
                postMain { status("Playing ${if (useS21) "S21" else "S11"} • I/Q stereo • 6 s") }
                audioTrack.play()

                var offset = 0
                while (offset < stereo.size && myGeneration == generation) {
                    val written = audioTrack.write(stereo, offset, stereo.size - offset, AudioTrack.WRITE_BLOCKING)
                    if (written <= 0) break
                    offset += written
                }

                if (myGeneration == generation) {
                    runCatching { audioTrack.stop() }
                    runCatching { audioTrack.release() }
                    if (track === audioTrack) track = null
                    postMain { status("RF AUDIO ready") }
                } else {
                    runCatching { audioTrack.stop() }
                    runCatching { audioTrack.release() }
                }
            } catch (t: Throwable) {
                if (myGeneration == generation) {
                    postMain { status("RF AUDIO error: ${t.message ?: t.javaClass.simpleName}") }
                }
            }
        }
    }

    private fun unwrapRadiansInPlace(v: DoubleArray) {
        if (v.size < 2) return
        var offset = 0.0
        var prev = v[0]
        for (i in 1 until v.size) {
            val raw = v[i]
            var delta = raw - prev
            if (delta > PI) offset -= 2.0 * PI
            else if (delta < -PI) offset += 2.0 * PI
            v[i] = raw + offset
            prev = raw
        }
    }

    private fun postMain(block: () -> Unit) {
        Handler(Looper.getMainLooper()).post(block)
    }
}

@Composable
fun RfSonificationCard(data: TouchstoneData) {
    val player = remember { RfAudioPlayer() }
    var status by remember(data) { mutableStateOf("RF AUDIO ready") }

    DisposableEffect(player) {
        onDispose { player.stop() }
    }

    val hasS21 = data.ports == 2 && data.points.count { it.s21 != null } >= 2

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("RF AUDIO — amplitude + phase sonification", style = MaterialTheme.typography.titleMedium)
            Text(
                "RF frequency is scanned through playback time. Magnitude controls loudness; " +
                    "complex phase controls stereo I/Q rotation. Headphones make phase changes easiest to hear.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { player.play(data, useS21 = false) { status = it } }
                ) { Text("PLAY S11", maxLines = 1) }

                Button(
                    modifier = Modifier.weight(1f),
                    enabled = hasS21,
                    onClick = { player.play(data, useS21 = true) { status = it } }
                ) { Text("PLAY S21", maxLines = 1) }

                Button(
                    modifier = Modifier.weight(1f),
                    onClick = {
                        player.stop()
                        status = "RF AUDIO stopped"
                    }
                ) { Text("STOP", maxLines = 1) }
            }
            Text(status, style = MaterialTheme.typography.bodySmall)
            Text(
                "Audio is post-processing only; measurement/calculation data are not modified.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
