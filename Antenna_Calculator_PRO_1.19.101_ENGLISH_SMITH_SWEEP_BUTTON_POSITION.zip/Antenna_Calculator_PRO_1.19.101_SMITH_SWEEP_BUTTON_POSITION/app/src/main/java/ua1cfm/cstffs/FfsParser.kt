package ua1cfm.cstffs

import java.io.BufferedReader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.sqrt

data class PatternPoint(val thetaDeg: Double, val db: Double)
data class Pattern3DPoint(val thetaDeg: Double, val phiDeg: Double, val db: Double)
data class ApertureIlluminationPoint(val thetaDeg: Double, val amplitude: Double)

data class FfsResult(
    val selectedFrequencyGHz: Double?,
    val availableFrequenciesGHz: List<Double>,
    val sourcePositionXM: Double?,
    val sourcePositionYM: Double?,
    val sourcePositionZM: Double?,
    val sampleCount: Int,
    val usedSampleCount: Int,
    val peakThetaDeg: Double?,
    val peakPhiDeg: Double?,
    val directivityDbi: Double?,
    val radiatedPowerW: Double?,
    val acceptedPowerW: Double?,
    val radiationEfficiency: Double?,
    val gainDbi: Double?,
    val spilloverEfficiency: Double?,
    val spilloverLossDb: Double?,
    val taperEfficiency: Double?,
    val taperLossDb: Double?,
    val ePlane: List<PatternPoint>,
    val hPlane: List<PatternPoint>,
    val surface3D: List<Pattern3DPoint>,
    val apertureIllumination: List<ApertureIlluminationPoint>,
    val phaseAnalysis: PhaseAnalysisResult?,
    val note: String
)

private data class PowerBlock(
    val prad: Double,
    val pacc: Double,
    val pstim: Double,
    val frequencyGHz: Double
)

object FfsParser {
    fun parse(
        reader: BufferedReader,
        targetGHz: Double,
        edgeAngleDeg: Double,
        onCalculationProgress: (Int) -> Unit = {}
    ): FfsResult {
        val powers = mutableListOf<PowerBlock>()
        val powerNumbers = mutableListOf<Double>()

        var collectingPowers = false
        var expectPosition = false
        var sourcePositionXM: Double? = null
        var sourcePositionYM: Double? = null
        var sourcePositionZM: Double? = null
        var expectCounts = false
        var nPhi = 0
        var nTheta = 0

        var selectedBlock = 0
        var selectedFrequencyGHz: Double? = null
        var selectedPower: PowerBlock? = null
        var blockIndex = -1
        var remainingDataLines = 0
        var parseThisBlock = false
        var selectionDone = false
        var selectedBlockFinished = false

        var rawSamples = 0
        var usedSamples = 0
        var peakU = -1.0
        var peakPhi: Double? = null
        var peakTheta: Double? = null
        var totalWeighted = 0.0
        var insideWeighted = 0.0
        var apertureAreaWeighted = 0.0
        var apertureAmplitudeWeighted = 0.0
        var aperturePowerWeighted = 0.0

        var firstPhi: Double? = null
        var lastPhi: Double? = null
        var lastTheta: Double? = null
        var dPhiDeg: Double? = null
        var dThetaDeg: Double? = null
        var lastReportedPercent = -1
        val eRaw = mutableListOf<Pair<Double, Double>>()
        val hRaw = mutableListOf<Pair<Double, Double>>()
        val surfaceRaw = mutableListOf<Triple<Double, Double, Double>>()
        val apertureAmpSum = mutableMapOf<Int, Double>()
        val apertureAmpCount = mutableMapOf<Int, Int>()
        val apertureTheta = mutableMapOf<Int, Double>()

        // Phase analysis: azimuth sums are kept per theta, so the parser remains streaming.
        var phaseTheta = DoubleArray(0)
        var phaseXRe = DoubleArray(0); var phaseXIm = DoubleArray(0); var phaseXAbs = DoubleArray(0)
        var phaseYRe = DoubleArray(0); var phaseYIm = DoubleArray(0); var phaseYAbs = DoubleArray(0)
        var phaseRRe = DoubleArray(0); var phaseRIm = DoubleArray(0); var phaseRAbs = DoubleArray(0)
        var phaseLRe = DoubleArray(0); var phaseLIm = DoubleArray(0); var phaseLAbs = DoubleArray(0)
        var phasePowerX = 0.0; var phasePowerY = 0.0; var phasePowerR = 0.0; var phasePowerL = 0.0
        var stokesS0 = 0.0; var stokesS1 = 0.0; var stokesS2 = 0.0; var stokesS3 = 0.0

        fun finalizePowerGroups() {
            if (powers.isNotEmpty()) return
            var i = 0
            while (i + 3 < powerNumbers.size) {
                val prad = powerNumbers[i]
                val pacc = powerNumbers[i + 1]
                val pstim = powerNumbers[i + 2]
                val freqHz = powerNumbers[i + 3]
                if (freqHz > 1.0e6) {
                    powers += PowerBlock(prad, pacc, pstim, freqHz / 1.0e9)
                }
                i += 4
            }
        }

        fun reportProgress(force: Boolean = false) {
            val expected = nPhi * nTheta
            if (expected <= 0) return
            val p = ((rawSamples * 100L) / expected.toLong()).toInt().coerceIn(0, 100)
            if (force || p != lastReportedPercent) {
                lastReportedPercent = p
                onCalculationProgress(p)
            }
        }

        onCalculationProgress(0)

        while (true) {
            val raw = reader.readLine() ?: break
            val line = raw.trim()
            if (line.isEmpty()) continue

            if (remainingDataLines > 0) {
                if (parseThisBlock) {
                    val p = splitNumbers(line)
                    if (p.size >= 6) {
                        // CST FFS v3.0 order: Phi, Theta, Re(E_Theta), Im(E_Theta), Re(E_Phi), Im(E_Phi)
                        val phi = p[0]
                        val theta = p[1]
                        val reEt = p[2]
                        val imEt = p[3]
                        val reEp = p[4]
                        val imEp = p[5]
                        rawSamples++

                        lastPhi?.let { lp ->
                            val step = abs(phi - lp)
                            if (step > 1.0e-9 && (dPhiDeg == null || step < dPhiDeg!!)) dPhiDeg = step
                        }
                        lastTheta?.let { lt ->
                            val step = abs(theta - lt)
                            if (step > 1.0e-9 && (dThetaDeg == null || step < dThetaDeg!!)) dThetaDeg = step
                        }
                        lastPhi = phi
                        lastTheta = theta
                        if (firstPhi == null) firstPhi = phi

                        val duplicatePhiEndpoint = abs(phi - 360.0) < 1.0e-7 &&
                            (firstPhi?.let { abs(it) < 1.0e-7 } == true)

                        if (!duplicatePhiEndpoint) {
                            val u = reEt * reEt + imEt * imEt + reEp * reEp + imEp * imEp
                            if (u.isFinite() && u >= 0.0) {
                                usedSamples++
                                val w = sin(Math.toRadians(theta)).coerceAtLeast(0.0)
                                val weighted = u * w
                                totalWeighted += weighted
                                val sampleIndex = rawSamples - 1
                                val phiIndex = if (nTheta > 0) sampleIndex / nTheta else 0
                                val thetaIndex = if (nTheta > 0) sampleIndex % nTheta else 0

                                if (theta <= edgeAngleDeg) {
                                    insideWeighted += weighted

                                    // Prime-focus paraboloid mapping:
                                    // rho = 2 F tan(theta/2).
                                    // dA is proportional to sin(theta)/cos^4(theta/2) dtheta dphi.
                                    // Aperture field amplitude is proportional to
                                    // sqrt(U) * cos^2(theta/2), so F cancels in eta_taper.
                                    val cHalf = cos(Math.toRadians(theta) / 2.0)
                                    if (cHalf > 1.0e-12) {
                                        val c2 = cHalf * cHalf
                                        val areaW = w / (c2 * c2)
                                        val apertureAmp = sqrt(u) * c2
                                        apertureAreaWeighted += areaW
                                        apertureAmplitudeWeighted += apertureAmp * areaW
                                        aperturePowerWeighted += apertureAmp * apertureAmp * areaW

                                        // Azimuth-averaged aperture illumination used later by the
                                        // system 3D Hankel-transform model. Full-resolution FFS samples
                                        // are accumulated here; no display decimation is involved.
                                        apertureTheta[thetaIndex] = theta
                                        apertureAmpSum[thetaIndex] = (apertureAmpSum[thetaIndex] ?: 0.0) + apertureAmp
                                        apertureAmpCount[thetaIndex] = (apertureAmpCount[thetaIndex] ?: 0) + 1

                                        if (thetaIndex in phaseTheta.indices) {
                                            // Fixed Ludwig-3 x/y basis. This removes the azimuth rotation
                                            // of the spherical E_theta/E_phi basis before phase analysis.
                                            val phRad = Math.toRadians(phi)
                                            val cp = cos(phRad)
                                            val sp = sin(phRad)
                                            val exr = reEt * cp - reEp * sp
                                            val exi = imEt * cp - imEp * sp
                                            val eyr = reEt * sp + reEp * cp
                                            val eyi = imEt * sp + imEp * cp
                                            val invSqrt2 = 1.0 / sqrt(2.0)
                                            // R=(X-jY)/sqrt(2), L=(X+jY)/sqrt(2).
                                            val rr = (exr + eyi) * invSqrt2
                                            val ri = (exi - eyr) * invSqrt2
                                            val lr = (exr - eyi) * invSqrt2
                                            val li = (exi + eyr) * invSqrt2
                                            val ax = sqrt(exr * exr + exi * exi)
                                            val ay = sqrt(eyr * eyr + eyi * eyi)
                                            val ar = sqrt(rr * rr + ri * ri)
                                            val al = sqrt(lr * lr + li * li)

                                            phaseTheta[thetaIndex] = theta
                                            phaseXRe[thetaIndex] += exr * areaW; phaseXIm[thetaIndex] += exi * areaW; phaseXAbs[thetaIndex] += ax * areaW
                                            phaseYRe[thetaIndex] += eyr * areaW; phaseYIm[thetaIndex] += eyi * areaW; phaseYAbs[thetaIndex] += ay * areaW
                                            phaseRRe[thetaIndex] += rr * areaW; phaseRIm[thetaIndex] += ri * areaW; phaseRAbs[thetaIndex] += ar * areaW
                                            phaseLRe[thetaIndex] += lr * areaW; phaseLIm[thetaIndex] += li * areaW; phaseLAbs[thetaIndex] += al * areaW

                                            // Polarization state is estimated in the central 20 degree cone
                                            // (or the full intercepted cone when theta_edge is smaller).
                                            if (theta <= minOf(edgeAngleDeg, 20.0)) {
                                                val pw = w
                                                val px = exr * exr + exi * exi
                                                val py = eyr * eyr + eyi * eyi
                                                phasePowerX += px * pw
                                                phasePowerY += py * pw
                                                phasePowerR += (rr * rr + ri * ri) * pw
                                                phasePowerL += (lr * lr + li * li) * pw
                                                stokesS0 += (px + py) * pw
                                                stokesS1 += (px - py) * pw
                                                stokesS2 += 2.0 * (exr * eyr + exi * eyi) * pw
                                                stokesS3 += 2.0 * (exi * eyr - exr * eyi) * pw
                                            }
                                        }
                                    }
                                }
                                if (u > peakU) {
                                    peakU = u
                                    peakPhi = phi
                                    peakTheta = theta
                                }
                                val pn = ((phi % 360.0) + 360.0) % 360.0
                                if (abs(pn) < 1.0e-7) eRaw += theta to u
                                if (abs(pn - 90.0) < 1.0e-7) hRaw += theta to u

                                // Lightweight 3D display mesh. Full-resolution values above are
                                // still used for all integrals; only visualization is decimated.
                                val keepTheta = thetaIndex % 3 == 0 || thetaIndex == nTheta - 1
                                val keepPhi = phiIndex % 4 == 0 || phiIndex == nPhi - 2
                                if (keepTheta && keepPhi) surfaceRaw += Triple(theta, pn, u)
                            }
                        }
                        reportProgress()
                    }
                }

                remainingDataLines--
                if (remainingDataLines == 0 && parseThisBlock) {
                    selectedBlockFinished = true
                    reportProgress(force = true)
                    break // no need to scan later frequency blocks
                }
                continue
            }

            if (line.startsWith("// Position", ignoreCase = true)) {
                expectPosition = true
                continue
            }

            if (expectPosition && !line.startsWith("//")) {
                val pos = splitNumbers(line)
                if (pos.size >= 3) {
                    sourcePositionXM = pos[0]
                    sourcePositionYM = pos[1]
                    sourcePositionZM = pos[2]
                    expectPosition = false
                    continue
                }
            }

            if (line.startsWith("// Radiated/Accepted/Stimulated Power", ignoreCase = true)) {
                collectingPowers = true
                continue
            }

            if (line.startsWith("// >> Total #phi samples", ignoreCase = true)) {
                collectingPowers = false
                finalizePowerGroups()
                expectCounts = true
                continue
            }

            if (expectCounts && !line.startsWith("//")) {
                val nums = splitNumbers(line)
                if (nums.size >= 2) {
                    nPhi = nums[0].toInt()
                    nTheta = nums[1].toInt()
                    phaseTheta = DoubleArray(nTheta) { Double.NaN }
                    phaseXRe = DoubleArray(nTheta); phaseXIm = DoubleArray(nTheta); phaseXAbs = DoubleArray(nTheta)
                    phaseYRe = DoubleArray(nTheta); phaseYIm = DoubleArray(nTheta); phaseYAbs = DoubleArray(nTheta)
                    phaseRRe = DoubleArray(nTheta); phaseRIm = DoubleArray(nTheta); phaseRAbs = DoubleArray(nTheta)
                    phaseLRe = DoubleArray(nTheta); phaseLIm = DoubleArray(nTheta); phaseLAbs = DoubleArray(nTheta)
                    expectCounts = false
                }
                continue
            }

            if (line.startsWith("// >> Phi, Theta", ignoreCase = true)) {
                finalizePowerGroups()
                if (!selectionDone) {
                    if (powers.isNotEmpty()) {
                        selectedBlock = powers.indices.minByOrNull {
                            abs(powers[it].frequencyGHz - targetGHz)
                        } ?: 0
                        selectedPower = powers.getOrNull(selectedBlock)
                        selectedFrequencyGHz = selectedPower?.frequencyGHz
                    }
                    selectionDone = true
                }

                blockIndex++
                remainingDataLines = (nPhi * nTheta).coerceAtLeast(0)
                parseThisBlock = blockIndex == selectedBlock
                if (parseThisBlock) onCalculationProgress(0)
                continue
            }

            if (collectingPowers && !line.startsWith("//")) {
                line.toDoubleOrNull()?.let { powerNumbers += it }
            }
        }

        finalizePowerGroups()
        if (selectedPower == null && powers.isNotEmpty()) {
            selectedBlock = powers.indices.minByOrNull { abs(powers[it].frequencyGHz - targetGHz) } ?: 0
            selectedPower = powers.getOrNull(selectedBlock)
            selectedFrequencyGHz = selectedPower?.frequencyGHz
        }

        if (!selectedBlockFinished || rawSamples == 0 || usedSamples == 0) {
            return FfsResult(
                selectedFrequencyGHz = selectedFrequencyGHz,
                availableFrequenciesGHz = powers.map { it.frequencyGHz },
                sourcePositionXM = sourcePositionXM,
                sourcePositionYM = sourcePositionYM,
                sourcePositionZM = sourcePositionZM,
                sampleCount = rawSamples,
                usedSampleCount = usedSamples,
                peakThetaDeg = null,
                peakPhiDeg = null,
                directivityDbi = null,
                radiatedPowerW = selectedPower?.prad,
                acceptedPowerW = selectedPower?.pacc,
                radiationEfficiency = efficiency(selectedPower?.prad, selectedPower?.pacc),
                gainDbi = null,
                spilloverEfficiency = null,
                spilloverLossDb = null,
                taperEfficiency = null,
                taperLossDb = null,
                ePlane = emptyList(),
                hPlane = emptyList(),
                surface3D = emptyList(),
                apertureIllumination = emptyList(),
                phaseAnalysis = null,
                note = "Failed to read the selected numeric FFS block completely. Check the file format."
            )
        }

        val dPhi = Math.toRadians(dPhiDeg ?: if (nPhi > 1) 360.0 / (nPhi - 1) else 360.0)
        val dTheta = Math.toRadians(dThetaDeg ?: if (nTheta > 1) 180.0 / (nTheta - 1) else 180.0)
        val integral = totalWeighted * dPhi * dTheta

        val directivityDbi = if (integral > 0.0 && peakU > 0.0) {
            val d = 4.0 * PI * peakU / integral
            if (d.isFinite() && d > 0.0) 10.0 * log10(d) else null
        } else null

        val spill = if (totalWeighted > 0.0) {
            (insideWeighted / totalWeighted).coerceIn(0.0, 1.0)
        } else null


        val taper = if (apertureAreaWeighted > 0.0 && aperturePowerWeighted > 0.0) {
            val eta = (apertureAmplitudeWeighted * apertureAmplitudeWeighted) /
                (apertureAreaWeighted * aperturePowerWeighted)
            eta.coerceIn(0.0, 1.0)
        } else null

        val eff = efficiency(selectedPower?.prad, selectedPower?.pacc)
        val gain = if (directivityDbi != null && eff != null && eff > 0.0) {
            directivityDbi + 10.0 * log10(eff)
        } else directivityDbi

        onCalculationProgress(100)

        val note = buildString {
            if (selectedFrequencyGHz != null) {
                append("Selected %.6f GHz block, closest to %.6f GHz. ".format(selectedFrequencyGHz, targetGHz))
            } else {
                append("Frequency table not found; the first block was used. ")
            }
            append("FFS was processed as a stream; frequency blocks after the selected block are not read.")
        }

        fun normalized(raw: List<Pair<Double, Double>>): List<PatternPoint> {
            if (peakU <= 0.0) return emptyList()
            return raw.sortedBy { it.first }.map { (theta, u) ->
                val db = if (u > 0.0) 10.0 * log10(u / peakU) else -80.0
                PatternPoint(theta, db.coerceAtLeast(-80.0))
            }
        }

        fun normalized3D(raw: List<Triple<Double, Double, Double>>): List<Pattern3DPoint> {
            if (peakU <= 0.0) return emptyList()
            return raw.map { (theta, phi, u) ->
                val db = if (u > 0.0) 10.0 * log10(u / peakU) else -80.0
                Pattern3DPoint(theta, phi, db.coerceAtLeast(-80.0))
            }
        }

        val apertureProfileRaw = apertureTheta.keys.sorted().mapNotNull { idx ->
            val count = apertureAmpCount[idx] ?: 0
            val sum = apertureAmpSum[idx] ?: 0.0
            val theta = apertureTheta[idx]
            if (count > 0 && theta != null) ApertureIlluminationPoint(theta, sum / count.toDouble()) else null
        }
        val apertureMax = apertureProfileRaw.maxOfOrNull { it.amplitude } ?: 0.0
        val apertureProfile = if (apertureMax > 0.0) {
            apertureProfileRaw.map { it.copy(amplitude = it.amplitude / apertureMax) }
        } else emptyList()

        val phaseBins = phaseTheta.indices.mapNotNull { idx ->
            val theta = phaseTheta[idx]
            if (!theta.isFinite()) null else PhaseBin(
                thetaDeg = theta,
                xRe = phaseXRe[idx], xIm = phaseXIm[idx], xAbs = phaseXAbs[idx],
                yRe = phaseYRe[idx], yIm = phaseYIm[idx], yAbs = phaseYAbs[idx],
                rRe = phaseRRe[idx], rIm = phaseRIm[idx], rAbs = phaseRAbs[idx],
                lRe = phaseLRe[idx], lIm = phaseLIm[idx], lAbs = phaseLAbs[idx]
            )
        }
        val phaseAnalysis = PhaseAnalyzer.analyze(
            bins = phaseBins,
            frequencyGHz = selectedFrequencyGHz ?: targetGHz,
            powerX = phasePowerX, powerY = phasePowerY,
            powerR = phasePowerR, powerL = phasePowerL,
            stokesS0 = stokesS0, stokesS1 = stokesS1,
            stokesS2 = stokesS2, stokesS3 = stokesS3
        )

        return FfsResult(
            selectedFrequencyGHz = selectedFrequencyGHz,
            availableFrequenciesGHz = powers.map { it.frequencyGHz },
            sourcePositionXM = sourcePositionXM,
            sourcePositionYM = sourcePositionYM,
            sourcePositionZM = sourcePositionZM,
            sampleCount = rawSamples,
            usedSampleCount = usedSamples,
            peakThetaDeg = peakTheta,
            peakPhiDeg = peakPhi,
            directivityDbi = directivityDbi,
            radiatedPowerW = selectedPower?.prad,
            acceptedPowerW = selectedPower?.pacc,
            radiationEfficiency = eff,
            gainDbi = gain,
            spilloverEfficiency = spill,
            spilloverLossDb = spill?.takeIf { it > 0.0 }?.let { 10.0 * log10(it) },
            taperEfficiency = taper,
            taperLossDb = taper?.takeIf { it > 0.0 }?.let { 10.0 * log10(it) },
            ePlane = normalized(eRaw),
            hPlane = normalized(hRaw),
            surface3D = normalized3D(surfaceRaw),
            apertureIllumination = apertureProfile,
            phaseAnalysis = phaseAnalysis,
            note = note
        )
    }

    private fun efficiency(prad: Double?, pacc: Double?): Double? {
        return if (prad != null && pacc != null && pacc > 0.0) {
            (prad / pacc).coerceIn(0.0, 1.0)
        } else null
    }

    private fun splitNumbers(line: String): DoubleArray {
        val parts = line.split(Regex("\\s+"))
        val out = DoubleArray(parts.size)
        var count = 0
        for (part in parts) {
            val v = part.toDoubleOrNull() ?: continue
            out[count++] = v
        }
        return out.copyOf(count)
    }
}
