package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.sqrt

data class DishResult(
    val wavelengthM: Double,
    val focalM: Double,
    val depthM: Double,
    val areaM2: Double,
    val idealDirectivityLinear: Double,
    val idealDirectivityDbi: Double,
    val surfaceRmsM: Double,
    val ruzeEfficiency: Double,
    val ruzeLossDb: Double,
    val edgeAngleDeg: Double,
    val edgeDevM: Double,
    val foldDevM: Double,
    val diameterM: Double
)

object AntennaMath {
    private const val C = 299_792_458.0

    fun calculate(frequencyGHz: Double, diameterM: Double, fd: Double,
                  edgeDevM: Double, foldDevM: Double): DishResult {
        require(frequencyGHz > 0.0 && diameterM > 0.0 && fd > 0.0)
        val wavelength = C / (frequencyGHz * 1e9)
        val focal = diameterM * fd
        val depth = diameterM * diameterM / (16.0 * focal)
        val area = PI * diameterM * diameterM / 4.0
        val dIdeal = (PI * diameterM / wavelength) * (PI * diameterM / wavelength)
        val rms = deformationRms(edgeDevM, foldDevM)
        val x = 4.0 * PI * rms / wavelength
        val ruze = exp(-(x * x))
        // Verified prime-focus reflector subtended half-angle as seen from the focus.
        // This direct form remains correct for deep dishes where theta_edge can exceed 90 deg.
        val edgeAngle = Math.toDegrees(2.0 * atan(diameterM / (4.0 * focal)))
        return DishResult(wavelength, focal, depth, area, dIdeal, 10.0*log10(dIdeal), rms,
            ruze, if (ruze > 0.0) 10.0*log10(ruze) else Double.NEGATIVE_INFINITY,
            edgeAngle, edgeDevM, foldDevM, diameterM)
    }

    private fun deformationRms(edgeDevM: Double, foldDevM: Double): Double {
        val nr = 180; val np = 360
        var s = 0.0; var wsum = 0.0
        for (ir in 0 until nr) {
            val t = (ir + 0.5) / nr.toDouble()
            for (ip in 0 until np) {
                val phi = 2.0 * PI * (ip + 0.5) / np.toDouble()
                // Edge deviation rises toward rim. Fold deviation is a smooth four-lobed
                // perturbation used only as an RMS surface-error term; no panel counts required.
                val err = edgeDevM*t*t*t*t + foldDevM*t*t*(1.0-t)*(1.0-t)*cos(4.0*phi)
                s += err*err*t; wsum += t
            }
        }
        return if (wsum > 0.0) sqrt(s/wsum) else 0.0
    }
}
