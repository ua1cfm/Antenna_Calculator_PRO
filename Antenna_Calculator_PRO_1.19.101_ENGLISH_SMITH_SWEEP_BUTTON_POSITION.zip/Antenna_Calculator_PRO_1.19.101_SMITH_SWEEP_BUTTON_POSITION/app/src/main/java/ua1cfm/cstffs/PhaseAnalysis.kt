package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Phase analysis of the feed over the angular region intercepted by a prime-focus reflector.
 *
 * E_theta/E_phi are first transformed to a fixed Ludwig-3 x/y basis in FfsParser.
 * FfsParser accumulates four candidate polarization components (X, Y, R, L) per theta.
 * The phase-center search is then inexpensive because an axial reference shift depends only on theta.
 */
data class PhaseProfilePoint(
    val thetaDeg: Double,
    val phaseDeg: Double,
    val amplitude: Double
)

data class PhaseBin(
    val thetaDeg: Double,
    val xRe: Double, val xIm: Double, val xAbs: Double,
    val yRe: Double, val yIm: Double, val yAbs: Double,
    val rRe: Double, val rIm: Double, val rAbs: Double,
    val lRe: Double, val lIm: Double, val lAbs: Double
)

data class PhaseAnalysisResult(
    val polarizationLabel: String,
    val componentLabel: String,
    val coPolarFraction: Double,
    val optimalPhaseCenterZM: Double,
    val phaseEfficiency: Double,
    val phaseLossDb: Double,
    val referenceRmsPhaseDeg: Double,
    val optimizedPhaseEfficiency: Double,
    val optimizedPhaseLossDb: Double,
    val optimizedRmsPhaseDeg: Double,
    val maxProfilePhaseErrorDeg: Double,
    val searchHalfRangeM: Double,
    val boundaryWarning: Boolean,
    val profile: List<PhaseProfilePoint>,
    val note: String
)

object PhaseAnalyzer {
    private const val C0 = 299_792_458.0

    fun analyze(
        bins: List<PhaseBin>,
        frequencyGHz: Double,
        powerX: Double,
        powerY: Double,
        powerR: Double,
        powerL: Double,
        stokesS0: Double,
        stokesS1: Double,
        stokesS2: Double,
        stokesS3: Double
    ): PhaseAnalysisResult? {
        if (bins.isEmpty() || frequencyGHz <= 0.0) return null

        val s0 = stokesS0.coerceAtLeast(0.0)
        val linearity = if (s0 > 0.0) sqrt(stokesS1 * stokesS1 + stokesS2 * stokesS2) / s0 else 0.0
        val circularity = if (s0 > 0.0) abs(stokesS3) / s0 else 0.0
        val orientationDeg = 0.5 * Math.toDegrees(atan2(stokesS2, stokesS1))

        val circular = circularity >= 0.60 && circularity > linearity
        val linear = linearity >= 0.60 && linearity >= circularity

        val component = when {
            circular -> if (powerR >= powerL) 2 else 3
            linear -> if (powerX >= powerY) 0 else 1
            else -> listOf(powerX, powerY, powerR, powerL).indices.maxByOrNull {
                listOf(powerX, powerY, powerR, powerL)[it]
            } ?: 0
        }

        val polarizationLabel = when {
            circular -> if (powerR >= powerL) {
                "Circular, R component dominant"
            } else {
                "Circular, L component dominant"
            }
            linear -> "Linear, angle ≈ %.1f°".format(orientationDeg)
            else -> "Elliptical/mixed"
        }

        val componentLabel = when (component) {
            0 -> "Ludwig-3 X"
            1 -> "Ludwig-3 Y"
            2 -> "Ludwig-3 R"
            else -> "Ludwig-3 L"
        }

        val polDenom = when (component) {
            0, 1 -> powerX + powerY
            else -> powerR + powerL
        }
        val selectedPower = when (component) {
            0 -> powerX
            1 -> powerY
            2 -> powerR
            else -> powerL
        }
        val coFraction = if (polDenom > 0.0) (selectedPower / polDenom).coerceIn(0.0, 1.0) else 0.0

        fun re(b: PhaseBin) = when (component) {
            0 -> b.xRe; 1 -> b.yRe; 2 -> b.rRe; else -> b.lRe
        }
        fun im(b: PhaseBin) = when (component) {
            0 -> b.xIm; 1 -> b.yIm; 2 -> b.rIm; else -> b.lIm
        }
        fun amp(b: PhaseBin) = when (component) {
            0 -> b.xAbs; 1 -> b.yAbs; 2 -> b.rAbs; else -> b.lAbs
        }

        val ampTotal = bins.sumOf { amp(it) }
        if (ampTotal <= 0.0 || !ampTotal.isFinite()) return null

        val wavelength = C0 / (frequencyGHz * 1.0e9)
        val k = 2.0 * PI / wavelength
        val halfRange = 2.0 * wavelength

        // CST far-field phase reference shift along +Z. A common constant phase is removed
        // by using (cos(theta)-1), therefore only phase curvature matters.
        fun coherence(z: Double): Double {
            var sr = 0.0
            var si = 0.0
            for (b in bins) {
                val theta = Math.toRadians(b.thetaDeg)
                val ph = -k * z * (cos(theta) - 1.0)
                val c = cos(ph)
                val s = sin(ph)
                val br = re(b)
                val bi = im(b)
                sr += br * c - bi * s
                si += br * s + bi * c
            }
            return (sr * sr + si * si) / (ampTotal * ampTotal)
        }

        // Coarse scan: 801 points across ±2 lambda => dz = lambda/200.
        val n = 800
        var bestI = 0
        var bestZ = -halfRange
        var bestEta = -1.0
        for (i in 0..n) {
            val z = -halfRange + (2.0 * halfRange) * i / n.toDouble()
            val eta = coherence(z)
            if (eta > bestEta) {
                bestEta = eta
                bestZ = z
                bestI = i
            }
        }

        // Local golden-section refinement around the winning coarse cell.
        val dz = 2.0 * halfRange / n.toDouble()
        var a = max(-halfRange, bestZ - 2.0 * dz)
        var b = kotlin.math.min(halfRange, bestZ + 2.0 * dz)
        val gr = (sqrt(5.0) - 1.0) / 2.0
        var c1 = b - gr * (b - a)
        var c2 = a + gr * (b - a)
        var f1 = coherence(c1)
        var f2 = coherence(c2)
        repeat(36) {
            if (f1 < f2) {
                a = c1; c1 = c2; f1 = f2
                c2 = a + gr * (b - a); f2 = coherence(c2)
            } else {
                b = c2; c2 = c1; f2 = f1
                c1 = b - gr * (b - a); f1 = coherence(c1)
            }
        }
        val refinedZ = (a + b) / 2.0
        val referenceEta = coherence(0.0).coerceIn(0.0, 1.0)
        val optimizedEta = coherence(refinedZ).coerceIn(0.0, 1.0)
        val boundary = bestI <= 2 || bestI >= n - 2 || abs(refinedZ) > 0.985 * halfRange

        // Overall coherent phase at optimum; used as the zero reference for the theta profile.
        var globalRe = 0.0
        var globalIm = 0.0
        for (bin in bins) {
            val theta = Math.toRadians(bin.thetaDeg)
            val ph = -k * refinedZ * (cos(theta) - 1.0)
            val c = cos(ph); val s = sin(ph)
            globalRe += re(bin) * c - im(bin) * s
            globalIm += re(bin) * s + im(bin) * c
        }
        val globalPhase = atan2(globalIm, globalRe)

        val rawProfile = bins.mapNotNull { bin ->
            val br0 = re(bin); val bi0 = im(bin)
            val rawAmp = sqrt(br0 * br0 + bi0 * bi0)
            if (rawAmp <= 1.0e-15) return@mapNotNull null
            val theta = Math.toRadians(bin.thetaDeg)
            val ph = -k * refinedZ * (cos(theta) - 1.0)
            val c = cos(ph); val s = sin(ph)
            val br = br0 * c - bi0 * s
            val bi = br0 * s + bi0 * c
            var d = Math.toDegrees(atan2(bi, br) - globalPhase)
            while (d > 180.0) d -= 360.0
            while (d < -180.0) d += 360.0
            PhaseProfilePoint(bin.thetaDeg, d, rawAmp)
        }
        val maxAmp = rawProfile.maxOfOrNull { it.amplitude } ?: 0.0
        val profile = if (maxAmp > 0.0) rawProfile.map { it.copy(amplitude = it.amplitude / maxAmp) } else rawProfile
        val maxProfile = profile.maxOfOrNull { abs(it.phaseDeg) } ?: 0.0

        // Circular-statistics equivalent RMS. For small errors this converges to ordinary RMS:
        // eta_phase = R^2, R = exp(-sigma_phi^2/2) => sigma_phi = sqrt(-ln(eta_phase)).
        fun rmsDegFromEta(e: Double): Double {
            val rmsRad = if (e > 1.0e-15) sqrt((-ln(e)).coerceAtLeast(0.0)) else Double.POSITIVE_INFINITY
            return Math.toDegrees(rmsRad)
        }
        val referenceRmsDeg = rmsDegFromEta(referenceEta)
        val optimizedRmsDeg = rmsDegFromEta(optimizedEta)
        val referenceLossDb = if (referenceEta > 0.0) 10.0 * log10(referenceEta) else Double.NEGATIVE_INFINITY
        val optimizedLossDb = if (optimizedEta > 0.0) 10.0 * log10(optimizedEta) else Double.NEGATIVE_INFINITY

        val note = buildString {
            append("Phase center found by maximizing coherent summation of the aperture field. ")
            append("RMS is the equivalent circular RMS from eta_phase; the profile is averaged over azimuth. ")
            if (boundary) append("WARNING: maximum is close to the ±2λ search boundary; Z requires an extended search.")
        }

        return PhaseAnalysisResult(
            polarizationLabel = polarizationLabel,
            componentLabel = componentLabel,
            coPolarFraction = coFraction,
            optimalPhaseCenterZM = refinedZ,
            phaseEfficiency = referenceEta,
            phaseLossDb = referenceLossDb,
            referenceRmsPhaseDeg = referenceRmsDeg,
            optimizedPhaseEfficiency = optimizedEta,
            optimizedPhaseLossDb = optimizedLossDb,
            optimizedRmsPhaseDeg = optimizedRmsDeg,
            maxProfilePhaseErrorDeg = maxProfile,
            searchHalfRangeM = halfRange,
            boundaryWarning = boundary,
            profile = profile,
            note = note
        )
    }
}
