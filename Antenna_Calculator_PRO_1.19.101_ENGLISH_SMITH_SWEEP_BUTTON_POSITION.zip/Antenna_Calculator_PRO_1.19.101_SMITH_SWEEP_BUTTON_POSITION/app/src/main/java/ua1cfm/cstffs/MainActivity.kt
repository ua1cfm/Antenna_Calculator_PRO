package ua1cfm.cstffs

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CalculatorApp()
            }
        }
    }
}

@Composable
private fun CalculatorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var frequency by remember { mutableStateOf("8.4") }
    var diameter by remember { mutableStateOf("1.0") }
    var fd by remember { mutableStateOf("0.38") }
    var edgeDevMm by remember { mutableStateOf("0.0") }
    var foldDevMm by remember { mutableStateOf("0.0") }

    var dishResult by remember { mutableStateOf<DishResult?>(null) }
    var ffsResult by remember { mutableStateOf<FfsResult?>(null) }
    var selectedFfsUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileFormat by remember { mutableStateOf("FFS") }
    var status by remember { mutableStateOf("Ready. Open a CST .ffs or HFSS .ffd file.") }

    var isBusy by remember { mutableStateOf(false) }
    var fileProgress by remember { mutableStateOf(0) }
    var calculationProgress by remember { mutableStateOf(0) }
    var activeTab by remember { mutableStateOf(0) }
    var designerMaaModel by remember { mutableStateOf<MaaModel?>(null) }

    fun currentDish(): DishResult? {
        val f = frequency.toDoubleOrNull()
        val d = diameter.toDoubleOrNull()
        val ratio = fd.toDoubleOrNull()
        val edge = edgeDevMm.toDoubleOrNull()
        val fold = foldDevMm.toDoubleOrNull()
        if (f == null || d == null || ratio == null || edge == null || fold == null || f <= 0.0 || d <= 0.0 || ratio <= 0.0
        ) return null

        return AntennaMath.calculate(
            frequencyGHz = f,
            diameterM = d,
            fd = ratio,
            edgeDevM = edge / 1000.0,
            foldDevM = fold / 1000.0
        )
    }

    fun querySize(uri: Uri): Long {
        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    fun processPattern(uri: Uri, target: Double, dish: DishResult, format: String) {
        dishResult = dish
        ffsResult = null
        isBusy = true
        fileProgress = 0
        calculationProgress = 0
        status = "Opening $format for %.6f GHz...".format(target)

        scope.launch {
            val parsed = withContext(Dispatchers.IO) {
                runCatching {
                    val totalBytes = querySize(uri)
                    val source = context.contentResolver.openInputStream(uri)
                        ?: error("Failed to open file.")

                    val progressSource = ProgressInputStream(source, totalBytes) { percent ->
                        scope.launch(Dispatchers.Main) {
                            fileProgress = percent
                        }
                    }

                    BufferedReader(InputStreamReader(progressSource), 256 * 1024).use { reader ->
                        val progress: (Int) -> Unit = { percent ->
                            scope.launch(Dispatchers.Main) {
                                calculationProgress = percent
                                if (percent > 0) status = "Calculating $format: $percent%"
                            }
                        }
                        if (format == "FFD") {
                            HfssFfdParser.parse(reader, target, dish.edgeAngleDeg, progress)
                        } else {
                            FfsParser.parse(reader, target, dish.edgeAngleDeg, progress)
                        }
                    }
                }
            }

            parsed.onSuccess {
                fileProgress = 100
                calculationProgress = 100
                ffsResult = it
                isBusy = false
                status = "Done: %.6f GHz → selected block %s GHz"
                    .format(target, it.selectedFrequencyGHz?.let { f -> "%.6f".format(f) } ?: "?")
            }.onFailure {
                isBusy = false
                status = "$format error: ${it.message ?: "unknown error"}"
            }
        }
    }

    fun acceptPickedUri(uri: Uri?, format: String) {
        if (uri == null) return
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val target = frequency.toDoubleOrNull()
        val dish = currentDish()
        if (target == null || dish == null) {
            status = "First check the frequency and paraboloid parameters."
            return
        }
        selectedFfsUri = uri
        selectedFileFormat = format
        processPattern(uri, target, dish, format)
    }

    val ffsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        acceptPickedUri(uri, "FFS")
    }
    val ffdPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        acceptPickedUri(uri, "FFD")
    }

    // Dish-only calculations are refreshed immediately when any geometry field changes.
    // FFS is deliberately invalidated because Spillover depends on the new edge angle.
    LaunchedEffect(frequency, diameter, fd, edgeDevMm, foldDevMm) {
        currentDish()?.let { dishResult = it }
        if (selectedFfsUri != null && !isBusy) {
            ffsResult = null
            status = "Parameters changed. The paraboloid has been updated; press ‘Calculate’ to recalculate the feed file."
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Antenna Calculator PRO", style = MaterialTheme.typography.headlineSmall)
        Text("Version 1.19.101 English — UA1CFM", style = MaterialTheme.typography.bodySmall)

        // 1.19.91 UI refresh: navigation follows user tasks rather than internal modules.
        val antennaSection = activeTab == 0 || activeTab == 1 || activeTab == 2 || activeTab == 5
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { if (!antennaSection) activeTab = 5 },
                    enabled = !antennaSection
                ) { AutoFitButtonText("ANTENNA") }
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { activeTab = 6 },
                    enabled = activeTab != 6
                ) { AutoFitButtonText("YAGI") }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { activeTab = 4 },
                    enabled = activeTab != 4
                ) { AutoFitButtonText("LiteVNA64") }
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = { activeTab = 3 },
                    enabled = activeTab != 3
                ) { AutoFitButtonText("TOOLS") }
            }
            if (antennaSection) {
                Text("Antenna workspace", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(modifier = Modifier.weight(1f), onClick = { activeTab = 0 }, enabled = activeTab != 0) { AutoFitButtonText("CALC") }
                    Button(modifier = Modifier.weight(1f), onClick = { activeTab = 1 }, enabled = activeTab != 1) { AutoFitButtonText("2D") }
                    Button(modifier = Modifier.weight(1f), onClick = { activeTab = 2 }, enabled = activeTab != 2) { AutoFitButtonText("3D") }
                    Button(modifier = Modifier.weight(1f), onClick = { activeTab = 5 }, enabled = activeTab != 5) { AutoFitButtonText("MAA") }
                }
            }
        }

        if (activeTab == 0) {
        ParameterField("Frequency, GHz", frequency, enabled = !isBusy) { frequency = it }
        ParameterField("Diameter D, m", diameter, enabled = !isBusy) { diameter = it }
        ParameterField("F/D", fd, enabled = !isBusy) { fd = it }
        ParameterField("EdgeDev, mm", edgeDevMm, enabled = !isBusy) { edgeDevMm = it }
        ParameterField("FoldDev, mm", foldDevMm, enabled = !isBusy) { foldDevMm = it }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = !isBusy,
                onClick = {
                    val target = frequency.toDoubleOrNull()
                    val dish = currentDish()
                    if (dish == null || target == null) {
                        status = "Error: check the entered numbers."
                    } else {
                        dishResult = dish
                        val uri = selectedFfsUri
                        if (uri != null) processPattern(uri, target, dish, selectedFileFormat)
                        else status = "Paraboloid parameters calculated."
                    }
                }
            ) {
                AutoFitButtonText("Calculate")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !isBusy,
                    onClick = { ffsPicker.launch(arrayOf("*/*")) }
                ) {
                    AutoFitButtonText("Open FFS")
                }

                Button(
                    modifier = Modifier.weight(1f),
                    enabled = !isBusy,
                    onClick = { ffdPicker.launch(arrayOf("*/*")) }
                ) {
                    AutoFitButtonText("Open FFD")
                }
            }
        }

        Text(status, style = MaterialTheme.typography.bodyMedium)

        if (isBusy || fileProgress > 0 || calculationProgress > 0) {
            ProgressCard(fileProgress, calculationProgress, isBusy)
        }

        dishResult?.let { DishCard(it) }
        ffsResult?.let { result ->
            FfsCard(result)
            FeedDiagnosticsCard(result, dishResult?.edgeAngleDeg)
            result.phaseAnalysis?.let { PhaseCard(it, result.sourcePositionZM) }
        }

        if (dishResult != null && ffsResult != null) {
            SystemCard(dishResult!!, ffsResult!!)
        }

        } else if (activeTab == 1) {
            DiagramTab(dishResult, ffsResult)
        } else if (activeTab == 2) {
            ThreeDAndExportTab(dishResult, ffsResult)
        } else if (activeTab == 3) {
            HamToolsTab()
        } else if (activeTab == 4) {
            TouchstoneTab()
        } else if (activeTab == 5) {
            YagiMaaTab(injectedModel = designerMaaModel)
        } else {
            YagiDesignerTab { generatedModel ->
                designerMaaModel = generatedModel
                activeTab = 5
            }
        }

        Text(
            "© 2026 UA1CFM • Antenna Calculator PRO v1.19.101",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun HamToolsTab() {
    var dbm by remember { mutableStateOf("30") }
    var freqMHz by remember { mutableStateOf("1296") }
    var distanceKm by remember { mutableStateOf("100") }
    var velocityFactor by remember { mutableStateOf("0.95") }
    var swr by remember { mutableStateOf("1.5") }
    var impedance by remember { mutableStateOf("50") }
    var powerW by remember { mutableStateOf("1") }
    var txDbm by remember { mutableStateOf("40") }
    var gainDbi by remember { mutableStateOf("10") }
    var cableLossDb by remember { mutableStateOf("1") }
    var bandwidthHz by remember { mutableStateOf("2400") }
    var tempK by remember { mutableStateOf("290") }
    var nfDb by remember { mutableStateOf("1") }
    var conductivity by remember { mutableStateOf("5.8e7") }
    var rxGainDbi by remember { mutableStateOf("10") }
    var rxLossDb by remember { mutableStateOf("1") }
    var helixTurns by remember { mutableStateOf("5") }
    var epsR by remember { mutableStateOf("2.2") }
    var zLoad by remember { mutableStateOf("100") }
    var fresnelD1Km by remember { mutableStateOf("50") }

    Text("Amateur radio calculators", style = MaterialTheme.typography.titleLarge)

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("RF Power: dBm ↔ W ↔ mW", style = MaterialTheme.typography.titleMedium)
            ParameterField("Power, dBm", dbm, true) { dbm = it }
            dbm.toDoubleOrNull()?.let {
                val w = HamTools.dbmToW(it)
                Text("${fmt(it, 3)} dBm = ${hamNum(w, "W")} = ${hamNum(w * 1000.0, "mW")}")
            }
            ParameterField("Power into 50 Ω, W", powerW, true) { powerW = it }
            ParameterField("Resistance, Ω", impedance, true) { impedance = it }
            val w = powerW.toDoubleOrNull()
            val r = impedance.toDoubleOrNull()
            if (w != null && r != null && w >= 0.0 && r > 0.0) {
                val vrms = HamTools.vrmsFromW(w, r)
                Text("P = ${fmt(HamTools.wToDbm(w), 3)} dBm")
                Text("Vrms = ${hamNum(vrms, "V")}   Vpeak = ${hamNum(HamTools.vPeakFromVrms(vrms), "V")}   Vpp = ${hamNum(HamTools.vPpFromVrms(vrms), "V")}")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Frequency, wavelength and antennas", style = MaterialTheme.typography.titleMedium)
            ParameterField("Frequency, MHz", freqMHz, true) { freqMHz = it }
            ParameterField("Velocity factor", velocityFactor, true) { velocityFactor = it }
            val f = freqMHz.toDoubleOrNull()
            val vf = velocityFactor.toDoubleOrNull()
            if (f != null && f > 0.0 && vf != null && vf > 0.0) {
                val lambda = HamTools.wavelengthM(f)
                Text("λ = ${hamNum(lambda, "m")}   (${fmt(lambda * 1000.0, 3)} mm)")
                Text("¼λ × VF = ${hamNum(lambda * 0.25 * vf, "m")}")
                Text("½λ × VF = ${hamNum(lambda * 0.50 * vf, "m")}")
                Text("⅝λ × VF = ${hamNum(lambda * 0.625 * vf, "m")}")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Propagation / FSPL / EIRP", style = MaterialTheme.typography.titleMedium)
            ParameterField("Distance, km", distanceKm, true) { distanceKm = it }
            val f = freqMHz.toDoubleOrNull()
            val d = distanceKm.toDoubleOrNull()
            if (f != null && f > 0.0 && d != null && d > 0.0)
                Text("FSPL = ${fmt(HamTools.fsplDb(f, d), 3)} dB")
            ParameterField("TX, dBm", txDbm, true) { txDbm = it }
            ParameterField("Antenna gain, dBi", gainDbi, true) { gainDbi = it }
            ParameterField("Cable loss, dB", cableLossDb, true) { cableLossDb = it }
            val tx = txDbm.toDoubleOrNull(); val g = gainDbi.toDoubleOrNull(); val loss = cableLossDb.toDoubleOrNull()
            if (tx != null && g != null && loss != null) {
                val eirp = HamTools.eirpDbm(tx, g, loss)
                Text("EIRP = ${fmt(eirp, 3)} dBm = ${hamNum(HamTools.dbmToW(eirp), "W")}")
                Text("ERP ≈ ${fmt(HamTools.erpDbmFromEirp(eirp), 3)} dBm")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SWR / Return Loss", style = MaterialTheme.typography.titleMedium)
            ParameterField("SWR", swr, true) { swr = it }
            swr.toDoubleOrNull()?.takeIf { it >= 1.0 }?.let {
                val gamma = HamTools.gammaFromSwr(it)
                Text("|Γ| = ${fmt(gamma, 6)}")
                Text("Return Loss = ${fmt(HamTools.returnLossDbFromGamma(gamma), 3)} dB")
                Text("Mismatch Loss = ${fmt(HamTools.mismatchLossDbFromGamma(gamma), 3)} dB")
                Text("Reflected power = ${fmt(gamma * gamma * 100.0, 3)} %")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Noise", style = MaterialTheme.typography.titleMedium)
            ParameterField("Bandwidth B, Hz", bandwidthHz, true) { bandwidthHz = it }
            ParameterField("Temperature T, K", tempK, true) { tempK = it }
            val bw = bandwidthHz.toDoubleOrNull(); val tk = tempK.toDoubleOrNull()
            if (bw != null && bw > 0.0 && tk != null && tk > 0.0)
                Text("kTB = ${fmt(HamTools.noisePowerDbm(bw, tk), 3)} dBm")
            ParameterField("Noise Figure, dB", nfDb, true) { nfDb = it }
            nfDb.toDoubleOrNull()?.let {
                Text("Noise Factor = ${fmt(HamTools.noiseFactorFromNfDb(it), 5)}")
                Text("Equivalent noise temperature = ${fmt(HamTools.noiseTemperatureKFromNfDb(it), 2)} K")
            }
            Text("At 290 K: ≈ −173.98 dBm/Hz")
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Skin depth", style = MaterialTheme.typography.titleMedium)
            ParameterField("Conductivity σ, S/m", conductivity, true) { conductivity = it }
            val f = freqMHz.toDoubleOrNull(); val sigma = conductivity.toDoubleOrNull()
            if (f != null && f > 0.0 && sigma != null && sigma > 0.0) {
                val delta = HamTools.skinDepthM(f, sigma)
                Text("δ = ${fmt(delta * 1e6, 3)} µm")
            }
            Text("Copper ≈ 5.8×10⁷ S/m; aluminum ≈ 3.5×10⁷ S/m", style = MaterialTheme.typography.bodySmall)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Link budget", style = MaterialTheme.typography.titleMedium)
            ParameterField("RX gain, dBi", rxGainDbi, true) { rxGainDbi = it }
            ParameterField("RX losses, dB", rxLossDb, true) { rxLossDb = it }
            val f = freqMHz.toDoubleOrNull(); val d = distanceKm.toDoubleOrNull()
            val tx = txDbm.toDoubleOrNull(); val gt = gainDbi.toDoubleOrNull(); val lt = cableLossDb.toDoubleOrNull()
            val gr = rxGainDbi.toDoubleOrNull(); val lr = rxLossDb.toDoubleOrNull()
            if (f != null && d != null && tx != null && gt != null && lt != null && gr != null && lr != null && f > 0 && d > 0) {
                val fspl = HamTools.fsplDb(f, d)
                val pr = tx + gt - lt - fspl + gr - lr
                Text("Prx ≈ ${fmt(pr, 2)} dBm   (${hamNum(HamTools.dbmToW(pr), "W")})")
                val np = bandwidthHz.toDoubleOrNull()?.let { bw -> nfDb.toDoubleOrNull()?.let { nf -> HamTools.noisePowerDbm(bw, 290.0) + nf } }
                np?.let { Text("SNR ≈ ${fmt(pr - it, 2)} dB for the specified B and NF") }
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Transmission lines / matching", style = MaterialTheme.typography.titleMedium)
            ParameterField("Load ZL, Ω", zLoad, true) { zLoad = it }
            val z0 = impedance.toDoubleOrNull(); val zl = zLoad.toDoubleOrNull(); val f = freqMHz.toDoubleOrNull(); val vf = velocityFactor.toDoubleOrNull()
            if (z0 != null && zl != null && z0 > 0 && zl > 0) Text("¼λ transformer: Zt = ${fmt(kotlin.math.sqrt(z0 * zl), 3)} Ω")
            if (f != null && vf != null && f > 0 && vf > 0) Text("¼λ section length = ${fmt(HamTools.wavelengthM(f) * vf * 250.0, 2)} mm")
            ParameterField("Substrate εr", epsR, true) { epsR = it }
            epsR.toDoubleOrNull()?.takeIf { it > 1.0 }?.let { er -> Text("Approximate microstrip VF ≈ ${fmt(1.0 / kotlin.math.sqrt((er + 1.0) / 2.0), 4)}") }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Helical antenna (axial mode)", style = MaterialTheme.typography.titleMedium)
            ParameterField("Number of turns N", helixTurns, true) { helixTurns = it }
            val f = freqMHz.toDoubleOrNull(); val n = helixTurns.toDoubleOrNull()
            if (f != null && n != null && f > 0 && n > 0) {
                val l = HamTools.wavelengthM(f)
                Text("Recommended circumference C ≈ λ = ${fmt(l * 1000, 2)} mm")
                Text("Helix diameter ≈ ${fmt(l / kotlin.math.PI * 1000, 2)} mm")
                Text("Pitch ≈ 0.23λ = ${fmt(l * .23 * 1000, 2)} mm")
                Text("Length ≈ ${fmt(n * l * .23 * 1000, 2)} mm")
                Text("Estimated gain ≈ ${fmt(10.0 * kotlin.math.log10(15.0 * n * .23), 2)} dBi")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("First Fresnel zone", style = MaterialTheme.typography.titleMedium)
            ParameterField("Distance to point d1, km", fresnelD1Km, true) { fresnelD1Km = it }
            val f = freqMHz.toDoubleOrNull(); val dt = distanceKm.toDoubleOrNull(); val d1 = fresnelD1Km.toDoubleOrNull()
            if (f != null && dt != null && d1 != null && f > 0 && dt > 0 && d1 > 0 && d1 < dt) {
                val rF = 17.32 * kotlin.math.sqrt(d1 * (dt-d1) / (f/1000.0 * dt))
                Text("F1 radius ≈ ${fmt(rF, 2)} m; 60% clearance ≈ ${fmt(.6*rF, 2)} m")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Fundamental constants", style = MaterialTheme.typography.titleMedium)
            Text("c = 299 792 458 m/s")
            Text("Z₀ = ${fmt(HamTools.Z_0, 6)} Ω")
            Text("k = 1.380649×10⁻²³ J/K")
            Text("μ₀ = 1.25663706212×10⁻⁶ H/m")
            Text("ε₀ = 8.8541878128×10⁻¹² F/m")
            Text("e = 1.602176634×10⁻¹⁹ C")
            Text("T₀ = 290 K")
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Popular amateur radio bands", style = MaterialTheme.typography.titleMedium)
            COMMON_HAM_BANDS.forEach {
                val lm = HamTools.wavelengthM(it.referenceMHz)
                Text("${it.name}: ${fmt(it.referenceMHz, 3)} MHz   λ≈${fmt(lm, 4)} m")
            }
            Text("Frequencies are convenient reference values, not boundaries of a national frequency allocation plan.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun hamNum(v: Double, unit: String): String {
    if (!v.isFinite()) return "$v $unit"
    val a = kotlin.math.abs(v)
    return when {
        a == 0.0 -> "0 $unit"
        a >= 1000.0 || a < 0.001 -> "%.6e %s".format(v, unit)
        else -> "${fmt(v, 6)} $unit"
    }
}

@Composable
private fun ProgressCard(filePercent: Int, calcPercent: Int, busy: Boolean) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(if (busy) "Progress" else "Last operation", style = MaterialTheme.typography.titleMedium)
            Text("Opening/reading file: $filePercent%")
            LinearProgressIndicator(
                progress = { filePercent.coerceIn(0, 100) / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Calculating selected block: $calcPercent%")
            LinearProgressIndicator(
                progress = { calcPercent.coerceIn(0, 100) / 100f },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ParameterField(
    label: String,
    value: String,
    enabled: Boolean,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun DishCard(r: DishResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("Paraboloid", style = MaterialTheme.typography.titleMedium)
            Text("λ₀ = ${fmt(r.wavelengthM * 1000.0, 3)} mm")
            Text("F = ${fmt(r.focalM, 4)} m")
            Text("Depth = ${fmt(r.depthM, 4)} m")
            Text("Aperture area = ${fmt(r.areaM2, 4)} m²")
            Text("Ideal directivity = ${fmt(r.idealDirectivityDbi, 2)} dBi")
            Text("EdgeDev = ${fmt(r.edgeDevM * 1000.0, 3)} mm")
            Text("FoldDev = ${fmt(r.foldDevM * 1000.0, 3)} mm")
            Text("Surface RMS = ${fmt(r.surfaceRmsM * 1000.0, 3)} mm")
            Text("Ruze efficiency = ${fmt(r.ruzeEfficiency * 100.0, 2)} %")
            Text("Ruze loss = ${fmt(r.ruzeLossDb, 2)} dB")
            Text("Edge angle from focus = ${fmt(r.edgeAngleDeg, 2)}°")
        }
    }
}

@Composable
private fun FfsCard(r: FfsResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("Feed file (FFS/FFD)", style = MaterialTheme.typography.titleMedium)
            Text("Points in selected block = ${r.sampleCount}")
            Text("Points used in integral = ${r.usedSampleCount}")
            if (r.availableFrequenciesGHz.isNotEmpty()) {
                Text("Frequencies available in the input file", style = MaterialTheme.typography.titleSmall)
                Text(
                    r.availableFrequenciesGHz.joinToString(separator = " • ") {
                        "${fmt(it, 6)} GHz"
                    }
                )
                Text("Total frequency blocks: ${r.availableFrequenciesGHz.size}")
            } else {
                Text(
                    "No frequency list is present in the file; the UI frequency is used.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            r.selectedFrequencyGHz?.let { Text("Selected for calculation = ${fmt(it, 6)} GHz") }
            if (r.sourcePositionXM != null || r.sourcePositionYM != null || r.sourcePositionZM != null) {
                Text("Origin position in FFS", style = MaterialTheme.typography.titleSmall)
                Text(
                    "X = ${fmt((r.sourcePositionXM ?: 0.0) * 1000.0, 2)} mm   " +
                        "Y = ${fmt((r.sourcePositionYM ?: 0.0) * 1000.0, 2)} mm   " +
                        "Z = ${fmt((r.sourcePositionZM ?: 0.0) * 1000.0, 2)} mm"
                )
                Text(
                    "These are the origin coordinates stored in the FFS; this is NOT a calculated phase-center offset.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    "Origin position in file: not specified",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            r.peakThetaDeg?.let { Text("Theta max = ${fmt(it, 3)}°") }
            r.peakPhiDeg?.let { Text("Phi max = ${fmt(it, 3)}°") }
            r.directivityDbi?.let { Text("Directivity ≈ ${fmt(it, 2)} dBi") }
            r.gainDbi?.let { Text("Gain ≈ ${fmt(it, 2)} dBi") }
            r.radiatedPowerW?.let { Text("Prad ≈ ${fmt(it, 6)} W") }
            r.acceptedPowerW?.let { Text("Paccepted ≈ ${fmt(it, 6)} W") }
            r.radiationEfficiency?.let { Text("Radiation efficiency ≈ ${fmt(it * 100.0, 2)} %") }
            r.spilloverEfficiency?.let { Text("Spillover efficiency ≈ ${fmt(it * 100.0, 2)} %") }
            r.spilloverLossDb?.let { Text("Spillover loss ≈ ${fmt(it, 2)} dB") }
            r.taperEfficiency?.let { Text("Taper efficiency ≈ ${fmt(it * 100.0, 2)} %") }
            r.taperLossDb?.let { Text("Taper loss ≈ ${fmt(it, 2)} dB") }
            Text(r.note, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun FeedDiagnosticsCard(r: FfsResult, edgeAngleDeg: Double?) {
    val d = FeedDiagnosticsMath.analyze(r)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("Feed-pattern diagnostics", style = MaterialTheme.typography.titleMedium)
            @Composable
            fun cutLine(name: String, c: CutDiagnostics?) {
                if (c == null) {
                    Text("$name: not enough points for analysis")
                    return
                }
                Text("$name: max θ=${fmt(c.peakThetaDeg, 2)}°, level=${fmt(c.peakDb, 2)} dB")
                c.hpbwDeg?.let { Text("$name HPBW (−3 dB) ≈ ${fmt(it, 2)}°  [${fmt(c.left3DbDeg ?: 0.0, 2)}° … ${fmt(c.right3DbDeg ?: 0.0, 2)}°]") }
                c.sideLobeRelativeDb?.let { Text("$name high sidelobe ≈ ${fmt(it, 2)} dB relative to main lobe") }
                edgeAngleDeg?.let { edge ->
                    FeedDiagnosticsMath.valueAt(if (name == "E-plane") r.ePlane else r.hPlane, edge)?.let { v ->
                        Text("$name @ dish edge θ=${fmt(edge, 2)}°: ${fmt(v, 2)} dB")
                    }
                }
            }
            cutLine("E-plane", d.e)
            cutLine("H-plane", d.h)
            d.beamwidthDifferenceDeg?.let { Text("E/H HPBW difference ≈ ${fmt(it, 2)}°") }
            d.peakThetaDifferenceDeg?.let { Text("E/H peak-position difference ≈ ${fmt(it, 2)}°") }
            r.phaseAnalysis?.let { ph ->
                Text("Co-pol fraction ≈ ${fmt(ph.coPolarFraction * 100.0, 2)} %; ${ph.polarizationLabel}")
            }
            Text("HPBW and sidelobe peaks are calculated from the imported E/H cuts without modifying the original FFS/FFD data.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PhaseCard(r: PhaseAnalysisResult, sourcePositionZM: Double?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("FFS/FFD phase analysis", style = MaterialTheme.typography.titleMedium)
            Text("Polarization: ${r.polarizationLabel}")
            Text("Analysis component: ${r.componentLabel}")
            Text("Co-pol fraction in the selected basis ≈ ${fmt(r.coPolarFraction * 100.0, 2)} %")
            Text("Phase center relative to file origin: Z ≈ ${fmt(r.optimalPhaseCenterZM * 1000.0, 2)} mm along +Z")
            sourcePositionZM?.let { originZ ->
                Text(
                    "Absolute phase-center Z in FFS coordinates ≈ " +
                        "${fmt((originZ + r.optimalPhaseCenterZM) * 1000.0, 2)} mm"
                )
            }
            Text("To align PC with focus: file origin ≈ ${fmt(-r.optimalPhaseCenterZM * 1000.0, 2)} mm relative to focus along Z")
            Text("With file origin at focus:")
            Text("  Phase efficiency ≈ ${fmt(r.phaseEfficiency * 100.0, 2)} %")
            Text("  Phase loss ≈ ${fmt(r.phaseLossDb, 3)} dB")
            Text("  Equivalent RMS ≈ ${fmt(r.referenceRmsPhaseDeg, 2)}°")
            Text("After aligning the phase center with focus:")
            Text("  Phase efficiency ≈ ${fmt(r.optimizedPhaseEfficiency * 100.0, 2)} %")
            Text("  Phase loss ≈ ${fmt(r.optimizedPhaseLossDb, 3)} dB")
            Text("  Equivalent RMS ≈ ${fmt(r.optimizedRmsPhaseDeg, 2)}°")
            Text("Max |Δφ| of θ profile after optimization ≈ ${fmt(r.maxProfilePhaseErrorDeg, 2)}°")
            if (r.boundaryWarning) {
                Text("⚠ Optimum is close to the ±${fmt(r.searchHalfRangeM * 1000.0, 1)} mm search boundary.")
            }
            Text(r.note, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SystemCard(dish: DishResult, ffs: FfsResult) {
    val spill = ffs.spilloverEfficiency
    val taper = ffs.taperEfficiency
    val radiation = ffs.radiationEfficiency
    val phase = ffs.phaseAnalysis?.phaseEfficiency
    val phaseOptimized = ffs.phaseAnalysis?.optimizedPhaseEfficiency

    val apertureAmplitudeOnly = if (spill != null && taper != null) {
        (spill * taper * dish.ruzeEfficiency).coerceIn(0.0, 1.0)
    } else null

    val apertureWithPhase = if (apertureAmplitudeOnly != null && phase != null) {
        (apertureAmplitudeOnly * phase).coerceIn(0.0, 1.0)
    } else apertureAmplitudeOnly
    val apertureOptimized = if (apertureAmplitudeOnly != null && phaseOptimized != null) {
        (apertureAmplitudeOnly * phaseOptimized).coerceIn(0.0, 1.0)
    } else null

    val dAmplitudeOnly = apertureAmplitudeOnly?.let {
        10.0 * kotlin.math.log10(dish.idealDirectivityLinear * it)
    }
    val dWithPhase = apertureWithPhase?.let {
        10.0 * kotlin.math.log10(dish.idealDirectivityLinear * it)
    }
    val dOptimized = apertureOptimized?.let {
        10.0 * kotlin.math.log10(dish.idealDirectivityLinear * it)
    }
    val gainWithPhase = if (dWithPhase != null && radiation != null && radiation > 0.0) {
        dWithPhase + 10.0 * kotlin.math.log10(radiation)
    } else dWithPhase
    val gainOptimized = if (dOptimized != null && radiation != null && radiation > 0.0) {
        dOptimized + 10.0 * kotlin.math.log10(radiation)
    } else dOptimized

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text("Feed + paraboloid system", style = MaterialTheme.typography.titleMedium)
            val lambda = dish.wavelengthM
            val hp = 58.0 * lambda / kotlin.math.sqrt(dish.areaM2 * 4.0 / kotlin.math.PI)
            val fn = 70.0 * lambda / kotlin.math.sqrt(dish.areaM2 * 4.0 / kotlin.math.PI)
            Text("Estimated HPBW ≈ ${fmt(hp, 3)}°   FNBW ≈ ${fmt(fn * 2.0, 3)}°")
            spill?.let { Text("Spillover efficiency ≈ ${fmt(it * 100.0, 2)} %") }
            taper?.let { Text("Taper efficiency ≈ ${fmt(it * 100.0, 2)} %") }
            phase?.let { Text("Phase efficiency (file origin at focus) ≈ ${fmt(it * 100.0, 2)} %") }
            Text("Ruze efficiency = ${fmt(dish.ruzeEfficiency * 100.0, 2)} %")
            apertureAmplitudeOnly?.let {
                Text("Aperture efficiency without phase ≈ ${fmt(it * 100.0, 2)} %")
            }
            apertureWithPhase?.let {
                Text("Aperture efficiency with file origin at focus ≈ ${fmt(it * 100.0, 2)} %")
            }
            apertureOptimized?.let {
                Text("Aperture efficiency after PC alignment ≈ ${fmt(it * 100.0, 2)} %")
            }
            if (phase != null) dAmplitudeOnly?.let {
                Text("Directivity without phase correction ≈ ${fmt(it, 2)} dBi")
            }
            dWithPhase?.let { Text("Directivity with file origin at focus ≈ ${fmt(it, 2)} dBi") }
            gainWithPhase?.let { Text("Gain with file origin at focus ≈ ${fmt(it, 2)} dBi") }
            dOptimized?.let { Text("Directivity after PC alignment ≈ ${fmt(it, 2)} dBi") }
            gainOptimized?.let { Text("Gain after PC alignment ≈ ${fmt(it, 2)} dBi") }
            Text(
                if (phase != null)
                    "Aperture efficiency = Spillover × Taper × Phase × Ruze. For the current system, Phase is evaluated at Z=0 (file origin at focus); the potential result after aligning the detected phase center with the focus is shown separately. Blockage and separate cross-pol efficiency are not included yet."
                else
                    "Aperture efficiency = Spillover × Taper × Ruze. Phase analysis is unavailable for this file; blockage and cross-pol are not accounted for separately.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun DiagramTab(dish: DishResult?, ffs: FfsResult?) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Patterns", style = MaterialTheme.typography.headlineSmall)
        if (ffs == null) {
            Card(modifier = Modifier.fillMaxWidth()) { Text("First load and calculate an FFS or FFD on the ‘Calculation’ tab.", modifier = Modifier.padding(12.dp)) }
        } else {
            PatternChart("Feed — E-plane (Phi = 0°)", ffs.ePlane, dish?.edgeAngleDeg)
            PatternChart("Feed — H-plane (Phi = 90°)", ffs.hPlane, dish?.edgeAngleDeg)
            ffs.phaseAnalysis?.let { PhaseProfileChart(it) }
        }
        if (dish != null) ParabolaChart(dish)
    }
}

@Composable
private fun PatternChart(title: String, points: List<PatternPoint>, edgeAngle: Double?) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (points.isEmpty()) { Text("This cut is not present in the selected file.") }
            else {
                Text("Normalized to the overall pattern maximum, range 0…−40 dB", style = MaterialTheme.typography.bodySmall)
                val axisColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .35f)
                val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .12f)
                val edgeColor = MaterialTheme.colorScheme.error.copy(alpha = .7f)
                val traceColor = MaterialTheme.colorScheme.primary
                Canvas(modifier = Modifier.fillMaxWidth().height(240.dp)) {
                    val left=44f; val right=size.width-12f; val top=12f; val bottom=size.height-30f
                    drawLine(axisColor, Offset(left,bottom), Offset(right,bottom))
                    drawLine(axisColor, Offset(left,top), Offset(left,bottom))
                    for (db in listOf(0,-10,-20,-30,-40)) {
                        val y=top + (-db/40f)*(bottom-top)
                        drawLine(gridColor, Offset(left,y), Offset(right,y))
                    }
                    edgeAngle?.let { e ->
                        val x=left+(e.coerceIn(0.0,180.0).toFloat()/180f)*(right-left)
                        drawLine(edgeColor, Offset(x,top), Offset(x,bottom), strokeWidth=2f)
                    }
                    val path=Path(); var first=true
                    points.forEach { pt ->
                        val x=left+(pt.thetaDeg.coerceIn(0.0,180.0).toFloat()/180f)*(right-left)
                        val db=pt.db.coerceIn(-40.0,0.0).toFloat()
                        val y=top+(-db/40f)*(bottom-top)
                        if(first){path.moveTo(x,y);first=false}else path.lineTo(x,y)
                    }
                    drawPath(path, traceColor, style=Stroke(width=3f))
                }
                Text("Theta: 0°                                      180°", style = MaterialTheme.typography.bodySmall)
                edgeAngle?.let { Text("Red line: dish edge θ = ${fmt(it,2)}°", style=MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun PhaseProfileChart(r: PhaseAnalysisResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Aperture phase after Z optimization", style = MaterialTheme.typography.titleMedium)
            Text(
                "${r.componentLabel}; Z = ${fmt(r.optimalPhaseCenterZM * 1000.0, 2)} mm; ηphase(opt) = ${fmt(r.optimizedPhaseEfficiency * 100.0, 2)} %",
                style = MaterialTheme.typography.bodySmall
            )
            val pts = r.profile
            if (pts.isEmpty()) {
                Text("No phase points available for plotting.")
            } else {
                val axisColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .35f)
                val gridColor = MaterialTheme.colorScheme.onSurface.copy(alpha = .12f)
                val traceColor = MaterialTheme.colorScheme.primary
                val maxTheta = (pts.maxOfOrNull { it.thetaDeg } ?: 1.0).coerceAtLeast(1.0)
                val phaseSpan = maxOf(30.0, pts.maxOfOrNull { kotlin.math.abs(it.phaseDeg) } ?: 30.0)
                    .coerceAtMost(180.0)
                Canvas(modifier = Modifier.fillMaxWidth().height(240.dp)) {
                    val left = 44f; val right = size.width - 12f
                    val top = 12f; val bottom = size.height - 30f
                    val mid = (top + bottom) / 2f
                    drawLine(axisColor, Offset(left, mid), Offset(right, mid), strokeWidth = 1.5f)
                    drawLine(axisColor, Offset(left, top), Offset(left, bottom), strokeWidth = 1.5f)
                    for (f in listOf(-1f, -0.5f, 0f, 0.5f, 1f)) {
                        val y = mid - f * (bottom - top) / 2f
                        drawLine(gridColor, Offset(left, y), Offset(right, y))
                    }
                    val path = Path()
                    var first = true
                    pts.sortedBy { it.thetaDeg }.forEach { pt ->
                        val x = left + (pt.thetaDeg / maxTheta).toFloat() * (right - left)
                        val ph = pt.phaseDeg.coerceIn(-phaseSpan, phaseSpan)
                        val y = mid - (ph / phaseSpan).toFloat() * (bottom - top) / 2f
                        if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                    }
                    drawPath(path, traceColor, style = Stroke(width = 3f))
                }
                Text(
                    "Theta: 0° … ${fmt(maxTheta, 1)}°    vertical range: ±${fmt(phaseSpan, 1)}°",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "The co-pol phase is shown, averaged over azimuth and referenced to the common aperture phase.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun ParabolaChart(dish: DishResult) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Paraboloid profile", style = MaterialTheme.typography.titleMedium)
            Text(
                "D = ${fmt(dish.diameterM,3)} m   F = ${fmt(dish.focalM,3)} m   depth h = ${fmt(dish.depthM,3)} m",
                style = MaterialTheme.typography.bodySmall
            )

            val parabolaColor = MaterialTheme.colorScheme.primary
            val focusColor = MaterialTheme.colorScheme.error
            val axisColor = MaterialTheme.colorScheme.outline

            Canvas(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                val leftMargin = 28f
                val rightMargin = 52f
                val topMargin = 24f
                val bottomMargin = 46f

                val radiusM = dish.diameterM / 2.0
                val depthM = dish.depthM.coerceAtLeast(1e-9)
                val focalM = dish.focalM.coerceAtLeast(1e-9)

                // Use the same scale for X and Z: 1 meter horizontally
                // equals 1 meter vertically on the screen.
                val usableW = (size.width - leftMargin - rightMargin).coerceAtLeast(1f)
                val usableH = (size.height - topMargin - bottomMargin).coerceAtLeast(1f)
                val verticalRangeM = maxOf(focalM, depthM) + dish.diameterM * 0.04
                val pxPerMeter = minOf(
                    usableW / dish.diameterM.toFloat(),
                    usableH / verticalRangeM.toFloat()
                )

                val centerX = leftMargin + usableW / 2f
                val vertexY = size.height - bottomMargin

                fun sx(xM: Double): Float = centerX + (xM * pxPerMeter).toFloat()
                fun sy(zM: Double): Float = vertexY - (zM * pxPerMeter).toFloat()

                // Z axis.
                val axisTopZ = verticalRangeM
                drawLine(
                    color = axisColor,
                    start = Offset(centerX, vertexY + 8f),
                    end = Offset(centerX, sy(axisTopZ)),
                    strokeWidth = 1.5f
                )

                // Geometrically correct profile z = x²/(4F), opening upward.
                val path = Path()
                for (i in 0..320) {
                    val xM = -radiusM + dish.diameterM * i / 320.0
                    val zM = xM * xM / (4.0 * focalM)
                    val x = sx(xM)
                    val y = sy(zM)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, parabolaColor, style = Stroke(width = 4f))

                // Vertex.
                drawCircle(
                    color = parabolaColor,
                    radius = 4.5f,
                    center = Offset(centerX, vertexY)
                )

                // Focus at z = F.
                val focusY = sy(focalM)
                if (focusY in 0f..size.height) {
                    drawCircle(
                        color = focusColor,
                        radius = 6f,
                        center = Offset(centerX, focusY)
                    )
                    drawLine(
                        color = focusColor,
                        start = Offset(centerX - 10f, focusY),
                        end = Offset(centerX + 10f, focusY),
                        strokeWidth = 2f
                    )
                }

                // Diameter D along the aperture rim line.
                val rimY = sy(depthM)
                val xLeft = sx(-radiusM)
                val xRight = sx(radiusM)
                val dimY = (rimY - 18f).coerceAtLeast(topMargin + 4f)
                drawLine(axisColor, Offset(xLeft, dimY), Offset(xRight, dimY), strokeWidth = 1.5f)
                drawLine(axisColor, Offset(xLeft, dimY - 6f), Offset(xLeft, dimY + 6f), strokeWidth = 1.5f)
                drawLine(axisColor, Offset(xRight, dimY - 6f), Offset(xRight, dimY + 6f), strokeWidth = 1.5f)
                drawLine(axisColor, Offset(xLeft, dimY), Offset(xLeft, rimY), strokeWidth = 1f)
                drawLine(axisColor, Offset(xRight, dimY), Offset(xRight, rimY), strokeWidth = 1f)

                // Depth h to the right of the parabola.
                val hX = (xRight + 24f).coerceAtMost(size.width - 18f)
                drawLine(axisColor, Offset(hX, rimY), Offset(hX, vertexY), strokeWidth = 1.5f)
                drawLine(axisColor, Offset(hX - 6f, rimY), Offset(hX + 6f, rimY), strokeWidth = 1.5f)
                drawLine(axisColor, Offset(hX - 6f, vertexY), Offset(hX + 6f, vertexY), strokeWidth = 1.5f)
            }

            Text(
                "X:Z scale = 1:1. Blue curve: z = r²/(4F). Red point: focus. Dimensions: D = ${fmt(dish.diameterM,3)} m, h = ${fmt(dish.depthM,3)} m.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun fmt(v: Double, digits: Int): String {
    return String.format(Locale.US, "%.${digits}f", v)
}
