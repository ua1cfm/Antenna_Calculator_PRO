package ua1cfm.cstffs

import android.content.Context
import android.hardware.usb.UsbDevice
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Process-level LiteVNA LIVE session with a deliberately decoupled acquisition/UI pipeline.
 *
 * USB acquisition runs continuously on Dispatchers.IO and NEVER waits for Compose. Completed
 * sweeps overwrite one AtomicReference slot, so there is no queue to grow when the UI is slower
 * than the analyzer. A small publisher emits only the newest completed immutable snapshot at a
 * bounded rate (2 Hz). Intermediate sweeps are intentionally dropped.
 */
object LiteVnaLiveController {
    private const val UI_PUBLISH_INTERVAL_MS = 1000L // 1 frame/s maximum: keeps heavy Canvas redraw away from USB acquisition

    data class UiState(
        val running: Boolean = false,
        val starting: Boolean = false,
        /** Last sweep actually published to Compose. */
        val sweepNumber: Long = 0L,
        /** Latest analyzer sweep known at the moment of the UI publication. */
        val acquiredSweepNumber: Long = 0L,
        val progressDone: Int = 0,
        val progressTotal: Int = 0,
        val data: TouchstoneData? = null,
        val deviceInfo: LiteVnaUsb.DeviceInfo? = null,
        val status: String = "LiteVNA LIVE is not running",
        val error: String? = null
    )

    private data class PendingFrame(
        val data: TouchstoneData,
        val info: LiteVnaUsb.DeviceInfo,
        val sweepNumber: Long
    )

    data class CaptureState(
        val active: Boolean = false,
        val targetPasses: Int = 0,
        val completedPasses: Int = 0,
        val firstSweepNumber: Long = 0L,
        val lastSweepNumber: Long = 0L,
        val result: TouchstoneData? = null,
        val error: String? = null
    )

    private data class CaptureAccumulator(
        val targetPasses: Int,
        val firstSweepNumber: Long,
        val referenceOhm: Double,
        val frequenciesHz: DoubleArray,
        val s11Re: DoubleArray,
        val s11Im: DoubleArray,
        val s21Re: DoubleArray,
        val s21Im: DoubleArray,
        var completedPasses: Int = 0,
        var lastSweepNumber: Long = 0L
    )

    private val usbExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "LiteVNA-USB-Dedicated").apply {
            priority = Thread.MAX_PRIORITY
            isDaemon = true
        }
    }
    private val usbDispatcher = usbExecutor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + usbDispatcher)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private val stateLock = Any()

    private fun updateState(transform: (UiState) -> UiState) {
        synchronized(stateLock) {
            _state.value = transform(_state.value)
        }
    }

    private val _captureState = MutableStateFlow(CaptureState())
    val captureState: StateFlow<CaptureState> = _captureState.asStateFlow()
    private val captureLock = Any()
    private var captureAccumulator: CaptureAccumulator? = null

    private val latestFrame = AtomicReference<PendingFrame?>(null)

    @Volatile private var latestProgressDone: Int = 0
    @Volatile private var latestProgressTotal: Int = 0
    @Volatile private var latestAcquiredSweep: Long = 0L

    @Volatile
    private var liveJob: Job? = null

    /**
     * Make a new list object for every frame that becomes visible to Compose. TouchstonePoint and
     * Cpx are immutable data classes, so copying the containing lists is enough to guarantee that
     * the UI never observes a producer-owned mutable collection/reference.
     */
    private fun immutableSnapshot(source: TouchstoneData): TouchstoneData = source.copy(
        points = source.points.map { p ->
            p.copy(
                s11 = p.s11.copy(),
                s21 = p.s21?.copy(),
                s12 = p.s12?.copy(),
                s22 = p.s22?.copy()
            )
        },
        comments = source.comments.map { it }
    )

    fun beginS2pCapture(passCount: Int): Boolean {
        val safeCount = passCount.coerceIn(1, 100)
        if (passCount != safeCount) return false
        if (liveJob?.isActive != true) {
            _captureState.value = CaptureState(error = "Start LIVE sweep before S2P capture")
            return false
        }
        synchronized(captureLock) {
            captureAccumulator = null
            _captureState.value = CaptureState(active = true, targetPasses = safeCount)
        }
        return true
    }

    fun cancelS2pCapture(message: String = "S2P capture cancelled") {
        synchronized(captureLock) {
            captureAccumulator = null
            _captureState.value = CaptureState(error = message)
        }
    }

    fun clearS2pCaptureResult() {
        synchronized(captureLock) {
            if (_captureState.value.active) return
            captureAccumulator = null
            _captureState.value = CaptureState()
        }
    }

    private fun consumeCaptureSweep(data: TouchstoneData, sweepNumber: Long) {
        synchronized(captureLock) {
            val state = _captureState.value
            if (!state.active || state.targetPasses !in 1..100) return
            if (data.points.isEmpty()) {
                cancelS2pCapture("S2P capture failed: empty sweep")
                return
            }
            if (data.points.any { p ->
                    !p.frequencyHz.isFinite() || !p.s11.re.isFinite() || !p.s11.im.isFinite() ||
                    p.s21 == null || !p.s21.re.isFinite() || !p.s21.im.isFinite()
                }) {
                cancelS2pCapture("S2P capture failed: incomplete/invalid sweep")
                return
            }

            var acc = captureAccumulator
            if (acc == null) {
                val n = data.points.size
                acc = CaptureAccumulator(
                    targetPasses = state.targetPasses,
                    firstSweepNumber = sweepNumber,
                    referenceOhm = data.referenceOhm,
                    frequenciesHz = DoubleArray(n) { data.points[it].frequencyHz },
                    s11Re = DoubleArray(n), s11Im = DoubleArray(n),
                    s21Re = DoubleArray(n), s21Im = DoubleArray(n)
                )
                captureAccumulator = acc
            } else {
                if (acc.frequenciesHz.size != data.points.size ||
                    kotlin.math.abs(acc.referenceOhm - data.referenceOhm) > 1e-9 ||
                    data.points.indices.any { i -> kotlin.math.abs(acc.frequenciesHz[i] - data.points[i].frequencyHz) > 0.5 }) {
                    cancelS2pCapture("S2P capture aborted: sweep grid changed during averaging")
                    return
                }
            }

            data.points.forEachIndexed { i, p ->
                acc.s11Re[i] += p.s11.re
                acc.s11Im[i] += p.s11.im
                val s21 = p.s21!!
                acc.s21Re[i] += s21.re
                acc.s21Im[i] += s21.im
            }
            acc.completedPasses += 1
            acc.lastSweepNumber = sweepNumber

            if (acc.completedPasses >= acc.targetPasses) {
                val k = 1.0 / acc.completedPasses.toDouble()
                val averaged = TouchstoneData(
                    ports = 2,
                    referenceOhm = acc.referenceOhm,
                    format = "RI",
                    frequencyUnit = "HZ",
                    points = acc.frequenciesHz.indices.map { i ->
                        TouchstonePoint(
                            frequencyHz = acc.frequenciesHz[i],
                            s11 = Cpx(acc.s11Re[i] * k, acc.s11Im[i] * k),
                            s21 = Cpx(acc.s21Re[i] * k, acc.s21Im[i] * k)
                        )
                    },
                    comments = listOf(
                        "LiteVNA LIVE averaged capture",
                        "${acc.completedPasses} complete consecutive sweeps averaged in complex RI domain",
                        "Sweep numbers ${acc.firstSweepNumber}..${acc.lastSweepNumber}",
                        "S12/S22 are not measured by the current forward LiteVNA RAW sweep"
                    )
                )
                captureAccumulator = null
                _captureState.value = CaptureState(
                    active = false,
                    targetPasses = acc.targetPasses,
                    completedPasses = acc.completedPasses,
                    firstSweepNumber = acc.firstSweepNumber,
                    lastSweepNumber = acc.lastSweepNumber,
                    result = averaged
                )
            } else {
                _captureState.value = CaptureState(
                    active = true,
                    targetPasses = acc.targetPasses,
                    completedPasses = acc.completedPasses,
                    firstSweepNumber = acc.firstSweepNumber,
                    lastSweepNumber = acc.lastSweepNumber
                )
            }
        }
    }

    @Synchronized
    fun start(context: Context, device: UsbDevice, config: LiteVnaProtocol.SweepConfig) {
        if (liveJob?.isActive == true) return

        latestFrame.set(null)
        synchronized(captureLock) {
            captureAccumulator = null
            _captureState.value = CaptureState()
        }
        latestProgressDone = 0
        latestProgressTotal = config.points
        latestAcquiredSweep = 0L

        val appContext = context.applicationContext
        _state.value = UiState(
            running = false,
            starting = true,
            progressTotal = config.points,
            status = "LiteVNA LIVE: opening USB and starting sweep…"
        )

        liveJob = scope.launch {
            val manager = LiteVnaUsb.manager(appContext)
            try {
                coroutineScope {
                    // UI publisher. It is the ONLY coroutine allowed to publish sweep data.
                    // Because it reads one replaceable slot, slow rendering can never create a
                    // backlog of old sweeps or consume unbounded memory.
                    val publisher = launch {
                        var lastPublishedSweep = 0L
                        while (isActive) {
                            delay(UI_PUBLISH_INTERVAL_MS)
                            val frame = latestFrame.get() ?: continue
                            if (frame.sweepNumber == lastPublishedSweep) continue

                            val visible = immutableSnapshot(frame.data)
                            lastPublishedSweep = frame.sweepNumber
                            updateState {
                                UiState(
                                    running = true,
                                    starting = false,
                                    sweepNumber = frame.sweepNumber,
                                    acquiredSweepNumber = latestAcquiredSweep,
                                    progressDone = visible.points.size,
                                    progressTotal = visible.points.size,
                                    data = visible,
                                    deviceInfo = frame.info,
                                    status = "LIVE SCROLL-SAFE • UI 1 Hz • sweep #${frame.sweepNumber} • ${visible.points.size} points",
                                    error = null
                                )
                            }
                        }
                    }

                    try {
                        LiteVnaUsb.measureContinuous(
                            manager = manager,
                            device = device,
                            config = config,
                            onProgress = { sweepNo, done, total ->
                                // Never emit StateFlow here: this callback can run dozens of times
                                // per sweep. Volatile counters are cheap and cannot trigger Compose.
                                latestAcquiredSweep = maxOf(latestAcquiredSweep, sweepNo - 1L)
                                latestProgressDone = done
                                latestProgressTotal = total
                            },
                            onRecovery = { stage, attempt, message ->
                                // Recovery events are rare, so publishing one status update is safe.
                                // Crucially, the LIVE job remains alive while USB/FIFO is resynchronized.
                                updateState { old ->
                                    old.copy(
                                        running = true,
                                        starting = false,
                                        status = "LiteVNA LIVE recovery: $stage #$attempt",
                                        error = null
                                    )
                                }
                            },
                            onSweep = { measurement, sweepNo ->
                                latestAcquiredSweep = sweepNo
                                consumeCaptureSweep(measurement.data, sweepNo)
                                latestProgressDone = measurement.data.points.size
                                latestProgressTotal = measurement.data.points.size

                                // Latest-wins buffer: overwrite any frame the UI has not consumed.
                                latestFrame.set(
                                    PendingFrame(
                                        data = measurement.data,
                                        info = measurement.info,
                                        sweepNumber = sweepNo
                                    )
                                )
                            }
                        )
                    } finally {
                        publisher.cancelAndJoin()
                    }
                }
            } catch (e: CancellationException) {
                // Normal STOP path. Session.use{} closes USB and restores normal device mode.
                throw e
            } catch (e: Throwable) {
                updateState { old ->
                    old.copy(
                        running = false,
                        starting = false,
                        acquiredSweepNumber = latestAcquiredSweep,
                        progressDone = latestProgressDone,
                        progressTotal = latestProgressTotal,
                        status = "LiteVNA LIVE stopped",
                        error = e.message ?: e::class.simpleName
                    )
                }
            } finally {
                // Preserve the last displayed snapshot so graphs do not disappear after STOP.
                updateState { old ->
                    old.copy(
                        running = false,
                        starting = false,
                        acquiredSweepNumber = latestAcquiredSweep,
                        progressDone = latestProgressDone,
                        progressTotal = latestProgressTotal,
                        status = if (old.error == null) "Continuous sweep stopped" else old.status
                    )
                }
                synchronized(this@LiteVnaLiveController) {
                    liveJob = null
                }
            }
        }
    }

    fun stop() {
        val job = liveJob ?: return
        if (_captureState.value.active) {
            cancelS2pCapture("S2P capture cancelled: LIVE stopped before all requested passes completed")
        }
        scope.launch {
            updateState { it.copy(status = "Stopping continuous sweep…") }
            job.cancelAndJoin()
        }
    }

    fun clearError() {
        updateState { it.copy(error = null) }
    }
}
