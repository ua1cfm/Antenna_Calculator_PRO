package ua1cfm.cstffs

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/**
 * Shared NEC-2 FULL geometry/segmentation data.
 *
 * 1.19.18 removes the legacy Android alpha/MoM solver.  This object intentionally contains only
 * the common mesh plan and complex segment-current carrier used by OpenNEC FULL, diagnostics,
 * convergence and Near Field.  It is not a second electromagnetic solver.
 */
object Nec2Core {
    enum class SegmentationMode { AUTO, MANUAL }

    data class SegmentationConfig(
        val mode: SegmentationMode = SegmentationMode.AUTO,
        /** Used directly in MANUAL. AUTO chooses its own electrical density. */
        val segmentsPerWavelength: Int = 30,
        /** Hard safety cap for the OpenNEC geometry order. */
        val maxSegments: Int = 480
    )

    data class SegmentationPlan(
        val mode: SegmentationMode,
        val effectiveSegmentsPerWavelength: Int,
        val requestedSegments: Int,
        val appliedSegments: Int,
        val maxSegments: Int,
        val capApplied: Boolean,
        val targetSegmentLengthM: Double,
        val longestSegmentM: Double,
        val matrixCells: Long,
        val estimatedMatrixMiB: Double,
        val maaHintUsed: Boolean,
        val maaHintSegmentsPerWavelength: Int?,
        val maaHintMaxSegments: Int?,
        internal val countsPerWire: List<Int>
    )

    data class NearFieldSegment(
        val x: Double, val y: Double, val z: Double,
        val ux: Double, val uy: Double, val uz: Double,
        val lengthM: Double, val radiusM: Double,
        val currentReA: Double, val currentImA: Double,
        val wireIndex: Int = -1,
        val alongWire: Double = 0.5
    )

    /**
     * Build the exact mesh plan used by the NEC-2 FULL deck builder.
     *
     * v1.19.31: MMANA's segmentation line is DM1, DM2, SC, EC.  The last field of
     * every wire is the SEG mode (>0, 0, -1, -2, -3), not a NEC tag.  Earlier
     * versions incorrectly treated DM2 as a simple global segments-per-wavelength
     * density and therefore under-segmented ordinary Yagi elements with SEG=-1.
     * AUTO now reproduces OpenNEC 2.2.0 compute_segmentation() count semantics.
     */
    fun planSegmentation(model: MaaModel, config: SegmentationConfig): SegmentationPlan {
        require(model.frequencyMHz > 0.0 && model.wires.isNotEmpty()) { "Invalid MAA model." }
        val lambda = model.wavelengthM
        val mm = parseMmanaSegmentation(model.segmentationDescription)
        val density = when (config.mode) {
            SegmentationMode.MANUAL -> config.segmentsPerWavelength.coerceIn(8, 100)
            SegmentationMode.AUTO -> mm?.dm2 ?: autoDensity(model)
        }
        val target = lambda / density.toDouble()
        val centreSourceWires: Set<Int> = if (model.sources.isNotEmpty()) {
            model.sources.filter { it.position.lowercaseChar() == 'c' }.map { it.wireIndex }.toSet()
        } else if (sourceFraction(model.sourceDescription) in 0.35..0.65) {
            setOf(model.sourceWireIndex ?: -1)
        } else emptySet()

        // Keep this correction deliberately scoped to ordinary parasitic/Yagi arrays.
        // LPDA has its own crossed-TL builder and the other antenna families keep the
        // already validated 1.19.30 mesh policy until they are reviewed separately.
        val mmanaExactAuto = config.mode == SegmentationMode.AUTO && mm != null &&
            model.analysisProfile == "PARASITIC_ARRAY"
        val desired = model.wires.mapIndexed { index, w ->
            var n = if (mmanaExactAuto) {
                computeMmanaSegmentCount(
                    wireLen = w.lengthM,
                    wavelength = lambda,
                    segMode = w.tag,
                    dm1 = mm!!.dm1,
                    dm2 = mm.dm2,
                    sc = mm.sc,
                    ec = mm.ec
                )
            } else {
                max(1, ceil(w.lengthM / target).toInt())
            }

            /*
             * Do NOT alter MMANA's exact automatic count merely to force an odd
             * centre segment. OpenNEC's own MAA importer uses (segs+1)/2 for a
             * centre source, even if an imported count is even.  Changing the count
             * here would make the geometry different from MMANA/OpenNEC.
             * For our non-MMANA fallback/manual mesh retain the historical odd-source
             * convenience because no external mesh definition exists there.
             */
            if (!mmanaExactAuto && index in centreSourceWires) {
                n = max(n, 3)
                if (n % 2 == 0) n++
            }
            n.coerceAtLeast(1)
        }

        val requested = desired.sum()
        val userCap = config.maxSegments.coerceIn(max(model.wires.size, 24), 600)
        val cap = userCap
        val counts = desired.toMutableList()
        var total = counts.sum()
        if (total > cap) {
            val scale = cap.toDouble() / total.toDouble()
            for (i in counts.indices) counts[i] = max(1, floor(counts[i] * scale).toInt())
            total = counts.sum()
            var guard = 0
            while (total < cap && guard < model.wires.size * 20) {
                val candidates = counts.indices.filter { counts[it] < desired[it] }
                if (candidates.isEmpty()) break
                val i = candidates.maxByOrNull { desired[it].toDouble() / counts[it].coerceAtLeast(1) } ?: break
                counts[i]++
                total++
                guard++
            }

            // Only a safety-cap rescale is allowed to adjust a source count.
            // Keep a centre source odd when this can be done without exceeding cap.
            centreSourceWires.filter { it in counts.indices }.forEach { sw ->
                if (counts[sw] > 1 && counts[sw] % 2 == 0) {
                    if (counts.sum() < cap && counts[sw] < desired[sw]) counts[sw]++
                    else if (counts[sw] > 2) counts[sw]--
                }
            }
        }

        total = counts.sum()
        var longest = 0.0
        model.wires.forEachIndexed { i, w -> longest = max(longest, w.lengthM / counts[i].coerceAtLeast(1)) }
        val cells = total.toLong() * total.toLong()
        val matrixMiB = cells * 32.0 / (1024.0 * 1024.0)
        return SegmentationPlan(
            mode = config.mode,
            effectiveSegmentsPerWavelength = density,
            requestedSegments = requested,
            appliedSegments = total,
            maxSegments = cap,
            capApplied = requested > total,
            targetSegmentLengthM = target,
            longestSegmentM = longest,
            matrixCells = cells,
            estimatedMatrixMiB = matrixMiB,
            maaHintUsed = config.mode == SegmentationMode.AUTO && mm != null,
            maaHintSegmentsPerWavelength = mm?.dm2,
            maaHintMaxSegments = mm?.dm1,
            countsPerWire = counts.toList()
        )
    }

    private data class MmanaSegmentation(
        val dm1: Int,
        val dm2: Int,
        val sc: Double,
        val ec: Int
    )

    private fun parseMmanaSegmentation(desc: String?): MmanaSegmentation? {
        if (desc.isNullOrBlank()) return null
        val nums = Regex("[-+]?\\d+(?:[.,]\\d+)?")
            .findAll(desc)
            .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
            .toList()
        if (nums.size < 4) return null
        var dm1 = nums[0].toInt()
        var dm2 = nums[1].toInt()
        var sc = nums[2]
        var ec = nums[3].toInt()
        if (dm1 <= 0) dm1 = 200
        if (dm2 <= 0) dm2 = 20
        if (dm1 < dm2) { val t = dm1; dm1 = dm2; dm2 = t }
        if (sc < 1.01) sc = 2.0
        if (sc > 3.0) sc = 3.0
        if (ec < 1) ec = 1
        return MmanaSegmentation(dm1, dm2, sc, ec)
    }

    /** Kotlin port of OpenNEC v2.2.0 geometry.c compute_segmentation(). */
    private fun computeMmanaSegmentCount(
        wireLen: Double,
        wavelength: Double,
        segMode: Int,
        dm1: Int,
        dm2: Int,
        sc: Double,
        ec: Int
    ): Int {
        if (wireLen <= 0.0 || wavelength <= 0.0) return 1
        if (segMode > 0) return segMode.coerceAtLeast(1)

        var d1 = if (dm1 > 0) dm1 else 200
        var d2 = if (dm2 > 0) dm2 else 20
        if (d1 < d2) { val t = d1; d1 = d2; d2 = t }
        val growth = sc.coerceIn(1.01, 3.0)
        val endCount = ec.coerceAtLeast(1)

        var segFine = wavelength / d1.toDouble()
        var segCoarse = wavelength / d2.toDouble()
        val segFloor = wavelength * 0.001
        if (segFine < segFloor) segFine = segFloor
        if (segCoarse < segFine) segCoarse = segFine

        if (segMode == 0 || segMode !in -3..-1) {
            return ceil(wireLen / segCoarse).toInt().coerceAtLeast(1)
        }

        // One tapered end: EC finest pieces, then one piece per geometric step.
        var endLen = segFine * endCount.toDouble()
        var endSegs = endCount
        var s = segFine * growth
        var guard = 0
        while (s < segCoarse - 1e-12 && guard < 31) {
            endLen += s
            endSegs++
            s *= growth
            guard++
        }

        val nEnds = if (segMode == -1) 2 else 1
        val middleLen = wireLen - nEnds * endLen
        if (middleLen < 0.0) {
            return ceil(wireLen / segFine).toInt().coerceAtLeast(1)
        }
        val middleSegs = if (middleLen > 0.0) ceil(middleLen / segCoarse).toInt() else 0
        return (nEnds * endSegs + middleSegs).coerceAtLeast(1)
    }

    private fun autoDensity(model: MaaModel): Int {
        val lambda = model.wavelengthM
        val maxRadiusLambda = model.wires.maxOfOrNull { it.radiusM / lambda } ?: 0.0
        val manyBends = model.wires.size >= 24 || model.antennaKind.contains("Helical", true) || model.antennaKind.contains("Loop", true)
        val compact3d = !model.isPlanar && model.spanX > 0.0 && model.spanY > 0.0 && model.spanZ > 0.0
        return when {
            maxRadiusLambda > 0.01 || (manyBends && compact3d) -> 42
            manyBends -> 36
            else -> 30
        }
    }

    private fun sourceFraction(desc: String?): Double {
        val m = Regex("w\\s*\\d+\\s*([bce])").find(desc?.lowercase().orEmpty())
        return when (m?.groupValues?.getOrNull(1)) {
            "b" -> 0.0
            "e" -> 1.0
            else -> 0.5
        }
    }
}
