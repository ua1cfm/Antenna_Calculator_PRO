package ua1cfm.cstffs

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Full measured MIT KEMAR normal-pinna HRIR renderer dataset.
 *
 * Source: Bill Gardner and Keith Martin, MIT Media Laboratory, 1994.
 * 710 measured directions, stereo HRIR, 512 samples, 44.1 kHz.
 * The MIT data is provided free of charge with no restrictions on use so long
 * as Gardner and Martin are cited (see HRTF_ATTRIBUTION_1.19.79.txt).
 *
 * The binary asset is a losslessly-positioned, int16-quantized copy of the
 * original SOFA Data.IR with one global scale factor. Interaural timing is kept
 * inside the measured HRIR; no synthetic ITD is added.
 */
internal class FullKemarHrtf(context: Context) {
    companion object {
        const val FFT_SIZE = 1024
        const val HRIR_TAPS = 512
        const val SAMPLE_RATE = 44100
        private const val NEIGHBORS = 4
    }

    private val count: Int
    private val azRad: DoubleArray
    private val elRad: DoubleArray
    // Packed spectra: [direction][ear][re/im][bin]
    private val spectra: FloatArray

    init {
        val bytes = context.assets.open("mit_kemar_normal_full_512.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = ByteArray(4); bb.get(magic)
        require(String(magic, Charsets.US_ASCII) == "KHF1") { "Bad KEMAR asset" }
        val version = bb.int
        val sr = bb.int
        count = bb.int
        val taps = bb.int
        val scale = bb.float.toDouble()
        require(version == 1 && sr == SAMPLE_RATE && taps == HRIR_TAPS && count > 0) { "Unsupported KEMAR asset" }

        azRad = DoubleArray(count)
        elRad = DoubleArray(count)
        spectra = FloatArray(count * 2 * 2 * FFT_SIZE)
        val re = DoubleArray(FFT_SIZE)
        val im = DoubleArray(FFT_SIZE)
        for (d in 0 until count) {
            azRad[d] = Math.toRadians(bb.float.toDouble())
            elRad[d] = Math.toRadians(bb.float.toDouble())
            for (ear in 0..1) {
                java.util.Arrays.fill(re, 0.0)
                java.util.Arrays.fill(im, 0.0)
                for (k in 0 until HRIR_TAPS) re[k] = bb.short.toDouble() * scale
                fft(re, im, false)
                val base = (((d * 2 + ear) * 2) * FFT_SIZE)
                for (k in 0 until FFT_SIZE) {
                    spectra[base + k] = re[k].toFloat()
                    spectra[base + FFT_SIZE + k] = im[k].toFloat()
                }
            }
        }
    }

    /**
     * Interpolate four closest measured directions on the sphere.
     * azimuthRightDeg: 0 front, +90 right, 180 back, -90 left.
     * MIT/SOFA azimuth is positive toward the listener's left, hence the sign flip.
     */
    fun fillSpectrum(
        azimuthRightDeg: Double,
        elevationDeg: Double,
        lRe: DoubleArray, lIm: DoubleArray,
        rRe: DoubleArray, rIm: DoubleArray
    ) {
        require(lRe.size >= FFT_SIZE && lIm.size >= FFT_SIZE && rRe.size >= FFT_SIZE && rIm.size >= FFT_SIZE)
        var sofaAz = Math.toRadians(-azimuthRightDeg)
        while (sofaAz < 0.0) sofaAz += 2.0 * PI
        while (sofaAz >= 2.0 * PI) sofaAz -= 2.0 * PI
        val el = Math.toRadians(elevationDeg.coerceIn(-40.0, 90.0))
        val sinEl = sin(el); val cosEl = cos(el)

        val bestIdx = IntArray(NEIGHBORS) { -1 }
        val bestAng = DoubleArray(NEIGHBORS) { Double.POSITIVE_INFINITY }
        for (d in 0 until count) {
            val dot = (sinEl * sin(elRad[d]) + cosEl * cos(elRad[d]) * cos(sofaAz - azRad[d])).coerceIn(-1.0, 1.0)
            val ang = acos(dot)
            var pos = NEIGHBORS
            for (j in 0 until NEIGHBORS) if (ang < bestAng[j]) { pos = j; break }
            if (pos < NEIGHBORS) {
                for (j in NEIGHBORS - 1 downTo pos + 1) {
                    bestAng[j] = bestAng[j - 1]; bestIdx[j] = bestIdx[j - 1]
                }
                bestAng[pos] = ang; bestIdx[pos] = d
            }
        }
        val w = DoubleArray(NEIGHBORS)
        if (bestAng[0] < 1e-7) {
            w[0] = 1.0
        } else {
            var sum = 0.0
            for (j in 0 until NEIGHBORS) {
                val a = bestAng[j].coerceAtLeast(Math.toRadians(0.35))
                w[j] = 1.0 / (a * a)
                sum += w[j]
            }
            for (j in 0 until NEIGHBORS) w[j] /= sum
        }
        java.util.Arrays.fill(lRe, 0.0); java.util.Arrays.fill(lIm, 0.0)
        java.util.Arrays.fill(rRe, 0.0); java.util.Arrays.fill(rIm, 0.0)
        for (j in 0 until NEIGHBORS) {
            val d = bestIdx[j]
            if (d < 0 || w[j] == 0.0) continue
            val wl = w[j]
            val lb = (((d * 2) * 2) * FFT_SIZE)
            val rb = ((((d * 2 + 1) * 2)) * FFT_SIZE)
            for (k in 0 until FFT_SIZE) {
                lRe[k] += spectra[lb + k] * wl
                lIm[k] += spectra[lb + FFT_SIZE + k] * wl
                rRe[k] += spectra[rb + k] * wl
                rIm[k] += spectra[rb + FFT_SIZE + k] * wl
            }
        }
    }

    internal fun fft(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }
        var len = 2
        while (len <= n) {
            val ang = (if (inverse) 2.0 else -2.0) * PI / len
            val wLenRe = cos(ang); val wLenIm = sin(ang)
            var base = 0
            while (base < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len / 2) {
                    val uRe = re[base + k]; val uIm = im[base + k]
                    val vr0 = re[base + k + len / 2]; val vi0 = im[base + k + len / 2]
                    val vRe = vr0 * wr - vi0 * wi
                    val vIm = vr0 * wi + vi0 * wr
                    re[base + k] = uRe + vRe; im[base + k] = uIm + vIm
                    re[base + k + len / 2] = uRe - vRe; im[base + k + len / 2] = uIm - vIm
                    val nw = wr * wLenRe - wi * wLenIm
                    wi = wr * wLenIm + wi * wLenRe; wr = nw
                }
                base += len
            }
            len = len shl 1
        }
        if (inverse) for (k in 0 until n) { re[k] = re[k] / n.toDouble(); im[k] = im[k] / n.toDouble() }
    }
}
