package ua1cfm.cstffs

import kotlin.math.abs

/**
 * In-app LiteVNA calibration for the RAW FIFO wave-ratio stream.
 *
 * S11 uses the classical three-term one-port OSL error model:
 *   m = Ed + Er*Γ/(1 - Es*Γ)
 * with ideal OPEN Γ=+1, SHORT Γ=-1 and LOAD Γ=0.
 * S21 is normalized by a measured THRU response when one is available.
 *
 * Calibration is deliberately UI-side; the proven LiteVnaUsb/LiteVnaProtocol transport remains
 * untouched. If a calibration grid does not exactly match the active sweep, RAW data is returned.
 */
object LiteVnaCalibrationMath {
    private fun mul(a: Cpx, b: Cpx) = Cpx(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re)

    private fun sameGrid(a: TouchstoneData, b: TouchstoneData): Boolean {
        if (a.points.size != b.points.size) return false
        return a.points.indices.all { i ->
            val fa = a.points[i].frequencyHz
            val fb = b.points[i].frequencyHz
            abs(fa - fb) <= maxOf(1.0, abs(fa) * 1e-10)
        }
    }

    fun applyOrRaw(
        raw: TouchstoneData,
        open: TouchstoneData?,
        short: TouchstoneData?,
        load: TouchstoneData?,
        thru: TouchstoneData?
    ): TouchstoneData {
        if (open == null || short == null || load == null) return raw
        if (!sameGrid(raw, open) || !sameGrid(raw, short) || !sameGrid(raw, load)) return raw
        val useThru = thru != null && sameGrid(raw, thru)

        val corrected = raw.points.mapIndexed { i, p ->
            val mOpen = open.points[i].s11
            val mShort = short.points[i].s11
            val ed = load.points[i].s11
            val a = mOpen - ed
            val b = mShort - ed
            val esDen = a - b

            val gamma = if (esDen.mag > 1e-12) {
                val es = (a + b) / esDen
                val er = mul(a, Cpx(1.0, 0.0) - es)
                val q = p.s11 - ed
                val den = er + mul(es, q)
                if (den.mag > 1e-12) q / den else p.s11
            } else p.s11

            val s21Corrected = if (useThru && p.s21 != null) {
                val t = thru!!.points[i].s21
                if (t != null && t.mag > 1e-12) p.s21 / t else p.s21
            } else p.s21

            p.copy(s11 = gamma, s21 = s21Corrected)
        }

        return raw.copy(
            format = "CAL",
            points = corrected,
            comments = raw.comments + buildList {
                add("In-app LiteVNA OSL S11 calibration applied")
                if (useThru) add("In-app LiteVNA THRU S21 normalization applied")
            }
        )
    }
}
