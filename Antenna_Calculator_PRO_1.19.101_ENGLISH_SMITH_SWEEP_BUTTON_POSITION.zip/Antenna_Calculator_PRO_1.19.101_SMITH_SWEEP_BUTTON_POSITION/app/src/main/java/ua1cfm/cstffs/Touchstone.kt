package ua1cfm.cstffs

import java.io.BufferedReader
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

data class Cpx(val re: Double, val im: Double) {
    val mag: Double get() = sqrt(re * re + im * im)
    operator fun plus(o: Cpx) = Cpx(re + o.re, im + o.im)
    operator fun minus(o: Cpx) = Cpx(re - o.re, im - o.im)
    operator fun times(k: Double) = Cpx(re * k, im * k)
    operator fun div(o: Cpx): Cpx {
        val d = o.re * o.re + o.im * o.im
        return Cpx((re * o.re + im * o.im) / d, (im * o.re - re * o.im) / d)
    }
}

data class TouchstonePoint(
    val frequencyHz: Double,
    val s11: Cpx,
    val s21: Cpx? = null,
    val s12: Cpx? = null,
    val s22: Cpx? = null
)

data class TouchstoneData(
    val ports: Int,
    val referenceOhm: Double,
    val format: String,
    val frequencyUnit: String,
    val points: List<TouchstonePoint>,
    val comments: List<String>
)

data class TouchstoneSummary(
    val minS11Index: Int,
    val minS11Db: Double,
    val minS11FrequencyHz: Double,
    val minVswr: Double,
    val minImpedance: Cpx,
    val bandwidthLowHz: Double?,
    val bandwidthHighHz: Double?,
    val bandwidthHz: Double?,
    val maxS21Db: Double?,
    val maxS21FrequencyHz: Double?
)

object TouchstoneParser {
    fun parse(reader: BufferedReader, fileName: String? = null): TouchstoneData {
        var ports = when {
            fileName?.lowercase()?.endsWith(".s1p") == true -> 1
            fileName?.lowercase()?.endsWith(".s2p") == true -> 2
            else -> 0
        }
        var unit = "GHZ"
        var format = "MA"
        var reference = 50.0
        val comments = mutableListOf<String>()
        val numeric = mutableListOf<Double>()
        var inNetworkData = true

        reader.forEachLine { raw ->
            val beforeComment = raw.substringBefore('!')
            raw.substringAfter('!', "").trim().takeIf { it.isNotEmpty() }?.let { comments += it }
            val line = beforeComment.trim()
            if (line.isEmpty()) return@forEachLine

            if (line.startsWith("[")) {
                val lower = line.lowercase()
                when {
                    lower.startsWith("[number of ports]") -> {
                        Regex("""\d+""").find(line)?.value?.toIntOrNull()?.let { ports = it }
                    }
                    lower.startsWith("[reference]") -> {
                        Regex("""[-+]?\d+(?:[.,]\d+)?(?:[eE][-+]?\d+)?""")
                            .findAll(line.substringAfter("]"))
                            .firstOrNull()?.value?.replace(',', '.')?.toDoubleOrNull()?.let { reference = it }
                    }
                    lower.startsWith("[network data]") -> inNetworkData = true
                    lower.startsWith("[noise data]") -> inNetworkData = false
                    lower.startsWith("[end]") -> inNetworkData = false
                }
                return@forEachLine
            }

            if (line.startsWith("#")) {
                val t = line.substring(1).trim().uppercase().split(Regex("""\s+"""))
                t.firstOrNull { it in setOf("HZ", "KHZ", "MHZ", "GHZ") }?.let { unit = it }
                t.firstOrNull { it in setOf("RI", "MA", "DB") }?.let { format = it }
                val ri = t.indexOf("R")
                if (ri >= 0 && ri + 1 < t.size) t[ri + 1].replace(',', '.').toDoubleOrNull()?.let { reference = it }
                return@forEachLine
            }

            if (!inNetworkData) return@forEachLine
            line.split(Regex("""[\s,;]+""")).forEach { token ->
                token.replace(',', '.').toDoubleOrNull()?.let { numeric += it }
            }
        }

        if (ports == 0) {
            // Infer from record width when extension/version info is unavailable.
            ports = when {
                numeric.size >= 9 && numeric.size % 9 == 0 -> 2
                numeric.size >= 3 && numeric.size % 3 == 0 -> 1
                else -> error("Could not determine the number of Touchstone ports. Use .s1p or .s2p.")
            }
        }
        require(ports == 1 || ports == 2) { "Touchstone S1P and S2P are currently supported." }

        val width = if (ports == 1) 3 else 9
        require(numeric.size >= width) { "Touchstone contains no complete data rows." }
        require(numeric.size % width == 0) {
            "Invalid Touchstone: ${numeric.size} numbers; expected a multiple of $width."
        }

        val multiplier = when (unit) {
            "HZ" -> 1.0
            "KHZ" -> 1e3
            "MHZ" -> 1e6
            else -> 1e9
        }

        fun pair(a: Double, b: Double): Cpx = when (format) {
            "RI" -> Cpx(a, b)
            "DB" -> {
                val mag = 10.0.pow(a / 20.0)
                val rad = b * PI / 180.0
                Cpx(mag * kotlin.math.cos(rad), mag * kotlin.math.sin(rad))
            }
            else -> {
                val rad = b * PI / 180.0
                Cpx(a * kotlin.math.cos(rad), a * kotlin.math.sin(rad))
            }
        }

        val points = ArrayList<TouchstonePoint>(numeric.size / width)
        var i = 0
        while (i + width <= numeric.size) {
            val f = numeric[i] * multiplier
            val s11 = pair(numeric[i + 1], numeric[i + 2])
            if (ports == 1) {
                points += TouchstonePoint(f, s11)
            } else {
                // Touchstone 1.x/2.x two-port network data order:
                // S11, S21, S12, S22.
                points += TouchstonePoint(
                    f, s11,
                    pair(numeric[i + 3], numeric[i + 4]),
                    pair(numeric[i + 5], numeric[i + 6]),
                    pair(numeric[i + 7], numeric[i + 8])
                )
            }
            i += width
        }
        require(points.size >= 2) { "Too few Touchstone points." }
        return TouchstoneData(ports, reference, format, unit, points, comments)
    }
}

object TouchstoneMath {
    fun db(s: Cpx): Double = if (s.mag > 0.0) 20.0 * log10(s.mag) else -300.0
    fun phaseDeg(s: Cpx): Double = atan2(s.im, s.re) * 180.0 / PI
    fun returnLossDb(s11: Cpx): Double = -db(s11)
    fun vswr(s11: Cpx): Double {
        val g = s11.mag
        if (!g.isFinite() || g >= 1.0) return Double.POSITIVE_INFINITY
        // Passive one-port VSWR is physically bounded by 1.0.  Keep the guard here,
        // not only in the plot, so markers/CSV/summary can never report VSWR < 1.
        return ((1.0 + g) / (1.0 - g)).coerceAtLeast(1.0)
    }
    fun impedance(s11: Cpx, z0: Double): Cpx {
        val one = Cpx(1.0, 0.0)
        val den = one - s11
        if (den.mag < 1e-15) return Cpx(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY)
        return ((one + s11) / den) * z0
    }

    fun summarize(data: TouchstoneData, thresholdDb: Double = -10.0): TouchstoneSummary {
        val pts = data.points
        val minIndex = pts.indices.minByOrNull { db(pts[it].s11) } ?: 0
        val minDb = db(pts[minIndex].s11)

        fun crossing(i0: Int, i1: Int): Double {
            val x0 = pts[i0].frequencyHz
            val x1 = pts[i1].frequencyHz
            val y0 = db(pts[i0].s11)
            val y1 = db(pts[i1].s11)
            if (y1 == y0) return x0
            val t = ((thresholdDb - y0) / (y1 - y0)).coerceIn(0.0, 1.0)
            return x0 + (x1 - x0) * t
        }

        var low: Double? = null
        var high: Double? = null
        if (minDb <= thresholdDb) {
            var l = minIndex
            while (l > 0 && db(pts[l - 1].s11) <= thresholdDb) l--
            low = if (l == 0) pts.first().frequencyHz else crossing(l - 1, l)

            var h = minIndex
            while (h < pts.lastIndex && db(pts[h + 1].s11) <= thresholdDb) h++
            high = if (h == pts.lastIndex) pts.last().frequencyHz else crossing(h, h + 1)
        }

        val s21Candidates = pts.mapIndexedNotNull { idx, p -> p.s21?.let { idx to db(it) } }
        val maxS21 = s21Candidates.maxByOrNull { it.second }

        return TouchstoneSummary(
            minIndex,
            minDb,
            pts[minIndex].frequencyHz,
            vswr(pts[minIndex].s11),
            impedance(pts[minIndex].s11, data.referenceOhm),
            low,
            high,
            if (low != null && high != null) high - low else null,
            maxS21?.second,
            maxS21?.let { pts[it.first].frequencyHz }
        )
    }
}
