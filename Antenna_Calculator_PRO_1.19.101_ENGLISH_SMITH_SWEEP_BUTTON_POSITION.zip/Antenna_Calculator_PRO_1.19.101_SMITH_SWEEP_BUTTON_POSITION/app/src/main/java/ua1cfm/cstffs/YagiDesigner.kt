package ua1cfm.cstffs

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private data class YagiElement(
    val name: String,
    val xM: Double,
    val lengthM: Double,
    val driven: Boolean = false
)

private data class YagiDesign(
    val frequencyMHz: Double,
    val diameterMm: Double,
    val z0Ohm: Double,
    val elements: List<YagiElement>,
    val profile: String
) {
    val wavelengthM = 299.792458 / frequencyMHz
    val boomLengthM = (elements.maxOfOrNull { it.xM } ?: 0.0) - (elements.minOfOrNull { it.xM } ?: 0.0)
}

private data class YagiNecSummary(
    val z: OpenNecFull.InputImpedance,
    val maxGainDb: Double?,
    val fbDb: Double?,
    val warning: String?
)

@Composable
fun YagiDesignerTab(onSendToCalculator: (MaaModel) -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var frequency by remember { mutableStateOf("145.0") }
    var count by remember { mutableStateOf("5") }
    var diameter by remember { mutableStateOf("10.0") }
    var z0 by remember { mutableStateOf("50") }
    var profile by remember { mutableStateOf("GAIN") }
    var design by remember { mutableStateOf<YagiDesign?>(null) }
    var nec by remember { mutableStateOf<YagiNecSummary?>(null) }
    var status by remember { mutableStateOf("Enter the design frequency and element count.") }
    var running by remember { mutableStateOf(false) }
    var autoTuneRunning by remember { mutableStateOf(false) }
    var autoTuneProgress by remember { mutableStateOf(0) }
    var exportText by remember { mutableStateOf("") }
    var exportMaaText by remember { mutableStateOf("") }

    val exportMaa = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && exportMaaText.isNotBlank()) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportMaaText) }
        }
    }

    val exportNec = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && exportText.isNotBlank()) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportText) }
        }
    }

    fun build(): YagiDesign? {
        val f = frequency.trim().replace(',', '.').toDoubleOrNull() ?: return null
        val n = count.toIntOrNull()?.coerceIn(3, 15) ?: return null
        val d = diameter.trim().replace(',', '.').toDoubleOrNull() ?: return null
        val ref = z0.trim().replace(',', '.').toDoubleOrNull() ?: return null
        if (f <= 0.0 || d <= 0.0 || ref <= 0.0) return null
        return makeYagiDesign(f, n, d, ref, profile)
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("YAGI DESIGNER", style = MaterialTheme.typography.titleLarge)
        Text("Design → edit → match → analyze", style = MaterialTheme.typography.bodySmall)

        Text("1 • DESIGN TARGET", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(frequency, { frequency = it }, label = { Text("Frequency, MHz") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(count, { count = it }, label = { Text("Elements 3–15") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(diameter, { diameter = it }, label = { Text("Element Ø, mm") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(z0, { z0 = it }, label = { Text("Z0, Ω") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("Profile", style = MaterialTheme.typography.labelMedium)
        Button(onClick = { profile = "GAIN" }, enabled = profile != "GAIN", modifier = Modifier.fillMaxWidth()) { Text("GAIN") }
        Button(onClick = { profile = "WIDE" }, enabled = profile != "WIDE", modifier = Modifier.fillMaxWidth()) { Text("WIDE") }
        Button(onClick = { profile = "COMPACT" }, enabled = profile != "COMPACT", modifier = Modifier.fillMaxWidth()) { Text("COMPACT") }

        Button(
            onClick = {
                val initial = build()
                if (initial == null) {
                    status = "Check frequency, element count, diameter and Z0."
                } else if (!OpenNecFull.isAvailable) {
                    design = initial
                    nec = null
                    status = "Initial geometry generated. NEC-2 FULL is unavailable, so automatic Z0 matching was skipped."
                } else {
                    design = initial
                    nec = null
                    autoTuneRunning = true
                    autoTuneProgress = 0
                    status = "Building ${fmt(initial.z0Ohm,0)} Ω Yagi: optimizing R+jX with NEC-2 FULL…"
                    scope.launch {
                        val outcome = runCatching {
                            withContext(Dispatchers.Default) {
                                autoTuneMatch(initial) { p -> autoTuneProgress = p }
                            }
                        }
                        outcome.onSuccess { (bestDesign, bestNec) ->
                            design = bestDesign
                            nec = bestNec
                            status = "${fmt(bestDesign.z0Ohm,0)} Ω geometry ready: Z=${bestNec.z.formattedZ()}, SWR=${fmt(bestNec.z.swr(bestDesign.z0Ohm),3)}."
                        }.onFailure {
                            design = initial
                            status = "50 Ω auto-match failed: ${it.message ?: "unknown"}. Initial geometry kept."
                        }
                        autoTuneRunning = false
                        autoTuneProgress = 100
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !running && !autoTuneRunning
        ) { Text("CALCULATE ${if (z0.trim().isBlank()) "50" else z0.trim()} Ω GEOMETRY") }

        design?.let { d ->
            Text("2 • GEOMETRY", style = MaterialTheme.typography.titleSmall)
            YagiGeometryPreview(d)
            YagiDimensionsCard(
                d = d,
                onDesignChange = { edited ->
                    design = edited
                    nec = null
                    status = "Geometry edited. ANALYZE IN MAA / NEC will use these dimensions."
                },
                onEditError = { message -> status = message }
            )

            Text("3 • VERIFY & MATCH", style = MaterialTheme.typography.titleSmall)
            Button(
                onClick = {
                    running = true; nec = null; status = "NEC-2 FULL calculation…"
                    scope.launch {
                        val outcome = runCatching { withContext(Dispatchers.Default) { solveYagi(d) } }
                        outcome.onSuccess { nec = it; status = "NEC-2 FULL complete." }
                            .onFailure { status = "NEC error: ${it.message ?: "unknown"}" }
                        running = false
                    }
                },
                enabled = !running && !autoTuneRunning && OpenNecFull.isAvailable,
                modifier = Modifier.fillMaxWidth()
            ) { AutoFitButtonText("NEC CHECK", maxLines = 2) }
            Button(
                onClick = {
                    autoTuneRunning = true; autoTuneProgress = 0; nec = null
                    status = "Matching R+jX to Z0: driven length + REF spacing + D1 spacing…"
                    scope.launch {
                        val outcome = runCatching {
                            withContext(Dispatchers.Default) {
                                autoTuneMatch(d) { p -> autoTuneProgress = p }
                            }
                        }
                        outcome.onSuccess { (bestDesign, bestNec) ->
                            design = bestDesign; nec = bestNec
                            status = "AUTO MATCH complete: Z=${bestNec.z.formattedZ()}, SWR=${fmt(bestNec.z.swr(bestDesign.z0Ohm),3)}."
                        }.onFailure { status = "Auto tune error: ${it.message ?: "unknown"}" }
                        autoTuneRunning = false; autoTuneProgress = 100
                    }
                },
                enabled = !running && !autoTuneRunning && OpenNecFull.isAvailable,
                modifier = Modifier.fillMaxWidth()
            ) { AutoFitButtonText("AUTO MATCH TO Z0", maxLines = 2) }
            if (running || autoTuneRunning) {
                LinearProgressIndicator(
                    progress = { if (autoTuneRunning) autoTuneProgress / 100f else 0.5f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Text("4 • USE / SAVE", style = MaterialTheme.typography.titleSmall)
            Button(
                onClick = {
                    val model = toMaaModel(d)
                    status = "Sending generated Yagi geometry to the main MAA / NEC calculator…"
                    onSendToCalculator(model)
                },
                enabled = !running && !autoTuneRunning,
                modifier = Modifier.fillMaxWidth()
            ) { AutoFitButtonText("ANALYZE IN MAA / NEC", maxLines = 2) }

            Button(
                onClick = {
                    val model = toMaaModel(d)
                    exportMaaText = MaaTextWriter.toText(model)
                    exportMaa.launch("Yagi_${d.elements.size}el_${fmt(d.frequencyMHz,3)}MHz.maa")
                },
                enabled = !running && !autoTuneRunning,
                modifier = Modifier.fillMaxWidth()
            ) { AutoFitButtonText("SAVE MAA", maxLines = 2) }

            Button(
                onClick = {
                    exportText = Nec2FullDeck.fromMaa(toMaaModel(d), Nec2Core.SegmentationConfig()).deck
                    exportNec.launch("Yagi_${d.elements.size}el_${fmt(d.frequencyMHz,3)}MHz.nec")
                },
                enabled = !running && !autoTuneRunning,
                modifier = Modifier.fillMaxWidth()
            ) { AutoFitButtonText("EXPORT NEC", maxLines = 2) }
        }

        nec?.let { n -> YagiNecCard(n, design?.z0Ohm ?: 50.0) }
        Text(status, style = MaterialTheme.typography.bodySmall)
        if (!OpenNecFull.isAvailable) Text(OpenNecFull.availabilityMessage ?: "NEC-2 FULL unavailable", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun YagiGeometryPreview(d: YagiDesign) {
    val axisColor = MaterialTheme.colorScheme.outline
    val drivenColor = MaterialTheme.colorScheme.primary
    val elementColor = MaterialTheme.colorScheme.onSurface
    Card(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(230.dp).padding(10.dp)) {
            val minX = d.elements.minOf { it.xM }
            val maxX = d.elements.maxOf { it.xM }.let { if (it == minX) minX + 1.0 else it }
            val maxL = d.elements.maxOf { it.lengthM }
            fun x(v: Double) = size.width * (0.08f + 0.84f * ((v - minX) / (maxX - minX)).toFloat())
            val cy = size.height * 0.5f
            val scaleY = size.height * 0.78f / maxL.toFloat()
            drawLine(axisColor, Offset(x(minX), cy), Offset(x(maxX), cy), strokeWidth = 5f, cap = StrokeCap.Round)
            d.elements.forEach { e ->
                val xx = x(e.xM)
                val half = (e.lengthM.toFloat() * scaleY) * 0.5f
                drawLine(if (e.driven) drivenColor else elementColor, Offset(xx, cy-half), Offset(xx, cy+half), strokeWidth = if (e.driven) 7f else 5f, cap = StrokeCap.Round)
                if (e.driven) drawCircle(drivenColor, 8f, Offset(xx, cy))
            }
        }
    }
}

@Composable
private fun YagiDimensionsCard(
    d: YagiDesign,
    onDesignChange: (YagiDesign) -> Unit,
    onEditError: (String) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Geometry editor", style = MaterialTheme.typography.titleMedium)
            Text("λ = ${fmt(d.wavelengthM,4)} m   •   boom = ${fmt(d.boomLengthM,3)} m   •   profile ${d.profile}")
            Text(
                "Reflector is the boom origin: REF = 0 mm. Edit each element length and its absolute boom position measured from the reflector. APPLY updates the geometry used by NEC and MAA export.",
                style = MaterialTheme.typography.bodySmall
            )

            d.elements.forEachIndexed { index, e ->
                var lengthText by remember(e.name, e.lengthM) { mutableStateOf(fmt(e.lengthM * 1000.0, 1)) }
                var positionText by remember(e.name, e.xM) { mutableStateOf(fmt(e.xM * 1000.0, 1)) }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(
                            if (e.driven) "${e.name}  •  DRIVEN" else e.name,
                            style = MaterialTheme.typography.titleSmall
                        )
                        OutlinedTextField(
                            value = lengthText,
                            onValueChange = { lengthText = it },
                            label = { Text("Length, mm") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        if (index == 0) {
                            OutlinedTextField(
                                value = "0.0",
                                onValueChange = {},
                                label = { Text("Position from REF, mm") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                readOnly = true
                            )
                        } else {
                            OutlinedTextField(
                                value = positionText,
                                onValueChange = { positionText = it },
                                label = { Text("Position from REF, mm") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        if (index > 0) {
                            val spacing = (e.xM - d.elements[index - 1].xM) * 1000.0
                            Text("Spacing to previous = ${fmt(spacing, 1)} mm", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text("Boom origin / reflector position = 0 mm", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            onClick = {
                                val newLengthMm = lengthText.trim().replace(',', '.').toDoubleOrNull()
                                if (newLengthMm == null || newLengthMm <= 0.0) {
                                    onEditError("${e.name}: enter a valid positive element length.")
                                    return@Button
                                }
                                val newPositionMm = if (index > 0) positionText.trim().replace(',', '.').toDoubleOrNull() else 0.0
                                if (newPositionMm == null || newPositionMm < 0.0) {
                                    onEditError("${e.name}: enter a valid position from the reflector.")
                                    return@Button
                                }
                                if (index > 0) {
                                    val prevMm = d.elements[index - 1].xM * 1000.0
                                    val nextMm = d.elements.getOrNull(index + 1)?.xM?.times(1000.0)
                                    if (newPositionMm <= prevMm) {
                                        onEditError("${e.name}: position must be greater than ${d.elements[index - 1].name} (${fmt(prevMm,1)} mm).")
                                        return@Button
                                    }
                                    if (nextMm != null && newPositionMm >= nextMm) {
                                        onEditError("${e.name}: position must be less than ${d.elements[index + 1].name} (${fmt(nextMm,1)} mm).")
                                        return@Button
                                    }
                                }

                                val edited = d.elements.toMutableList()
                                edited[index] = edited[index].copy(
                                    xM = if (index == 0) 0.0 else newPositionMm / 1000.0,
                                    lengthM = newLengthMm / 1000.0
                                )
                                // Keep the reflector as the absolute boom origin.
                                edited[0] = edited[0].copy(xM = 0.0)
                                onDesignChange(d.copy(elements = edited))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("APPLY ${e.name}") }
                    }
                }
            }
        }
    }
}

@Composable
private fun YagiNecCard(n: YagiNecSummary, z0: Double) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("NEC-2 FULL", style = MaterialTheme.typography.titleMedium)
            Text("Z = ${n.z.formattedZ()}")
            Text("SWR(${fmt(z0,0)} Ω) = ${fmt(n.z.swr(z0),3)}")
            n.maxGainDb?.let { Text("Max gain = ${fmt(it,2)} dBi") }
            n.fbDb?.let { Text("F/B ≈ ${fmt(it,2)} dB") }
            n.warning?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private fun makeYagiDesign(fMHz: Double, n: Int, diameterMm: Double, z0: Double, profile: String): YagiDesign {
    val lambda = 299.792458 / fMHz
    val diameterRatio = (diameterMm / 1000.0 / lambda).coerceIn(0.0005, 0.05)
    // Diameter correction keeps the initial resonant length conservative for practical tubing.
    val diameterCorrection = (1.0 - 0.55 * sqrt(diameterRatio)).coerceIn(0.94, 0.995)
    val driven = 0.478 * lambda * diameterCorrection
    val reflector = driven * when (profile) { "WIDE" -> 1.055; "COMPACT" -> 1.045; else -> 1.060 }
    val refSpacing = lambda * when (profile) { "WIDE" -> 0.26; "COMPACT" -> 0.20; else -> 0.24 }
    val firstDirSpacing = lambda * when (profile) { "WIDE" -> 0.20; "COMPACT" -> 0.15; else -> 0.18 }
    val regularSpacing = lambda * when (profile) { "WIDE" -> 0.22; "COMPACT" -> 0.15; else -> 0.20 }

    val out = mutableListOf<YagiElement>()
    // Manufacturing-friendly coordinate system: reflector is the absolute boom origin.
    out += YagiElement("REF", 0.0, reflector)
    out += YagiElement("DRIVEN", refSpacing, driven, true)
    var x = refSpacing + firstDirSpacing
    val directors = n - 2
    for (i in 0 until directors) {
        val progress = if (directors <= 1) 0.0 else i.toDouble() / (directors - 1).toDouble()
        val ratio = when (profile) {
            "WIDE" -> 0.955 - 0.030 * progress
            "COMPACT" -> 0.945 - 0.035 * progress
            else -> 0.950 - 0.045 * progress
        }
        out += YagiElement("D${i+1}", x, driven * ratio)
        x += regularSpacing * (1.0 + 0.06 * progress)
    }
    return YagiDesign(fMHz, diameterMm, z0, out, profile)
}

private fun toMaaModel(d: YagiDesign): MaaModel {
    val radius = d.diameterMm / 2000.0
    val wires = d.elements.mapIndexed { index, e ->
        MaaWire(e.xM, -e.lengthM/2.0, 0.0, e.xM, e.lengthM/2.0, 0.0, radius, index+1)
    }
    val drivenIndex = d.elements.indexOfFirst { it.driven }.coerceAtLeast(1)
    val src = MaaSource(drivenIndex, 'C', 0, 0.0, 1.0, "Yagi Designer center feed")
    return MaaModel(
        title = "${d.elements.size} element Yagi Designer ${d.profile}",
        frequencyMHz = d.frequencyMHz,
        wires = wires,
        sourceWireIndex = drivenIndex,
        sourceDescription = "w${drivenIndex+1}c",
        loads = emptyList(),
        segmentationDescription = null,
        rawWireCount = wires.size,
        referenceImpedanceOhms = d.z0Ohm,
        fileNameHint = "YagiDesigner",
        sources = listOf(src),
        groundType = 0,
        addHeightM = 0.0,
        materialCode = 0
    )
}

private fun solveYagi(d: YagiDesign): YagiNecSummary {
    val result = OpenNecFull.solveModel(toMaaModel(d), Nec2Core.SegmentationConfig())
    val maxGain = result.nativePattern.maxOfOrNull { it.gainDb }
    fun angularDistance(theta: Double, phi: Double, t: Double, p: Double): Double {
        val dp = min(abs(phi-p), 360.0-abs(phi-p))
        return hypot(theta-t, dp)
    }
    val fw = result.nativePattern.minByOrNull { angularDistance(it.thetaDeg,it.phiDeg,90.0,0.0) }?.gainDb
    val bw = result.nativePattern.minByOrNull { angularDistance(it.thetaDeg,it.phiDeg,90.0,180.0) }?.gainDb
    val fb = if (fw != null && bw != null) fw-bw else null
    return YagiNecSummary(result.primary, maxGain, fb, result.warning)
}

private fun matchScore(z: OpenNecFull.InputImpedance, z0: Double): Double {
    val rErr = (z.rOhm - z0) / z0.coerceAtLeast(1e-9)
    val xErr = z.xOhm / z0.coerceAtLeast(1e-9)
    // Distance to the requested real impedance. This explicitly drives both R -> Z0 and X -> 0.
    return rErr * rErr + xErr * xErr
}

private fun withDrivenPosition(d: YagiDesign, newPosM: Double): YagiDesign {
    val drivenIndex = d.elements.indexOfFirst { it.driven }
    require(drivenIndex >= 1)
    val oldPos = d.elements[drivenIndex].xM
    val delta = newPosM - oldPos
    val els = d.elements.mapIndexed { i, e ->
        when {
            i < drivenIndex -> e
            else -> e.copy(xM = e.xM + delta)
        }
    }
    return d.copy(elements = els)
}

private fun withFirstDirectorSpacing(d: YagiDesign, newSpacingM: Double): YagiDesign {
    val drivenIndex = d.elements.indexOfFirst { it.driven }
    val d1Index = drivenIndex + 1
    if (d1Index !in d.elements.indices) return d
    val target = d.elements[drivenIndex].xM + newSpacingM
    val delta = target - d.elements[d1Index].xM
    val els = d.elements.mapIndexed { i, e -> if (i >= d1Index) e.copy(xM = e.xM + delta) else e }
    return d.copy(elements = els)
}

private fun withDrivenLength(d: YagiDesign, newLengthM: Double): YagiDesign {
    val drivenIndex = d.elements.indexOfFirst { it.driven }
    require(drivenIndex >= 0)
    val els = d.elements.toMutableList()
    els[drivenIndex] = els[drivenIndex].copy(lengthM = newLengthM)
    return d.copy(elements = els)
}

private suspend fun autoTuneMatch(d: YagiDesign, progress: (Int)->Unit): Pair<YagiDesign,YagiNecSummary> {
    val lambda = d.wavelengthM
    val drivenIndex = d.elements.indexOfFirst { it.driven }
    require(drivenIndex >= 1)
    val d1Index = drivenIndex + 1

    var bestDesign = d
    var bestNec = solveYagi(d)
    var bestScore = matchScore(bestNec.z, d.z0Ohm)

    // 28 NEC evaluations max after the initial solve. Coordinate search is intentionally used
    // instead of only changing driven length, because element spacing controls the real part R.
    val coarseRef = listOf(0.18, 0.21, 0.24, 0.27, 0.30).map { it * lambda }
    val coarseD1 = listOf(0.12, 0.15, 0.18, 0.21, 0.24).map { it * lambda }
    val baseDrivenLength = d.elements[drivenIndex].lengthM
    val coarseLength = listOf(0.95, 0.975, 1.0, 1.025, 1.05, 1.075, 1.10).map { baseDrivenLength * it }

    val total = coarseRef.size + (if (d1Index in d.elements.indices) coarseD1.size else 0) + coarseLength.size + 11
    var done = 0

    suspend fun consider(candidate: YagiDesign) {
        val solved = solveYagi(candidate)
        val score = matchScore(solved.z, d.z0Ohm)
        if (score < bestScore) {
            bestScore = score
            bestDesign = candidate
            bestNec = solved
        }
        done++
        progress((done * 100 / total).coerceIn(0, 99))
    }

    // REF -> DRIVEN spacing: move driven and the complete director train together.
    for (p in coarseRef) consider(withDrivenPosition(bestDesign, p))

    // DRIVEN -> D1 spacing: move D1 and all later directors, preserving the rest of the boom spacings.
    if (d1Index in d.elements.indices) {
        for (s in coarseD1) consider(withFirstDirectorSpacing(bestDesign, s))
    }

    // Driven length primarily cancels reactance after R has been moved toward Z0 by spacing.
    for (l in coarseLength) consider(withDrivenLength(bestDesign, l))

    // Local refinement around the best geometry.
    val bestDrivenPos = bestDesign.elements[drivenIndex].xM
    for (df in listOf(-0.020, -0.010, 0.0, 0.010, 0.020)) {
        consider(withDrivenPosition(bestDesign, (bestDrivenPos + df * lambda).coerceAtLeast(0.10 * lambda)))
    }
    if (d1Index in bestDesign.elements.indices) {
        val currentSpacing = bestDesign.elements[d1Index].xM - bestDesign.elements[drivenIndex].xM
        for (df in listOf(-0.015, 0.0, 0.015)) {
            consider(withFirstDirectorSpacing(bestDesign, (currentSpacing + df * lambda).coerceAtLeast(0.08 * lambda)))
        }
    }
    val currentLength = bestDesign.elements[drivenIndex].lengthM
    for (factor in listOf(0.985, 1.0, 1.015)) consider(withDrivenLength(bestDesign, currentLength * factor))

    progress(100)
    return bestDesign to bestNec
}

private fun fmt(v: Double, digits: Int): String = if (v.isFinite()) String.format(Locale.US, "%.${digits}f", v) else "∞"
