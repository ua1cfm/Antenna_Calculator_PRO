package ua1cfm.cstffs

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Far-field pattern reconstructed directly from the complex segment currents solved by OpenNEC.
 *
 * NEC-2 FULL remains responsible for the electromagnetic solution (impedance + currents).  This
 * class only evaluates the standard thin-wire radiation integral for two display cuts.  Unlike the
 * old NEC2-alpha preview it never re-solves or calibrates the currents, so a Yagi pattern uses the
 * same complex currents that produced the displayed FULL input impedance.
 */
object OpenNecPattern {
    data class Result(
        val previewTop: MaaPatternPreview,
        val previewSide: MaaPatternPreview,
        val principalPlane1Label: String,
        val principalPlane2Label: String,
        val note: String
    )

    private data class C(val re: Double, val im: Double) {
        operator fun plus(o: C) = C(re + o.re, im + o.im)
        operator fun times(o: C) = C(re * o.re - im * o.im, re * o.im + im * o.re)
        operator fun times(v: Double) = C(re * v, im * v)
        fun mag2(): Double = re * re + im * im
    }

    private data class PlaneCut(val a: DoubleArray, val b: DoubleArray, val label: String)
    private data class RawCut(val power: DoubleArray, val peak: Double)

    fun calculate(model: MaaModel, solved: OpenNecFull.Result): Result {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }

        val sampler = nativeSamplerOrNull(solved.nativePattern)
        val k = 2.0 * PI / model.wavelengthM
        val cuts = principalCuts(model, sampler, solved.segments, k)
        val raw1 = if (sampler != null)
            farFieldNativeRaw(sampler, model.groundType != 0, cuts.first.a, cuts.first.b)
        else
            farFieldRaw(solved.segments, k, cuts.first.a, cuts.first.b, model.groundType == 1 || model.groundType == 2)
        val raw2 = if (sampler != null)
            farFieldNativeRaw(sampler, model.groundType != 0, cuts.second.a, cuts.second.b)
        else
            farFieldRaw(solved.segments, k, cuts.second.a, cuts.second.b, model.groundType == 1 || model.groundType == 2)
        // Both 2D cuts use one common normalization.  Since adaptive principal cuts pass through
        // the same full-pattern main lobe, this preserves the real relative level between planes.
        val commonPeak = max(raw1.peak, raw2.peak).coerceAtLeast(1e-30)
        val p1 = finishPreview(raw1.power, commonPeak)
        val p2 = finishPreview(raw2.power, commonPeak)
        val basisNote = if (sampler != null)
            "native OpenNEC RP / far_e_field coherent Eθ/Eφ"
        else if (solved.segments.all { it.hasNecCurrentBasis })
            "fallback OpenNEC NEC A/B/C current basis"
        else
            "legacy centre-current fallback"
        val groundNote = when (model.groundType) {
            0 -> "native Free Space"
            1 -> "native Perfect Ground"
            2 -> "native Real Ground epsr=13, sigma=0.005 S/m"
            -1 -> "native Sommerfeld-Norton ground"
            else -> "native OpenNEC ground"
        }
        return Result(
            previewTop = p1,
            previewSide = p2,
            principalPlane1Label = cuts.first.label,
            principalPlane2Label = cuts.second.label,
            note = "NEC-2 FULL pattern: $basisNote; $groundNote."
        )
    }

    /** Spatial display surface. 1.19.35 prefers the solver-native OpenNEC RP grid. */
    fun calculate3D(
        model: MaaModel,
        solved: OpenNecFull.Result,
        thetaStepDeg: Double = 5.0,
        phiStepDeg: Double = 5.0,
        onProgress: ((doneRows: Int, totalRows: Int) -> Unit)? = null
    ): List<Pattern3DPoint> {
        require(solved.segments.isNotEmpty()) { "NEC-2 FULL returned no currents for the 3D radiation pattern." }
        require(model.frequencyMHz > 0.0) { "Invalid frequency." }
        val thStep = thetaStepDeg.coerceIn(0.5, 30.0)
        val phStep = phiStepDeg.coerceIn(0.5, 30.0)
        val thetas = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < 180.0 - 1e-9) { add(v); v += thStep }
            if (lastOrNull()?.let { kotlin.math.abs(it - 180.0) > 1e-9 } != false) add(180.0)
        }
        val phis = mutableListOf<Double>().apply {
            var v = 0.0
            while (v < 360.0 - 1e-9) { add(v); v += phStep }
        }

        val sampler = nativeSamplerOrNull(solved.nativePattern)
        data class Raw3D(val theta: Double, val phi: Double, val power: Double)
        val raw = ArrayList<Raw3D>(thetas.size * phis.size)
        var peak = 0.0

        if (sampler != null) {
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = sampler.powerForDirection(n, model.groundType != 0)
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        } else {
            // Compatibility fallback for an older native library/payload.
            val k = 2.0 * PI / model.wavelengthM
            phis.forEachIndexed { rowIndex, phiDeg ->
                val phi = Math.toRadians(phiDeg)
                val cp = cos(phi)
                val sp = sin(phi)
                for (thetaDeg in thetas) {
                    val theta = Math.toRadians(thetaDeg)
                    val st = sin(theta)
                    val n = doubleArrayOf(st * cp, st * sp, cos(theta))
                    val power = fieldPower(solved.segments, k, n, model.groundType == 1 || model.groundType == 2)
                    raw += Raw3D(thetaDeg, phiDeg, power)
                    if (power > peak) peak = power
                }
                onProgress?.invoke(rowIndex + 1, phis.size)
            }
        }

        val norm = peak.coerceAtLeast(1e-30)
        return raw.map { q ->
            val db = (10.0 * log10((q.power / norm).coerceAtLeast(1e-8))).coerceAtLeast(-80.0)
            Pattern3DPoint(q.theta, q.phi, db)
        }
    }


    /**
     * A JNI/native RP payload is used only when it contains a meaningful set of finite gain
     * samples.  This prevents a partially initialized OpenNEC rpat buffer from collapsing the
     * whole 3D surface to the -80 dB floor.  The exact NEC A/B/C renderer remains the fail-safe.
     */
    private fun nativeSamplerOrNull(points: List<OpenNecFull.NativePatternPoint>): NativePatternSampler? {
        if (points.isEmpty()) return null
        val usable = points.filter { p ->
            p.thetaDeg.isFinite() && p.phiDeg.isFinite() && p.gainDb.isFinite() && p.gainDb > -290.0
        }
        return if (usable.size >= 100) NativePatternSampler(usable) else null
    }

    /**
     * Regular 2.5° native RP sampler. OpenNEC reports theta=0..180 and phi=0..360.
     * Interpolation is done in LINEAR power, never in dB, so cuts at 1° stay smooth without
     * inventing a second phase-summation path. Missing lower-hemisphere ground points are zero.
     */
    private class NativePatternSampler(points: List<OpenNecFull.NativePatternPoint>) {
        private val step = 2.5
        private val nTheta = 73
        private val nPhi = 145
        private val power = DoubleArray(nTheta * nPhi) { Double.NaN }

        init {
            points.forEach { p ->
                val ti = kotlin.math.round(p.thetaDeg / step).toInt()
                val pi = kotlin.math.round(p.phiDeg / step).toInt()
                if (ti in 0 until nTheta && pi in 0 until nPhi) {
                    val db = p.gainDb.coerceIn(-300.0, 300.0)
                    power[pi * nTheta + ti] = Math.pow(10.0, db / 10.0)
                }
            }
        }

        fun powerForDirection(n: DoubleArray, hasGround: Boolean): Double {
            if (hasGround && n[2] < -1e-10) return 0.0
            val nz = n[2].coerceIn(-1.0, 1.0)
            val theta = Math.toDegrees(kotlin.math.acos(nz)).coerceIn(0.0, 180.0)
            var phi = Math.toDegrees(kotlin.math.atan2(n[1], n[0]))
            if (phi < 0.0) phi += 360.0
            if (phi >= 360.0) phi -= 360.0
            return interpolate(theta, phi)
        }

        private fun value(ti: Int, pi: Int): Double {
            val v = power[pi.coerceIn(0, nPhi - 1) * nTheta + ti.coerceIn(0, nTheta - 1)]
            return if (v.isFinite()) v else 0.0
        }

        private fun interpolate(theta: Double, phi: Double): Double {
            val tf = theta / step
            val pf = phi / step
            val t0 = kotlin.math.floor(tf).toInt().coerceIn(0, nTheta - 1)
            val t1 = (t0 + 1).coerceAtMost(nTheta - 1)
            val p0 = kotlin.math.floor(pf).toInt().coerceIn(0, nPhi - 2)
            val p1 = (p0 + 1).coerceAtMost(nPhi - 1)
            val ft = (tf - t0).coerceIn(0.0, 1.0)
            val fp = (pf - p0).coerceIn(0.0, 1.0)
            val a = value(t0, p0) * (1.0 - ft) + value(t1, p0) * ft
            val b = value(t0, p1) * (1.0 - ft) + value(t1, p1) * ft
            return (a * (1.0 - fp) + b * fp).coerceAtLeast(0.0)
        }
    }

    private fun farFieldNativeRaw(
        sampler: NativePatternSampler,
        hasGround: Boolean,
        axisA: DoubleArray,
        axisB: DoubleArray
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val p = sampler.powerForDirection(n, hasGround)
            raw[idx] = p
            if (p > peak) peak = p
        }
        return RawCut(raw, peak)
    }

    private fun farFieldRaw(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        axisA: DoubleArray,
        axisB: DoubleArray,
        usePerfectGroundImage: Boolean
    ): RawCut {
        val raw = DoubleArray(361)
        var peak = 0.0
        for (idx in raw.indices) {
            val angle = Math.toRadians(idx - 180.0)
            val n = add(scale(axisA, cos(angle)), scale(axisB, sin(angle)))
            val power = fieldPower(segments, k, n, usePerfectGroundImage)
            raw[idx] = power
            if (power > peak) peak = power
        }
        return RawCut(raw, peak)
    }

    /**
     * Far-field power in direction n from the solved NEC solution.
     *
     * Since 1.19.30 the preferred path reproduces NEC's segment radiation integral from the
     * solver's A/B/C sinusoidal current-expansion coefficients. A single complex centre current
     * multiplied by a finite-segment sinc is only exact for a uniform-current segment and can
     * noticeably corrupt phase-sensitive end-fire arrays (Yagi/LPDA) even when input Z is right.
     *
     * OpenNEC uses, for each segment (geometry lengths are in wavelengths internally):
     *   omega = -(n dot u), el = pi * halfLengthLambda
     *   rr = a*A.re + b*B.im + c*C.re
     *   ri = a*A.im - b*B.re + c*C.im
     * followed by exp(+j 2*pi n dot r/lambda).
     *
     * If an old native payload without A/B/C is ever parsed, all segments fall back together to
     * the previous centre-current approximation; exact and approximate amplitudes are never mixed.
     *
     * For MMANA G=1/G=2 the FULL deck uses ideal PEC (`GN 1`). The image current is
     * J_image=(-Jx,-Jy,+Jz) at z -> -z. Radiation below the PEC plane is blocked.
     */
    private fun fieldPower(
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double,
        n: DoubleArray,
        usePerfectGroundImage: Boolean
    ): Double {
        if (usePerfectGroundImage && n[2] < -1e-10) return 0.0

        var ex = C(0.0, 0.0)
        var ey = C(0.0, 0.0)
        var ez = C(0.0, 0.0)
        val useNecBasis = segments.all { it.hasNecCurrentBasis }

        fun sinc(x: Double): Double = if (abs(x) < 1.0e-7) 1.0 - x * x / 6.0 else sin(x) / x

        fun necBasisAmplitude(s: OpenNecFull.SegmentCurrent, ndotu: Double): C {
            val omega = -ndotu
            // OpenNEC geometry.half_len is half segment length in wavelengths.
            // lambda = 2*pi/k => pi*halfLen/lambda = k*length/4.
            val el = 0.25 * k * s.lengthM
            val sill = omega * el
            val top = el + sill
            val bot = el - sill
            val a = if (abs(omega) >= 1.0e-7) {
                2.0 * sin(sill) / omega
            } else {
                (2.0 - omega * omega * el * el / 3.0) * el
            }
            val too = sinc(top)
            val boo = sinc(bot)
            val b = el * (boo - too)
            val c = el * (boo + too)
            return C(
                a * s.basisARe + b * s.basisBIm + c * s.basisCRe,
                a * s.basisAIm - b * s.basisBRe + c * s.basisCIm
            )
        }

        fun accumulate(
            s: OpenNecFull.SegmentCurrent,
            zM: Double,
            ux: Double,
            uy: Double,
            uz: Double,
            currentSign: Double
        ) {
            val ndotu = n[0] * ux + n[1] * uy + n[2] * uz
            // n x (u x n): only the transverse part radiates.
            val vx = ux - n[0] * ndotu
            val vy = uy - n[1] * ndotu
            val vz = uz - n[2] * ndotu
            val phase = k * (n[0] * s.xM + n[1] * s.yM + n[2] * zM)
            val phasor = C(cos(phase), sin(phase))

            val segmentAmp = if (useNecBasis) {
                necBasisAmplitude(s, ndotu) * currentSign
            } else {
                // Compatibility only: 1.19.29 and earlier payloads had one centre current/segment.
                val current = C(s.currentReA * currentSign, s.currentImA * currentSign)
                val q = 0.5 * k * s.lengthM * ndotu
                val finiteSegment = if (abs(q) < 1e-8) 1.0 else sin(q) / q
                current * (s.lengthM * finiteSegment)
            }
            val amp = segmentAmp * phasor
            ex = ex + amp * vx
            ey = ey + amp * vy
            ez = ez + amp * vz
        }

        for (s in segments) {
            accumulate(s, s.zM, s.ux, s.uy, s.uz, +1.0)
            if (usePerfectGroundImage) {
                // Mirror direction + reverse scalar current => Jimg=(-Jx,-Jy,+Jz).
                accumulate(s, -s.zM, s.ux, s.uy, -s.uz, -1.0)
            }
        }
        return ex.mag2() + ey.mag2() + ez.mag2()
    }

    private fun finishPreview(raw: DoubleArray, peakIn: Double): MaaPatternPreview {
        val peak = peakIn.coerceAtLeast(1e-30)
        val points = raw.indices.map { idx ->
            val db = (10.0 * log10((raw[idx] / peak).coerceAtLeast(1e-6))).coerceAtLeast(-60.0)
            MaaPatternPoint(idx - 180.0, db)
        }
        val peakIdx = raw.indices.maxByOrNull { raw[it] } ?: 180
        val oppositeIdx = (peakIdx + 180).let { if (it > 360) it - 360 else it }
        val fb = points[peakIdx].db - points[oppositeIdx].db

        fun crossing(start: Int, step: Int): Double? {
            var i = start + step
            while (i in 0..360) {
                if (points[i].db <= -3.0) {
                    val j = i - step
                    val a = points[j]
                    val b = points[i]
                    val den = b.db - a.db
                    if (abs(den) < 1e-12) return b.angleDeg
                    val t = (-3.0 - a.db) / den
                    return a.angleDeg + (b.angleDeg - a.angleDeg) * t
                }
                i += step
            }
            return null
        }

        val left = crossing(peakIdx, -1)
        val right = crossing(peakIdx, 1)
        val hpbw = if (left != null && right != null && right >= left) right - left else null
        val peakAngle = points[peakIdx].angleDeg
        val exclusion = ((hpbw ?: 30.0) * 0.75).coerceAtLeast(10.0)
        fun angularDistance(a: Double, b: Double): Double {
            var d = abs(a - b) % 360.0
            if (d > 180.0) d = 360.0 - d
            return d
        }
        var side = -60.0
        for (i in 1 until points.lastIndex) {
            if (angularDistance(points[i].angleDeg, peakAngle) >= exclusion &&
                points[i].db >= points[i - 1].db && points[i].db >= points[i + 1].db
            ) {
                side = max(side, points[i].db)
            }
        }
        return MaaPatternPreview(points, hpbw, fb, side)
    }

    private fun principalCuts(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): Pair<PlaneCut, PlaneCut> {
        val omni = model.omniSymmetryAxis
        if (omni != null) {
            val transverse = listOf('X', 'Y', 'Z').filter { it != omni }
            fun span(axis: Char): Double = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            val t1 = transverse.maxByOrNull(::span) ?: transverse.first()
            val t2 = transverse.first { it != t1 }
            return PlaneCut(axisVector(t1), axisVector(t2), "AZ $t1-$t2") to
                PlaneCut(axisVector(t1), axisVector(omni), "EL $t1-$omni")
        }

        // For every non-omnidirectional topology, derive the two displayed principal cuts from
        // the ACTUAL full-field main-lobe direction. This fixes rotated/crossed/phased arrays
        // whose lobe is not contained in one of the global XY/XZ/YZ planes.
        val forward = findMainLobeDirection(model, sampler, segments, k)

        // Pick the geometrically most meaningful transverse reference axis. The projection makes
        // it exactly perpendicular to the full-pattern main-lobe vector.
        val refs = listOf('X', 'Y', 'Z').map { axis ->
            val sp = when (axis) {
                'X' -> model.spanX
                'Y' -> model.spanY
                else -> model.spanZ
            }
            axisVector(axis) to sp
        }
        val ref = refs.maxByOrNull { (v, sp) ->
            val proj2 = (1.0 - dot(v, forward) * dot(v, forward)).coerceAtLeast(0.0)
            sp * sp * proj2
        }?.first ?: axisVector('Z')
        var transverse1 = subtract(ref, scale(forward, dot(ref, forward)))
        if (norm(transverse1) < 1e-8) {
            val fallback = if (abs(forward[2]) < 0.9) axisVector('Z') else axisVector('Y')
            transverse1 = subtract(fallback, scale(forward, dot(fallback, forward)))
        }
        transverse1 = normalize(transverse1)
        val transverse2 = normalize(cross(forward, transverse1))

        val az = Math.toDegrees(kotlin.math.atan2(forward[1], forward[0])).let { if (it < 0.0) it + 360.0 else it }
        val el = Math.toDegrees(kotlin.math.asin(forward[2].coerceIn(-1.0, 1.0)))
        val dir = "AZ %.1f° EL %.1f°".format(java.util.Locale.US, az, el)
        return PlaneCut(forward, transverse1, "P1 MAIN • $dir") to
            PlaneCut(forward, transverse2, "P2 ORTHO • $dir")
    }

    private fun findMainLobeDirection(
        model: MaaModel,
        sampler: NativePatternSampler?,
        segments: List<OpenNecFull.SegmentCurrent>,
        k: Double
    ): DoubleArray {
        if (sampler != null) {
            var best = axisVector(model.mainAxis)
            var bestPower = -1.0
            var theta = 0.0
            while (theta <= 180.0 + 1e-9) {
                val th = Math.toRadians(theta)
                var phi = 0.0
                while (phi < 360.0 - 1e-9) {
                    val ph = Math.toRadians(phi)
                    val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                    val p = sampler.powerForDirection(n, model.groundType != 0)
                    if (p > bestPower) { bestPower = p; best = n }
                    phi += 2.5
                }
                theta += 2.5
            }
            return normalize(best)
        }

        // Compatibility fallback for old native payloads: a 10° full-sphere search is enough to
        // orient the 1° display cuts; the cuts themselves still use the exact coherent field sum.
        var best = axisVector(model.mainAxis)
        var bestPower = -1.0
        var theta = 0.0
        while (theta <= 180.0 + 1e-9) {
            val th = Math.toRadians(theta)
            var phi = 0.0
            while (phi < 360.0 - 1e-9) {
                val ph = Math.toRadians(phi)
                val n = doubleArrayOf(sin(th) * cos(ph), sin(th) * sin(ph), cos(th))
                val p = fieldPower(segments, k, n, model.groundType == 1 || model.groundType == 2)
                if (p > bestPower) { bestPower = p; best = n }
                phi += 10.0
            }
            theta += 10.0
        }
        return normalize(best)
    }

    private fun axisVector(axis: Char): DoubleArray = when (axis) {
        'X' -> doubleArrayOf(1.0, 0.0, 0.0)
        'Y' -> doubleArrayOf(0.0, 1.0, 0.0)
        else -> doubleArrayOf(0.0, 0.0, 1.0)
    }

    private fun dot(a: DoubleArray, b: DoubleArray) = a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
    private fun norm(a: DoubleArray) = sqrt(dot(a, a))
    private fun normalize(a: DoubleArray): DoubleArray {
        val n = norm(a).coerceAtLeast(1e-30)
        return doubleArrayOf(a[0]/n, a[1]/n, a[2]/n)
    }
    private fun scale(a: DoubleArray, s: Double) = doubleArrayOf(a[0]*s, a[1]*s, a[2]*s)
    private fun subtract(a: DoubleArray, b: DoubleArray) = doubleArrayOf(a[0]-b[0], a[1]-b[1], a[2]-b[2])
    private fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0]
    )
    private fun add(a: DoubleArray, b: DoubleArray) =
        doubleArrayOf(a[0] + b[0], a[1] + b[1], a[2] + b[2])
}
