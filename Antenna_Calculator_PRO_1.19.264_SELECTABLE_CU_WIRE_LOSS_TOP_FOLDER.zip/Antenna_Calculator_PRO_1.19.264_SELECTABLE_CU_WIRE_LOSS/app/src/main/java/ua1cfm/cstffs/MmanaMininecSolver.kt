package ua1cfm.cstffs

import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * MMANA/MININEC pulse-matrix impedance core.
 *
 * 1.19.258 keeps the single MAA numerical engine and fixes source-pulse polarity/junction-root mapping. There is no PEEC/EFIE, FDTD,
 * FEM or corpus impedance fallback. Loads, MMANA taper expansion, multiple
 * sources and endpoint junctions are handled in this pulse space. Ground
 * models are applied as image terms inside the same pulse matrix.
 */
object MmanaMininecSolver {
    private const val C_MHZ = 299.8
    private const val EPS0 = 8.8541878128e-12
    private const val MAX_PULSES = 1600

    private data class C(val re: Double, val im: Double) {
        operator fun plus(o: C) = C(re + o.re, im + o.im)
        operator fun minus(o: C) = C(re - o.re, im - o.im)
        operator fun times(o: C) = C(re * o.re - im * o.im, re * o.im + im * o.re)
        operator fun times(s: Double) = C(re * s, im * s)
        operator fun div(o: C): C {
            val d = o.re * o.re + o.im * o.im
            if (d <= 1e-300) return C(0.0, 0.0)
            return C((re * o.re + im * o.im) / d, (im * o.re - re * o.im) / d)
        }
        fun mag() = hypot(re, im)
    }

    private data class V(val x: Double, val y: Double, val z: Double) {
        operator fun plus(o: V) = V(x + o.x, y + o.y, z + o.z)
        operator fun minus(o: V) = V(x - o.x, y - o.y, z - o.z)
        operator fun times(s: Double) = V(x * s, y * s, z * s)
        fun dot(o: V) = x * o.x + y * o.y + z * o.z
        fun norm() = sqrt(x * x + y * y + z * z)
    }

    private data class Pulse(
        val local: Int,
        val point: V,
        val endNeg: V,
        val endPos: V,
        val lenNeg: Double,
        val lenPos: Double,
        val dirNeg: V,
        val dirPos: V,
        val radiusNeg: Double,
        val radiusPos: Double,
        val wireNeg: Int,
        val wirePos: Int
    ) {
        fun len(side: Int) = if (side == 0) lenNeg else lenPos
        fun end(side: Int) = if (side == 0) endNeg else endPos
        fun dir(side: Int) = if (side == 0) dirNeg else dirPos
        fun radius(side: Int) = if (side == 0) radiusNeg else radiusPos
        fun wire(side: Int) = if (side == 0) wireNeg else wirePos
        fun endSeg(ds: Double): V {
            val e = if (ds > 0.0) endPos else endNeg
            return point + (e - point) * abs(ds)
        }
        fun dvecs(ds: Double): Pair<V, V> =
            if (ds < 0.0) endSeg(ds) to point else point to endSeg(ds)
        val simpleInternal: Boolean get() = wireNeg == wirePos
    }

    private data class WirePulseRef(val id: Int, val sign: Double)

    private data class Built(
        val pulses: List<Pulse>,
        val pulseRefsByWire: List<List<WirePulseRef>>,
        val spansByWire: List<List<MmanaGalSegmentation.Span>>,
        val connectedPairs: Set<Long>,
        val junctionCount: Int,
        val groundTerminalCount: Int
    ) {
        val pulseIdsByWire: List<List<Int>> get() = pulseRefsByWire.map { refs -> refs.map { it.id } }
    }

    private data class ResolvedSource(
        val source: MaaSource,
        val pulseIndex: Int,
        val pulseSign: Double,
        val voltage: C
    )

    private data class GroundExpansion(
        val model: MaaModel,
        val physicalGround: GroundModelV2.Spec,
        val originalWireCount: Int,
        val groundedEndpointCount: Int,
        val unfolded: Boolean
    )

    private fun prepareGroundModel(model: MaaModel, ground: GroundModelV2.Spec): GroundExpansion {
        if (!ground.hasGround) return GroundExpansion(model, ground, model.wires.size, 0, false)

        // PEC image theory is exact.  MMANA also uses its special image-completed
        // terminal pulse when a real-earth model is electrically connected to z=0.
        // Explicit unfolding reproduces those grounded source/load factors without
        // a second solver.  Elevated finite-earth antennas keep the finite-earth
        // image coefficient inside the same MININEC matrix.
        val doUnfold = ground.mode == GroundModelV2.Mode.PEC_PLANE || ground.wiresTouchingPlane > 0
        if (!doUnfold) return GroundExpansion(model, ground, model.wires.size, 0, false)

        val tol = max(1e-8, model.wavelengthM * 1e-8)
        val h = ground.addHeightM
        val upper = model.wires.map { w -> w.copy(z1 = w.z1 + h, z2 = w.z2 + h) }
        val groundedEndpoints = upper.sumOf { w ->
            (if (abs(w.z1) <= tol) 1 else 0) + (if (abs(w.z2) <= tol) 1 else 0)
        }
        val image = upper.map { w ->
            MaaWire(
                x1 = w.x2, y1 = w.y2, z1 = -w.z2,
                x2 = w.x1, y2 = w.y1, z2 = -w.z1,
                radiusM = w.radiusM, tag = w.tag, taperRef = w.taperRef
            )
        }
        val n = upper.size
        fun mirrorPosition(c: Char): Char = when (c.lowercaseChar()) {
            'b' -> 'e'
            'e' -> 'b'
            else -> 'c'
        }
        val imageSources = model.sources.map { src ->
            src.copy(
                wireIndex = src.wireIndex + n,
                position = mirrorPosition(src.position),
                segmentOffset = -src.segmentOffset,
                raw = src.raw + " [MMANA image]"
            )
        }
        val imageLoads = model.loads.map { load ->
            load.copy(
                wireIndex = load.wireIndex + n,
                position = mirrorPosition(load.position),
                segmentOffset = -load.segmentOffset,
                raw = load.raw + " [MMANA image]"
            )
        }
        val work = model.copy(
            wires = upper + image,
            loads = model.loads + imageLoads,
            sources = model.sources + imageSources,
            groundType = 0, addHeightM = 0.0,
            rawWireCount = upper.size + image.size
        )
        return GroundExpansion(work, ground, n, groundedEndpoints, true)
    }

    fun solve(
        model: MaaModel,
        cancel: AtomicBoolean,
        onProgress: (MmanaSolverApi.Progress) -> Unit,
        conductorConductivitySPerM: Double? = null
    ): MmanaSolverApi.Result {
        require(model.frequencyMHz > 0.0) { "MMANA/MININEC: invalid frequency" }
        require(model.wires.isNotEmpty()) { "MMANA/MININEC: no wires" }
        require(model.sources.isNotEmpty()) { "MMANA/MININEC: no valid source" }
        require(model.invalidSourceRecords == 0) {
            "MMANA/MININEC: ${model.invalidSourceRecords} invalid source record(s)"
        }
        require(model.invalidLoadRecords == 0) {
            "MMANA/MININEC: ${model.invalidLoadRecords} invalid load record(s)"
        }

        val lambda = C_MHZ / model.frequencyMHz
        val physicalGround = GroundModelV2.spec(model)
        val expansion = prepareGroundModel(model, physicalGround)
        val workModel = expansion.model
        val coreGround = if (expansion.unfolded) GroundModelV2.spec(workModel) else physicalGround
        val coreShift = if (expansion.unfolded) 0.0 else coreGround.addHeightM
        val built = build(
            workModel, lambda, coreShift,
            allowCompactShortTaper = !physicalGround.hasGround
        ) ?: throw IllegalArgumentException("MMANA/MININEC: geometry cannot be discretised")
        val n = built.pulses.size
        require(n in 1..MAX_PULSES) {
            "MMANA/MININEC: $n pulse unknowns exceed mobile limit $MAX_PULSES"
        }

        fun resolvePulseRef(wireIndex: Int, position: Char, offset: Int): WirePulseRef {
            val refs = built.pulseRefsByWire.getOrNull(wireIndex).orEmpty()
            require(refs.isNotEmpty()) {
                "MMANA/MININEC: W${wireIndex + 1} has no conducting pulse"
            }
            val ri = MmanaGalSegmentation.pulseIndex(position, refs.size, offset)
            return refs[ri]
        }

        fun resolvePulse(wireIndex: Int, position: Char, offset: Int): Int =
            resolvePulseRef(wireIndex, position, offset).id

        val resolvedSources = workModel.sources.map { source ->
            val ref = resolvePulseRef(source.wireIndex, source.position, source.segmentOffset)
            val ph = source.phaseDeg * PI / 180.0
            val voltage = C(source.amplitude * cos(ph), source.amplitude * sin(ph))
            ResolvedSource(source, ref.id, ref.sign, voltage)
        }
        val primary = resolvedSources.first()

        onProgress(MmanaSolverApi.Progress(2, "MMANA/MININEC pulse matrix"))
        val engine = Engine(
            frequencyMHz = model.frequencyMHz,
            p = built.pulses,
            connectedPairs = built.connectedPairs,
            ground = coreGround,
            cancel = cancel
        ) { fraction ->
            onProgress(
                MmanaSolverApi.Progress(
                    (2 + 70 * fraction).toInt().coerceIn(2, 72),
                    "MMANA/MININEC pulse matrix"
                )
            )
        }
        val z = engine.matrix()
        val invM = 1.0 / engine.m

        // Skin-effect conductor loss: R_s = sqrt(pi*f*mu0/sigma) [ohm/square]
        // and R_wire = R_s * length / (2*pi*radius). This uses the SAME
        // -R/M diagonal stamp as the existing series R+jX loads, without any
        // impedance calibration, resonance shift, or changes to pulse geometry.
        // Only enabled for explicitly selected conductive wire material;
        // null denotes the previous perfect-conductor (PEC) calculation.
        if (conductorConductivitySPerM != null) {
            require(conductorConductivitySPerM.isFinite() && conductorConductivitySPerM > 0.0) {
                "Conductor conductivity must be positive and finite"
            }
            val mu0 = 4.0e-7 * PI
            val surfaceResistance = sqrt(PI * model.frequencyMHz * 1.0e6 * mu0 / conductorConductivitySPerM)
            for ((i, pulse) in built.pulses.withIndex()) {
                val radiusNeg = abs(pulse.radiusNeg)
                val radiusPos = abs(pulse.radiusPos)
                if (radiusNeg <= 0.0 || radiusPos <= 0.0) continue
                val rNeg = surfaceResistance * pulse.lenNeg / (2.0 * PI * radiusNeg)
                val rPos = surfaceResistance * pulse.lenPos / (2.0 * PI * radiusPos)
                val seriesOhm = 0.5 * (rNeg + rPos)
                z.second[i * n + i] -= seriesOhm * invM
            }
        }

        // MMANA MININEC3 load/source normalization:
        // ordinary pulse -> 1/M; image-completed terminal pulse on the ground plane -> 2/M.
        // In the unfolded PEC representation the physical and mirrored records meet on that
        // same terminal pulse.  Stamp only the physical record there and use 2/M explicitly,
        // instead of relying on two independent 1/M contributions.
        val groundTol = max(1e-8, lambda * 1e-8)
        fun isImageCompletedGroundPulse(pidx: Int): Boolean {
            if (!expansion.unfolded) return false
            val pulse = built.pulses.getOrNull(pidx) ?: return false
            if (abs(pulse.point.z) > groundTol) return false
            val nw = expansion.originalWireCount
            val a = pulse.wireNeg
            val b = pulse.wirePos
            return (a in 0 until nw && b == a + nw) ||
                (b in 0 until nw && a == b + nw)
        }

        val resolvedLoadText = ArrayList<String>()
        for (load in workModel.loads) {
            val pidx = resolvePulse(load.wireIndex, load.position, load.segmentOffset)
            val specialGroundPulse = isImageCompletedGroundPulse(pidx)
            if (specialGroundPulse && load.wireIndex >= expansion.originalWireCount) continue
            val zl = loadImpedance(load, workModel.frequencyMHz)
                ?: throw IllegalArgumentException("MMANA/MININEC: unsupported load kind ${load.kind}")
            val scale = if (specialGroundPulse) 2.0 * invM else invM
            val q = pidx * n + pidx
            z.first[q] += zl.im * scale
            z.second[q] += -zl.re * scale
            resolvedLoadText +=
                "W${load.wireIndex + 1}${load.position.uppercaseChar()}${load.segmentOffset}:" +
                "%.4g%sj%.4g@p%d%s".format(
                    zl.re, if (zl.im >= 0.0) "+" else "-", abs(zl.im), pidx + 1,
                    if (specialGroundPulse) "[2/M]" else ""
                )
        }

        val rhsR = DoubleArray(n)
        val rhsI = DoubleArray(n)
        for (rs in resolvedSources) {
            val specialGroundPulse = isImageCompletedGroundPulse(rs.pulseIndex)
            if (specialGroundPulse && rs.source.wireIndex >= expansion.originalWireCount) continue
            // WirePulseRef.sign is the orientation of this wire reference relative
            // to the global MININEC pulse current.  A source voltage follows the same
            // orientation.  MMANA uses 2/M on an image-completed ground terminal pulse.
            val signedVoltage = rs.voltage * rs.pulseSign
            val scale = if (specialGroundPulse) 2.0 * invM else invM
            rhsR[rs.pulseIndex] += signedVoltage.im * scale
            rhsI[rs.pulseIndex] += -signedVoltage.re * scale
        }

        onProgress(MmanaSolverApi.Progress(75, "MMANA/MININEC solve"))
        val (ir, ii) = gaussianSolve(z.first, z.second, rhsR, rhsI, n, cancel)
        val primaryCurrent = C(ir[primary.pulseIndex], ii[primary.pulseIndex])
        require(primaryCurrent.mag() > 1e-18) { "MMANA/MININEC: zero source current" }
        val zin = (primary.voltage * primary.pulseSign) / primaryCurrent
        require(zin.re.isFinite() && zin.im.isFinite()) { "MMANA/MININEC: non-finite impedance" }

        val residual = matrixResidual(z.first, z.second, ir, ii, rhsR, rhsI, n)
        val allFields = buildFieldSegments(workModel, built, ir, ii, coreShift)
        val fields = if (expansion.unfolded)
            allFields.filter { it.tag <= expansion.originalWireCount }
        else allFields
        val minLr = fields.minOfOrNull { it.lengthM / max(abs(it.radiusM), 1e-12) } ?: Double.NaN
        val sourcesText = resolvedSources.take(model.sources.size).joinToString(";") { rs ->
            val ss = rs.source
            "W${ss.wireIndex + 1}${ss.position.uppercaseChar()}${ss.segmentOffset}" +
                "@${"%.3f".format(ss.amplitude)}∠${"%.1f".format(ss.phaseDeg)}°"
        }
        val sourceHost = resolvedSources.joinToString(",") { rs ->
            built.spansByWire.getOrNull(rs.source.wireIndex)?.size?.toString() ?: "0"
        }
        val loadHost = model.loads.joinToString(",") { ld ->
            built.spansByWire.getOrNull(ld.wireIndex)?.size?.toString() ?: "0"
        }
        val groundLabel = when {
            !physicalGround.hasGround -> "free"
            expansion.unfolded && physicalGround.mode == GroundModelV2.Mode.PEC_PLANE -> "PEC unfolded image"
            expansion.unfolded -> "real-earth grounded MMANA image"
            else -> "real-earth finite image"
        }
        val reportedPulses = if (!expansion.unfolded) n else
            ((n - expansion.groundedEndpointCount) / 2 + expansion.groundedEndpointCount)
        onProgress(MmanaSolverApi.Progress(100, "MMANA/MININEC complete"))
        return MmanaSolverApi.Result(
            rOhm = zin.re,
            xOhm = zin.im,
            segments = reportedPulses,
            passCount = 1,
            deltaPercent = 0.0,
            confidence = "MMANA/MININEC 1.19.264 • ${if (conductorConductivitySPerM == null) "PEC wire" else "Cu wire loss"} • $groundLabel",
            minSegmentRadiusRatio = minLr,
            matrixResidual = residual,
            junctionCount = built.junctionCount,
            resolvedSources = sourcesText,
            resolvedLoads = if (resolvedLoadText.isEmpty()) "none" else resolvedLoadText.joinToString(";"),
            skippedInsulatorWires = model.wires.count { abs(it.radiusM) <= 1e-15 },
            groundTerminalCount = if (expansion.unfolded) expansion.groundedEndpointCount else built.groundTerminalCount,
            endpointFineWireCount = 0,
            sourceHostSegments = sourceHost,
            loadHostSegments = loadHost,
            fieldSegments = fields
        )
    }


    private fun build(model: MaaModel, lambda: Double, zShift: Double, allowCompactShortTaper: Boolean = true): Built? {
        val params = MmanaGalSegmentation.parse(model.segmentationDescription)
            ?: MmanaGalSegmentation.Params()

        // MMANA uses geometry-aware tapering: in dense structures made from many
        // short connected wires it does not independently force every short piece
        // to lambda/DM1. Select the compact short-wire taper only for that physical
        // regime; ordinary dipoles, Yagis, loaded gamma matches and taper-wire-set
        // models retain their already validated segmentation.
        val shortLimit = lambda * 0.035
        val shortTagged = model.wires.count {
            it.tag in -3..-1 && it.lengthM > 1e-12 && it.lengthM <= shortLimit
        }
        val denseShortTaper = allowCompactShortTaper && model.groundType == 0 &&
            model.loads.isEmpty() &&
            !model.hasTaperWireExpansion &&
            model.wires.size >= 20 &&
            shortTagged * 3 >= model.wires.size * 2

        data class SegGeom(
            val wi: Int, val idx: Int, val a: V, val b: V, val len: Double,
            val dir: V, val radius: Double
        )
        data class EndRef(val wi: Int, val atStart: Boolean, val point: V, val seg: SegGeom)

        val pulses = ArrayList<Pulse>()
        val spansByWire = ArrayList<List<MmanaGalSegmentation.Span>>(model.wires.size)
        val segsByWire = ArrayList<List<SegGeom>>(model.wires.size)
        val refsByWire = ArrayList<MutableList<WirePulseRef>>(model.wires.size)

        // Use the physical MMANA segmentation everywhere.  The parser has already
        // expanded $$$ Taper wire set $$$ into stepped wires, so the solver does
        // not need a second, legacy taper path.
        for ((wi, w) in model.wires.withIndex()) {
            val rr = abs(w.radiusM)
            val length = w.lengthM
            if (rr <= 1e-15 || length <= 1e-12) {
                spansByWire.add(emptyList())
                segsByWire.add(emptyList())
                refsByWire.add(ArrayList())
                continue
            }

            var spans = if (model.legacyStackCopies > 1) {
                MmanaStackSegmentation.spans(length, lambda, w.tag, params)
            } else {
                MmanaGalSegmentation.spans(
                    length, lambda, w.tag, params, compactShortTaper = denseShortTaper
                )
            }
            if (spans.size < 2) spans = MmanaGalSegmentation.uniform(2)
            spansByWire += spans

            val a0 = V(w.x1, w.y1, w.z1 + zShift)
            val b0 = V(w.x2, w.y2, w.z2 + zShift)
            val delta = b0 - a0
            val dir = delta * (1.0 / length)
            val points = ArrayList<V>(spans.size + 1)
            points += a0 + delta * spans.first().f0
            spans.forEach { points += a0 + delta * it.f1 }

            val segs = ArrayList<SegGeom>(spans.size)
            for (k in spans.indices) {
                val aa = points[k]
                val bb = points[k + 1]
                segs += SegGeom(wi, k, aa, bb, (bb - aa).norm(), dir, rr)
            }
            segsByWire += segs

            val refs = ArrayList<WirePulseRef>()
            for (k in 0 until segs.lastIndex) {
                val sg0 = segs[k]
                val sg1 = segs[k + 1]
                val id = pulses.size
                pulses += Pulse(
                    local = k,
                    point = sg0.b,
                    endNeg = sg0.a,
                    endPos = sg1.b,
                    lenNeg = sg0.len,
                    lenPos = sg1.len,
                    dirNeg = sg0.dir,
                    dirPos = sg1.dir,
                    radiusNeg = sg0.radius,
                    radiusPos = sg1.radius,
                    wireNeg = wi,
                    wirePos = wi
                )
                refs += WirePulseRef(id, 1.0)
            }
            refsByWire += refs
        }

        val eps = max(1e-8, lambda * 1e-8)
        val eps2 = eps * eps
        val ends = ArrayList<EndRef>()
        for ((wi, segs) in segsByWire.withIndex()) {
            if (segs.isEmpty()) continue
            ends += EndRef(wi, true, segs.first().a, segs.first())
            ends += EndRef(wi, false, segs.last().b, segs.last())
        }

        val used = BooleanArray(ends.size)
        val connectedPairs = HashSet<Long>()
        var junctionCount = 0
        var groundTerminalCount = 0

        fun pairKey(a: Int, b: Int): Long {
            val x = minOf(a, b).toLong()
            val y = maxOf(a, b).toLong()
            return (x shl 32) xor (y and 0xffffffffL)
        }

        fun addRef(e: EndRef, ref: WirePulseRef) {
            val list = refsByWire[e.wi]
            if (e.atStart) list.add(0, ref) else list.add(ref)
        }

        fun addJunction(a: EndRef, b: EndRef, mapA: Boolean, mapB: Boolean) {
            val aFar = if (a.atStart) a.seg.b else a.seg.a
            val bFar = if (b.atStart) b.seg.b else b.seg.a
            val aSign = if (a.atStart) -1.0 else 1.0
            val bSign = if (b.atStart) 1.0 else -1.0
            val id = pulses.size
            pulses += Pulse(
                local = -1,
                point = a.point,
                endNeg = aFar,
                endPos = bFar,
                lenNeg = a.seg.len,
                lenPos = b.seg.len,
                dirNeg = a.seg.dir * aSign,
                dirPos = b.seg.dir * bSign,
                radiusNeg = a.seg.radius,
                radiusPos = b.seg.radius,
                wireNeg = a.wi,
                wirePos = b.wi
            )
            if (mapA) addRef(a, WirePulseRef(id, aSign))
            if (mapB) addRef(b, WirePulseRef(id, bSign))
            if (a.wi != b.wi) connectedPairs += pairKey(a.wi, b.wi)
            junctionCount++
        }

        // MININEC current unknowns live at wire junctions.  Two-way nodes are
        // exact.  For a multi-way node use a deterministic spanning tree, which
        // keeps every branch in the same pulse system without falling back to
        // another numerical engine.
        for (i in ends.indices) {
            if (used[i]) continue
            val group = ArrayList<Int>()
            group += i
            for (j in i + 1 until ends.size) {
                val d = ends[i].point - ends[j].point
                if (d.dot(d) <= eps2) group += j
            }
            group.forEach { used[it] = true }

            fun endpointHasSourceOrLoad(e: EndRef): Boolean {
                val pos = if (e.atStart) 'b' else 'e'
                val srcHit = model.sources.any {
                    it.wireIndex == e.wi && it.position.lowercaseChar() == pos && it.segmentOffset == 0
                }
                if (srcHit) return true
                return model.loads.any {
                    it.wireIndex == e.wi && it.position.lowercaseChar() == pos && it.segmentOffset == 0
                }
            }

            // At a 3+ wire node the spanning-tree root affects which physical
            // branch is represented by the first junction pulse.  Prefer an end
            // without a source/load so the fed/loaded branch keeps its full wire
            // current reference instead of becoming the partially mapped root.
            val rootGroupIndex = if (group.size >= 3) {
                group.firstOrNull { gi -> !endpointHasSourceOrLoad(ends[gi]) } ?: group.last()
            } else group.first()
            val root = ends[rootGroupIndex]
            if (model.groundType != 0 && abs(root.point.z) <= eps) {
                groundTerminalCount += group.size
            }
            if (group.size <= 1) continue

            // Mark all physical wire pairs at this node as connected for the
            // exact near-singular kernel decision.
            for (ga in 0 until group.size) {
                for (gb in ga + 1 until group.size) {
                    val ea = ends[group[ga]]
                    val eb = ends[group[gb]]
                    if (ea.wi != eb.wi) connectedPairs += pairKey(ea.wi, eb.wi)
                }
            }

            if (group.size == 2 && ends[group[0]].wi == ends[group[1]].wi) {
                // Closed loop: one closing pulse, mapped once to avoid duplicating
                // the same unknown in the wire's ordered pulse list.
                addJunction(ends[group[0]], ends[group[1]], mapA = true, mapB = false)
                continue
            }

            var rootMapped = false
            for (gi in group) {
                if (gi == rootGroupIndex) continue
                val other = ends[gi]
                addJunction(
                    root,
                    other,
                    mapA = !rootMapped,
                    mapB = true
                )
                rootMapped = true
            }
        }

        if (pulses.isEmpty()) return null
        return Built(
            pulses = pulses,
            pulseRefsByWire = refsByWire,
            spansByWire = spansByWire,
            connectedPairs = connectedPairs,
            junctionCount = junctionCount,
            groundTerminalCount = groundTerminalCount
        )
    }


    private class Engine(
        frequencyMHz: Double,
        private val p: List<Pulse>,
        private val connectedPairs: Set<Long>,
        private val ground: GroundModelV2.Spec,
        private val cancel: AtomicBoolean,
        private val progress: (Double) -> Unit
    ) {
        private val lambda = C_MHZ / frequencyMHz
        val m = 4.77783352 * lambda
        private val srm = 0.0001 * lambda
        private val wave = 2.0 * PI / lambda
        private val wave2 = wave * wave / 2.0
        private val omega = 2.0 * PI * frequencyMHz * 1e6
        private val groundImageCoeff: C = when (ground.mode) {
            GroundModelV2.Mode.FREE_SPACE -> C(0.0, 0.0)
            GroundModelV2.Mode.PEC_PLANE -> C(1.0, 0.0)
            GroundModelV2.Mode.REAL_EARTH -> {
                // MMANA/MININEC convention for the current/Z solution:
                // real-earth epsR/sigma are NOT used in the impedance matrix.
                // Input impedance and near reactive field assume a perfectly conducting
                // ground; real-earth loss is applied by the radiation-pattern ground model.
                C(1.0, 0.0)
            }
        }

        private val x2 = doubleArrayOf(-0.28867513459481287, 0.28867513459481287)
        private val w2 = doubleArrayOf(0.5, 0.5)
        private val x4 = doubleArrayOf(-0.4305681557970263, -0.16999052179242813, 0.16999052179242813, 0.4305681557970263)
        private val w4 = doubleArrayOf(0.17392742256872679, 0.3260725774312732, 0.3260725774312732, 0.17392742256872679)
        private val x8 = doubleArrayOf(-0.4801449282487681, -0.39833323870681336, -0.2627662049581645, -0.09171732124782489, 0.09171732124782489, 0.2627662049581645, 0.39833323870681336, 0.4801449282487681)
        private val w8 = doubleArrayOf(0.05061426814518853, 0.11119051722668721, 0.15685332293894344, 0.18134189168918083, 0.18134189168918083, 0.15685332293894344, 0.11119051722668721, 0.05061426814518853)

        fun matrix(): Pair<DoubleArray, DoubleArray> {
            val n = p.size
            val ar = DoubleArray(n * n)
            val ai = DoubleArray(n * n)
            for (row in 0 until n) {
                if ((row and 3) == 0) {
                    if (cancel.get()) throw InterruptedException("MMANA pulse solve cancelled")
                    progress(row.toDouble() / max(1, n))
                }
                val pr = p[row]
                val zzz = pr.dir(0) * pr.lenNeg + pr.dir(1) * pr.lenPos
                for (col in 0 until n) {
                    val pc = p[col]
                    val u = vectorPotential(row, col, +0.5)
                    val v = vectorPotential(row, col, -0.5)
                    val vecRe = pc.dir(1) * u.re + pc.dir(0) * v.re
                    val vecIm = pc.dir(1) * u.im + pc.dir(0) * v.im
                    val d = C(wave2 * vecRe.dot(zzz), wave2 * vecIm.dot(zzz))

                    val equalSidesRow = abs(pr.lenNeg - pr.lenPos) <= 1e-11 * max(pr.lenNeg, pr.lenPos)
                    val equalSidesCol = abs(pc.lenNeg - pc.lenPos) <= 1e-11 * max(pc.lenNeg, pc.lenPos)
                    val same = pr.simpleInternal && pc.simpleInternal &&
                        pr.wire(0) == pc.wire(0) && equalSidesRow && equalSidesCol
                    val f8 = if (same) if (row == col) 2 else 1 else 0
                    val scalar = if (f8 < 2) {
                        val u56 = if (f8 == 1) u + vectorPotential(row, col, -0.5)
                            else scalarPotential(row, col, +0.5, +1.0)
                        val sp1 = scalarPotential(row, col, -0.5, +1.0)
                        var s = (sp1 - u56) * (1.0 / pc.lenPos)
                        val u34 = scalarPotential(row, col, +0.5, -1.0)
                        val sp2 = if (f8 == 1) u56 else scalarPotential(row, col, -0.5, -1.0)
                        s = s + (u34 - sp2) * (1.0 / pc.lenNeg)
                        s
                    } else {
                        val sp = scalarPotential(row, col, -0.5, +1.0)
                        (sp * 2.0 - u * 4.0) * (1.0 / pc.lenPos)
                    }
                    val q = row * n + col
                    ar[q] = d.re + scalar.re
                    ai[q] = d.im + scalar.im

                    if (groundImageCoeff.mag() > 1e-15) {
                        val ipc = mirrorPulse(pc)
                        val iu = vectorPotentialImage(pr, ipc, +0.5)
                        val iv = vectorPotentialImage(pr, ipc, -0.5)
                        val ivecRe = ipc.dir(1) * iu.re + ipc.dir(0) * iv.re
                        val ivecIm = ipc.dir(1) * iu.im + ipc.dir(0) * iv.im
                        val id = C(wave2 * ivecRe.dot(zzz), wave2 * ivecIm.dot(zzz))

                        val is56 = scalarPotentialImage(pr, ipc, +0.5, +1.0)
                        val isp1 = scalarPotentialImage(pr, ipc, -0.5, +1.0)
                        var iscal = (isp1 - is56) * (1.0 / ipc.lenPos)
                        val iu34 = scalarPotentialImage(pr, ipc, +0.5, -1.0)
                        val isp2 = scalarPotentialImage(pr, ipc, -0.5, -1.0)
                        iscal = iscal + (iu34 - isp2) * (1.0 / ipc.lenNeg)

                        // PEC image: horizontal current reverses, vertical current keeps
                        // sign; electric charge reverses. mirrorPulse() encodes the
                        // current transform, therefore the scalar image enters with -1.
                        val imageEntry = id - iscal
                        val gi = imageEntry * groundImageCoeff
                        ar[q] += gi.re
                        ai[q] += gi.im
                    }
                }
            }
            progress(1.0)
            return ar to ai
        }

        private fun mirrorPoint(v: V) = V(v.x, v.y, -v.z)
        private fun mirrorDir(v: V) = V(-v.x, -v.y, v.z)

        private fun mirrorPulse(src: Pulse): Pulse = Pulse(
            local = src.local,
            point = mirrorPoint(src.point),
            endNeg = mirrorPoint(src.endNeg),
            endPos = mirrorPoint(src.endPos),
            lenNeg = src.lenNeg,
            lenPos = src.lenPos,
            dirNeg = mirrorDir(src.dirNeg),
            dirPos = mirrorDir(src.dirPos),
            radiusNeg = src.radiusNeg,
            radiusPos = src.radiusPos,
            wireNeg = src.wireNeg,
            wirePos = src.wirePos
        )

        private fun vectorPotentialImage(pr: Pulse, pc: Pulse, ds: Double): C {
            val side = if (ds > 0.0) 1 else 0
            val radius = pc.radius(side)
            val segLen = pc.len(side)
            val (a, b) = pc.dvecs(ds)
            return psi(a - pr.point, b - pr.point, ds, radius, segLen, exact = false, scalar = false)
        }

        private fun scalarPotentialImage(pr: Pulse, pc: Pulse, ds1: Double, ds2: Double): C {
            val side = if (ds2 > 0.0) 1 else 0
            val radius = pc.radius(side)
            val segLen = pc.len(side)
            val obs = pr.endSeg(ds1)
            val (a, b) = pc.dvecs(ds2)
            return psi(a - obs, b - obs, ds2, radius, segLen, exact = false, scalar = true)
        }

        private fun pairKey(a: Int, b: Int): Long {
            val x=minOf(a,b).toLong(); val y=maxOf(a,b).toLong()
            return (x shl 32) xor (y and 0xffffffffL)
        }
        private fun exactConnected(a: Pulse, b: Pulse): Boolean {
            val aw=intArrayOf(a.wire(0),a.wire(1)); val bw=intArrayOf(b.wire(0),b.wire(1))
            for (x in aw) for (y in bw) if (x==y || pairKey(x,y) in connectedPairs) return true
            return false
        }

        private fun vectorPotential(row: Int, col: Int, ds: Double): C {
            val pr = p[row]
            val pc = p[col]
            val side = if (ds > 0.0) 1 else 0
            val radius=pc.radius(side); val segLen=pc.len(side)
            if (row == col && radius < srm) {
                return C(kotlin.math.ln(segLen / radius), -wave * segLen / 2.0)
            }
            val (a, b) = pc.dvecs(ds)
            return psi(a - pr.point, b - pr.point, ds, radius, segLen, exact = exactConnected(pr,pc), scalar = false)
        }

        private fun scalarPotential(row: Int, col: Int, ds1: Double, ds2: Double): C {
            val pr = p[row]
            val pc = p[col]
            val side = if (ds2 > 0.0) 1 else 0
            val radius=pc.radius(side); val segLen=pc.len(side)
            if (pr.simpleInternal && pc.simpleInternal &&
                pr.wire(0)==pc.wire(0) &&
                abs((pr.local + ds1) - (pc.local + ds2 / 2.0)) < 1e-12 && radius < srm) {
                return C(2.0 * kotlin.math.ln(segLen / radius), -wave * segLen)
            }
            val obs = pr.endSeg(ds1)
            val (a, b) = pc.dvecs(ds2)
            return psi(a - obs, b - obs, ds2, radius, segLen, exact = exactConnected(pr,pc), scalar = true)
        }

        private fun psi(v2: V, vv: V, scale: Double, radius: Double, segLen: Double, exact: Boolean, scalar: Boolean): C {
            val d0 = v2.norm()
            val d3 = vv.norm()
            val s4 = abs(scale) * segLen
            val t = (d0 + d3) / segLen
            val useExact = exact && t <= 1.1
            val f2 = if (useExact) 2.0 * abs(scale) else 1.0
            val fvs = if (scalar) 2.0 else 1.0
            if (useExact && radius <= srm) {
                return C(fvs * kotlin.math.ln(segLen / radius), -0.5 * fvs * wave * segLen)
            }
            val order = when {
                useExact -> 8
                t > 10.0 -> 2
                t > 6.0 -> 4
                else -> 8
            }
            var q = quad(1.0 / f2, v2, vv, radius, useExact, order)
            if (useExact && radius > srm) {
                val i6 = (1.0 + kotlin.math.ln(16.0 * radius / segLen)) / (PI * radius)
                q = q + C(i6, 0.0)
            }
            return q * s4
        }

        private fun quad(bound: Double, v2: V, vv: V, radius: Double, exact: Boolean, order: Int): C {
            val xs = if (order == 2) x2 else if (order == 4) x4 else x8
            val ws = if (order == 2) w2 else if (order == 4) w4 else w8
            var sr = 0.0
            var si = 0.0
            for (i in xs.indices) {
                val t = (xs[i] + 0.5) * bound
                val q = integral(t, v2, vv, radius, exact)
                sr += ws[i] * q.re
                si += ws[i] * q.im
            }
            return C(sr, si)
        }

        private fun integral(t: Double, v2: V, vv: V, radius: Double, exact: Boolean): C {
            val q = v2 + (vv - v2) * t
            val d0 = q.norm().coerceAtLeast(1e-15)
            var d = d0
            var corr = 0.0
            if (radius > srm) {
                val a2 = radius * radius
                val d2 = d0 * d0
                d = sqrt(a2 + d2)
                if (exact) {
                    // MININEC thick-wire exact-kernel correction. pymininec uses
                    // K(1-b)*sqrt(1-b), b=d^2/(d^2+4a^2).
                    val b = d2 / (d2 + 4.0 * a2)
                    val mm = (1.0 - b).coerceIn(0.0, 1.0 - 1e-15)
                    val v0 = completeEllipticK(mm) * sqrt(mm)
                    val lr = kotlin.math.ln((d2 / (64.0 * a2)).coerceAtLeast(1e-300)) * 0.5
                    corr = (v0 + lr) / (PI * radius) - 1.0 / d
                }
            }
            val a = wave * d
            return C(cos(a) / d + corr, -sin(a) / d)
        }

        private fun completeEllipticK(m: Double): Double {
            if (m <= 0.0) return PI * 0.5
            var a = 1.0
            var b = sqrt((1.0 - m).coerceAtLeast(1e-30))
            repeat(32) {
                val an = (a + b) * 0.5
                val bn = sqrt(a * b)
                if (abs(an - bn) <= 1e-15 * max(1.0, an)) { a = an; return PI / (2.0 * a) }
                a = an; b = bn
            }
            return PI / (2.0 * a)
        }
    }

    private fun loadImpedance(load: MaaLoad, frequencyMHz: Double): C? {
        val omega = 2.0 * PI * frequencyMHz * 1e6
        return when (load.kind) {
            0 -> {
                val l = load.value1 * 1e-6
                val c = load.value2 * 1e-12
                val q = load.value3
                when {
                    l <= 0.0 && c <= 0.0 -> C(0.0, 0.0)
                    l > 0.0 && c <= 0.0 -> {
                        val x = omega * l
                        C(if (q > 0.0) abs(x) / q else 0.0, x)
                    }
                    l <= 0.0 && c > 0.0 -> {
                        val x = -1.0 / max(omega * c, 1e-30)
                        C(if (q > 0.0) abs(x) / q else 0.0, x)
                    }
                    else -> {
                        val xl = omega * l
                        val rl = if (q > 0.0) abs(xl) / q else 0.0
                        val xc = -1.0 / max(omega * c, 1e-30)
                        val rc = if (q > 0.0) abs(xc) / q else 0.0
                        val zl = C(rl, xl)
                        val zc = C(rc, xc)
                        val den = zl + zc
                        if (den.mag() < 1e-20) C(1e12, 0.0) else (zl * zc) / den
                    }
                }
            }
            1 -> C(load.value1, load.value2)
            else -> null
        }
    }

    private fun gaussianSolve(
        arIn: DoubleArray, aiIn: DoubleArray,
        brIn: DoubleArray, biIn: DoubleArray,
        n: Int, cancel: AtomicBoolean
    ): Pair<DoubleArray, DoubleArray> {
        val ar = arIn.copyOf(); val ai = aiIn.copyOf(); val br = brIn.copyOf(); val bi = biIn.copyOf()
        fun id(i: Int, j: Int) = i * n + j
        for (i in 0 until n) {
            var mx = 0.0
            for (j in 0 until n) mx = max(mx, hypot(ar[id(i,j)], ai[id(i,j)]))
            if (!mx.isFinite() || mx <= 1e-300) throw ArithmeticException("MININEC empty row $i")
            val inv = 1.0 / mx
            for (j in 0 until n) { val q=id(i,j); ar[q]*=inv; ai[q]*=inv }
            br[i]*=inv; bi[i]*=inv
        }
        val floor = 1e-12
        for (k in 0 until n) {
            if ((k and 3)==0 && cancel.get()) throw InterruptedException("MMANA pulse solve cancelled")
            var piv=k; var best=-1.0
            for (i in k until n) { val z=hypot(ar[id(i,k)],ai[id(i,k)]); if(z>best){best=z;piv=i} }
            if (!best.isFinite() || best<floor) throw ArithmeticException("MININEC ill-conditioned pivot $k")
            if (piv!=k) {
                for (j in 0 until n) { val a=id(k,j);val b=id(piv,j);var t=ar[a];ar[a]=ar[b];ar[b]=t;t=ai[a];ai[a]=ai[b];ai[b]=t }
                var t=br[k];br[k]=br[piv];br[piv]=t;t=bi[k];bi[k]=bi[piv];bi[piv]=t
            }
            val akr=ar[id(k,k)];val aki=ai[id(k,k)];val den=akr*akr+aki*aki
            for (i in k+1 until n) {
                val q=id(i,k);val xr=ar[q];val xi=ai[q]
                val fr=(xr*akr+xi*aki)/den; val fi=(xi*akr-xr*aki)/den
                ar[q]=0.0;ai[q]=0.0
                for (j in k+1 until n) { val ij=id(i,j);val kj=id(k,j);ar[ij]-=fr*ar[kj]-fi*ai[kj];ai[ij]-=fr*ai[kj]+fi*ar[kj] }
                br[i]-=fr*br[k]-fi*bi[k]; bi[i]-=fr*bi[k]+fi*br[k]
            }
        }
        val xr=DoubleArray(n);val xi=DoubleArray(n)
        for (i in n-1 downTo 0) {
            var sr=br[i];var si=bi[i]
            for (j in i+1 until n) { val q=id(i,j);sr-=ar[q]*xr[j]-ai[q]*xi[j];si-=ar[q]*xi[j]+ai[q]*xr[j] }
            val dr=ar[id(i,i)];val di=ai[id(i,i)];val den=dr*dr+di*di
            xr[i]=(sr*dr+si*di)/den;xi[i]=(si*dr-sr*di)/den
        }
        return xr to xi
    }

    private fun matrixResidual(
        ar: DoubleArray, ai: DoubleArray, xr: DoubleArray, xi: DoubleArray,
        br: DoubleArray, bi: DoubleArray, n: Int
    ): Double {
        var num = 0.0; var den = 0.0
        for (i in 0 until n) {
            var rr = -br[i]; var ri = -bi[i]
            for (j in 0 until n) { val q=i*n+j; rr += ar[q]*xr[j]-ai[q]*xi[j]; ri += ar[q]*xi[j]+ai[q]*xr[j] }
            num += rr*rr+ri*ri; den += br[i]*br[i]+bi[i]*bi[i]
        }
        return sqrt(num / max(den, 1e-300))
    }

    private fun buildFieldSegments(
        model: MaaModel,
        built: Built,
        ir: DoubleArray,
        ii: DoubleArray,
        zShift: Double
    ): List<AntennaSolveTypes.SegmentCurrent> {
        val out = ArrayList<AntennaSolveTypes.SegmentCurrent>()
        var global = 0
        for ((wi, w) in model.wires.withIndex()) {
            val spans = built.spansByWire[wi]
            val refs = built.pulseRefsByWire[wi]
            val len = w.lengthM
            val ux=w.dx/len;val uy=w.dy/len;val uz=w.dz/len
            // refs are ordered from B to E.  A connected endpoint contributes
            // one extra pulse at the corresponding end.
            val hasB = refs.size == spans.size && refs.isNotEmpty() && built.pulses[refs.first().id].local < 0
            val hasE = refs.size == spans.size && refs.isNotEmpty() && built.pulses[refs.last().id].local < 0
            fun pulseAtBoundary(boundary:Int): C {
                if (boundary==0) {
                    if (!hasB) return C(0.0,0.0)
                    val r=refs.first(); return C(ir[r.id],ii[r.id])*r.sign
                }
                if (boundary==spans.size) {
                    if (!hasE) return C(0.0,0.0)
                    val r=refs.last(); return C(ir[r.id],ii[r.id])*r.sign
                }
                val idx=(if(hasB) boundary else boundary-1).coerceIn(0,refs.lastIndex)
                val r=refs[idx]; return C(ir[r.id],ii[r.id])*r.sign
            }
            for (si in spans.indices) {
                val cur=(pulseAtBoundary(si)+pulseAtBoundary(si+1))*0.5
                val sp=spans[si];val fc=(sp.f0+sp.f1)*0.5;val sl=(sp.f1-sp.f0)*len
                out += AntennaSolveTypes.SegmentCurrent(
                    globalIndex=global++, tag=wi+1, segment=si+1,
                    xM=w.x1+w.dx*fc, yM=w.y1+w.dy*fc, zM=w.z1+zShift+w.dz*fc,
                    lengthM=sl, radiusM=w.radiusM,
                    ux=ux,uy=uy,uz=uz,currentReA=cur.re,currentImA=cur.im
                )
            }
        }
        return out
    }

}
