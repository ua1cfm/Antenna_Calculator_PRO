package ua1cfm.cstffs

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Application theme (1.19.268 UI refresh).
 *
 * Light only on purpose: the plots (Smith chart, patterns, 3D views) are drawn with fixed
 * colours that assume a light background, so a dark scheme would make them unreadable.
 */
private val AntennaColors = lightColorScheme(
    primary = Color(0xFF1F5F8B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E8F5),
    onPrimaryContainer = Color(0xFF0B2A40),
    secondary = Color(0xFF4F6B7A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCE7EE),
    onSecondaryContainer = Color(0xFF14262F),
    tertiary = Color(0xFF2E7D6B),
    onTertiary = Color.White,
    background = Color(0xFFF5F8FA),
    onBackground = Color(0xFF12191E),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF12191E),
    surfaceVariant = Color(0xFFE3EAEF),
    onSurfaceVariant = Color(0xFF44525B),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1F5F8),
    surfaceContainer = Color(0xFFEBF0F4),
    surfaceContainerHigh = Color(0xFFE6ECF0),
    surfaceContainerHighest = Color(0xFFE1E8ED),
    outline = Color(0xFF73828C),
    outlineVariant = Color(0xFFC6D0D6)
)

private val AntennaShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

private val AntennaTypography = Typography(
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun AntennaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AntennaColors,
        typography = AntennaTypography,
        shapes = AntennaShapes,
        content = content
    )
}
