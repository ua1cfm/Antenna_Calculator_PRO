# Antenna Calculator PRO 1.19.268 — UI Refresh (экспериментальная)

Основа: исходный проект 1.19.267 SWEEP FALLBACK GUARD.

Применено предложение из `files (1).zip`:
- `app/src/main/java/ua1cfm/cstffs/AppTheme.kt`: новая светлая Material3 палитра, закругления и типографика.
- `app/src/main/java/ua1cfm/cstffs/MainActivity.kt`: `setContent { AntennaTheme { CalculatorApp() } }`, без чего патч не влиял бы на главный экран.
- `app/build.gradle.kts`: `versionName = "1.19.268"`, `versionCode = 119268`.

## Сохранено
Вычислительное ядро MININEC, исправления sweep 1.19.266–267, Near Field, LiteVNA, модели и остальные исходники сохранены без функциональных изменений.

## Проверки
Проверены содержимое ZIP, наличие темы, включение её в точке входа, согласованность версии и неизменность файлов решателя. Полная Android-сборка и выполнение на телефоне здесь не выполнялись.

## Запуск
Откройте эту папку через Android Studio. Выполните Gradle Sync и Build > Make Project. Протестируйте все вкладки, Smith, 2D/3D, Near Field и экран LiteVNA при светлой теме.

© UA1CFM, 2026.
