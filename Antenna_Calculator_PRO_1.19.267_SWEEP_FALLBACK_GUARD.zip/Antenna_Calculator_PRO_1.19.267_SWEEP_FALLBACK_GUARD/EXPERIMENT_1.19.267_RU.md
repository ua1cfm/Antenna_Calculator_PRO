# Antenna Calculator PRO 1.19.267 — sweep fallback guard (experiment)

Base: 1.19.266. The geometry discretisation remains fixed at f0 for all sweep samples. No smoothing or impedance fitting.

## Confirmed defect
For activeSources >= 2, real ground (groundType == 2), and primary.rOhm < 0, MmanaSolverApi used to switch to MmanaMultiSourceReference without the sweep reference frequency. That solver uses independently adaptive discretisation. This could insert points from incompatible grids into one Smith trace.

## Change
When a sweep reference frequency is supplied and the fallback condition is reached, abort the sweep with an explicit diagnostic instead of drawing an inconsistent point. Single-frequency calculations and the fallback outside sweeps remain unchanged.

This is a safety/consistency fix, NOT a proof of more accurate impedance or a numerical fix for negative resistance. It does not alter DDRR single-source sweeps.

## Validation limits
Static assertion and source checks pass. No instrumented Android compile, 2435-model numerical regression or fresh MMANA comparison was possible. The previous 1.19.266 screenshot is the only available phone-level confirmation of improved Smith continuity.

## Follow-up
Implement a common frozen pulse topology for MmanaMultiSourceReference or remove its fallback after physical validation. Build a JVM numerical harness linking exactly the production solver, then compare model-level results against authoritative MMANA CSV.
