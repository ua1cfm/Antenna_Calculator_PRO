package ua1cfm.cstffs

import android.graphics.Paint
import android.graphics.Bitmap
import android.content.Intent
import android.content.ContentValues
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.os.Build
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.StringReader
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.nio.charset.Charset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.log10
import kotlin.math.sqrt
import kotlin.math.sin
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.ExecutionException

private enum class MaaViewMode { ISO, SIDE, FRONT }
private enum class MaaPatternMode { POLAR, RECT }
private enum class MaaCutView { PRINCIPAL_1, PRINCIPAL_2 }
private enum class MaaFieldDisplay { H_DB, E_DB, H_LINEAR, E_LINEAR, B_MICROTESLA, S_DB, S_LINEAR, Z_EH }
private enum class MaaFieldDetail { NORMAL, HIGH, ULTRA }


/**
 * Audio/visual impedance palette.
 * X < 0: violet/blue, X ~= 0: green, X > 0: yellow/red.
 * Brightness increases as |Gamma| approaches zero (better match).
 */
private fun impedanceSweepColor(rOhm: Double, xOhm: Double, z0Ohm: Double): Color {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val xNorm = (xOhm / (2.0 * z0)).coerceIn(-1.0, 1.0)
    val hue = if (xNorm <= 0.0) {
        (120.0 + (-xNorm) * 120.0).toFloat() // green -> blue
    } else {
        (120.0 - xNorm * 120.0).toFloat()    // green -> red
    }
    val den = (rOhm + z0) * (rOhm + z0) + xOhm * xOhm
    val gammaMag = if (den <= 1e-30 || !den.isFinite()) 1.0 else {
        val gr = (((rOhm - z0) * (rOhm + z0) + xOhm * xOhm) / den)
        val gi = (2.0 * z0 * xOhm / den)
        kotlin.math.hypot(gr, gi).coerceIn(0.0, 1.0)
    }
    val saturation = (0.58 + 0.34 * kotlin.math.abs(xNorm)).toFloat().coerceIn(0f, 1f)
    val value = (1.0 - 0.36 * gammaMag).toFloat().coerceIn(0.55f, 1f)
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, value)))
}


private fun sonogramScalarColor(value01: Double, invert: Boolean = false): Color {
    val u0 = value01.coerceIn(0.0, 1.0)
    val u = if (invert) 1.0 - u0 else u0
    // green -> yellow -> red: compact "good to bad" engineering palette.
    val hue = (120.0 * (1.0 - u)).toFloat()
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.82f, 0.96f)))
}

private fun sonogramResistanceColor(rOhm: Double, z0Ohm: Double): Color {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val e = ((rOhm - z0) / z0).coerceIn(-1.0, 1.0)
    // Low R = cyan/blue, R=R0 = green, high R = orange/red.
    val hue = if (e < 0.0) (120.0 + (-e) * 90.0) else (120.0 - e * 120.0)
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue.toFloat(), 0.78f, 0.95f)))
}

private fun sonogramPhaseColor(phaseDeg: Double): Color {
    val p = ((phaseDeg + 180.0) / 360.0).coerceIn(0.0, 1.0)
    val hue = (300.0 * p).toFloat()
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.72f, 0.95f)))
}

private fun gammaMagFromZ(rOhm: Double, xOhm: Double, z0Ohm: Double): Double =
    impedanceToGamma(rOhm, xOhm, z0Ohm).mag.coerceIn(0.0, 1.0)


private fun nearFieldRasterSize(gridSize: Int, detail: MaaFieldDetail, animated: Boolean): Int {
    val n = gridSize.coerceAtLeast(2)
    return if (animated) {
        when (detail) {
            MaaFieldDetail.NORMAL -> n.coerceIn(72, 96)
            MaaFieldDetail.HIGH -> n.coerceIn(96, 128)
            MaaFieldDetail.ULTRA -> n.coerceIn(128, 160)
        }
    } else {
        when (detail) {
            MaaFieldDetail.NORMAL -> max(n, 128).coerceAtMost(192)
            MaaFieldDetail.HIGH -> max(n * 2, 256).coerceAtMost(384)
            MaaFieldDetail.ULTRA -> max(n * 3, 384).coerceAtMost(512)
        }
    }
}

/** 1024-entry version of the previous blue-to-red HSV scale; precomputed to avoid per-pixel Color objects. */
private val nearFieldPaletteArgb: IntArray by lazy {
    IntArray(1024) { i ->
        val n = i / 1023f
        val hue = 240f * (1f - n)
        val value = (0.20f + 0.80f * kotlin.math.sqrt(n.toDouble()).toFloat()).coerceIn(0f, 1f)
        android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.92f, value))
    }
}

private data class LoadedMaa(
    val name: String?,
    val model: MaaModel,
    val rawText: String,
    val sourcePathHint: String?
)
private data class MaaFolderFile(val name: String, val relativePath: String, val uri: Uri)
private data class BuiltInMaaEntry(val path: String, val title: String, val frequencyMHz: Double?, val category: String)
private data class LearnedMaaEntry(
    val path: String,
    val title: String,
    val frequencyMHz: Double?,
    val antennaKind: String,
    val analysisProfile: String
)

@Composable
fun YagiMaaTab(injectedModel: MaaModel? = null) {
    val context = LocalContext.current
    // Geometry classifiers are retained only for labels/pattern orientation; they never select an impedance solver.
    remember {
        runCatching { context.assets.open("maa_geometry_forest_v2.tsv").use(MaaGeometryForestV2::install) }
        runCatching { context.assets.open("maa_geometry_policy_2435.tsv").use(MaaGeometryPolicyIndexV2::install) }
        true
    }
    var model by remember { mutableStateOf<MaaModel?>(null) }
    var fileName by remember { mutableStateOf<String?>(null) }
    var rawMaaText by remember { mutableStateOf<String?>(null) }
    // Full archive/document path is kept as semantic context for corpus-assisted MAA interpretation.
    var maaSourcePath by remember { mutableStateOf<String?>(null) }
    var currentMaaUri by remember { mutableStateOf<Uri?>(null) }
    var maaFolderUri by remember { mutableStateOf<Uri?>(null) }
    var maaFolderFiles by remember { mutableStateOf<List<MaaFolderFile>>(emptyList()) }
    var pendingMaaNavigation by remember { mutableStateOf(0) }
    var libraryExpanded by remember { mutableStateOf(false) }
    var librarySearch by remember { mutableStateOf("") }
    var libraryCategory by remember { mutableStateOf("ALL") }
    val builtInLibrary: List<BuiltInMaaEntry> by remember {
        mutableStateOf<List<BuiltInMaaEntry>>(
            runCatching {
                context.assets.open("maa_library_index.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.mapNotNull { line ->
                        val p = line.split('\t')
                        if (p.size < 4) null else BuiltInMaaEntry(
                            path = p[0],
                            title = p[1],
                            frequencyMHz = p[2].toDoubleOrNull(),
                            category = p[3]
                        )
                    }.toList()
                }
            }.getOrDefault(emptyList())
        )
    }
    // 1.19.127: keep the curated 722-model category corpus and add the full 1713-model
    // experience corpus. The 1713 labels were generated by THIS version's MaaParser from
    // geometry/topology, then learned as filename/title vocabulary. MMANA/MININEC is the
    // only physics engine; corpus learning never invents Z, currents or radiation patterns.
    val learned1713: List<LearnedMaaEntry> by remember {
        mutableStateOf<List<LearnedMaaEntry>>(
            runCatching {
                context.assets.open("maa_corpus_1713_index.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.mapNotNull { line ->
                        val p = line.split('\t')
                        if (p.size < 5) null else LearnedMaaEntry(
                            path = p[0],
                            title = p[1],
                            frequencyMHz = p[2].toDoubleOrNull(),
                            antennaKind = p[3],
                            analysisProfile = p[4]
                        )
                    }.toList()
                }
            }.getOrDefault(emptyList())
        )
    }
    val corpusLearner = remember(builtInLibrary, learned1713) {
        MaaCorpusLearner(
            seeds = builtInLibrary.map { MaaCorpusSeed(it.path, it.title, it.frequencyMHz, it.category) },
            experienceSeeds = learned1713.map {
                MaaCorpusExperienceSeed(it.path, it.title, it.frequencyMHz, it.antennaKind, it.analysisProfile)
            }
        )
    }
    var copperWireLoss by remember { mutableStateOf(true) }
    var analysisFrequencyMHz by remember { mutableStateOf<Double?>(null) }
    var analysisFrequencyText by remember { mutableStateOf("") }
    var analysisFrequencyError by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Open an MMANA-GAL antenna description file (*.maa).") }
    var viewMode by remember { mutableStateOf(MaaViewMode.ISO) }
    // Keep the last ISO geometry camera so the NEC 3D radiation pattern can open from
    // exactly the same engineering view instead of forcing the user to rotate it by hand.
    var geometryIsoYawDeg by remember { mutableFloatStateOf(-28f) }
    var geometryIsoPitchDeg by remember { mutableFloatStateOf(22f) }
    var geometryExpanded by remember { mutableStateOf(false) }
    var patternMode by remember { mutableStateOf(MaaPatternMode.POLAR) }
    var cutView by remember { mutableStateOf(MaaCutView.PRINCIPAL_1) }
    var radiation3DExpanded by remember { mutableStateOf(false) }
    var cuts2DExpanded by remember { mutableStateOf(false) }
    var radiation3DPoints by remember { mutableStateOf<List<Pattern3DPoint>>(emptyList()) }
    var radiation3DStepDeg by remember { mutableStateOf(5.0) }
    var radiation3DRunning by remember { mutableStateOf(false) }
    var radiation3DProgress by remember { mutableStateOf(0) }
    var radiation3DError by remember { mutableStateOf<String?>(null) }
    val solverScope = rememberCoroutineScope()
    // 1.19.191: isolated full-wave solver laboratory. It never feeds the production Zin/pattern path.
    var labResult by remember { mutableStateOf<MmanaSolverApi.Result?>(null) }
    var labRunning by remember { mutableStateOf(false) }
    var labProgress by remember { mutableStateOf(0) }
    var labStage by remember { mutableStateOf("Idle") }
    var labError by remember { mutableStateOf<String?>(null) }
    var labCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    // 1.19.206: unattended batch audit. One folder selection -> all MAA files -> one CSV.
    var batchRunning by remember { mutableStateOf(false) }
    var batchProgress by remember { mutableStateOf(0) }
    var batchStatus by remember { mutableStateOf("") }
    var batchLastReport by remember { mutableStateOf<String?>(null) }
    var batchCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    var batchAutoResumeChecked by remember { mutableStateOf(false) }
    var smithSweepPoints by remember { mutableStateOf<List<AntennaSolveTypes.SweepPoint>>(emptyList()) }
    var smithSweepRunning by remember { mutableStateOf(false) }
    var smithSweepProgress by remember { mutableStateOf(0) }
    var smithSweepError by remember { mutableStateOf<String?>(null) }
    var smithSweepCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    var fieldPlane by remember { mutableStateOf(NearFieldEngine.Plane.XZ) }
    var fieldDisplay by remember { mutableStateOf(MaaFieldDisplay.H_DB) }
    var fieldDetail by remember { mutableStateOf(MaaFieldDetail.HIGH) }
    var fieldGridText by remember { mutableStateOf("71") }
    var fieldRangeDbText by remember { mutableStateOf("60") }
    var fieldResult by remember { mutableStateOf<NearFieldEngine.Grid?>(null) }
    var fieldRunning by remember { mutableStateOf(false) }
    var fieldProgress by remember { mutableStateOf(0) }
    var fieldError by remember { mutableStateOf<String?>(null) }
    var fieldCancelToken by remember { mutableStateOf<AtomicBoolean?>(null) }
    var fieldVectorMode by remember { mutableStateOf(false) }
    var fieldCleanView by remember { mutableStateOf(false) }
    var phaseViewEnabled by remember { mutableStateOf(false) }
    var phaseAnimationRunning by remember { mutableStateOf(false) }
    var phaseAnimationDeg by remember { mutableFloatStateOf(0f) }
    var phaseAnimationSpeed by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(model) {
        // Every newly loaded MAA model starts from the same canonical ISO camera.
        geometryIsoYawDeg = -28f
        geometryIsoPitchDeg = 22f
    }

    // One NEC solution contains complex phasors. Animation only rotates their common time phase;
    // it never re-runs NEC and therefore cannot change input impedance or the solved current distribution.
    LaunchedEffect(phaseAnimationRunning, phaseAnimationSpeed) {
        while (phaseAnimationRunning) {
            delay(33L)
            phaseAnimationDeg = (phaseAnimationDeg + 3.0f * phaseAnimationSpeed) % 360.0f
        }
    }


    fun invalidateFullImpedance() {
        smithSweepCancelToken?.set(true)
        smithSweepCancelToken = null
        smithSweepRunning = false
        smithSweepPoints = emptyList()
        smithSweepProgress = 0
        smithSweepError = null
        labCancelToken?.set(true)
        labCancelToken = null
        labRunning = false
        labProgress = 0
        labStage = "Idle"
        labResult = null
        labError = null
        geometryExpanded = false
        radiation3DExpanded = false
        cuts2DExpanded = false
        radiation3DPoints = emptyList()
        radiation3DRunning = false
        radiation3DProgress = 0
        radiation3DError = null
        fieldResult = null
        fieldError = null
    }

    fun resetAnalysisResults() {
        phaseAnimationRunning = false
        phaseViewEnabled = false
        fieldVectorMode = false
        invalidateFullImpedance()
    }

    fun startRadiation3D(target: MaaModel, segments: List<AntennaSolveTypes.SegmentCurrent>) {
        if (radiation3DRunning) return
        radiation3DRunning = true
        radiation3DProgress = 0
        radiation3DError = null
        radiation3DPoints = emptyList()
        solverScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.Default) {
                    MmanaRadiationPattern.calculate3DFromFullWave(target, segments, thetaStepDeg = radiation3DStepDeg, phiStepDeg = radiation3DStepDeg) { done, total ->
                        solverScope.launch {
                            radiation3DProgress = if (total > 0) ((100.0 * done / total).toInt()).coerceIn(0, 100) else 0
                        }
                    }
                }
            }
            outcome.onSuccess { radiation3DPoints = it }
                .onFailure { radiation3DError = it.message ?: "3D pattern build error" }
            if (outcome.isSuccess) radiation3DProgress = 100
            radiation3DRunning = false
        }
    }

    fun parseAnalysisFrequency(text: String): Double? =
        text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() && it > 0.0 }

    fun startFullWaveLab(target: MaaModel) {
        val token = AtomicBoolean(false)
        val selectedWireMaterial = if (copperWireLoss) MmanaSolverApi.WireMaterial.COPPER else MmanaSolverApi.WireMaterial.PERFECT
        labCancelToken?.set(true)
        labCancelToken = token
        labRunning = true
        labProgress = 0
        labStage = "Preparing"
        labError = null
        labResult = null
        radiation3DPoints = emptyList()
        radiation3DError = null
        fieldResult = null
        fieldError = null
        solverScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.Default) {
                    MmanaSolverApi.solveAdaptive(target, token, 5, wireMaterial = selectedWireMaterial) { p ->
                        solverScope.launch {
                            labProgress = p.percent.coerceIn(0, 100)
                            labStage = p.stage
                        }
                    }
                }
            }
            outcome.onSuccess {
                labResult = it
                labProgress = 100
                labStage = "Complete"
            }.onFailure { err ->
                if (token.get()) labStage = "Cancelled" else {
                    labError = err.message ?: "MMANA/MININEC error"
                    labStage = "Error"
                }
            }
            labRunning = false
            if (labCancelToken === token) labCancelToken = null
        }
    }

    fun startSmithSweep(target: MaaModel) {
        val selectedWireMaterial = if (copperWireLoss) MmanaSolverApi.WireMaterial.COPPER else MmanaSolverApi.WireMaterial.PERFECT
        val centre = labResult ?: return
        if (labRunning || smithSweepRunning || fieldRunning) return

        val centreMHz = target.frequencyMHz
        if (!centreMHz.isFinite() || centreMHz <= 0.0) {
            smithSweepError = "Invalid center frequency."
            return
        }

        val token = AtomicBoolean(false)
        smithSweepCancelToken?.set(true)
        smithSweepCancelToken = token
        smithSweepRunning = true
        smithSweepPoints = emptyList()
        smithSweepProgress = 0
        smithSweepError = null

        solverScope.launch {
            // A high-Q antenna cannot be represented reliably by 21 uniformly
            // spaced samples over +/-5%. Concentrate physical solve points near f0.
            // The sweep keeps the entire +/-5% interval, with no smoothing/fitting.
            val count = 61
            val frequencies = List(count) { i ->
                val t = (2.0 * i / (count - 1).toDouble()) - 1.0
                val q = 0.05 * t * kotlin.math.abs(t)
                centreMHz * (1.0 + q)
            }
            val collected = ArrayList<AntennaSolveTypes.SweepPoint>(count)

            for ((index, frequencyMHz) in frequencies.withIndex()) {
                if (token.get()) break
                val pointResult = runCatching {
                    withContext(Dispatchers.Default) {
                        // Solve every point through the same path, including f0.
                        // Avoid mixing the previous single-frequency result with a
                        // separate sweep; hold the pulse discretisation at f0.
                        val rr = MmanaSolverApi.solveAdaptive(
                            target.copy(frequencyMHz = frequencyMHz),
                            token,
                            4,
                            wireMaterial = selectedWireMaterial,
                            segmentationReferenceMHz = centreMHz
                        ) {}
                        AntennaSolveTypes.SweepPoint(
                            frequencyMHz = frequencyMHz,
                            inputs = listOf(
                                AntennaSolveTypes.InputImpedance(
                                    tag = 1,
                                    segment = 1,
                                    rOhm = rr.rOhm,
                                    xOhm = rr.xOhm
                                )
                            )
                        )
                    }
                }
                if (pointResult.isFailure) {
                    val err = pointResult.exceptionOrNull()
                    smithSweepError = err?.message ?: "MMANA/MININEC sweep error"
                    break
                }
                val point = pointResult.getOrThrow()
                collected += point
                smithSweepPoints = collected.toList()
                smithSweepProgress = (((index + 1) * 100.0) / count).toInt().coerceIn(0, 100)
            }
            if (!token.get() && smithSweepError == null) smithSweepProgress = 100
            smithSweepRunning = false
            if (smithSweepCancelToken === token) smithSweepCancelToken = null
        }
    }

    fun readMaaUri(uri: Uri): Result<LoadedMaa> = runCatching {
        val name: String? = context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }

        val bytes: ByteArray = context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes()
        } ?: error("Failed to open file.")

        val text: String = decodeMaaText(bytes)
        // SAF document IDs often preserve a useful relative folder path (for example
        // ANT/HF multibands/Short/...).  Use it when available so the corpus learner can
        // understand feed/short/match variants instead of seeing only the bare filename.
        val documentPathHint = runCatching {
            DocumentsContract.getDocumentId(uri).substringAfter(':').replace('\\', '/')
        }.getOrNull()?.takeIf { it.isNotBlank() }
        val semanticPathHint = documentPathHint ?: name
        val parsed: MaaModel = BufferedReader(StringReader(text)).use { reader ->
            MaaParser.parse(reader, semanticPathHint)
        }
        LoadedMaa(name, parsed, text, semanticPathHint)
    }

    fun applyLoadedMaa(uri: Uri, loaded: LoadedMaa, keepFolderNavigation: Boolean) {
        val name: String? = loaded.name
        val parsed: MaaModel = loaded.model
        model = parsed
        fileName = name
        rawMaaText = loaded.rawText
        maaSourcePath = loaded.sourcePathHint
        currentMaaUri = uri
        if (!keepFolderNavigation) {
            maaFolderUri = null
            maaFolderFiles = emptyList()
            pendingMaaNavigation = 0
        }
        analysisFrequencyMHz = parsed.frequencyMHz
        analysisFrequencyText = "%.6g".format(parsed.frequencyMHz)
        analysisFrequencyError = null
        fieldPlane = NearFieldEngine.Plane.XZ
        fieldResult = null
        fieldProgress = 0
        fieldError = null
        status = "Done: ${parsed.wires.size} wires, ${parsed.elementStationsM.size} geometric positions. ${parsed.antennaKind}"
    }

    fun loadMaaUri(uri: Uri, keepFolderNavigation: Boolean) {
        readMaaUri(uri).onSuccess { loaded ->
            applyLoadedMaa(uri, loaded, keepFolderNavigation)
        }.onFailure { error ->
            status = "MAA error: ${error.message ?: "unknown error"}"
        }
    }

    fun loadBuiltInMaa(entry: BuiltInMaaEntry) {
        runCatching {
            val bytes = context.assets.open("maa_library/${entry.path}").use { it.readBytes() }
            val text = decodeMaaText(bytes)
            val parsed = BufferedReader(StringReader(text)).use { reader -> MaaParser.parse(reader, entry.path) }
            parsed to text
        }.onSuccess { (parsed, text) ->
            model = parsed
            fileName = entry.path.substringAfterLast('/')
            rawMaaText = text
            maaSourcePath = entry.path
            currentMaaUri = null
            maaFolderUri = null
            maaFolderFiles = emptyList()
            pendingMaaNavigation = 0
            analysisFrequencyMHz = parsed.frequencyMHz
            analysisFrequencyText = "%.6g".format(parsed.frequencyMHz)
            analysisFrequencyError = null
            resetAnalysisResults()
            fieldPlane = NearFieldEngine.Plane.XZ
            status = "Library: ${entry.category} / ${entry.title} • ${parsed.wires.size} wires. MMANA/MININEC ready."
            libraryExpanded = false
        }.onFailure { err ->
            status = "Library MAA error: ${err.message ?: "unknown error"}"
        }
    }

    /**
     * Recursive SAF scanner.
     *
     * Some Android document providers do not report subdirectories with the
     * standard MIME_TYPE_DIR value.  The older walker therefore saw only the
     * selected folder's direct *.maa files on those providers.
     *
     * 1.19.213 does not trust MIME type alone: every non-MAA child is also
     * probed as a possible parent document.  Regular files simply return no
     * children / throw and are treated as leaves.  Directory cycles are
     * prevented by document-id tracking.
     */
    fun listMaaFiles(treeUri: Uri): Result<List<MaaFolderFile>> = runCatching {
        val resolver = context.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val files = ArrayList<MaaFolderFile>()
        val visited = HashSet<String>()

        fun queryChildren(parentId: String): List<Triple<String, String, String?>> {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
            return try {
                resolver.query(
                    childrenUri,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE
                    ),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                    buildList {
                        while (cursor.moveToNext()) {
                            val id = if (idCol >= 0) cursor.getString(idCol) else null
                            val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                            val mime = if (mimeCol >= 0 && !cursor.isNull(mimeCol)) cursor.getString(mimeCol) else null
                            if (!id.isNullOrBlank() && !name.isNullOrBlank()) {
                                add(Triple(id, name, mime))
                            }
                        }
                    }
                } ?: emptyList()
            } catch (_: SecurityException) {
                emptyList()
            } catch (_: IllegalArgumentException) {
                emptyList()
            } catch (_: UnsupportedOperationException) {
                emptyList()
            } catch (_: RuntimeException) {
                // Several OEM document providers throw provider-specific RuntimeException
                // when a regular file is probed as a directory.
                emptyList()
            }
        }

        fun walk(parentId: String, prefix: String, depth: Int) {
            if (depth > 96 || !visited.add(parentId)) return

            val children = queryChildren(parentId)
            for ((docId, name, mime) in children) {
                val rel = if (prefix.isBlank()) name else "$prefix/$name"

                if (name.endsWith(".maa", ignoreCase = true)) {
                    files += MaaFolderFile(
                        name = name,
                        relativePath = rel,
                        uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                    )
                    continue
                }

                // Standard providers identify directories correctly.
                // OEM/provider fallback: probe any non-MAA child as a possible directory.
                val declaredDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR
                if (declaredDirectory) {
                    walk(docId, rel, depth + 1)
                } else {
                    val probe = queryChildren(docId)
                    if (probe.isNotEmpty()) {
                        // Avoid querying the same directory twice: process the already-fetched
                        // children through a small local traversal helper.
                        if (visited.add(docId)) {
                            fun walkKnown(
                                currentId: String,
                                currentPrefix: String,
                                knownChildren: List<Triple<String, String, String?>>,
                                currentDepth: Int
                            ) {
                                if (currentDepth > 96) return
                                for ((childId, childName, childMime) in knownChildren) {
                                    val childRel = if (currentPrefix.isBlank()) childName else "$currentPrefix/$childName"
                                    if (childName.endsWith(".maa", ignoreCase = true)) {
                                        files += MaaFolderFile(
                                            name = childName,
                                            relativePath = childRel,
                                            uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                                        )
                                    } else {
                                        val isDir = childMime == DocumentsContract.Document.MIME_TYPE_DIR
                                        if (isDir) {
                                            walk(childId, childRel, currentDepth + 1)
                                        } else {
                                            val grandChildren = queryChildren(childId)
                                            if (grandChildren.isNotEmpty() && visited.add(childId)) {
                                                walkKnown(
                                                    childId,
                                                    childRel,
                                                    grandChildren,
                                                    currentDepth + 1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            walkKnown(docId, rel, probe, depth + 1)
                        }
                    }
                }
            }
        }

        walk(rootId, "", 0)

        // Protect against duplicate provider aliases while keeping same-named files
        // from different subdirectories as distinct entries.
        files
            .distinctBy { it.uri.toString() }
            .sortedBy { it.relativePath.lowercase() }
    }

    fun batchCsvCell(value: Any?): String {
        val s = value?.toString() ?: ""
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + s.replace("\"", "\"\"") + "\""
        } else s
    }

    fun nearestStandard(r: Double): Pair<Double, Double>? {
        if (!r.isFinite() || r <= 0.0) return null
        val standards = doubleArrayOf(12.5, 28.0, 50.0, 75.0, 100.0, 150.0, 200.0, 300.0, 450.0, 600.0)
        val z0 = standards.minByOrNull { abs(it - r) } ?: return null
        return z0 to (100.0 * abs(r - z0) / z0)
    }

    fun writeBatchCsv(text: String): String {
        val name = "antenna_solver_audit_${System.currentTimeMillis()}.csv"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AntennaCalculator")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Cannot create CSV in Downloads")
            context.contentResolver.openOutputStream(uri, "w")!!.bufferedWriter(Charsets.UTF_8).use { it.write(text) }
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            "Downloads/AntennaCalculator/$name"
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            val out = File(dir, name)
            out.writeText(text, Charsets.UTF_8)
            out.absolutePath
        }
    }

    // Batch audit 1.19.210:
    // - recursive folder traversal from 1.19.209;
    // - foreground service + PARTIAL_WAKE_LOCK: screen may be off;
    // - row-by-row checkpoint after every antenna;
    // - automatic restart/resume from the first unfinished relative path;
    // - one bad/slow antenna never aborts the remaining corpus.
    fun startBatchAudit(
        files: List<MaaFolderFile>,
        treeUri: Uri,
        resumeExisting: Boolean = false
    ) {
        if (batchRunning || files.isEmpty()) return
        val selectedWireMaterial = if (copperWireLoss) MmanaSolverApi.WireMaterial.COPPER else MmanaSolverApi.WireMaterial.PERFECT

        val csvHeader = buildString {
            append("file,title,f_MHz,type,ground,wire_material,sources,loads,wires,R0_Ohm,")
            append("MININEC_R,MININEC_X,MININEC_status,MININEC_error,")
            append("nearest_standard_Ohm,R_deviation_percent,invalid_sources,invalid_loads,")
            append("matrix_residual,junctions,resolved_sources,resolved_loads,")
            append("R0_insulators_skipped,ground_terminals,source_host_segments,load_host_segments\n")
        }

        val existing = BatchResumeStore.checkpointText(context)
        val schemaMatches = existing.isBlank() || existing.lineSequence().firstOrNull() == csvHeader.trimEnd()
        if (!resumeExisting || !schemaMatches) {
            BatchResumeStore.clear(context)
            BatchResumeStore.begin(context, treeUri, files.size, csvHeader)
        } else if (existing.isBlank()) {
            BatchResumeStore.begin(context, treeUri, files.size, csvHeader)
        }

        val completed = BatchResumeStore.completedPaths(context)
        val alreadyDone = completed.size.coerceAtMost(files.size)
        val batchCancel = AtomicBoolean(false)
        batchCancelToken?.set(true)
        batchCancelToken = batchCancel
        batchRunning = true
        batchProgress = ((100.0 * alreadyDone) / files.size).roundToInt().coerceIn(0, 99)
        batchLastReport = null
        batchStatus = if (resumeExisting && alreadyDone > 0 && schemaMatches) {
            "Resuming MMANA/MININEC batch • $alreadyDone/${files.size} already saved"
        } else {
            "Preparing ${files.size} MAA files • MMANA/MININEC ONLY"
        }

        BatchKeepAliveService.start(
            context,
            text = "$alreadyDone/${files.size} • preparing",
            progress = batchProgress
        )

        solverScope.launch {
            val outcome = runCatching {
                withContext(Dispatchers.IO) {
                    var processed = alreadyDone

                    fun persistRow(relativePath: String, row: List<Any?>) {
                        val line = row.joinToString(",") { batchCsvCell(it) } + "\n"
                        processed++
                        BatchResumeStore.appendRow(
                            context = context,
                            relativePath = relativePath,
                            csvRowWithNewline = line,
                            processed = processed
                        )
                    }

                    for (entry in files) {
                        if (batchCancel.get()) break
                        if (entry.relativePath in completed) continue

                        fun ui(stage: String) {
                            val pct = ((100.0 * processed) / files.size)
                                .roundToInt().coerceIn(0, 99)
                            val text = "${processed + 1}/${files.size} • ${entry.relativePath} • $stage"
                            solverScope.launch {
                                batchProgress = pct
                                batchStatus = text
                            }
                            runCatching { BatchKeepAliveService.update(context, text, pct) }
                        }

                        ui("parse")
                        val parsedResult = runCatching {
                            val bytes = context.contentResolver.openInputStream(entry.uri)
                                ?.use { it.readBytes() } ?: error("Cannot open file")
                            val text = decodeMaaText(bytes)
                            BufferedReader(StringReader(text)).use {
                                MaaParser.parse(it, entry.relativePath)
                            }
                        }
                        val parsed = parsedResult.getOrNull()

                        if (parsed == null) {
                            val err = parsedResult.exceptionOrNull()?.message ?: "parse error"
                            persistRow(
                                entry.relativePath,
                                listOf(
                                    entry.relativePath, "", "", "", "", "", "", "", "",
                                    "", "", "", "PARSE: $err",
                                    "", "", "", "", "", "", "", "", "", "", "", ""
                                )
                            )
                            continue
                        }

                        var r: Double? = null
                        var x: Double? = null
                        var solverStatus = ""
                        var solverError = ""
                        var residual: Double? = null
                        var junctions: Int? = null
                        var resolvedSources = ""
                        var resolvedLoads = ""
                        var skippedInsulators: Int? = null
                        var groundTerminals: Int? = null
                        var sourceHostSegments = ""
                        var loadHostSegments = ""

                        val invalidTopology =
                            parsed.invalidSourceRecords > 0 ||
                            parsed.invalidLoadRecords > 0 ||
                            parsed.sources.isEmpty()

                        if (invalidTopology) {
                            solverError = "Invalid MAA source/load topology"
                        } else {
                            ui("MMANA/MININEC")
                            val solveCancel = AtomicBoolean(false)
                            val worker = Executors.newSingleThreadExecutor { task ->
                                Thread(task, "maa-batch-mininec").apply {
                                    isDaemon = true
                                    priority = Thread.MIN_PRIORITY
                                }
                            }
                            val future = worker.submit<MmanaSolverApi.Result> {
                                MmanaSolverApi.solveAdaptive(parsed, solveCancel, 1, wireMaterial = selectedWireMaterial) {}
                            }
                            try {
                                val z = future.get(25, TimeUnit.SECONDS)
                                r = z.rOhm
                                x = z.xOhm
                                solverStatus = z.confidence
                                residual = z.matrixResidual
                                junctions = z.junctionCount
                                resolvedSources = z.resolvedSources
                                resolvedLoads = z.resolvedLoads
                                skippedInsulators = z.skippedInsulatorWires
                                groundTerminals = z.groundTerminalCount
                                sourceHostSegments = z.sourceHostSegments
                                loadHostSegments = z.loadHostSegments
                            } catch (e: TimeoutException) {
                                solverError = "TIMEOUT after 25 s; skipped, batch continues"
                                solveCancel.set(true)
                                future.cancel(true)
                            } catch (e: ExecutionException) {
                                solverError = e.cause?.message
                                    ?: e.cause?.javaClass?.simpleName
                                    ?: "MMANA/MININEC error"
                            } catch (e: InterruptedException) {
                                solverError = "Interrupted"
                                solveCancel.set(true)
                                future.cancel(true)
                                Thread.currentThread().interrupt()
                            } finally {
                                solveCancel.set(true)
                                worker.shutdownNow()
                            }
                        }

                        val std = r?.let { nearestStandard(it) }
                        val ground = GroundModelV2.spec(parsed).label
                        val kind = runCatching { parsed.structuralKind }.getOrElse { "" }

                        persistRow(
                            entry.relativePath,
                            listOf(
                                entry.relativePath,
                                parsed.title,
                                parsed.frequencyMHz,
                                kind,
                                ground,
                                selectedWireMaterial.name,
                                parsed.sources.size,
                                parsed.loads.size,
                                parsed.wires.size,
                                parsed.referenceImpedanceOhms ?: "",
                                r ?: "",
                                x ?: "",
                                solverStatus,
                                solverError,
                                std?.first ?: "",
                                std?.second ?: "",
                                parsed.invalidSourceRecords,
                                parsed.invalidLoadRecords,
                                residual ?: "",
                                junctions ?: "",
                                resolvedSources,
                                resolvedLoads,
                                skippedInsulators ?: "",
                                groundTerminals ?: "",
                                sourceHostSegments,
                                loadHostSegments
                            )
                        )
                    }

                    val csv = BatchResumeStore.checkpointText(context)
                    val path = if (csv.isNotBlank()) writeBatchCsv(csv) else ""
                    Triple(
                        path,
                        processed,
                        if (batchCancel.get()) "Cancelled by user" else null
                    )
                }
            }

            outcome.onSuccess { (path, processed, reason) ->
                batchLastReport = path.takeIf { it.isNotBlank() }
                batchProgress = ((100.0 * processed) / files.size)
                    .roundToInt().coerceIn(0, 100)
                batchStatus = if (reason == null) {
                    BatchResumeStore.clear(context)
                    "Batch complete • $processed/${files.size} files • MMANA/MININEC CSV saved"
                } else {
                    BatchResumeStore.markInactive(context)
                    "Batch cancelled • $processed/${files.size} • partial CSV saved"
                }
            }.onFailure { err ->
                batchStatus = "Batch interrupted: ${err.message ?: "unknown"} • restart app to resume"
            }

            batchRunning = false
            if (batchCancelToken === batchCancel) batchCancelToken = null
            runCatching { BatchKeepAliveService.stop(context) }
        }
    }

    fun navigateMaaFiles(files: List<MaaFolderFile>, direction: Int) {
        if (files.isEmpty()) {
            status = "No *.maa files in the selected folder."
            return
        }
        val currentIndex = files.indexOfFirst { entry ->
            entry.uri == currentMaaUri || entry.name.equals(fileName, ignoreCase = true)
        }
        val targetIndex = if (currentIndex >= 0) {
            (currentIndex + direction + files.size) % files.size
        } else if (direction >= 0) {
            0
        } else {
            files.lastIndex
        }
        loadMaaUri(files[targetIndex].uri, keepFolderNavigation = true)
    }

    val folderPicker = rememberLauncherForActivityResult<Uri?, Uri?>(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        val direction = pendingMaaNavigation
        pendingMaaNavigation = 0
        if (treeUri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            listMaaFiles(treeUri).onSuccess { files ->
                maaFolderUri = treeUri
                maaFolderFiles = files
                status = "Recursive folder scan: ${files.size} MAA files found."
                if (direction != 0) navigateMaaFiles(files, direction)
            }.onFailure { error ->
                status = "Failed to read MAA folder: ${error.message ?: "access denied"}"
            }
        }
    }

    val batchFolderPicker = rememberLauncherForActivityResult<Uri?, Uri?>(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            listMaaFiles(treeUri).onSuccess { files ->
                maaFolderUri = treeUri
                maaFolderFiles = files
                batchStatus = "Recursive scan complete • ${files.size} MAA files found"
                startBatchAudit(files, treeUri, resumeExisting = false)
            }.onFailure { error ->
                batchStatus = "Batch folder error: ${error.message ?: "access denied"}"
            }
        }
    }

    // Restart recovery: persisted SAF permission + row checkpoint allow the corpus to
    // continue without asking the user to reselect the directory.
    LaunchedEffect(Unit) {
        if (!batchAutoResumeChecked) {
            batchAutoResumeChecked = true
            val pending = BatchResumeStore.pending(context)
            if (pending != null) {
                batchStatus = "Found unfinished batch • ${pending.processed}/${pending.total} • restoring…"
                listMaaFiles(pending.treeUri).onSuccess { files ->
                    maaFolderUri = pending.treeUri
                    maaFolderFiles = files
                    if (files.isNotEmpty()) {
                        startBatchAudit(files, pending.treeUri, resumeExisting = true)
                    } else {
                        batchStatus = "Resume failed: no *.maa files are accessible in the saved folder."
                    }
                }.onFailure { error ->
                    batchStatus = "Resume failed: ${error.message ?: "saved folder is no longer accessible"}"
                }
            }
        }
    }

    fun requestMaaNavigation(direction: Int) {
        if (direction == 0 || model == null) return
        val files = maaFolderFiles
        val currentKnown = files.any { entry ->
            entry.uri == currentMaaUri || entry.name.equals(fileName, ignoreCase = true)
        }
        if (maaFolderUri != null && files.isNotEmpty() && currentKnown) {
            navigateMaaFiles(files, direction)
        } else {
            pendingMaaNavigation = direction
            folderPicker.launch(null)
        }
    }

    val picker = rememberLauncherForActivityResult<Array<String>, Uri?>(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            loadMaaUri(uri, keepFolderNavigation = false)
        }
    }

    val saveCurrentMaa = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            val textToSave = rawMaaText ?: model?.let { MaaTextWriter.toText(it) }.orEmpty()
            if (textToSave.isNotBlank()) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(textToSave) }
                }.onFailure { err ->
                    status = "MAA save error: ${err.message ?: "unknown error"}"
                }.onSuccess {
                    status = "MAA saved successfully."
                }
            }
        }
    }

    LaunchedEffect(injectedModel) {
        val generated = injectedModel ?: return@LaunchedEffect
        resetAnalysisResults()
        model = generated
        fileName = "Yagi Designer — in memory"
        rawMaaText = MaaTextWriter.toText(generated)
        maaSourcePath = generated.fileNameHint
        currentMaaUri = null
        maaFolderUri = null
        maaFolderFiles = emptyList()
        pendingMaaNavigation = 0
        analysisFrequencyMHz = generated.frequencyMHz
        analysisFrequencyText = "%.6g".format(generated.frequencyMHz)
        analysisFrequencyError = null
        fieldPlane = NearFieldEngine.Plane.XZ
        geometryExpanded = true
        cuts2DExpanded = true
        status = "Yagi Designer geometry received: ${generated.wires.size} elements. MMANA/MININEC calculation started automatically."
    }

    Text("MAA Antenna Viewer", style = MaterialTheme.typography.titleLarge)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            modifier = Modifier.weight(0.24f),
            onClick = { requestMaaNavigation(-1) },
        ) { Text("<") }
        Button(
            modifier = Modifier.weight(1f),
            onClick = { picker.launch(arrayOf("*/*")) },
        ) { AutoFitButtonText("Open MAA") }
        Button(
            modifier = Modifier.weight(0.24f),
            onClick = { requestMaaNavigation(1) },
        ) { Text(">") }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(
            onClick = { libraryExpanded = !libraryExpanded },
            modifier = Modifier.weight(1f),
        ) { AutoFitButtonText(if (libraryExpanded) "ANTENNA LIBRARY ✓" else "ANTENNA LIBRARY (${builtInLibrary.size})", maxLines = 2, minFontSize = 9.sp) }
    }
    if (libraryExpanded) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = librarySearch,
                    onValueChange = { librarySearch = it },
                    label = { Text("Search antenna") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                val categories = listOf("ALL") + builtInLibrary.map { it.category }.distinct().sorted()
                val visibleCats = categories.chunked(4)
                visibleCats.forEach { group ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        group.forEach { cat ->
                            Button(
                                onClick = { libraryCategory = cat },
                                modifier = Modifier.weight(1f)
                            ) { AutoFitButtonText(if (libraryCategory == cat) "$cat ✓" else cat, maxLines = 2, minFontSize = 8.sp) }
                        }
                    }
                }
                val q = librarySearch.trim().lowercase()
                val filtered = builtInLibrary.filter { e ->
                    (libraryCategory == "ALL" || e.category == libraryCategory) &&
                        (q.isEmpty() || e.title.lowercase().contains(q) || e.path.lowercase().contains(q) || (e.frequencyMHz?.toString()?.contains(q) == true))
                }
                Text("${filtered.size} antenna(s) found", style = MaterialTheme.typography.bodySmall)
                filtered.take(30).forEach { e ->
                    Button(
                        onClick = { loadBuiltInMaa(e) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val f = e.frequencyMHz?.let { " • ${"%.6g".format(it)} MHz" } ?: ""
                        AutoFitButtonText("${e.title}$f", maxLines = 2, maxFontSize = 15.sp, minFontSize = 8.sp)
                    }
                }
                if (filtered.size > 30) Text("Showing first 30. Refine search or category.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (model != null) {
        Button(
            onClick = {
                val sourceName = fileName?.replace(" — in memory", "")?.trim()
                val suggested = if (!sourceName.isNullOrBlank() && sourceName.endsWith(".maa", ignoreCase = true)) {
                    sourceName.dropLast(4) + ".MAA"
                } else {
                    "Yagi_${model?.wires?.size ?: 0}el_${"%.3f".format(model?.frequencyMHz ?: 0.0)}MHz.MAA"
                }
                saveCurrentMaa.launch(suggested)
            },
            modifier = Modifier.fillMaxWidth(),
        ) { AutoFitButtonText("SAVE CURRENT MAA", maxLines = 2) }
    }

    model?.let { sourceModel ->
        val activeFrequencyMHz = analysisFrequencyMHz?.takeIf { it.isFinite() && it > 0.0 } ?: sourceModel.frequencyMHz
        val m = remember(sourceModel, activeFrequencyMHz) {
            if (abs(activeFrequencyMHz - sourceModel.frequencyMHz) < 1e-12) sourceModel
            else sourceModel.copy(frequencyMHz = activeFrequencyMHz)
        }
        MaaInfoCard(fileName, m, sourceModel.frequencyMHz, corpusLearner.profile(m, maaSourcePath))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = {
                    val open = !geometryExpanded
                    geometryExpanded = open
                    if (!open) radiation3DExpanded = false
                },
                modifier = Modifier.weight(1f)
            ) { Text(if (geometryExpanded) "3D MODEL ✓" else "3D MODEL", maxLines = 1) }
            Button(
                onClick = {
                    val open = !radiation3DExpanded
                    radiation3DExpanded = open
                    if (open) {
                        geometryExpanded = true
                        val segments = labResult?.fieldSegments.orEmpty()
                        if (segments.isNotEmpty() && radiation3DPoints.isEmpty() && !radiation3DRunning) {
                            startRadiation3D(m, segments)
                        }
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text(if (radiation3DExpanded) "3D PATTERN ✓" else "3D PATTERN", maxLines = 1) }
        }

        if (geometryExpanded && !radiation3DExpanded) {
            Card(modifier = Modifier.fillMaxWidth()) {
Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3D antenna model", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { viewMode = MaaViewMode.ISO }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.ISO) { Text("ISO") }
                        Button(onClick = { viewMode = MaaViewMode.SIDE }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.SIDE) { Text("SIDE") }
                        Button(onClick = { viewMode = MaaViewMode.FRONT }, modifier = Modifier.weight(1f), enabled = viewMode != MaaViewMode.FRONT) { Text("FRONT") }
                    }
                    MaaGeometryCanvas(m, viewMode) { yawDeg, pitchDeg ->
                        geometryIsoYawDeg = yawDeg
                        geometryIsoPitchDeg = pitchDeg
                    }
                }
            }
        }

        val visualizationSegments = labResult?.fieldSegments.orEmpty()
        val visualizationEngineLabel = "MMANA/MININEC complex currents"
        val fullPattern = remember(m, labResult, radiation3DPoints) {
            when {
                radiation3DPoints.isNotEmpty() -> {
                    val absolutePeakDbi = estimatePattern3DDirectivityDbi(radiation3DPoints)
                    runCatching { MmanaRadiationPattern.calculateFrom3D(m, radiation3DPoints, absolutePeakDbi) }.getOrNull()
                }
                visualizationSegments.isNotEmpty() ->
                    runCatching { MmanaRadiationPattern.calculateFromFullWave(m, visualizationSegments) }.getOrNull()
                else -> null
            }
        }
        val preview = fullPattern?.let { if (cutView == MaaCutView.PRINCIPAL_1) it.previewTop else it.previewSide }


        if (radiation3DExpanded) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        if (radiation3DStepDeg != 5.0) {
                            radiation3DStepDeg = 5.0
                            radiation3DPoints = emptyList()
                            radiation3DError = null
                            labResult?.fieldSegments?.takeIf { it.isNotEmpty() }?.let { startRadiation3D(m, it) }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !radiation3DRunning && radiation3DStepDeg != 5.0
                ) { Text("NORMAL 5°", maxLines = 1) }
                Button(
                    onClick = {
                        if (radiation3DStepDeg != 2.5) {
                            radiation3DStepDeg = 2.5
                            radiation3DPoints = emptyList()
                            radiation3DError = null
                            labResult?.fieldSegments?.takeIf { it.isNotEmpty() }?.let { startRadiation3D(m, it) }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    enabled = !radiation3DRunning && radiation3DStepDeg != 2.5
                ) { Text("PRECISE 2.5°", maxLines = 1) }
            }
            when {
                visualizationSegments.isEmpty() -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Run CALCULATE ANTENNA first. 3D PATTERN uses the same MMANA/MININEC currents as R+jX.",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                radiation3DRunning -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("Building 3D pattern ${format3DStep(radiation3DStepDeg)}°… ${radiation3DProgress}%", style = MaterialTheme.typography.bodyMedium)
                            LinearProgressIndicator(progress = { radiation3DProgress / 100f }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                radiation3DError != null -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("3D pattern: ${radiation3DError}", style = MaterialTheme.typography.bodyMedium)
                            Button(onClick = { labResult?.fieldSegments?.takeIf { it.isNotEmpty() }?.let { startRadiation3D(m, it) } }) { Text("RETRY") }
                        }
                    }
                }
                radiation3DPoints.isNotEmpty() -> {
                    val peak3D = remember(radiation3DPoints) { radiation3DPoints.maxByOrNull { it.db } }
                    val dMax3D = remember(radiation3DPoints) { estimatePattern3DDirectivityDbi(radiation3DPoints) }
                    val back3D = remember(radiation3DPoints, peak3D) {
                        peak3D?.let { peak ->
                            val targetPhi = (peak.phiDeg + 180.0) % 360.0
                            val sameTheta = radiation3DPoints.filter { abs(it.thetaDeg - peak.thetaDeg) < 1e-6 }
                            sameTheta.minByOrNull { p ->
                                val d = abs(p.phiDeg - targetPhi) % 360.0
                                min(d, 360.0 - d)
                            }
                        }
                    }
                    val fb3D = remember(peak3D, back3D) {
                        if (peak3D != null && back3D != null) peak3D.db - back3D.db else null
                    }
                    Radiation3DCard(
                        title = "3D antenna + radiation pattern",
                        points = radiation3DPoints,
                        subtitle = "θ/φ step ${format3DStep(radiation3DStepDeg)}°",
                        initialRadiusScale = Radius3DScale.DB,
                        absolutePeakDbi = dMax3D,
                        absolutePeakLabel = "Dmax",
                        peakThetaDeg = peak3D?.thetaDeg,
                        peakPhiDeg = peak3D?.phiDeg,
                        geometryViewYawDeg = when (viewMode) {
                            MaaViewMode.ISO -> geometryIsoYawDeg
                            MaaViewMode.SIDE -> 0f
                            MaaViewMode.FRONT -> -90f
                        },
                        geometryViewPitchDeg = when (viewMode) {
                            MaaViewMode.ISO -> geometryIsoPitchDeg
                            MaaViewMode.SIDE, MaaViewMode.FRONT -> 0f
                        },
                        // Geometry and pattern are now rendered in one common X/Y/Z scene.
                        // No display-only azimuth rotation is applied: phi=0 is +X, phi=90 is +Y.
                        patternAzimuthDisplayOffsetDeg = 0.0,
                        overlayModel = m
                    )
                    if (peak3D != null) {
                        val mainAz = ((peak3D.phiDeg % 360.0) + 360.0) % 360.0
                        val mainEl = 90.0 - peak3D.thetaDeg
                        val backAz = back3D?.let { ((it.phiDeg % 360.0) + 360.0) % 360.0 }
                        val frontD = dMax3D?.let { it + peak3D.db }
                        val backD = if (dMax3D != null && back3D != null) dMax3D + back3D.db else null
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("3D result", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Main: az %.1f°   el %.1f°".format(mainAz, mainEl),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                if (back3D != null && backAz != null) {
                                    Text(
                                        "Back: az %.1f°   el %.1f°".format(backAz, 90.0 - back3D.thetaDeg),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                if (frontD != null && backD != null) {
                                    Text(
                                        "Front %.2f dBi   Back %.2f dBi".format(frontD, backD),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                if (fb3D != null) {
                                    Text(
                                        "F/B = %.2f dB".format(fb3D),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                    Button(
                        onClick = { cuts2DExpanded = !cuts2DExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (cuts2DExpanded) "2D CUTS ✓" else "2D CUTS") }
                    if (cuts2DExpanded) {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Radiation-pattern cuts", style = MaterialTheme.typography.bodyMedium)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val p1 = fullPattern?.principalPlane1Label ?: "P1"
                                    val p2 = fullPattern?.principalPlane2Label ?: "P2"
                                    Button(onClick = { cutView = MaaCutView.PRINCIPAL_1 }, modifier = Modifier.weight(1f), enabled = cutView != MaaCutView.PRINCIPAL_1) { Text(p1, maxLines = 1) }
                                    Button(onClick = { cutView = MaaCutView.PRINCIPAL_2 }, modifier = Modifier.weight(1f), enabled = cutView != MaaCutView.PRINCIPAL_2) { Text(p2, maxLines = 1) }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { patternMode = MaaPatternMode.POLAR }, modifier = Modifier.weight(1f), enabled = patternMode != MaaPatternMode.POLAR) { Text("POLAR") }
                                    Button(onClick = { patternMode = MaaPatternMode.RECT }, modifier = Modifier.weight(1f), enabled = patternMode != MaaPatternMode.RECT) { Text("dB / ANGLE") }
                                }
                                if (preview == null || preview.points.isEmpty()) {
                                    Text("No 2D pattern data.")
                                } else {
                                    if (patternMode == MaaPatternMode.POLAR) MaaPolarPattern(preview) else MaaRectPattern(preview)
                                    val planeLabel = fullPattern?.let {
                                        if (cutView == MaaCutView.PRINCIPAL_1) it.principalPlane1Label else it.principalPlane2Label
                                    } ?: if (cutView == MaaCutView.PRINCIPAL_1) "P1" else "P2"
                                    MaaPatternEngineeringInfo(m, preview, planeLabel)
                                }
                            }
                        }
                    }
                }
                else -> {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text("Preparing 3D pattern…", modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MAA / MMANA/MININEC analysis", style = MaterialTheme.typography.titleMedium)

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Analysis frequency", style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(
                            value = analysisFrequencyText,
                            onValueChange = { value ->
                                analysisFrequencyText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(14)
                                analysisFrequencyError = null
                            },
                            label = { Text("Frequency, MHz") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            isError = analysisFrequencyError != null,
                            supportingText = analysisFrequencyError?.let { err -> { Text(err) } }
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    val f = sourceModel.frequencyMHz
                                    analysisFrequencyText = "%.6g".format(f)
                                    analysisFrequencyMHz = f
                                    analysisFrequencyError = null
                                    resetAnalysisResults()
                                    startFullWaveLab(sourceModel)
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("FROM MAA") }
                            Button(
                                onClick = {
                                    val f = parseAnalysisFrequency(analysisFrequencyText)
                                    if (f == null) {
                                        analysisFrequencyError = "Enter a frequency greater than 0 MHz"
                                    } else {
                                        analysisFrequencyMHz = f
                                        analysisFrequencyText = "%.6g".format(f)
                                        analysisFrequencyError = null
                                        resetAnalysisResults()
                                        startFullWaveLab(sourceModel.copy(frequencyMHz = f))
                                    }
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("APPLY") }
                        }
                        Button(onClick = {
                            copperWireLoss = !copperWireLoss
                            resetAnalysisResults()
                        }) {
                            Text(if (copperWireLoss) "WIRE MATERIAL: Cu" else "WIRE MATERIAL: PERFECT (PEC)")
                        }
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("ANTENNA CALCULATION", style = MaterialTheme.typography.titleSmall)

                        Button(
                            onClick = { startFullWaveLab(m) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(if (labRunning) "CALCULATING…" else "CALCULATE ANTENNA", maxLines = 1)
                        }

                        if (labRunning) {
                            LinearProgressIndicator(
                                progress = { labProgress.coerceIn(0, 100) / 100f },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("$labProgress% • $labStage", style = MaterialTheme.typography.bodySmall)
                        }

                        labError?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall)
                        }

                        labResult?.let { r ->
                            val r0 = (m.referenceImpedanceOhms ?: 50.0).coerceAtLeast(1.0)
                            val gammaDen = (r.rOhm + r0) * (r.rOhm + r0) + r.xOhm * r.xOhm
                            val gammaMag = if (gammaDen > 0.0) {
                                val gr = ((r.rOhm - r0) * (r.rOhm + r0) + r.xOhm * r.xOhm) / gammaDen
                                val gi = (2.0 * r.xOhm * r0) / gammaDen
                                kotlin.math.sqrt(gr * gr + gi * gi).coerceIn(0.0, 0.999999999)
                            } else 0.999999999
                            val swr = (1.0 + gammaMag) / (1.0 - gammaMag)

                            Text(
                                buildString {
                                    
                                    append("%.2f %s j%.2f Ω".format(
                                        r.rOhm,
                                        if (r.xOhm >= 0.0) "+" else "−",
                                        kotlin.math.abs(r.xOhm)
                                    ))
                                    append(" • SWR ")
                                    append(if (swr.isFinite()) "%.3f".format(swr) else "∞")
                                },
                                style = MaterialTheme.typography.bodyMedium
                            )

                            r.deltaPercent?.let { d ->
                                Text(
                                    "${r.segments} seg. • ${r.passCount} passes • Δ=${"%.2f".format(d)}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            // Smith chart restored for the MMANA/MININEC main engine.
                            // The main marker is the exact MMANA/MININEC impedance shown above.
                            val smithPrimary = AntennaSolveTypes.InputImpedance(
                                tag = 1,
                                segment = 1,
                                rOhm = r.rOhm,
                                xOhm = r.xOhm
                            )
                            AntennaSmithCard(
                                primary = smithPrimary,
                                inputs = listOf(smithPrimary),
                                z0Ohm = r0,
                                sweepPoints = smithSweepPoints,
                                sweepRunning = smithSweepRunning,
                                sweepProgress = smithSweepProgress,
                                sweepError = smithSweepError,
                                onStartSweep = { startSmithSweep(m) },
                                onCancelSweep = { smithSweepCancelToken?.set(true) }
                            )
                        }
                    }
                }

            }
        }

        if (visualizationSegments.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("MMANA/MININEC current/field phase animation", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                phaseViewEnabled = true
                                phaseAnimationRunning = !phaseAnimationRunning
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(if (phaseAnimationRunning) "⏸ PAUSE" else "▶ PHASE ANIMATION") }
                        Button(
                            onClick = {
                                phaseAnimationRunning = false
                                phaseViewEnabled = false
                            },
                            modifier = Modifier.weight(1f),
                            enabled = phaseViewEnabled
                        ) { Text("STATIC") }
                    }
                    Text("Phase: ${"%.1f".format(phaseAnimationDeg)}°", style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = phaseAnimationDeg,
                        onValueChange = {
                            phaseAnimationRunning = false
                            phaseViewEnabled = true
                            phaseAnimationDeg = it
                        },
                        valueRange = 0f..360f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(0.25f, 0.5f, 1.0f, 2.0f).forEach { speed ->
                            Button(
                                onClick = { phaseAnimationSpeed = speed },
                                modifier = Modifier.weight(1f),
                                enabled = kotlin.math.abs(phaseAnimationSpeed - speed) > 0.001f
                            ) { Text("${if (speed == speed.toInt().toFloat()) speed.toInt() else speed}×") }
                        }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Electromagnetic field E/H/B/S — Near Field", style = MaterialTheme.typography.titleMedium)

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.XY; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.XY) { Text("XY") }
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.XZ; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.XZ) { Text("XZ") }
                    Button(onClick = { fieldPlane = NearFieldEngine.Plane.YZ; fieldResult = null }, modifier = Modifier.weight(1f), enabled = !fieldRunning && fieldPlane != NearFieldEngine.Plane.YZ) { Text("YZ") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = fieldGridText,
                        onValueChange = { fieldGridText = it.filter(Char::isDigit); fieldResult = null },
                        label = { Text("Grid") },
                        singleLine = true,
                        enabled = !fieldRunning,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fieldRangeDbText,
                        onValueChange = { fieldRangeDbText = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } },
                        label = { Text("dB range") },
                        singleLine = true,
                        enabled = !fieldRunning,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDetail = MaaFieldDetail.NORMAL }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.NORMAL) { Text("FIELD N") }
                    Button(onClick = { fieldDetail = MaaFieldDetail.HIGH }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.HIGH) { Text("FIELD HD") }
                    Button(onClick = { fieldDetail = MaaFieldDetail.ULTRA }, modifier = Modifier.weight(1f), enabled = fieldDetail != MaaFieldDetail.ULTRA) { Text("FIELD ULTRA") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.H_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.H_DB) { Text("H dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.E_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.E_DB) { Text("E dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.B_MICROTESLA }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.B_MICROTESLA) { Text("B µT") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.H_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.H_LINEAR) { Text("H A/m") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.E_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.E_LINEAR) { Text("E V/m") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(
                        onClick = {
                            val enableVector = !fieldVectorMode
                            fieldVectorMode = enableVector
                            if (enableVector) {
                                fieldDisplay = MaaFieldDisplay.E_LINEAR
                                phaseViewEnabled = true
                            } else {
                                phaseAnimationRunning = false
                                phaseViewEnabled = false
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(if (fieldVectorMode) "E-VECTOR ✓" else "E-VECTOR") }
                    Button(
                        onClick = {
                            fieldVectorMode = true
                            fieldDisplay = MaaFieldDisplay.E_LINEAR
                            phaseViewEnabled = true
                            phaseAnimationRunning = !phaseAnimationRunning
                        },
                        modifier = Modifier.weight(1f),
                        enabled = fieldResult != null
                    ) { Text(if (phaseAnimationRunning && fieldVectorMode) "⏸ E" else "▶ ROTATE E") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.S_DB }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.S_DB) { Text("S dB") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.S_LINEAR }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.S_LINEAR) { Text("S W/m²") }
                    Button(onClick = { fieldDisplay = MaaFieldDisplay.Z_EH }, modifier = Modifier.weight(1f), enabled = !fieldVectorMode && fieldDisplay != MaaFieldDisplay.Z_EH) { Text("|E|/|H|") }
                }
                val segmentsForField = visualizationSegments.map { sg ->
                    Nec2Core.NearFieldSegment(
                        x = sg.xM,
                        y = sg.yM,
                        z = sg.zM,
                        ux = sg.ux,
                        uy = sg.uy,
                        uz = sg.uz,
                        lengthM = sg.lengthM,
                        radiusM = sg.radiusM,
                        currentReA = sg.currentReA,
                        currentImA = sg.currentImA,
                        wireIndex = sg.tag - 1
                    )
                }
                if (segmentsForField.isEmpty()) {
                    Text("MMANA/MININEC complex currents are required. Run CALCULATE ANTENNA first.", style = MaterialTheme.typography.bodySmall)
                } else if (!fieldRunning) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Button(
                            onClick = {
                                val token = AtomicBoolean(false)
                                fieldCancelToken = token
                                fieldRunning = true
                                fieldProgress = 0
                                fieldError = null
                                val halfSpan = NearFieldEngine.autoHalfSpanLambda(m, fieldPlane)
                                val grid = (fieldGridText.toIntOrNull() ?: 71).coerceIn(21, 161)
                                solverScope.launch {
                                    val outcome = runCatching {
                                        withContext(Dispatchers.Default) {
                                            NearFieldEngine.calculate(
                                                model = m,
                                                segments = segmentsForField,
                                                plane = fieldPlane,
                                                halfSpanLambda = halfSpan,
                                                gridSize = grid,
                                                currentSourceLabel = visualizationEngineLabel,
                                                onProgress = { pr -> solverScope.launch { fieldProgress = pr.percent } },
                                                isCancelled = { token.get() }
                                            )
                                        }
                                    }
                                    outcome.onSuccess { fieldResult = it; fieldProgress = 100 }
                                    outcome.onFailure { e -> fieldError = e.message ?: "Near Field error" }
                                    fieldRunning = false
                                    fieldCancelToken = null
                                }
                            },
                            modifier = Modifier.weight(2f)
                        ) { Text(if (fieldResult == null) "CALCULATE FIELD" else "RECALCULATE FIELD") }
                    }
                } else {
                    Text("$fieldProgress% • Calculating electromagnetic field", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { fieldProgress.coerceIn(0,100) / 100f }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { fieldCancelToken?.set(true) }, modifier = Modifier.fillMaxWidth()) { Text("CANCEL FIELD") }
                }
                fieldError?.let { Text("Near Field: $it", style = MaterialTheme.typography.bodySmall) }
                fieldResult?.let { g ->
                    val fieldRangeDb = (fieldRangeDbText.replace(",", ".").toDoubleOrNull() ?: 60.0).coerceIn(20.0, 100.0)
                    val animatedFieldFrame = fieldVectorMode || phaseViewEnabled
                    // In E-VECTOR mode only arrows rotate; the colour envelope is static and can stay HD.
                    val animatedColorRaster = phaseViewEnabled && !fieldVectorMode
                    val rasterSize = nearFieldRasterSize(g.size, fieldDetail, animatedColorRaster)
                    Text(
                        "Display raster ${rasterSize}×${rasterSize} • GPU smooth filtering • physics grid ${g.size}×${g.size}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    NearFieldHeatMap(
                        model = m,
                        grid = g,
                        display = fieldDisplay,
                        detail = fieldDetail,
                        dbRange = fieldRangeDb,
                        phaseDeg = if (animatedFieldFrame) phaseAnimationDeg else null,
                        vectorMode = fieldVectorMode,
                        cleanWireArtifacts = fieldCleanView
                    )
                    val peakText = when (fieldDisplay) {
                        MaaFieldDisplay.H_DB -> "0.0 dB (|H|)"
                        MaaFieldDisplay.E_DB -> "0.0 dB (|E|)"
                        MaaFieldDisplay.S_DB -> "0.0 dB (|S|)"
                        MaaFieldDisplay.H_LINEAR -> "${"%.4g".format(g.peakHAmpPerM)} A/m"
                        MaaFieldDisplay.E_LINEAR -> "${"%.4g".format(g.peakEVoltPerM)} V/m"
                        MaaFieldDisplay.B_MICROTESLA -> "${"%.4g".format(g.peakBMicroTesla)} µT"
                        MaaFieldDisplay.S_LINEAR -> "${"%.4g".format(g.peakPowerDensityWPerM2)} W/m²"
                        MaaFieldDisplay.Z_EH -> "local |E|/|H|"
                    }
                    val peakU = when (fieldDisplay) {
                        MaaFieldDisplay.E_DB, MaaFieldDisplay.E_LINEAR -> g.peakEU
                        MaaFieldDisplay.S_DB, MaaFieldDisplay.S_LINEAR -> g.peakSU
                        else -> g.peakHU
                    }
                    val peakV = when (fieldDisplay) {
                        MaaFieldDisplay.E_DB, MaaFieldDisplay.E_LINEAR -> g.peakEV
                        MaaFieldDisplay.S_DB, MaaFieldDisplay.S_LINEAR -> g.peakSV
                        else -> g.peakHV
                    }
                    Text(
                        "${g.plane} • ${g.size}×${g.size} • peak $peakText • u=${"%.3f".format(peakU)} m, v=${"%.3f".format(peakV)} m",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

    }
}


@Composable
private fun MaaPatternEngineeringInfo(model: MaaModel, preview: MaaPatternPreview, planeLabel: String) {
    val pts = preview.points
    if (pts.isEmpty()) return
    val maxPoint = pts.maxByOrNull { it.db } ?: return
    fun db(v: Double?) = v?.let { "%.1f dB".format(it) } ?: "—"
    fun deg(v: Double) = "%.1f°".format((v % 360.0 + 360.0) % 360.0)

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            val peakText = preview.absolutePeakDbi?.let { "%.1f dBi".format(it) } ?: db(maxPoint.db)
            Text("$planeLabel • max $peakText @ ${deg(maxPoint.angleDeg)}", style = MaterialTheme.typography.bodyMedium)
            Text(
                "HPBW ${preview.hpbwDeg?.let { "%.1f°".format(it) } ?: "—"} • F/B ${db(preview.frontBackDb)} • sidelobe ${db(preview.maxSideLobeDb)}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun MaaInfoCard(
    fileName: String?,
    m: MaaModel,
    sourceFrequencyMHz: Double = m.frequencyMHz,
    corpusProfile: MaaCorpusProfile? = null
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(m.title, style = MaterialTheme.typography.titleMedium)
            fileName?.takeIf { it.isNotBlank() }?.let { maaFileName ->
                Text("MAA: $maaFileName", style = MaterialTheme.typography.bodySmall)
            }
            Text("${m.antennaKind} • ${"%.3f".format(m.frequencyMHz)} MHz")
            val sourceCount = m.sources.size.coerceAtLeast(if (m.sourceWireIndex != null) 1 else 0)
            Text("Wires ${m.wires.size} • Sources $sourceCount • ${"%.3f".format(m.spanX)} × ${"%.3f".format(m.spanY)} × ${"%.3f".format(m.spanZ)} m", style = MaterialTheme.typography.bodySmall)
            val exactGeometry = MaaGeometryPolicyIndexV2.match(m)
            val aiGeometry = MaaGeometryForestV2.predict(m)
            (exactGeometry?.takeIf { it.exactGeometry }?.let { it.profile to it.confidencePercent }
                ?: aiGeometry?.let { it.profile to it.confidencePercent })?.let { (profile, confidence) ->
                Text("Geometry AI 2435 • $profile $confidence%", style = MaterialTheme.typography.bodySmall)
            }
            if (abs(m.frequencyMHz - sourceFrequencyMHz) > 1e-9) {
                Text("Original MAA frequency: ${"%.3f".format(sourceFrequencyMHz)} MHz", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun MaaGeometryCanvas(
    model: MaaModel,
    mode: MaaViewMode,
    onIsoViewChanged: (yawDeg: Float, pitchDeg: Float) -> Unit = { _, _ -> }
) {
    var yaw by remember(model) { mutableFloatStateOf(-28f) }
    var pitch by remember(model) { mutableFloatStateOf(22f) }
    var zoom by remember(model) { mutableFloatStateOf(1f) }
    var panX by remember(model) { mutableFloatStateOf(0f) }
    var panY by remember(model) { mutableFloatStateOf(0f) }
    var orbitInertiaJob by remember(model) { mutableStateOf<Job?>(null) }
    val orbitScope = rememberCoroutineScope()

    val normal = MaterialTheme.colorScheme.primary
    val source = MaterialTheme.colorScheme.error
    val load = Color(0xFFFFB74D)
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.23f)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(330.dp)
            .pointerInput(model, mode) {
                // 1.19.158 Orbit Touch Controller.
                // One finger = direct orbit (yaw/pitch) in ISO view.
                // Two fingers = pinch zoom + centroid pan.
                // Releasing a one-finger drag starts a short damped inertia motion.
                // Pointer-count changes are ignored for one frame, so adding/removing
                // a second finger never produces a camera jump.
                awaitPointerEventScope {
                    var previousPointerCount = 0
                    var lastSingleDelta = Offset.Zero
                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.filter { it.pressed }
                        val pointerCount = pressed.size

                        if (pointerCount > 0) {
                            orbitInertiaJob?.cancel()
                            orbitInertiaJob = null
                        }

                        if (pointerCount == previousPointerCount && pointerCount > 0) {
                            if (pointerCount == 1) {
                                val ch = pressed[0]
                                val d = ch.position - ch.previousPosition
                                if (mode == MaaViewMode.ISO) {
                                    yaw += d.x * 0.34f
                                    pitch = (pitch - d.y * 0.30f).coerceIn(-85f, 85f)
                                    onIsoViewChanged(yaw, pitch)
                                    lastSingleDelta = d
                                } else {
                                    // Fixed SIDE/FRONT views remain fixed; one-finger drag pans.
                                    panX += d.x
                                    panY += d.y
                                    lastSingleDelta = Offset.Zero
                                }
                            } else {
                                val a = pressed[0]
                                val b = pressed[1]
                                val prevAx = a.previousPosition.x
                                val prevAy = a.previousPosition.y
                                val prevBx = b.previousPosition.x
                                val prevBy = b.previousPosition.y
                                val curAx = a.position.x
                                val curAy = a.position.y
                                val curBx = b.position.x
                                val curBy = b.position.y

                                val prevDx = prevBx - prevAx
                                val prevDy = prevBy - prevAy
                                val curDx = curBx - curAx
                                val curDy = curBy - curAy
                                val prevDist = sqrt(prevDx * prevDx + prevDy * prevDy)
                                val curDist = sqrt(curDx * curDx + curDy * curDy)
                                if (prevDist > 2f && curDist > 2f) {
                                    zoom = (zoom * (curDist / prevDist)).coerceIn(0.35f, 7.0f)
                                }

                                val prevCx = (prevAx + prevBx) * 0.5f
                                val prevCy = (prevAy + prevBy) * 0.5f
                                val curCx = (curAx + curBx) * 0.5f
                                val curCy = (curAy + curBy) * 0.5f
                                panX += curCx - prevCx
                                panY += curCy - prevCy
                                lastSingleDelta = Offset.Zero
                            }
                        } else if (pointerCount == 0 && previousPointerCount == 1 && mode == MaaViewMode.ISO) {
                            val initial = lastSingleDelta
                            val speed = sqrt(initial.x * initial.x + initial.y * initial.y)
                            if (speed > 1.2f) {
                                orbitInertiaJob = orbitScope.launch {
                                    var vx = initial.x * 0.34f
                                    var vy = -initial.y * 0.30f
                                    repeat(36) {
                                        if (sqrt(vx * vx + vy * vy) < 0.08f) return@launch
                                        yaw += vx
                                        pitch = (pitch + vy).coerceIn(-85f, 85f)
                                        onIsoViewChanged(yaw, pitch)
                                        vx *= 0.87f
                                        vy *= 0.87f
                                        delay(16L)
                                    }
                                }
                            }
                            lastSingleDelta = Offset.Zero
                        }

                        previousPointerCount = pointerCount
                        event.changes.forEach { if (it.pressed) it.consume() }
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        // engineering-paper grid
        val step = min(w, h) / 10f
        var x = 0f
        while (x <= w) { drawLine(grid, Offset(x, 0f), Offset(x, h), 1f); x += step }
        var y = 0f
        while (y <= h) { drawLine(grid, Offset(0f, y), Offset(w, y), 1f); y += step }

        val corners = listOf(
            doubleArrayOf(model.minX, model.minY, model.minZ), doubleArrayOf(model.minX, model.minY, model.maxZ),
            doubleArrayOf(model.minX, model.maxY, model.minZ), doubleArrayOf(model.minX, model.maxY, model.maxZ),
            doubleArrayOf(model.maxX, model.minY, model.minZ), doubleArrayOf(model.maxX, model.minY, model.maxZ),
            doubleArrayOf(model.maxX, model.maxY, model.minZ), doubleArrayOf(model.maxX, model.maxY, model.maxZ)
        )
        val center = doubleArrayOf((model.minX+model.maxX)/2, (model.minY+model.maxY)/2, (model.minZ+model.maxZ)/2)
        val yawNow = when (mode) { MaaViewMode.ISO -> yaw.toDouble(); MaaViewMode.SIDE -> 0.0; MaaViewMode.FRONT -> -90.0 }
        val pitchNow = when (mode) { MaaViewMode.ISO -> pitch.toDouble(); MaaViewMode.SIDE -> 0.0; MaaViewMode.FRONT -> 0.0 }
        val rawCorners = corners.map { project3d(it[0], it[1], it[2], center, yawNow, pitchNow) }
        val minPx = rawCorners.minOf { it.first }; val maxPx = rawCorners.maxOf { it.first }
        val minPy = rawCorners.minOf { it.second }; val maxPy = rawCorners.maxOf { it.second }
        val spanX = (maxPx-minPx).coerceAtLeast(1e-6); val spanY = (maxPy-minPy).coerceAtLeast(1e-6)
        val sc = 0.82 * min(w.toDouble()/spanX, h.toDouble()/spanY) * zoom
        val cx = w/2f + panX; val cy = h/2f + panY
        fun p(xx: Double, yy: Double, zz: Double): Offset {
            val q = project3d(xx, yy, zz, center, yawNow, pitchNow)
            return Offset((cx + q.first*sc).toFloat(), (cy - q.second*sc).toFloat())
        }

        // Axes use the same colors as the 3D radiation-pattern renderer so both views are
        // visually comparable: X = red, Y = green, Z = blue.
        val axisLen = max(model.boomLengthM, model.transverseSizeM).coerceAtLeast(0.05) * 0.18
        val o = p(center[0], center[1], center[2])
        drawLine(Color(0xFFFF5353), o, p(center[0]+axisLen, center[1], center[2]), 2.6f)
        drawLine(Color(0xFF63E572), o, p(center[0], center[1]+axisLen, center[2]), 2.6f)
        drawLine(Color(0xFF6695FF), o, p(center[0], center[1], center[2]+axisLen), 2.6f)

        val activeSources = if (model.sources.isNotEmpty()) {
            model.sources
        } else {
            model.sourceWireIndex?.let { listOf(MaaSource(it, 'C')) } ?: emptyList()
        }
        val sourceWireIndices = activeSources.map { it.wireIndex }.toSet()
        val activeLoads = model.loads
        val loadWireIndices = activeLoads.map { it.wireIndex }.toSet()

        model.wires.forEachIndexed { idx, wire ->
            val a = p(wire.x1, wire.y1, wire.z1)
            val b = p(wire.x2, wire.y2, wire.z2)
            val isSourceWire = idx in sourceWireIndices
            val isLoadWire = idx in loadWireIndices
            val wireColor = when {
                isSourceWire -> source
                isLoadWire -> load
                else -> normal
            }
            val wireWidth = if (isSourceWire || isLoadWire) 4.8f else 3.2f
            drawLine(wireColor, a, b, wireWidth)
        }

        // Draw EVERY MMANA excitation source, not only the legacy first source.
        // B/C/E are rendered at the physical beginning/centre/end of the original wire.
        // Numbered rings make multiple feeds on one antenna or on stacked/crossed antennas
        // unambiguous in the 3D model viewer.
        activeSources.forEachIndexed { sourceIndex, src ->
            val wire = model.wires.getOrNull(src.wireIndex) ?: return@forEachIndexed
            val t = when (src.position.uppercaseChar()) {
                'B' -> 0.0
                'E' -> 1.0
                else -> 0.5
            }
            val sx = wire.x1 + (wire.x2 - wire.x1) * t
            val sy = wire.y1 + (wire.y2 - wire.y1) * t
            val sz = wire.z1 + (wire.z2 - wire.z1) * t
            val q = p(sx, sy, sz)

            drawCircle(Color.White, radius = 10f, center = q)
            drawCircle(source, radius = 8f, center = q)
            drawCircle(Color.White, radius = 3.2f, center = q)
            drawLine(source, Offset(q.x - 13f, q.y), Offset(q.x + 13f, q.y), 2.2f)
            drawLine(source, Offset(q.x, q.y - 13f), Offset(q.x, q.y + 13f), 2.2f)

            val paint = Paint().apply {
                isAntiAlias = true
                color = source.toArgb()
                textSize = 28f
                isFakeBoldText = true
            }
            val sourceRef = Regex("(?i)w\\s*(\\d+)\\s*([bce])").find(src.raw)?.let { m ->
                "W${m.groupValues[1]}${m.groupValues[2].uppercase()}"
            } ?: "W${src.wireIndex + 1}${src.position.uppercaseChar()}"
            drawContext.canvas.nativeCanvas.drawText(
                "S${sourceIndex + 1}  $sourceRef",
                q.x + 12f,
                q.y - 10f,
                paint
            )
        }

        // Draw EVERY MMANA lumped load as a separate 3D marker.  Loads remain distinct from
        // sources even when both are placed on the same physical pulse.  This is especially
        // important for multi-element Yagi matching networks and loaded elements.
        activeLoads.forEachIndexed { loadIndex, ld ->
            val wire = model.wires.getOrNull(ld.wireIndex) ?: return@forEachIndexed
            val t = when (ld.position.uppercaseChar()) {
                'B' -> 0.0
                'E' -> 1.0
                else -> 0.5
            }
            val lx = wire.x1 + (wire.x2 - wire.x1) * t
            val ly = wire.y1 + (wire.y2 - wire.y1) * t
            val lz = wire.z1 + (wire.z2 - wire.z1) * t
            val q = p(lx, ly, lz)

            drawCircle(Color.White, radius = 10f, center = q)
            drawCircle(load, radius = 8f, center = q)
            drawRect(load, topLeft = Offset(q.x - 5.5f, q.y - 5.5f), size = Size(11f, 11f))
            drawLine(load, Offset(q.x - 13f, q.y - 13f), Offset(q.x + 13f, q.y + 13f), 2.2f)
            drawLine(load, Offset(q.x - 13f, q.y + 13f), Offset(q.x + 13f, q.y - 13f), 2.2f)

            val paint = Paint().apply {
                isAntiAlias = true
                color = load.toArgb()
                textSize = 27f
                isFakeBoldText = true
            }
            val kindLabel = when (ld.kind) {
                0 -> "LC"
                1 -> "R+jX"
                2 -> "S"
                else -> "LOAD"
            }
            val loadRef = Regex("(?i)w\\s*(\\d+)\\s*([bce])").find(ld.raw)?.let { m ->
                "W${m.groupValues[1]}${m.groupValues[2].uppercase()}"
            } ?: "W${ld.wireIndex + 1}${ld.position.uppercaseChar()}"
            drawContext.canvas.nativeCanvas.drawText(
                "L${loadIndex + 1}  $loadRef  $kindLabel",
                q.x + 12f,
                q.y + 25f,
                paint
            )
        }
    }
}

private fun project3d(x: Double, y: Double, z: Double, c: DoubleArray, yawDeg: Double, pitchDeg: Double): Pair<Double, Double> {
    val xx = x - c[0]; val yy = y - c[1]; val zz = z - c[2]
    val ya = Math.toRadians(yawDeg); val pa = Math.toRadians(pitchDeg)
    val x1 = xx * cos(ya) - yy * sin(ya)
    val y1 = xx * sin(ya) + yy * cos(ya)
    val z1 = zz
    val sx = x1
    val sy = z1 * cos(pa) - y1 * sin(pa)
    return sx to sy
}

@Composable
private fun MaaPolarPattern(preview: MaaPatternPreview) {
    val curve = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val textish = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    val marker = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(320.dp)) {
        val c = Offset(size.width/2f, size.height/2f)
        val rMax = min(size.width, size.height)*0.43f
        listOf(0f, -10f, -20f, -30f, -40f).forEach { db ->
            val r = rMax * ((db + 40f) / 40f)
            drawCircle(grid, r, c, style = Stroke(1f))
        }
        for (a in 0 until 360 step 30) {
            val t = Math.toRadians(a.toDouble())
            drawLine(grid, c, Offset(c.x + rMax*cos(t).toFloat(), c.y - rMax*sin(t).toFloat()), 1f)
        }
        // 1.19.165: draw the reference radius toward the ACTUAL computed peak.
        // With ground-backed patterns the maximum elevation is generally above the horizon,
        // so a hard-coded 0° horizontal radius was misleading even though the red peak marker
        // itself was already correct.
        preview.points.maxByOrNull { it.db }?.let { peak ->
            val peakT = Math.toRadians(peak.angleDeg)
            drawLine(
                textish,
                c,
                Offset(
                    c.x + rMax * cos(peakT).toFloat(),
                    c.y - rMax * sin(peakT).toFloat()
                ),
                2f
            )
        }
        // 1.19.165: keep the radiation contour OPEN. Ground-backed patterns contain only
        // the physical upper hemisphere; closing the stroke joined the two horizon endpoints
        // with a straight purple chord and made the calculated lobe look tied to the ground.
        val strokePath = Path()
        val fillPath = Path().apply { moveTo(c.x, c.y) }
        preview.points.forEachIndexed { idx, pp ->
            val db = pp.db.coerceIn(-40.0, 0.0)
            val rr = rMax * ((db + 40.0) / 40.0).toFloat()
            val t = Math.toRadians(pp.angleDeg)
            val p = Offset(c.x + rr*cos(t).toFloat(), c.y - rr*sin(t).toFloat())
            if (idx == 0) strokePath.moveTo(p.x, p.y) else strokePath.lineTo(p.x, p.y)
            fillPath.lineTo(p.x, p.y)
        }
        fillPath.lineTo(c.x, c.y)
        fillPath.close()
        drawPath(fillPath, curve.copy(alpha = 0.16f))
        drawPath(strokePath, curve, style = Stroke(3f))
        // Mark the actual computed peak. Older builds always put this marker at 0 deg,
        // which visually suggested that the maximum was on the horizon even when it was not.
        preview.points.maxByOrNull { it.db }?.let { peak ->
            val peakDb = peak.db.coerceIn(-40.0, 0.0)
            val peakR = rMax * ((peakDb + 40.0) / 40.0).toFloat()
            val peakT = Math.toRadians(peak.angleDeg)
            val peakP = Offset(c.x + peakR*cos(peakT).toFloat(), c.y - peakR*sin(peakT).toFloat())
            drawCircle(marker, 5f, peakP)
        }
    }
}

@Composable
private fun MaaRectPattern(preview: MaaPatternPreview) {
    val curve = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val marker = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(280.dp)) {
        val left=42f; val right=12f; val top=12f; val bottom=28f
        val pw=size.width-left-right; val ph=size.height-top-bottom
        for (i in 0..6) {
            val x=left+pw*i/6f
            drawLine(grid, Offset(x,top), Offset(x,top+ph),1f)
        }
        for (i in 0..4) {
            val y=top+ph*i/4f
            drawLine(grid, Offset(left,y), Offset(left+pw,y),1f)
        }
        fun pt(a:Double, db:Double):Offset {
            val x=left+((a+180.0)/360.0*pw).toFloat()
            val y=top+((-db.coerceIn(-40.0,0.0))/40.0*ph).toFloat()
            return Offset(x,y)
        }
        val path=Path()
        preview.points.forEachIndexed { i,p -> val q=pt(p.angleDeg,p.db); if(i==0)path.moveTo(q.x,q.y) else path.lineTo(q.x,q.y) }
        drawPath(path,curve,style=Stroke(3f))
        val x0 = pt(0.0, 0.0).x
        drawLine(marker.copy(alpha=.7f), Offset(x0, top), Offset(x0, top + ph), 2f)
    }
}


private fun decodeMaaText(bytes: ByteArray): String {
    // Modern files may be UTF-8; classic MMANA-GAL Russian files are commonly Windows-1251.
    return try {
        val decoder = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        decoder.decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: Exception) {
        String(bytes, Charset.forName("windows-1251"))
    }
}

@Composable
private fun NearFieldHeatMap(
    model: MaaModel,
    grid: NearFieldEngine.Grid,
    display: MaaFieldDisplay,
    detail: MaaFieldDetail,
    dbRange: Double,
    phaseDeg: Float? = null,
    vectorMode: Boolean = false,
    cleanWireArtifacts: Boolean = false
) {
    val surface = MaterialTheme.colorScheme.surface
    val textColor = MaterialTheme.colorScheme.onSurface
    val mu0 = 4.0e-7 * PI
    var probeX by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeY by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeGX by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }
    var probeGY by remember(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) { mutableFloatStateOf(Float.NaN) }

    fun displayValueAt(idx: Int): Double = when (display) {
        MaaFieldDisplay.H_DB -> grid.hDb(idx, -dbRange)
        MaaFieldDisplay.E_DB -> grid.eDb(idx, -dbRange)
        MaaFieldDisplay.S_DB -> grid.sDb(idx, -dbRange)
        MaaFieldDisplay.H_LINEAR -> grid.hAmpPerM[idx]
        MaaFieldDisplay.E_LINEAR -> grid.eVoltPerM[idx]
        MaaFieldDisplay.B_MICROTESLA -> grid.hAmpPerM[idx] * mu0 * 1e6
        MaaFieldDisplay.S_LINEAR -> grid.powerDensityWPerM2[idx]
        MaaFieldDisplay.Z_EH -> grid.localWaveImpedanceOhm[idx]
    }

    fun normalizedFromValue(value: Double): Float = when (display) {
        MaaFieldDisplay.H_DB, MaaFieldDisplay.E_DB, MaaFieldDisplay.S_DB ->
            ((value + dbRange) / dbRange).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.H_LINEAR -> (value / grid.peakHAmpPerM.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.E_LINEAR -> (value / grid.peakEVoltPerM.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.B_MICROTESLA -> (value / grid.peakBMicroTesla.coerceAtLeast(1e-30)).coerceIn(0.0, 1.0).toFloat()
        MaaFieldDisplay.S_LINEAR -> {
            val ref = grid.peakPowerDensityWPerM2.coerceAtLeast(1e-30) * if (phaseDeg != null) 2.0 else 1.0
            (value / ref).coerceIn(0.0, 1.0).toFloat()
        }
        MaaFieldDisplay.Z_EH -> {
            val z = value.coerceIn(1.0, 10000.0)
            val logRatio = kotlin.math.ln(z / 376.730313668) / kotlin.math.ln(10.0)
            ((logRatio + 2.0) / 4.0).coerceIn(0.0, 1.0).toFloat()
        }
    }

    fun colorArgbFor(norm: Float): Int {
        val safe = if (norm.isFinite()) norm.coerceIn(0f, 1f) else 0f
        val index = (safe * (nearFieldPaletteArgb.size - 1)).toInt().coerceIn(0, nearFieldPaletteArgb.lastIndex)
        return nearFieldPaletteArgb[index]
    }

    fun bilinearArray(values: DoubleArray, gx: Double, gy: Double): Double {
        val n = grid.size
        val x = gx.coerceIn(0.0, (n - 1).toDouble())
        val y = gy.coerceIn(0.0, (n - 1).toDouble())
        val x0 = kotlin.math.floor(x).toInt().coerceIn(0, n - 1)
        val y0 = kotlin.math.floor(y).toInt().coerceIn(0, n - 1)
        val x1 = (x0 + 1).coerceAtMost(n - 1)
        val y1 = (y0 + 1).coerceAtMost(n - 1)
        val tx = x - x0
        val ty = y - y0
        val v00 = values[y0 * n + x0]
        val v10 = values[y0 * n + x1]
        val v01 = values[y1 * n + x0]
        val v11 = values[y1 * n + x1]
        return (1.0 - ty) * ((1.0 - tx) * v00 + tx * v10) + ty * ((1.0 - tx) * v01 + tx * v11)
    }

    fun bilinearStaticValue(gx: Double, gy: Double): Double {
        val n = grid.size
        val x = gx.coerceIn(0.0, (n - 1).toDouble())
        val y = gy.coerceIn(0.0, (n - 1).toDouble())
        val x0 = kotlin.math.floor(x).toInt().coerceIn(0, n - 1)
        val y0 = kotlin.math.floor(y).toInt().coerceIn(0, n - 1)
        val x1 = (x0 + 1).coerceAtMost(n - 1)
        val y1 = (y0 + 1).coerceAtMost(n - 1)
        val tx = x - x0
        val ty = y - y0
        fun v(r: Int, c: Int) = displayValueAt(r * n + c)
        val v00 = v(y0, x0)
        val v10 = v(y0, x1)
        val v01 = v(y1, x0)
        val v11 = v(y1, x1)
        return (1.0 - ty) * ((1.0 - tx) * v00 + tx * v10) + ty * ((1.0 - tx) * v01 + tx * v11)
    }

    val phaseRad = phaseDeg?.toDouble()?.times(PI / 180.0)
    val phaseCos = phaseRad?.let { cos(it) } ?: 1.0
    val phaseSin = phaseRad?.let { sin(it) } ?: 0.0
    fun instant(re: Double, im: Double) = re * phaseCos - im * phaseSin
    fun ampDb(value: Double, peak: Double): Double =
        (20.0 * log10((value / peak.coerceAtLeast(1e-30)).coerceAtLeast(1e-12))).coerceAtLeast(-dbRange)
    fun powerDb(value: Double, peak: Double): Double =
        (10.0 * log10((value / peak.coerceAtLeast(1e-30)).coerceAtLeast(1e-12))).coerceAtLeast(-dbRange)

    fun phaseValue(gx: Double, gy: Double): Double {
        fun instComponent(reValues: DoubleArray, imValues: DoubleArray): Double =
            instant(bilinearArray(reValues, gx, gy), bilinearArray(imValues, gx, gy))

        return when (display) {
            MaaFieldDisplay.H_DB,
            MaaFieldDisplay.H_LINEAR,
            MaaFieldDisplay.B_MICROTESLA -> {
                val hx = instComponent(grid.hxRe, grid.hxIm)
                val hy = instComponent(grid.hyRe, grid.hyIm)
                val hz = instComponent(grid.hzRe, grid.hzIm)
                val h = sqrt(hx*hx + hy*hy + hz*hz)
                when (display) {
                    MaaFieldDisplay.H_DB -> ampDb(h, grid.peakHAmpPerM)
                    MaaFieldDisplay.B_MICROTESLA -> h * mu0 * 1e6
                    else -> h
                }
            }
            MaaFieldDisplay.E_DB,
            MaaFieldDisplay.E_LINEAR -> {
                val ex = instComponent(grid.exRe, grid.exIm)
                val ey = instComponent(grid.eyRe, grid.eyIm)
                val ez = instComponent(grid.ezRe, grid.ezIm)
                val e = sqrt(ex*ex + ey*ey + ez*ez)
                if (display == MaaFieldDisplay.E_DB) ampDb(e, grid.peakEVoltPerM) else e
            }
            MaaFieldDisplay.S_DB,
            MaaFieldDisplay.S_LINEAR,
            MaaFieldDisplay.Z_EH -> {
                val hx = instComponent(grid.hxRe, grid.hxIm)
                val hy = instComponent(grid.hyRe, grid.hyIm)
                val hz = instComponent(grid.hzRe, grid.hzIm)
                val ex = instComponent(grid.exRe, grid.exIm)
                val ey = instComponent(grid.eyRe, grid.eyIm)
                val ez = instComponent(grid.ezRe, grid.ezIm)
                val h = sqrt(hx*hx + hy*hy + hz*hz)
                val e = sqrt(ex*ex + ey*ey + ez*ez)
                if (display == MaaFieldDisplay.Z_EH) {
                    if (h > 1e-18) (e / h).coerceIn(0.0, 1.0e9) else 1.0e9
                } else {
                    // Instantaneous Poynting-vector magnitude |E(t) x H(t)|.
                    val sx = ey * hz - ez * hy
                    val sy = ez * hx - ex * hz
                    val sz = ex * hy - ey * hx
                    val s = sqrt(sx*sx + sy*sy + sz*sz)
                    if (display == MaaFieldDisplay.S_DB) {
                        powerDb(s, 2.0 * grid.peakPowerDensityWPerM2)
                    } else s
                }
            }
        }
    }

    // In E-vector mode the colour map deliberately stays on the phasor envelope.
    // Only the arrows rotate. This avoids the misleading "four moving lobes" effect of |E(t)|
    // and makes polarization visible as an actual vector trajectory.
    fun valueForPixel(gx: Double, gy: Double): Double =
        if (vectorMode || phaseDeg == null) bilinearStaticValue(gx, gy) else phaseValue(gx, gy)

    fun projectedEPhasor(gx: Double, gy: Double): DoubleArray {
        fun c(re: DoubleArray, im: DoubleArray): Pair<Double, Double> =
            Pair(bilinearArray(re, gx, gy), bilinearArray(im, gx, gy))
        val ex = c(grid.exRe, grid.exIm)
        val ey = c(grid.eyRe, grid.eyIm)
        val ez = c(grid.ezRe, grid.ezIm)
        return when (grid.plane) {
            NearFieldEngine.Plane.XY -> doubleArrayOf(ex.first, ex.second, ey.first, ey.second)
            NearFieldEngine.Plane.XZ -> doubleArrayOf(ex.first, ex.second, ez.first, ez.second)
            NearFieldEngine.Plane.YZ -> doubleArrayOf(ey.first, ey.second, ez.first, ez.second)
        }
    }

    // Display-only cleanup for the near-singular values sampled directly on a thin wire.
    // It never changes the NEC solution or the stored E/H phasors.  Only heat-map pixels
    // within a narrow tube around a wire are replaced by the average of two samples just
    // outside the tube, perpendicular to that wire.  RAW data, probe values and vectors
    // remain untouched.
    val cleanWireSegments = remember(model, grid) {
        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        val sliceCellM = 2.0 * grid.halfSpanM / (grid.size - 1).coerceAtLeast(1).toDouble()
        model.wires.mapNotNull { w ->
            val clipped = NearFieldSliceGeometry.clipWireToSlice(
                wire = w,
                plane = grid.plane,
                fixedCoordinateM = grid.fixedCoordinateM,
                zShiftM = zShift,
                sliceCellM = sliceCellM
            ) ?: return@mapNotNull null
            fun toGrid(x: Double, y: Double, z: Double): Pair<Double, Double> {
                val u: Double
                val v: Double
                when (grid.plane) {
                    NearFieldEngine.Plane.XY -> { u = x - grid.centerX; v = -(y - grid.centerY) }
                    NearFieldEngine.Plane.XZ -> { u = x - grid.centerX; v = -(z - grid.centerZ) }
                    NearFieldEngine.Plane.YZ -> { u = y - grid.centerY; v = -(z - grid.centerZ) }
                }
                val gx = (u + grid.halfSpanM) / (2.0 * grid.halfSpanM) * (grid.size - 1).toDouble()
                val gy = (v + grid.halfSpanM) / (2.0 * grid.halfSpanM) * (grid.size - 1).toDouble()
                return Pair(gx, gy)
            }
            val a = toGrid(clipped.x1, clipped.y1, clipped.z1)
            val b = toGrid(clipped.x2, clipped.y2, clipped.z2)
            doubleArrayOf(a.first, a.second, b.first, b.second)
        }
    }

    fun cleanedDisplayValue(gx: Double, gy: Double): Double {
        val raw = valueForPixel(gx, gy)
        if (!cleanWireArtifacts || cleanWireSegments.isEmpty()) return raw

        val maskRadiusCells = 1.55
        val sampleOffsetCells = 2.65
        var bestDist2 = Double.POSITIVE_INFINITY
        var bestX1 = 0.0
        var bestY1 = 0.0
        var bestX2 = 0.0
        var bestY2 = 0.0
        for (seg in cleanWireSegments) {
            val x1 = seg[0]; val y1 = seg[1]; val x2 = seg[2]; val y2 = seg[3]
            val dx = x2 - x1; val dy = y2 - y1
            val len2 = dx*dx + dy*dy
            val t = if (len2 > 1e-12) (((gx - x1)*dx + (gy - y1)*dy) / len2).coerceIn(0.0, 1.0) else 0.0
            val qx = x1 + t*dx; val qy = y1 + t*dy
            val ddx = gx - qx; val ddy = gy - qy
            val d2 = ddx*ddx + ddy*ddy
            if (d2 < bestDist2) {
                bestDist2 = d2
                bestX1 = x1; bestY1 = y1; bestX2 = x2; bestY2 = y2
            }
        }
        if (bestDist2 > maskRadiusCells * maskRadiusCells) return raw

        val dx = bestX2 - bestX1
        val dy = bestY2 - bestY1
        val len = sqrt(dx*dx + dy*dy)
        var nx = if (len > 1e-9) -dy / len else 1.0
        var ny = if (len > 1e-9) dx / len else 0.0
        if (!nx.isFinite() || !ny.isFinite()) { nx = 1.0; ny = 0.0 }

        val a = valueForPixel(gx + nx * sampleOffsetCells, gy + ny * sampleOffsetCells)
        val b = valueForPixel(gx - nx * sampleOffsetCells, gy - ny * sampleOffsetCells)
        val replacement = when {
            a.isFinite() && b.isFinite() -> 0.5 * (a + b)
            a.isFinite() -> a
            b.isFinite() -> b
            else -> raw
        }
        // Suppression mode must never create a new hotter peak than the RAW map.
        return if (display == MaaFieldDisplay.Z_EH) replacement else min(raw, replacement)
    }

    val projectedEPeak = remember(grid) {
        var peak = 0.0
        for (i in 0 until grid.size * grid.size) {
            val ur: Double; val ui: Double; val vr: Double; val vi: Double
            when (grid.plane) {
                NearFieldEngine.Plane.XY -> { ur = grid.exRe[i]; ui = grid.exIm[i]; vr = grid.eyRe[i]; vi = grid.eyIm[i] }
                NearFieldEngine.Plane.XZ -> { ur = grid.exRe[i]; ui = grid.exIm[i]; vr = grid.ezRe[i]; vi = grid.ezIm[i] }
                NearFieldEngine.Plane.YZ -> { ur = grid.eyRe[i]; ui = grid.eyIm[i]; vr = grid.ezRe[i]; vi = grid.ezIm[i] }
            }
            val a = sqrt(ur*ur + ui*ui + vr*vr + vi*vi)
            if (a > peak) peak = a
        }
        peak.coerceAtLeast(1e-30)
    }

    // Build the heat map as one raster image instead of issuing tens of thousands of drawRect()
    // calls.  This allows a denser static image and lets the GPU do the final smooth scaling.
    val rasterPhaseDeg = if (vectorMode) null else phaseDeg
    val rasterN = nearFieldRasterSize(grid.size, detail, rasterPhaseDeg != null)
    val heatMapImage = remember(grid, display, detail, dbRange, rasterPhaseDeg, vectorMode, cleanWireArtifacts) {
        val pixels = IntArray(rasterN * rasterN)
        val denom = (rasterN - 1).coerceAtLeast(1).toDouble()
        for (row in 0 until rasterN) {
            val gy = row * (grid.size - 1).toDouble() / denom
            val base = row * rasterN
            for (col in 0 until rasterN) {
                val gx = col * (grid.size - 1).toDouble() / denom
                val norm = normalizedFromValue(cleanedDisplayValue(gx, gy))
                pixels[base + col] = colorArgbFor(norm)
            }
        }
        Bitmap.createBitmap(rasterN, rasterN, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, rasterN, 0, 0, rasterN, rasterN)
        }.asImageBitmap()
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(360.dp)
            .pointerInput(grid, display, detail, dbRange, vectorMode, cleanWireArtifacts) {
                detectTapGestures { off ->
                    probeX = off.x
                    probeY = off.y
                    probeGX = (off.x / size.width.coerceAtLeast(1).toFloat() * (grid.size - 1)).coerceIn(0f, (grid.size - 1).toFloat())
                    probeGY = (off.y / size.height.coerceAtLeast(1).toFloat() * (grid.size - 1)).coerceIn(0f, (grid.size - 1).toFloat())
                }
            }
    ) {
        drawRect(surface)
        val n = grid.size
        if (n < 2) return@Canvas

        // One GPU-filtered image replaces thousands of individual Canvas rectangles.
        // The source raster is already interpolated from the physical Near Field grid; high
        // filter quality removes residual block edges when fitting it to the phone screen.
        drawImage(
            image = heatMapImage,
            dstSize = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1)),
            filterQuality = FilterQuality.High
        )

        fun mapPoint(x: Double, y: Double, z: Double): Offset {
            val u: Double
            val v: Double
            when (grid.plane) {
                NearFieldEngine.Plane.XY -> { u = x - grid.centerX; v = -(y - grid.centerY) }
                NearFieldEngine.Plane.XZ -> { u = x - grid.centerX; v = -(z - grid.centerZ) }
                NearFieldEngine.Plane.YZ -> { u = y - grid.centerY; v = -(z - grid.centerZ) }
            }
            val px = ((u + grid.halfSpanM) / (2.0 * grid.halfSpanM) * size.width).toFloat()
            val py = ((v + grid.halfSpanM) / (2.0 * grid.halfSpanM) * size.height).toFloat()
            return Offset(px, py)
        }

        // light reference grid
        for (i in 0..4) {
            val x = size.width * i / 4f
            val y = size.height * i / 4f
            drawLine(textColor.copy(alpha = 0.12f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(textColor.copy(alpha = 0.12f), Offset(0f, y), Offset(size.width, y), 1f)
        }

        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        // Overlay only geometry that physically belongs to the selected slice. Older builds
        // projected every wire onto the heat map, which could make an offset/cross section look
        // as if the whole antenna were located in that plane.
        val sliceCellM = 2.0 * grid.halfSpanM / (grid.size - 1).coerceAtLeast(1).toDouble()
        model.wires.forEachIndexed { wi, w ->
            val clipped = NearFieldSliceGeometry.clipWireToSlice(
                wire = w,
                plane = grid.plane,
                fixedCoordinateM = grid.fixedCoordinateM,
                zShiftM = zShift,
                sliceCellM = sliceCellM
            ) ?: return@forEachIndexed
            val a = mapPoint(clipped.x1, clipped.y1, clipped.z1)
            val b = mapPoint(clipped.x2, clipped.y2, clipped.z2)
            val source = wi == model.sourceWireIndex
            val c = if (source) Color.Red else textColor
            if (sqrt(((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)).toDouble()) < 3.0) {
                drawCircle(c, radius = if (source) 3.6f else 2.3f, center = a)
            } else {
                drawLine(
                    color = c,
                    start = a,
                    end = b,
                    strokeWidth = if (source) 3.8f else 1.6f,
                    cap = StrokeCap.Round
                )
            }
        }

        if (vectorMode) {
            val phi = (phaseDeg ?: 0f).toDouble() * PI / 180.0
            val cPhi = cos(phi)
            val sPhi = sin(phi)
            val arrowCols = 11
            val arrowRows = 11
            val stepX = size.width / (arrowCols + 1).toFloat()
            val stepY = size.height / (arrowRows + 1).toFloat()
            val maxArrow = min(stepX, stepY) * 0.72f

            fun drawArrow(center: Offset, du: Double, dv: Double, alpha: Float) {
                val mag = sqrt(du*du + dv*dv)
                if (mag <= projectedEPeak * 0.008) return
                val rel = (mag / projectedEPeak).coerceIn(0.0, 1.0)
                val len = maxArrow * (0.22f + 0.78f * sqrt(rel).toFloat())
                val ux = (du / mag).toFloat()
                val uy = (dv / mag).toFloat()
                val end = Offset(center.x + ux * len, center.y + uy * len)
                val head = (len * 0.28f).coerceIn(4f, 10f)
                val px = -uy
                val py = ux
                val h1 = Offset(end.x - ux * head + px * head * 0.52f, end.y - uy * head + py * head * 0.52f)
                val h2 = Offset(end.x - ux * head - px * head * 0.52f, end.y - uy * head - py * head * 0.52f)
                val outline = Color.Black.copy(alpha = (alpha * 0.70f).coerceIn(0.25f, 0.80f))
                val arrow = Color.White.copy(alpha = alpha.coerceIn(0.45f, 1.0f))
                drawLine(outline, center, end, 4.0f, cap = StrokeCap.Round)
                drawLine(outline, end, h1, 4.0f, cap = StrokeCap.Round)
                drawLine(outline, end, h2, 4.0f, cap = StrokeCap.Round)
                drawLine(arrow, center, end, 2.0f, cap = StrokeCap.Round)
                drawLine(arrow, end, h1, 2.0f, cap = StrokeCap.Round)
                drawLine(arrow, end, h2, 2.0f, cap = StrokeCap.Round)
                drawCircle(outline, 2.4f, center)
                drawCircle(arrow, 1.2f, center)
            }

            for (r in 1..arrowRows) {
                for (c in 1..arrowCols) {
                    val px = stepX * c
                    val py = stepY * r
                    val gx = px / size.width.coerceAtLeast(1f) * (grid.size - 1).toFloat()
                    val gy = py / size.height.coerceAtLeast(1f) * (grid.size - 1).toFloat()
                    val e = projectedEPhasor(gx.toDouble(), gy.toDouble())
                    val du = e[0] * cPhi - e[1] * sPhi
                    val dv = -(e[2] * cPhi - e[3] * sPhi)
                    val staticAmp = sqrt(e[0]*e[0] + e[1]*e[1] + e[2]*e[2] + e[3]*e[3])
                    val alpha = (0.35 + 0.65 * sqrt((staticAmp / projectedEPeak).coerceIn(0.0, 1.0))).toFloat()
                    drawArrow(Offset(px, py), du, dv, alpha)
                }
            }

            // At the selected probe draw the full polarization trajectory (ellipse/line) and
            // the current instantaneous vector. This is a direct view of the phasor pair;
            // no extra solver or synthetic 90° phase shift is introduced.
            if (!probeX.isNaN() && !probeY.isNaN() && !probeGX.isNaN() && !probeGY.isNaN()) {
                val e = projectedEPhasor(probeGX.toDouble(), probeGY.toDouble())
                var trajPeak = 0.0
                for (q in 0..72) {
                    val a = q * 2.0 * PI / 72.0
                    val uu = e[0] * cos(a) - e[1] * sin(a)
                    val vv = -(e[2] * cos(a) - e[3] * sin(a))
                    trajPeak = max(trajPeak, sqrt(uu*uu + vv*vv))
                }
                if (trajPeak > projectedEPeak * 1e-6) {
                    val radius = min(size.width, size.height) * 0.10f
                    val scale = radius / trajPeak.toFloat()
                    val path = Path()
                    for (q in 0..72) {
                        val a = q * 2.0 * PI / 72.0
                        val uu = (e[0] * cos(a) - e[1] * sin(a)).toFloat() * scale
                        val vv = (-(e[2] * cos(a) - e[3] * sin(a))).toFloat() * scale
                        val pt = Offset(probeX + uu, probeY + vv)
                        if (q == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                    }
                    drawPath(path, Color.White.copy(alpha = 0.88f), style = Stroke(2.0f))
                    val cu = (e[0] * cPhi - e[1] * sPhi).toFloat() * scale
                    val cv = (-(e[2] * cPhi - e[3] * sPhi)).toFloat() * scale
                    drawLine(Color.Black.copy(alpha = 0.75f), Offset(probeX, probeY), Offset(probeX + cu, probeY + cv), 5f, cap = StrokeCap.Round)
                    drawLine(Color.White, Offset(probeX, probeY), Offset(probeX + cu, probeY + cv), 2.5f, cap = StrokeCap.Round)
                }
            }
        }

        drawLine(textColor.copy(alpha = 0.45f), Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), 1f)
        drawLine(textColor.copy(alpha = 0.45f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1f)
        drawRect(textColor.copy(alpha = 0.35f), style = Stroke(1.5f))

        if (!probeX.isNaN() && !probeY.isNaN()) {
            val px = probeX.coerceIn(0f, size.width)
            val py = probeY.coerceIn(0f, size.height)
            drawLine(Color.White.copy(alpha = 0.95f), Offset(px, 0f), Offset(px, size.height), 1.2f)
            drawLine(Color.White.copy(alpha = 0.95f), Offset(0f, py), Offset(size.width, py), 1.2f)
            drawCircle(Color.White, radius = 5f, center = Offset(px, py), style = Stroke(1.8f))
        }
    }

    if (!probeX.isNaN() && !probeY.isNaN()) {
        if (vectorMode && !probeGX.isNaN() && !probeGY.isNaN()) {
            val e = projectedEPhasor(probeGX.toDouble(), probeGY.toDouble())
            val pa = PolarizationMath.analyze(e[0], e[1], e[2], e[3])
            val kind = when (pa.kind) {
                PolarizationMath.Kind.TOO_SMALL -> "field too small to evaluate"
                PolarizationMath.Kind.NEAR_CIRCULAR -> "nearly circular projection"
                PolarizationMath.Kind.ELLIPTICAL -> "elliptical projection"
                PolarizationMath.Kind.ELONGATED -> "highly elongated elliptical projection"
                PolarizationMath.Kind.NEAR_LINEAR -> "nearly linear projection"
            }
            Text(
                "Polarization at marker (${grid.plane}): |Eu|=${"%.3g".format(pa.amplitudeU)} V/m, |Ev|=${"%.3g".format(pa.amplitudeV)} V/m, min/max=${"%.3f".format(pa.minMaxAmplitudeRatio)}, Δφ=${"%+.1f".format(pa.deltaPhaseDeg)}°, AR≈${if (pa.axialRatio < 999.0) "%.2f".format(pa.axialRatio) else "∞"}:1 → $kind.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    } else {
        Text(
            if (vectorMode) "Tap the map: the selected point will show the E polarization trajectory and Δφ/AR estimate."
            else "Tap the field map to enable the visual crosshair and inspect the local Near Field region more precisely.",
            style = MaterialTheme.typography.bodySmall
        )
    }

    Text(
        if (vectorMode) {
            "E-VECTOR: color = static |E|; arrows and polarization trajectory are built from complex E components without changing the MMANA/MININEC solution or adding an artificial phase shift."
        } else if (phaseDeg != null) {
            when (display) {
                MaaFieldDisplay.H_DB -> "Phase frame: |H(t)| from Re{H·eʲφ}, dB relative to the static phasor peak."
                MaaFieldDisplay.E_DB -> "Phase frame: |E(t)| from Re{E·eʲφ}, dB relative to the static phasor peak."
                MaaFieldDisplay.H_LINEAR -> "Phase frame: instantaneous |H(t)|, A/m."
                MaaFieldDisplay.E_LINEAR -> "Phase frame: instantaneous |E(t)|, V/m."
                MaaFieldDisplay.B_MICROTESLA -> "Phase frame: |B(t)|=µ₀|H(t)|, µT."
                MaaFieldDisplay.S_DB -> "Phase frame: instantaneous |E(t)×H(t)|, dB; this is not period-averaged S."
                MaaFieldDisplay.S_LINEAR -> "Phase frame: instantaneous |E(t)×H(t)|, W/m²."
                MaaFieldDisplay.Z_EH -> "Phase frame: instantaneous |E(t)|/|H(t)|, Ω; near nodes the ratio can change sharply."
            }
        } else when (display) {
            MaaFieldDisplay.H_DB -> "Color: |H|, 0…−${dbRange.toInt()} dB relative to maximum H."
            MaaFieldDisplay.E_DB -> "Color: |E|, 0…−${dbRange.toInt()} dB relative to maximum E."
            MaaFieldDisplay.H_LINEAR -> "Color: |H|, A/m; visual scale normalized to the map maximum."
            MaaFieldDisplay.E_LINEAR -> "Color: |E|, V/m; visual scale normalized to the map maximum."
            MaaFieldDisplay.B_MICROTESLA -> "Color: |B|=µ₀|H|, µT; visual scale normalized to the map maximum."
            MaaFieldDisplay.S_DB -> "Color: |S|=|½Re(E×H*)|, 0…−${dbRange.toInt()} dB relative to maximum power flux."
            MaaFieldDisplay.S_LINEAR -> "Color: power flux density |S|, W/m²; scale normalized to the map maximum."
            MaaFieldDisplay.Z_EH -> "Color: local |E|/|H| ratio, Ω. About 376.7 Ω corresponds locally to free-space wave mode."
        },
        style = MaterialTheme.typography.bodySmall
    )
}



@Composable
private fun ImpedanceSonogramCard(
    sweepPoints: List<AntennaSolveTypes.SweepPoint>,
    z0Ohm: Double,
    sweepPosition: Double?
) {
    if (sweepPoints.size < 2) return
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val best = sweepPoints.minByOrNull { it.primary.swr(z0) } ?: return
    val resonance = sweepPoints.minByOrNull { kotlin.math.abs(it.primary.xOhm) } ?: best
    val r50 = sweepPoints.minByOrNull { kotlin.math.abs(it.primary.rOhm - z0) } ?: best
    val rl10 = sweepPoints.filter { gammaMagFromZ(it.primary.rOhm, it.primary.xOhm, z0) <= 0.31622776601683794 }
    val bandText = if (rl10.isNotEmpty()) {
        "−10 dB RL band: ${maaFmt(rl10.first().frequencyMHz, 6)}…${maaFmt(rl10.last().frequencyMHz, 6)} MHz"
    } else "−10 dB RL band: none in this sweep"
    val current = sweepPosition?.let { raw ->
        val u = raw.coerceIn(0.0, 1.0)
        val xx = u * (sweepPoints.lastIndex).toDouble()
        val i0 = kotlin.math.floor(xx).toInt().coerceIn(0, sweepPoints.lastIndex)
        val i1 = (i0 + 1).coerceAtMost(sweepPoints.lastIndex)
        val t = xx - i0
        val a = sweepPoints[i0]
        val b = sweepPoints[i1]
        val f = a.frequencyMHz + (b.frequencyMHz - a.frequencyMHz) * t
        val r = a.primary.rOhm + (b.primary.rOhm - a.primary.rOhm) * t
        val x = a.primary.xOhm + (b.primary.xOhm - a.primary.xOhm) * t
        Triple(f, r, x)
    }
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val surfaceColor = MaterialTheme.colorScheme.surface
    val bgColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f)
    val bestColor = MaterialTheme.colorScheme.tertiary
    val labelArgb = axisColor.toArgb()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("IMPEDANCE SONOGRAM", style = MaterialTheme.typography.titleSmall)
            Text(
                "Five synchronized maps: R • X • VSWR • |Γ| • ∠Γ. Vertical cursor follows ANTENNA AUDIO.",
                style = MaterialTheme.typography.bodySmall
            )
            Canvas(Modifier.fillMaxWidth().height(230.dp)) {
                drawRoundRect(bgColor, Offset.Zero, size, androidx.compose.ui.geometry.CornerRadius(18f,18f))
                val left = 62f
                val right = 8f
                val top = 12f
                val rowGap = 6f
                val rows = 5
                val plotW = (size.width - left - right).coerceAtLeast(1f)
                val rowH = ((size.height - top * 2f - rowGap * (rows - 1)) / rows).coerceAtLeast(1f)
                val labels = listOf("R", "X", "VSWR", "|Γ|", "∠Γ")
                val paint = Paint().apply { color = labelArgb; textSize = 19f; isAntiAlias = true }

                fun xForIndex(i: Int): Float = left + plotW * i.toFloat() / sweepPoints.lastIndex.toFloat()
                for (row in 0 until rows) {
                    val y = top + row * (rowH + rowGap)
                    drawRoundRect(surfaceColor.copy(alpha=0.55f), Offset(left,y), Size(plotW,rowH), androidx.compose.ui.geometry.CornerRadius(8f,8f))
                    drawContext.canvas.nativeCanvas.drawText(labels[row], 8f, y + rowH*0.68f, paint)
                    for (i in 0 until sweepPoints.lastIndex) {
                        val a=sweepPoints[i]
                        val b=sweepPoints[i+1]
                        val r=0.5*(a.primary.rOhm+b.primary.rOhm)
                        val x=0.5*(a.primary.xOhm+b.primary.xOhm)
                        val gm=gammaMagFromZ(r,x,z0)
                        val swr=((1.0+gm)/(1.0-gm).coerceAtLeast(1e-6)).coerceAtMost(20.0)
                        val ph=TouchstoneMath.phaseDeg(impedanceToGamma(r,x,z0))
                        val c=when(row){
                            0 -> sonogramResistanceColor(r,z0)
                            1 -> impedanceSweepColor(r,x,z0)
                            2 -> sonogramScalarColor(((swr-1.0)/5.0).coerceIn(0.0,1.0))
                            3 -> sonogramScalarColor(gm)
                            else -> sonogramPhaseColor(ph)
                        }
                        val x0=xForIndex(i); val x1=xForIndex(i+1)
                        drawRect(c, Offset(x0,y), Size((x1-x0)+1f,rowH))
                    }
                    drawLine(gridColor,Offset(left,y+rowH),Offset(left+plotW,y+rowH),strokeWidth=1f)
                }

                // Diagnostic marker lines: resonance, best match and R~=R0.
                fun markerX(point: AntennaSolveTypes.SweepPoint): Float {
                    val idx=sweepPoints.indexOf(point).coerceAtLeast(0)
                    return xForIndex(idx)
                }
                drawLine(axisColor.copy(alpha=.70f),Offset(markerX(resonance),top),Offset(markerX(resonance),size.height-top),strokeWidth=1.4f)
                drawLine(bestColor,Offset(markerX(best),top),Offset(markerX(best),size.height-top),strokeWidth=2.6f)
                drawLine(axisColor.copy(alpha=.42f),Offset(markerX(r50),top),Offset(markerX(r50),size.height-top),strokeWidth=1.2f)

                sweepPosition?.let { raw ->
                    val u=raw.coerceIn(0.0,1.0).toFloat()
                    val xc=left+plotW*u
                    drawLine(surfaceColor,Offset(xc,top-3f),Offset(xc,size.height-top+3f),strokeWidth=5.0f)
                    drawLine(axisColor,Offset(xc,top-3f),Offset(xc,size.height-top+3f),strokeWidth=2.0f)
                }
            }
            Text(
                "MARKERS: BEST ${maaFmt(best.frequencyMHz,6)} MHz / SWR ${maaFmt(best.primary.swr(z0),3)}   •   RES X≈0 ${maaFmt(resonance.frequencyMHz,6)} MHz / X=${maaFmt(resonance.primary.xOhm,2)} Ω   •   R≈${maaFmt(z0,0)} Ω @ ${maaFmt(r50.frequencyMHz,6)} MHz",
                style = MaterialTheme.typography.bodySmall
            )
            Text(bandText, style = MaterialTheme.typography.bodySmall)
            current?.let { (f,r,x) ->
                val g=impedanceToGamma(r,x,z0)
                val gm=g.mag.coerceIn(0.0,0.999999)
                val swr=(1.0+gm)/(1.0-gm)
                Text(
                    "CURSOR ${maaFmt(f,6)} MHz   •   Z=${maaFmt(r,2)} ${if(x>=0) "+" else "−"} j${maaFmt(kotlin.math.abs(x),2)} Ω   •   VSWR=${maaFmt(swr,3)}   •   |Γ|=${maaFmt(gm,4)}   •   ∠Γ=${maaFmt(TouchstoneMath.phaseDeg(g),1)}°",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(
                "COLOR KEY: R low→blue / R0→green / high→red • X capacitive→blue, resonance→green, inductive→red • VSWR and |Γ| green→red • phase uses a cyclic hue scale.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}


@Composable
private fun AntennaSmithCard(
    primary: AntennaSolveTypes.InputImpedance,
    inputs: List<AntennaSolveTypes.InputImpedance>,
    z0Ohm: Double,
    sweepPoints: List<AntennaSolveTypes.SweepPoint>,
    sweepRunning: Boolean,
    sweepProgress: Int,
    sweepError: String?,
    onStartSweep: () -> Unit,
    onCancelSweep: () -> Unit
) {
    val gamma = impedanceToGamma(primary.rOhm, primary.xOhm, z0Ohm)
    val sweepGammas = sweepPoints.map { it to impedanceToGamma(it.primary.rOhm, it.primary.xOhm, z0Ohm) }
    var audioSweepPosition by remember(sweepPoints) { mutableStateOf<Double?>(null) }
    var audioMode by remember { mutableStateOf(AntennaAudioMode.COMPLEX_IFFT) }
    var audioVisualMode by remember { mutableStateOf(AntennaAudioMode.COMPLEX_IFFT) }
    val markerColor = MaterialTheme.colorScheme.secondary
    val extraMarkerColor = MaterialTheme.colorScheme.tertiary
    val thresholdColor = MaterialTheme.colorScheme.tertiary
    val sweepColor = MaterialTheme.colorScheme.primary
    val axisColor = MaterialTheme.colorScheme.onSurface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val chartBackground = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f)
    val surfaceColor = MaterialTheme.colorScheme.surface
    val labelArgb = axisColor.toArgb()

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Sonification of the antenna's own MMANA/MININEC impedance sweep.
        // Uses the already calculated Smith sweep only; no solver path is changed.
        AntennaSonificationCard(
            sweepPoints = sweepPoints,
            z0Ohm = z0Ohm,
            sweepRunning = sweepRunning,
            onSweepAudioPosition = { audioSweepPosition = it },
            onModeChanged = { audioVisualMode = it }
        )

        // 1.19.101: keep the Smith sweep controls directly above the Smith diagram.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = onStartSweep,
                modifier = Modifier.weight(1f),
                enabled = !sweepRunning
            ) { Text(if (sweepPoints.isEmpty()) "CALCULATE Z(f) ±5%" else "RECALCULATE Z(f)") }
            if (sweepRunning) {
                Button(onClick = onCancelSweep) { Text("STOP") }
            }
        }
        if (sweepRunning) {
            LinearProgressIndicator(
                progress = { (sweepProgress.coerceIn(0, 100) / 100f) },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Sweep MMANA/MININEC: $sweepProgress%", style = MaterialTheme.typography.bodySmall)
        }
        sweepError?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

        Text("Smith chart", style = MaterialTheme.typography.titleSmall)
        Text(
            "Z0 is a display/SWR reference only. MMANA/MININEC R+jX is never tuned or forced to Z0.",
            style = MaterialTheme.typography.bodySmall
        )
        Card(modifier = Modifier.fillMaxWidth()) {
            Canvas(modifier = Modifier.fillMaxWidth().height(560.dp).padding(2.dp)) {
                drawRoundRect(
                    chartBackground,
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f, 22f)
                )

                val cx = size.width / 2f
                val cy = size.height / 2f
                val r = min(size.width, size.height) * 0.475f
                val paint = Paint().apply {
                    color = labelArgb
                    textSize = 23f
                    isAntiAlias = true
                }

                drawCircle(surfaceColor.copy(alpha = 0.50f), r, Offset(cx, cy))
                drawCircle(axisColor, r, Offset(cx, cy), style = Stroke(width = 3.0f))
                val smithClip = Path().apply { addOval(Rect(cx - r, cy - r, cx + r, cy + r)) }
                fun pt(g: Cpx) = Offset(cx + (g.re * r).toFloat(), cy - (g.im * r).toFloat())

                clipPath(smithClip) {
                    drawLine(axisColor, Offset(cx - r, cy), Offset(cx + r, cy), strokeWidth = 1.25f)
                    listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { rv ->
                        val cr = r / (1.0 + rv).toFloat()
                        val ccx = cx + r * (rv / (1.0 + rv)).toFloat()
                        drawCircle(gridColor, cr, Offset(ccx, cy), style = Stroke(width = 1.35f))
                    }
                    listOf(0.2, 0.5, 1.0, 2.0, 5.0).forEach { xv ->
                        val rr = r / xv.toFloat()
                        val ccx = cx + r
                        drawCircle(gridColor, rr, Offset(ccx, cy - rr), style = Stroke(width = 1.20f))
                        drawCircle(gridColor, rr, Offset(ccx, cy + rr), style = Stroke(width = 1.20f))
                    }
                    drawCircle(
                        thresholdColor.copy(alpha = 0.75f),
                        r / 3f,
                        Offset(cx, cy),
                        style = Stroke(width = 2.1f)
                    )

                    if (sweepGammas.size >= 2) {
                        // 1.19.58: each impedance interval gets a physical color.
                        // Capacitive X<0 = blue/violet, resonance X~0 = green,
                        // inductive X>0 = yellow/red; better match is brighter.
                        for (i in 0 until sweepGammas.lastIndex) {
                            val a = sweepGammas[i]
                            val b = sweepGammas[i + 1]
                            val ga = a.second
                            val gb = b.second
                            if (!ga.re.isFinite() || !ga.im.isFinite() || !gb.re.isFinite() || !gb.im.isFinite()) continue
                            val pa = pt(ga)
                            val pb = pt(gb)
                            val za = a.first.primary
                            val zb = b.first.primary
                            val rr = 0.5 * (za.rOhm + zb.rOhm)
                            val xx = 0.5 * (za.xOhm + zb.xOhm)
                            drawLine(
                                impedanceSweepColor(rr, xx, z0Ohm),
                                pa, pb,
                                strokeWidth = 5.5f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                drawCircle(axisColor.copy(alpha = 0.85f), 3.8f, Offset(cx, cy))
                drawContext.canvas.nativeCanvas.drawText("Z0=${"%.0f".format(z0Ohm)} Ω ref", cx + 8f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("0", cx - r - 22f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("∞", cx + r - 8f, cy - 8f, paint)
                drawContext.canvas.nativeCanvas.drawText("+jX", cx - 16f, cy - r - 6f, paint)
                drawContext.canvas.nativeCanvas.drawText("−jX", cx - 16f, cy + r + 24f, paint)
                drawContext.canvas.nativeCanvas.drawText("VSWR 2", cx + r / 3f + 6f, cy - 8f, paint)

                // 1.19.55: audio-synchronized moving marker on the Smith sweep.
                audioSweepPosition?.let { rawU ->
                    if (sweepGammas.size >= 2) {
                        val u = rawU.coerceIn(0.0, 1.0)
                        val x = u * (sweepGammas.size - 1).toDouble()
                        val i0 = kotlin.math.floor(x).toInt().coerceIn(0, sweepGammas.lastIndex)
                        val i1 = (i0 + 1).coerceAtMost(sweepGammas.lastIndex)
                        val t = x - i0.toDouble()

                        val g0 = sweepGammas[i0].second
                        val g1 = sweepGammas[i1].second
                        val gi = Cpx(
                            g0.re + (g1.re - g0.re) * t,
                            g0.im + (g1.im - g0.im) * t
                        )
                        val p = pt(gi)

                        val f0 = sweepGammas[i0].first.frequencyMHz
                        val f1 = sweepGammas[i1].first.frequencyMHz
                        val fNow = f0 + (f1 - f0) * t

                        val z0p = sweepGammas[i0].first.primary
                        val z1p = sweepGammas[i1].first.primary
                        val rNow = z0p.rOhm + (z1p.rOhm - z0p.rOhm) * t
                        val xNow = z0p.xOhm + (z1p.xOhm - z0p.xOhm) * t
                        val liveColor = impedanceSweepColor(rNow, xNow, z0Ohm)

                        // Halo + palette-colored point makes audio position visible.
                        drawCircle(surfaceColor, 14.0f, p)
                        drawCircle(liveColor, 9.5f, p)
                        drawCircle(axisColor, 2.6f, p)
                        drawContext.canvas.nativeCanvas.drawText(
                            "${maaFmt(fNow, 4)} MHz",
                            p.x + 10f,
                            p.y - 10f,
                            paint
                        )
                    }
                }

                if (sweepGammas.size >= 2) {
                    val first = sweepGammas.first()
                    val last = sweepGammas.last()
                    val pf = pt(first.second)
                    val pl = pt(last.second)
                    drawCircle(surfaceColor, 6.5f, pf)
                    drawCircle(sweepColor, 4.0f, pf)
                    drawCircle(surfaceColor, 6.5f, pl)
                    drawCircle(sweepColor, 4.0f, pl)
                    drawContext.canvas.nativeCanvas.drawText("−5%", pf.x + 7f, pf.y - 6f, paint)
                    drawContext.canvas.nativeCanvas.drawText("+5%", pl.x + 7f, pl.y - 6f, paint)
                }

                if (inputs.size > 1) {
                    inputs.drop(1).take(3).forEachIndexed { idx, input ->
                        val p = pt(impedanceToGamma(input.rOhm, input.xOhm, z0Ohm))
                        drawCircle(surfaceColor, 7f, p)
                        drawCircle(extraMarkerColor.copy(alpha = 0.75f), 4.8f, p)
                        drawContext.canvas.nativeCanvas.drawText("M${idx + 2}", p.x + 8f, p.y - 7f, paint)
                    }
                }

                val q = pt(gamma)
                drawCircle(surfaceColor, 10f, q)
                drawCircle(markerColor, 6.8f, q)
                drawContext.canvas.nativeCanvas.drawText("M1", q.x + 8f, q.y - 7f, paint)
            }
        }

    }
}


private fun impedanceToGamma(rOhm: Double, xOhm: Double, z0Ohm: Double): Cpx {
    val z0 = z0Ohm.coerceAtLeast(1e-9)
    val num = Cpx(rOhm - z0, xOhm)
    val den = Cpx(rOhm + z0, xOhm)
    if (den.mag < 1e-15) return Cpx(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY)
    return num / den
}

private fun maaFmt(v: Double, digits: Int = 3): String =
    if (v.isFinite()) "% .${digits}f".format(v).trim() else "∞"


private fun format3DStep(stepDeg: Double): String =
    if (kotlin.math.abs(stepDeg - kotlin.math.round(stepDeg)) < 1e-9) "%.0f".format(stepDeg) else "%.1f".format(stepDeg).replace('.', ',')
