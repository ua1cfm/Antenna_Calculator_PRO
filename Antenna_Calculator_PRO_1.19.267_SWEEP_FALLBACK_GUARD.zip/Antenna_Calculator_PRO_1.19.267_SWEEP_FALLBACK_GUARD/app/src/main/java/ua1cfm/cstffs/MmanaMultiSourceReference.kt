package ua1cfm.cstffs

import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * ISOLATED SOLVER LAB v5: independent thin-wire Pocklington/EFIE solver. Not used by production antenna calculations.
 *
 * This engine is intentionally independent of BigStarLegacyAlphaImpedance, geometry-corpus
 * impedance guesses and the historical Alpha/MoM compatibility path.  It solves the retarded
 * thin-wire EFIE in mixed current/charge (PEEC) form:
 *
 *   Z = j*w*L + (1/(j*w))*B^T*P*B + Zload
 *
 * v2 fixed the two most important thin-wire singular terms: the vector-potential self integral is
 * evaluated as an analytic finite-radius static term plus a smooth retarded correction, and nodal
 * charge self potential is averaged over the local half-segment support instead of using 1/a.
 * This removes the huge artificial capacitive reactance of v1 without fitting to antenna names or
 * stored impedances.  Lumped loads and delta-gap sources remain physical series/impressed terms.
 *
 * v4 / Ground Model v2 separates the actual boundary physics. G=1 is an infinite PEC plane;
 * G=2 is a finite-conductivity earth using complex-permittivity Fresnel image coefficients in
 * the EFIE mutual terms instead of pretending that real soil is PEC. MMANA Add-height is applied
 * before the image solve. Explicit radial / ground-plane wires remain ordinary wire geometry.
 */
object MmanaMultiSourceReference {
    private const val C0 = 299_792_458.0
    private const val MU0 = 1.25663706212e-6
    private const val EPS0 = 8.8541878128e-12

    data class Progress(val percent: Int, val stage: String)
    data class Result(
        val rOhm: Double,
        val xOhm: Double,
        val segments: Int,
        val passCount: Int,
        val deltaPercent: Double?,
        val confidence: String,
        val minSegmentRadiusRatio: Double,
        val matrixResidual: Double,
        val junctionCount: Int,
        val resolvedSources: String,
        val resolvedLoads: String,
        val skippedInsulatorWires: Int,
        val groundTerminalCount: Int,
        val endpointFineWireCount: Int,
        val sourceHostSegments: String,
        val loadHostSegments: String,
        val fieldSegments: List<AntennaSolveTypes.SegmentCurrent>
    ) {
        fun formattedZ(): String = "%.2f %s j%.2f Ω".format(rOhm, if (xOhm >= 0.0) "+" else "−", abs(xOhm))
    }

    private data class C(val re: Double, val im: Double) {
        operator fun plus(o: C) = C(re + o.re, im + o.im)
        operator fun minus(o: C) = C(re - o.re, im - o.im)
        operator fun times(o: C) = C(re * o.re - im * o.im, re * o.im + im * o.re)
        operator fun times(s: Double) = C(re * s, im * s)
        operator fun div(o: C): C {
            val d = o.re * o.re + o.im * o.im
            return if (d < 1e-300) C(0.0, 0.0)
            else C((re * o.re + im * o.im) / d, (im * o.re - re * o.im) / d)
        }
        fun mag() = sqrt(re * re + im * im)
    }

    private data class Node(
        val x: Double,
        val y: Double,
        val z: Double,
        var radius: Double,
        var groundTerminal: Boolean = false
    )
    private data class Seg(
        val wireIndex: Int,
        val n0: Int, val n1: Int,
        val x: Double, val y: Double, val z: Double,
        val ux: Double, val uy: Double, val uz: Double,
        val length: Double, val radius: Double,
        val along: Double
    )
    private data class Pass(
        val r: Double,
        val x: Double,
        val n: Int,
        val minLr: Double,
        val residual: Double,
        val junctionCount: Int,
        val resolvedSources: String,
        val resolvedLoads: String,
        val skippedInsulators: Int,
        val groundTerminals: Int,
        val endpointFineWires: Int,
        val sourceHostSegments: String,
        val loadHostSegments: String,
        val fieldSegments: List<AntennaSolveTypes.SegmentCurrent>
    )

    fun solveAdaptive(
        model: MaaModel,
        cancel: AtomicBoolean = AtomicBoolean(false),
        maxPasses: Int = 5,
        onProgress: (Progress) -> Unit = {}
    ): Result {
        require(model.frequencyMHz > 0.0 && model.wires.isNotEmpty())
        val hint = segmentationDensity(model.segmentationDescription) ?: 30
        // Pulse-basis thin-wire EFIE is most stable near the MMANA discretisation range.
        // Refinement is deliberately gradual; over-segmentation is diagnosed rather than forced.
        val densities = intArrayOf(
            max(14, (hint * 0.55).roundToInt()),
            max(16, (hint * 0.70).roundToInt()),
            max(18, (hint * 0.82).roundToInt()),
            max(20, (hint * 0.92).roundToInt()),
            max(22, hint)
        )
        val caps = intArrayOf(260, 340, 420, 500, 580)
        val passes = ArrayList<Pass>(5)
        var lastDelta: Double? = null
        var stablePairs = 0

        val passLimit = maxPasses.coerceIn(2, densities.size)
        for (pi in 0 until passLimit) {
            if (cancel.get()) throw InterruptedException("EFIE v5 cancelled")
            val base = (pi * 20)
            val p = solvePass(model, densities[pi], caps[pi], cancel) { q, s ->
                onProgress(Progress((base + q * 0.20).roundToInt().coerceIn(base, min(99, base + 20)), "E${pi + 1} • $s"))
            }
            passes += p
            if (passes.size >= 2) {
                val d = delta(passes[passes.size - 2], p)
                lastDelta = d
                stablePairs = if (d <= 2.0) stablePairs + 1 else 0
                // Require two consecutive stable refinements, so a one-off crossing does not fake convergence.
                if (stablePairs >= 2) {
                    onProgress(Progress(100, "EFIE v5 converged"))
                    return Result(p.r, p.x, p.n, pi + 1, d, "Converged", p.minLr, p.residual, p.junctionCount, p.resolvedSources, p.resolvedLoads, p.skippedInsulators, p.groundTerminals, p.endpointFineWires, p.sourceHostSegments, p.loadHostSegments, p.fieldSegments)
                }
            }
        }

        val p = passes.last()
        val conf = when {
            lastDelta != null && lastDelta <= 3.0 -> "Marginal"
            lastDelta != null && lastDelta <= 8.0 -> "Marginal"
            else -> "Not converged"
        }
        onProgress(Progress(100, "EFIE v5 $conf"))
        // Important: always return the latest refinement. No rollback to Alpha/native/best-looking value.
        return Result(p.r, p.x, p.n, passes.size, lastDelta, conf, p.minLr, p.residual, p.junctionCount, p.resolvedSources, p.resolvedLoads, p.skippedInsulators, p.groundTerminals, p.endpointFineWires, p.sourceHostSegments, p.loadHostSegments, p.fieldSegments)
    }


    /**
     * Returns center-line spacing to the closest substantially-overlapping parallel wire.
     * This is geometry-only and is used to keep transmission-line / folded-wire mutual
     * coupling resolved. A λ/N-only mesh can completely miss a small HF feeder spacing.
     */
    private fun closeParallelSpacing(model: MaaModel, wi: Int): Double? {
        if (wi !in model.wires.indices) return null
        val a = model.wires[wi]
        val la = a.lengthM
        if (la <= 1e-9) return null
        val ux = a.dx / la; val uy = a.dy / la; val uz = a.dz / la
        var best: Double? = null
        for (j in model.wires.indices) {
            if (j == wi) continue
            val b = model.wires[j]
            val lb = b.lengthM
            if (lb <= 1e-9) continue
            val vx = b.dx / lb; val vy = b.dy / lb; val vz = b.dz / lb
            val ad = kotlin.math.abs(ux * vx + uy * vy + uz * vz)
            if (ad < 0.985) continue
            val t1 = (b.x1 - a.x1) * ux + (b.y1 - a.y1) * uy + (b.z1 - a.z1) * uz
            val t2 = (b.x2 - a.x1) * ux + (b.y2 - a.y1) * uy + (b.z2 - a.z1) * uz
            val lo = max(0.0, min(t1, t2))
            val hi = min(la, max(t1, t2))
            val overlap = hi - lo
            if (overlap < 0.15 * min(la, lb)) continue
            val mx = b.midX - a.midX; val my = b.midY - a.midY; val mz = b.midZ - a.midZ
            val along = mx * ux + my * uy + mz * uz
            val px = mx - along * ux; val py = my - along * uy; val pz = mz - along * uz
            val spacing = sqrt(px * px + py * py + pz * pz)
            val minPhysical = 2.05 * max(kotlin.math.abs(a.radiusM), kotlin.math.abs(b.radiusM))
            if (spacing <= minPhysical || !spacing.isFinite()) continue
            if (best == null || spacing < best!!) best = spacing
        }
        return best
    }

    private fun solvePass(
        model: MaaModel,
        density: Int,
        cap: Int,
        cancel: AtomicBoolean,
        progress: (Int, String) -> Unit
    ): Pass {
        val f = model.frequencyMHz * 1e6
        val omega = 2.0 * PI * f
        val k = omega / C0
        val lambda = C0 / f
        val target = lambda / density.toDouble()

        // MMANA-GAL: R=0 is an INSULATOR / construction line, not an infinitely thin conductor.
        // NEC already follows this rule; FULL-WAVE must do the same.
        val conducting = BooleanArray(model.wires.size) { wi -> model.wires[wi].radiusM > 0.0 }
        val skippedInsulators = conducting.count { !it }
        model.sources.forEach { src ->
            require(src.wireIndex in model.wires.indices && conducting[src.wireIndex]) {
                "FULL-WAVE source references MMANA R=0 insulator W${src.wireIndex + 1}"
            }
        }
        model.loads.forEach { ld ->
            require(ld.wireIndex in model.wires.indices && conducting[ld.wireIndex]) {
                "FULL-WAVE load references MMANA R=0 insulator W${ld.wireIndex + 1}"
            }
        }

        val segNums = model.segmentationDescription?.let { desc ->
            Regex("[-+]?\\d+(?:[.,]\\d+)?").findAll(desc)
                .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }.toList()
        }.orEmpty()
        val baseDm1 = segNums.getOrNull(0)?.toInt()?.coerceAtLeast(1) ?: density * 10
        val baseDm2 = segNums.getOrNull(1)?.toInt()?.coerceAtLeast(1) ?: density
        val sc = segNums.getOrNull(2)?.coerceIn(1.01, 3.0) ?: 2.0
        val ec = segNums.getOrNull(3)?.toInt()?.coerceAtLeast(1) ?: 1
        fun mmanaGroundCount(w: MaaWire): Int {
            if (w.tag > 0) return w.tag.coerceAtLeast(1)
            if (w.tag !in -3..-1) return max(1, ceil(w.lengthM / target).toInt())
            val ratio = baseDm1.toDouble() / max(1, baseDm2).toDouble()
            val dm2 = density.coerceAtLeast(8)
            val dm1 = max(dm2, (dm2 * ratio).roundToInt())
            var fine = lambda / dm1.toDouble()
            var coarse = lambda / dm2.toDouble()
            val segFloor = lambda * 0.001
            if (fine < segFloor) fine = segFloor
            if (coarse < fine) coarse = fine
            var endLen = fine * ec.toDouble()
            var endSegs = ec
            var ss = fine * sc
            var guard = 0
            while (ss < coarse - 1e-12 && guard < 31) {
                endLen += ss; endSegs++; ss *= sc; guard++
            }
            val nEnds = if (w.tag == -1) 2 else 1
            val middle = w.lengthM - nEnds * endLen
            return if (middle < 0.0) ceil(w.lengthM / fine).toInt().coerceAtLeast(1)
            else (nEnds * endSegs + if (middle > 0.0) ceil(middle / coarse).toInt() else 0).coerceAtLeast(1)
        }

        fun minimumSegmentsForPulse(position: Char, offset: Int): Int = when (position.lowercaseChar()) {
            'b', 'e' -> 1 + abs(offset)
            else -> 1 + 2 * abs(offset)
        }
        val mmanaSegParams = MmanaGalSegmentationReference.parse(model.segmentationDescription)
        val travelingWaveProfile = model.analysisProfile == "TRAVELING_WAVE"

        // Ground/add-height must be available here during mesh planning.
        // Do not reference the later local zShift variable from this earlier scope.
        val endpointZShift = GroundModelV2.spec(model).addHeightM

        fun shiftedEndpointZ(wireIndex: Int, position: Char): Double? {
            val w = model.wires.getOrNull(wireIndex) ?: return null
            return when (position.lowercaseChar()) {
                'b' -> w.z1 + endpointZShift
                'e' -> w.z2 + endpointZShift
                else -> null
            }
        }

        val endpointSensitiveWires = mutableSetOf<Int>()
        model.sources.forEach { src ->
            val ep = src.position.lowercaseChar() == 'b' || src.position.lowercaseChar() == 'e'
            val grounded = shiftedEndpointZ(src.wireIndex, src.position)?.let { abs(it) <= 1e-8 } == true
            if (ep && (travelingWaveProfile || grounded)) endpointSensitiveWires += src.wireIndex
        }
        model.loads.forEach { ld ->
            val ep = ld.position.lowercaseChar() == 'b' || ld.position.lowercaseChar() == 'e'
            val grounded = shiftedEndpointZ(ld.wireIndex, ld.position)?.let { abs(it) <= 1e-8 } == true
            if (ep && (travelingWaveProfile || grounded)) endpointSensitiveWires += ld.wireIndex
        }

        val endpointFineDensity = mmanaSegParams?.let {
            (it.dm1 * it.ec.coerceAtLeast(1)).coerceIn(20, 1200)
        }

        val pulseMinimums = IntArray(model.wires.size) { wi -> if (conducting[wi]) 1 else 0 }
        for (src in model.sources) {
            if (src.wireIndex in pulseMinimums.indices) {
                pulseMinimums[src.wireIndex] = max(
                    pulseMinimums[src.wireIndex],
                    minimumSegmentsForPulse(src.position, src.segmentOffset)
                )
            }
        }
        for (load in model.loads) {
            if (load.wireIndex in pulseMinimums.indices) {
                pulseMinimums[load.wireIndex] = max(
                    pulseMinimums[load.wireIndex],
                    minimumSegmentsForPulse(load.position, load.segmentOffset)
                )
            }
        }

        val desired = model.wires.mapIndexed { wi, w ->
            if (!conducting[wi]) return@mapIndexed 0
            // 1.19.218: use MMANA's requested SEG COUNT for both FREE SPACE and GROUND.
            // Important: we intentionally keep the stable UNIFORM physical FULL-WAVE mesh.
            // 1.19.209 showed that reproducing tapered physical span lengths directly caused
            // a severe regression. Here only the pulse/segment COUNT is borrowed from MMANA.
            var n = if (mmanaSegParams != null) {
                MmanaGalSegmentationReference.segmentCount(
                    wireLengthM = w.lengthM,
                    wavelengthM = lambda,
                    segMode = w.tag,
                    params = mmanaSegParams
                )
            } else {
                max(1, ceil(w.lengthM / target).toInt())
            }

            if (wi in endpointSensitiveWires && endpointFineDensity != null) {
                val fineTarget = lambda / endpointFineDensity.toDouble()
                n = max(n, ceil(w.lengthM / fineTarget).toInt().coerceAtLeast(2))
            }

            // Port/load host wires need enough local degrees of freedom to represent the
            // delta-gap voltage and series load without making the entire antenna dense.
            // This is topology-driven and helps LPDA feeds, folded feeds, short matching
            // wires, spring/helix feeds and travelling-wave terminations.
            val hasSource = model.sources.any { it.wireIndex == wi }
            val hasLoad = model.loads.any { it.wireIndex == wi }
            if ((hasSource || hasLoad) && w.tag == 0) {
                // Only SEG=0 is truly automatic uniform segmentation.
                // SEG=-1/-2/-3 already carry explicit MMANA taper semantics and their
                // pulse count MUST stay exactly as MmanaGalSegmentation resolved it.
                // Forcing an odd/minimum-5 count here moved W#C and W#B pulses on
                // gamma/T/folded matching wires (e.g. 144omni W13) relative to NEC/MMANA.
                val aspect = w.lengthM / max(abs(w.radiusM), 1e-12)
                if (aspect >= 8.0) {
                    n = max(n, 5)
                    val centerAddressed = model.sources.any {
                        it.wireIndex == wi && it.position.lowercaseChar() == 'c'
                    } || model.loads.any {
                        it.wireIndex == wi && it.position.lowercaseChar() == 'c'
                    }
                    if (centerAddressed && n % 2 == 0) n++
                }
            }

            // Accuracy v5: λ/N alone is insufficient for feeder / folded / transformer models.
            // Resolve close parallel conductors using their real center-line spacing.
            val spacing = closeParallelSpacing(model, wi)
            if (spacing != null && spacing < lambda / 12.0) {
                // Refine across passes as well as along wavelength: early passes use about
                // 1.2× spacing, the densest pass approaches one spacing per segment.
                val spacingFactor = (1.55 - 0.0075 * density).coerceIn(0.80, 1.30)
                val localTarget = min(target, max(4.0 * max(kotlin.math.abs(w.radiusM), 1e-6), spacingFactor * spacing))
                n = max(n, ceil(w.lengthM / localTarget).toInt())
            }
            if (model.sources.any { it.wireIndex == wi } && w.tag >= 0) {
                // Explicit MMANA taper modes (-1/-2/-3) are already fully resolved above.
                // Do not silently move their source pulse by forcing an odd count.
                val aspect = w.lengthM / max(abs(w.radiusM), 1e-12)
                if (aspect < 4.0 && pulseMinimums[wi] <= 1 && w.tag <= 1) {
                    // Only a genuinely short/thick automatic/manual bridge may remain one cell.
                    n = 1
                } else if (w.tag == 0) {
                    n = max(3, n)
                    val centerSource = model.sources.any {
                        it.wireIndex == wi && it.position.lowercaseChar() == 'c'
                    }
                    if (centerSource && n % 2 == 0) n++
                }
            }
            max(n, pulseMinimums[wi])
        }
        val counts = desired.toMutableList()
        var total = counts.sum()
        if (total > cap) {
            val scale = cap.toDouble() / total
            for (i in counts.indices) {
                counts[i] = max(pulseMinimums[i], floor(counts[i] * scale).toInt())
            }
            total = counts.sum()

            // If preserving exact MMANA pulse offsets pushed us above the cap, reduce only
            // wires that still have cells above their pulse-safe minimum.
            var shrinkGuard = 0
            while (total > cap && shrinkGuard < model.wires.size * 100) {
                val c = counts.indices.filter { counts[it] > pulseMinimums[it] }
                if (c.isEmpty()) break
                val i = c.maxByOrNull { counts[it] - pulseMinimums[it] } ?: break
                counts[i]--; total--; shrinkGuard++
            }

            var guard = 0
            while (total < cap && guard < model.wires.size * 30) {
                val c = counts.indices.filter { counts[it] < desired[it] }
                if (c.isEmpty()) break
                val i = c.maxByOrNull { desired[it].toDouble() / counts[it].coerceAtLeast(1) } ?: break
                counts[i]++; total++; guard++
            }
        }

        // MMANA electrical connection rule:
        // different wires connect only when ORIGINAL wire endpoints coincide.
        // Interior segment nodes are private to their own wire. This prevents a geometric
        // crossing or an endpoint touching an unsplit wire interior from becoming an
        // accidental electrical junction merely because the solver mesh placed a node there.
        val coordScale = model.wires.fold(1.0) { acc, w ->
            max(acc, max(max(abs(w.x1), abs(w.y1)), max(abs(w.z1), max(max(abs(w.x2), abs(w.y2)), abs(w.z2)))))
        }
        val nodeTol = max(1e-11, coordScale * 1e-12)
        val nodes = ArrayList<Node>(total + model.wires.size)
        val buckets = HashMap<String, MutableList<Int>>()

        fun coordKey(prefix: String, x: Double, y: Double, z: Double): String {
            val ix = kotlin.math.round(x / nodeTol).toLong()
            val iy = kotlin.math.round(y / nodeTol).toLong()
            val iz = kotlin.math.round(z / nodeTol).toLong()
            return "$prefix:$ix:$iy:$iz"
        }

        fun nodeIndex(
            wireIndex: Int,
            originalEndpoint: Boolean,
            x: Double, y: Double, z: Double,
            radius: Double
        ): Int {
            val isGroundTerminal = model.groundType != 0 && originalEndpoint && abs(z) <= 1e-8
            // endpoint key is global; interior key is wire-private.
            val prefix = if (originalEndpoint) "E" else "I$wireIndex"
            val kk = coordKey(prefix, x, y, z)
            val list = buckets[kk]
            if (list != null) {
                for (idx in list) {
                    val n = nodes[idx]
                    val dx = n.x - x; val dy = n.y - y; val dz = n.z - z
                    if (dx * dx + dy * dy + dz * dz <= nodeTol * nodeTol) {
                        if (radius > n.radius) n.radius = radius
                        if (isGroundTerminal) n.groundTerminal = true
                        return idx
                    }
                }
            }
            val idx = nodes.size
            nodes += Node(x, y, z, radius, isGroundTerminal)
            buckets.getOrPut(kk) { ArrayList() }.add(idx)
            return idx
        }

        val segs = ArrayList<Seg>(total)
        val ground = GroundModelV2.spec(model)
        // MMANA H (Add height) shifts the complete antenna before applying the z=0 boundary.
        val zShift = ground.addHeightM
        // 1.19.232: MMANA G=2 phased/multi-source models use the MMANA current convention:
        // solve the coupled antenna currents against the ideal image plane, then apply the
        // finite-conductivity Fresnel correction only in the far-field integrator.  Applying
        // real-earth image coefficients inside the current matrix AND again in the radiation
        // integral rotates the relative current phases before coherent Eθ/Eφ summation.
        // Keep the change scoped to >=2 active sources so validated single-source FULL-WAVE
        // models retain their existing Ground Model v2 behavior.
        val activeSourceCount = model.sources.count { kotlin.math.abs(it.amplitude) > 1e-12 }
        val mmanaPhasedRealGround =
            ground.mode == GroundModelV2.Mode.REAL_EARTH && activeSourceCount >= 2
        val usePecImage =
            ground.mode == GroundModelV2.Mode.PEC_PLANE || mmanaPhasedRealGround
        val useRealEarth =
            ground.mode == GroundModelV2.Mode.REAL_EARTH && !mmanaPhasedRealGround
        // Complex relative permittivity eps_r - j*sigma/(omega*eps0).
        val earthEps = C(ground.epsR, -ground.sigmaSM / (omega * EPS0))
        fun csqrtLocal(z: C): C {
            val m = sqrt(z.re * z.re + z.im * z.im)
            val re = sqrt(max(0.0, (m + z.re) * 0.5))
            val im = (if (z.im < 0.0) -1.0 else 1.0) * sqrt(max(0.0, (m - z.re) * 0.5))
            return C(re, im)
        }
        fun fresnelHorizontal(cosTheta: Double): C {
            if (usePecImage) return C(-1.0, 0.0)
            if (!useRealEarth) return C(0.0, 0.0)
            val c = cosTheta.coerceIn(1e-6, 1.0)
            val sin2 = max(0.0, 1.0 - c * c)
            val q = csqrtLocal(earthEps - C(sin2, 0.0))
            return (C(c, 0.0) - q) / (C(c, 0.0) + q)
        }
        fun fresnelVertical(cosTheta: Double): C {
            if (usePecImage) return C(1.0, 0.0)
            if (!useRealEarth) return C(0.0, 0.0)
            val c = cosTheta.coerceIn(1e-6, 1.0)
            val sin2 = max(0.0, 1.0 - c * c)
            val q = csqrtLocal(earthEps - C(sin2, 0.0))
            val ec = earthEps * c
            return (ec - q) / (ec + q)
        }
        val chargeImage = when {
            usePecImage -> C(-1.0, 0.0)
            useRealEarth -> (C(1.0, 0.0) - earthEps) / (C(1.0, 0.0) + earthEps)
            else -> C(0.0, 0.0)
        }

        // Near-field image coefficients follow from the dielectric half-space
        // quasi-static image solution. Horizontal electric-current/dipole image
        // uses the same coefficient as charge; the normal/vertical component
        // changes sign due to mirror orientation. For PEC this tends exactly to
        // H=-1, V=+1.
        val quasiHorizontalImage = chargeImage
        val quasiVerticalImage = C(-chargeImage.re, -chargeImage.im)

        fun blendComplex(a: C, b: C, t: Double): C {
            val u = t.coerceIn(0.0, 1.0)
            return C(a.re + (b.re - a.re) * u, a.im + (b.im - a.im) * u)
        }

        fun currentImageCoefficients(cosTheta: Double, distanceM: Double): Pair<C, C> {
            if (usePecImage) return C(-1.0, 0.0) to C(1.0, 0.0)
            if (!useRealEarth) return C(0.0, 0.0) to C(0.0, 0.0)

            val farH = fresnelHorizontal(cosTheta)
            val farV = fresnelVertical(cosTheta)

            // Sommerfeld half-space behaviour is quasi-static close to the source
            // and approaches Fresnel reflection in the radiation zone.  A smooth
            // dimensionless transition avoids applying a far-field coefficient to
            // the singular/induction terms of the EFIE Green function.
            val kr = k * distanceM.coerceAtLeast(0.0)
            val wFar = (kr * kr) / (1.0 + kr * kr)
            return blendComplex(quasiHorizontalImage, farH, wFar) to
                blendComplex(quasiVerticalImage, farV, wFar)
        }
        model.wires.forEachIndexed { wi, w ->
            if (!conducting[wi]) return@forEachIndexed
            val len = w.lengthM
            if (len <= 1e-12) return@forEachIndexed
            val n = counts[wi].coerceAtLeast(1)
            val ux = w.dx / len; val uy = w.dy / len; val uz = w.dz / len
            val sl = len / n
            val rr = max(abs(w.radiusM), 1e-7)
            for (s in 0 until n) {
                val f0 = s / n.toDouble(); val f1 = (s + 1.0) / n.toDouble(); val fm = (s + 0.5) / n.toDouble()
                val x0 = w.x1 + w.dx * f0; val y0 = w.y1 + w.dy * f0; val z0 = w.z1 + zShift + w.dz * f0
                val x1 = w.x1 + w.dx * f1; val y1 = w.y1 + w.dy * f1; val z1 = w.z1 + zShift + w.dz * f1
                val n0 = nodeIndex(wi, s == 0, x0, y0, z0, rr)
                val n1 = nodeIndex(wi, s == n - 1, x1, y1, z1, rr)
                segs += Seg(wi, n0, n1, w.x1 + w.dx * fm, w.y1 + w.dy * fm, w.z1 + zShift + w.dz * fm,
                    ux, uy, uz, sl, rr, fm)
            }
        }
        val n = segs.size
        require(n > 0)
        // Local support of a nodal charge basis: one half of every incident segment.
        require(segs.isNotEmpty()) { "FULL-WAVE: no conducting MMANA wires after R=0 insulators are removed." }

        val nodeSupport = DoubleArray(nodes.size)
        val nodeDegree = IntArray(nodes.size)
        val nodeMinHalf = DoubleArray(nodes.size) { Double.POSITIVE_INFINITY }
        for (sg in segs) {
            val h = 0.5 * sg.length
            nodeSupport[sg.n0] += h; nodeSupport[sg.n1] += h
            nodeDegree[sg.n0]++; nodeDegree[sg.n1]++
            if (h < nodeMinHalf[sg.n0]) nodeMinHalf[sg.n0] = h
            if (h < nodeMinHalf[sg.n1]) nodeMinHalf[sg.n1] = h
        }
        val junctionCount = nodeDegree.count { it >= 3 }
        val groundTerminalCount = nodes.count { it.groundTerminal }
        progress(8, "mesh $n")

        val ar = DoubleArray(n * n)
        val ai = DoubleArray(n * n)
        fun id(i: Int, j: Int) = i * n + j

        fun green(dx: Double, dy: Double, dz: Double, regularize: Double): C {
            val r = sqrt(dx * dx + dy * dy + dz * dz + regularize * regularize)
            val rr = max(r, 1e-12)
            val ph = -k * rr
            return C(cos(ph) / rr, sin(ph) / rr)
        }

        // Vector-potential term j*w*L. Five-point Gauss is used for mutual terms.
        // For a self term, split exp(-jkr)/r = 1/r + (exp(-jkr)-1)/r.  The first
        // integral has the exact finite-radius value 2*asinh(l/(2a)); the second is smooth.
        val gp = doubleArrayOf(-0.9061798459386640, -0.5384693101056831, 0.0, 0.5384693101056831, 0.9061798459386640)
        val gw = doubleArrayOf(0.2369268850561891, 0.4786286704993665, 0.5688888888888889, 0.4786286704993665, 0.2369268850561891)
        fun asinhLocal(x: Double): Double = kotlin.math.ln(x + sqrt(x * x + 1.0))
        for (m in 0 until n) {
            if ((m and 3) == 0) {
                if (cancel.get()) throw InterruptedException("EFIE v5 cancelled")
                progress(10 + (36.0 * m / max(1, n)).roundToInt(), "vector matrix")
            }
            val a = segs[m]
            for (nn in 0 until n) {
                val b = segs[nn]
                var gr = 0.0; var gi = 0.0
                if (m == nn) {
                    val aa = max(b.radius, 1e-9)
                    // exact electrostatic part of the source-segment integral
                    gr = 2.0 * asinhLocal(b.length / (2.0 * aa))
                    // smooth retardation correction; unlike 1/r this has a finite limit at r=0
                    for (q in gp.indices) {
                        val t = 0.5 * gp[q]
                        val zz = b.length * t
                        val rr = sqrt(zz * zz + aa * aa)
                        val ph = -k * rr
                        val corr = C((cos(ph) - 1.0) / rr, sin(ph) / rr)
                        val ww = 0.5 * b.length * gw[q]
                        gr += corr.re * ww; gi += corr.im * ww
                    }
                } else {
                    for (q in gp.indices) {
                        val t = 0.5 * gp[q]
                        val sx = b.x + b.ux * b.length * t
                        val sy = b.y + b.uy * b.length * t
                        val sz = b.z + b.uz * b.length * t
                        val reg = 1.00 * max(a.radius, b.radius)
                        val g = green(a.x - sx, a.y - sy, a.z - sz, reg)
                        val ww = 0.5 * b.length * gw[q]
                        gr += g.re * ww; gi += g.im * ww
                    }
                }
                val dot = a.ux * b.ux + a.uy * b.uy + a.uz * b.uz
                val scale = MU0 / (4.0 * PI) * a.length * dot
                // j*w*scale*(gr+jgi) = -w*scale*gi + j*w*scale*gr
                ar[id(m, nn)] += -omega * scale * gi
                ai[id(m, nn)] += omega * scale * gr

                if (usePecImage || useRealEarth) {
                    // Ground image term. PEC uses the exact image signs. Real earth uses
                    // complex Fresnel coefficients evaluated for each image ray: horizontal
                    // current -> TE coefficient, vertical current -> TM coefficient.
                    var zr = 0.0; var zi = 0.0
                    for (q in gp.indices) {
                        val t = 0.5 * gp[q]
                        val sx = b.x + b.ux * b.length * t
                        val sy = b.y + b.uy * b.length * t
                        val sourceZ = b.z + b.uz * b.length * t
                        val szImage = -sourceZ
                        val dx = a.x - sx; val dy = a.y - sy; val dz = a.z - szImage
                        val reg = 1.00 * max(a.radius, b.radius)
                        val rr = sqrt(dx * dx + dy * dy + dz * dz + reg * reg).coerceAtLeast(1e-12)
                        val ct = abs(dz) / rr
                        val (gh, gv) = currentImageCoefficients(ct, rr)
                        val orient = gh * (a.ux * b.ux + a.uy * b.uy) +
                            gv * (a.uz * b.uz)
                        val g = green(dx, dy, dz, reg)
                        val z = g * orient
                        val ww = 0.5 * b.length * gw[q]
                        zr += z.re * ww; zi += z.im * ww
                    }
                    val imageScale = MU0 / (4.0 * PI) * a.length
                    ar[id(m, nn)] += -omega * imageScale * zi
                    ai[id(m, nn)] += omega * imageScale * zr
                }
            }
        }

        // Retarded scalar-potential matrix P at continuity nodes. We never store P: accumulate
        // B^T P B directly using the four endpoint combinations of each segment pair.
        for (m in 0 until n) {
            if ((m and 3) == 0) {
                if (cancel.get()) throw InterruptedException("EFIE v5 cancelled")
                progress(47 + (31.0 * m / max(1, n)).roundToInt(), "charge matrix")
            }
            val sm = segs[m]
            val ma = nodes[sm.n0]; val mb = nodes[sm.n1]
            for (nn in 0 until n) {
                val sn = segs[nn]
                val na = nodes[sn.n0]; val nb = nodes[sn.n1]
                fun p(aIdx: Int, a: Node, bIdx: Int, b: Node, same: Boolean): C {
                    val g = if (same) {
                        // Average the singular potential over the local nodal support.  A point
                        // self term 1/a is far too large for a pulse/charge discretisation.
                        val aa = max(max(a.radius, b.radius), 1e-9)
                        // At a 3+ wire junction, summing every half-segment makes the effective
                        // charge support unrealistically long and allows large non-physical current
                        // discontinuities. Use the local shortest incident support at such nodes.
                        val sa = if (nodeDegree[aIdx] >= 3 && nodeMinHalf[aIdx].isFinite()) nodeMinHalf[aIdx] else nodeSupport[aIdx]
                        val sb = if (nodeDegree[bIdx] >= 3 && nodeMinHalf[bIdx].isFinite()) nodeMinHalf[bIdx] else nodeSupport[bIdx]
                        val rawSupport = max(1e-9, max(sa, sb))
                        val lr = rawSupport / aa
                        val blend = ((kotlin.math.ln(max(lr, 8.0)) - kotlin.math.ln(8.0)) /
                            (kotlin.math.ln(100.0) - kotlin.math.ln(8.0))).coerceIn(0.0, 1.0)
                        val supportFactor = 0.82 + 0.13 * blend
                        val support = max(1e-9, supportFactor * rawSupport)
                        val re = 2.0 * asinhLocal(support / (2.0 * aa)) / support
                        // first retarded term of the support-average integral
                        C(re, -k)
                    } else {
                        val reg = 0.10 * max(a.radius, b.radius)
                        green(a.x - b.x, a.y - b.y, a.z - b.z, reg)
                    }
                    var tr = g.re
                    var ti = g.im
                    if (usePecImage || useRealEarth) {
                        // Scalar-potential image. For PEC gamma_q=-1 exactly. For finite earth
                        // use the complex quasi-static dielectric image coefficient; this is the
                        // near-field limit of the Sommerfeld half-space response and avoids the
                        // old incorrect PEC assumption for G=2.
                        val reg = 0.10 * max(a.radius, b.radius)
                        val gi = green(a.x - b.x, a.y - b.y, a.z + b.z, reg)
                        val img = gi * chargeImage
                        tr += img.re
                        ti += img.im
                    }
                    val s = 1.0 / (4.0 * PI * EPS0)
                    return C(tr * s, ti * s)
                }
                // MMANA/grounded-wire continuity: at a true z=0 original endpoint
                // current continues into the ground half-space. Do not treat that terminal
                // as an open wire end carrying an artificial nodal charge.
                val bm0 = if (ma.groundTerminal) 0.0 else -1.0
                val bm1 = if (mb.groundTerminal) 0.0 else  1.0
                val bn0 = if (na.groundTerminal) 0.0 else -1.0
                val bn1 = if (nb.groundTerminal) 0.0 else  1.0

                val paa = p(sm.n0, ma, sn.n0, na, sm.n0 == sn.n0)
                val pab = p(sm.n0, ma, sn.n1, nb, sm.n0 == sn.n1)
                val pba = p(sm.n1, mb, sn.n0, na, sm.n1 == sn.n0)
                val pbb = p(sm.n1, mb, sn.n1, nb, sm.n1 == sn.n1)
                val zaa = bm0 * bn0
                val zab = bm0 * bn1
                val zba = bm1 * bn0
                val zbb = bm1 * bn1
                val kr = zaa * paa.re + zab * pab.re + zba * pba.re + zbb * pbb.re
                val ki = zaa * paa.im + zab * pab.im + zba * pba.im + zbb * pbb.im
                // (1/(j*w))*K = -j/w * (kr+jki) = ki/w - j*kr/w
                ar[id(m, nn)] += ki / omega
                ai[id(m, nn)] += -kr / omega
            }
        }

        // Physical series lumped loads.
        val resolvedLoadInfo = ArrayList<String>(model.loads.size)
        for (load in model.loads) {
            val candidates = segs.indices.filter { segs[it].wireIndex == load.wireIndex }
            if (candidates.isEmpty()) continue
            val localIndex = MmanaGalSegmentationReference.pulseIndex(
                load.position, candidates.size, load.segmentOffset
            )
            val si = candidates[localIndex]
            resolvedLoadInfo += "W${load.wireIndex + 1}${load.position.uppercaseChar()}${if (load.segmentOffset != 0) "%+d".format(load.segmentOffset) else ""}->${localIndex + 1}/${candidates.size}"
            val z = loadImpedance(load, omega) ?: continue
            ar[id(si, si)] += z.re
            ai[id(si, si)] += z.im
        }

        // Complex impressed voltage sources.
        // For MMANA phased arrays solve one RHS per source on the SAME matrix
        // and coherently sum the complex current vectors.
        val vr = DoubleArray(n); val vi = DoubleArray(n)
        val sources = if (model.sources.isNotEmpty()) model.sources else model.sourceWireIndex?.let {
            listOf(MaaSource(it, sourcePosition(model.sourceDescription)))
        } ?: emptyList()
        require(sources.isNotEmpty()) { "EFIE: no source." }

        data class SourceDrive(val seg: Int, val voltage: C, val label: String)
        val drives = ArrayList<SourceDrive>(sources.size)
        var primarySeg = -1
        var primaryV = C(1.0, 0.0)
        val resolvedSourceInfo = ArrayList<String>(sources.size + 1)
        val activeDrives = sources.count { kotlin.math.abs(it.amplitude) > 1e-15 }
        val mmanaPhasedPulseDrive = activeDrives >= 2
        for ((siSrc, src) in sources.withIndex()) {
            val candidates = segs.indices.filter { segs[it].wireIndex == src.wireIndex }
            if (candidates.isEmpty()) continue
            val localIndex = MmanaGalSegmentationReference.pulseIndex(src.position, candidates.size, src.segmentOffset)
            val si = candidates[localIndex]
            val label = "W${src.wireIndex + 1}${src.position.uppercaseChar()}${if (src.segmentOffset != 0) "%+d".format(src.segmentOffset) else ""}->${localIndex + 1}/${candidates.size}"
            resolvedSourceInfo += label
            val ph = src.phaseDeg * PI / 180.0
            val vv = C(src.amplitude * cos(ph), src.amplitude * sin(ph))
            drives += SourceDrive(si, vv, label)

            if (mmanaPhasedPulseDrive) {
                // MMANA/MININEC excites a PULSE (a segment junction), not one
                // piecewise-constant current cell.  The original MININEC RHS is
                // -j*V/M.  M is a common real normalization already contained in
                // this SI EFIE matrix, so retain the physically important -j
                // operator and project the junction excitation onto the two local
                // current cells.  For first-order rooftop functions the adjacent
                // Galerkin overlap is 1/4 of the principal cell (mass-matrix
                // off-diagonal 1/6 vs diagonal 2/3).
                val er = vv.im
                val ei = -vv.re
                vr[si] += er
                vi[si] += ei
                val nextLocal = when {
                    localIndex + 1 < candidates.size -> localIndex + 1
                    localIndex > 0 -> localIndex - 1
                    else -> localIndex
                }
                val sj = candidates[nextLocal]
                if (sj != si) {
                    vr[sj] += 0.25 * er
                    vi[sj] += 0.25 * ei
                }
            } else {
                // Keep the established single-source FULL-WAVE convention intact.
                // This prevents the phased-array correction from regressing the
                // already validated Yagi/LPDA/vertical impedance path.
                vr[si] += vv.re
                vi[si] += vv.im
            }
            if (siSrc == 0) { primarySeg = si; primaryV = vv }
        }
        if (mmanaPhasedPulseDrive) resolvedSourceInfo += "MININEC-pulse-drive"
        if (primarySeg < 0) primarySeg = vr.indices.maxByOrNull { sqrt(vr[it] * vr[it] + vi[it] * vi[it]) } ?: 0

        progress(80, "solve")
        val arCheck = ar.copyOf()
        val aiCheck = ai.copyOf()
        val vrCheck = vr.copyOf()
        val viCheck = vi.copyOf()

        // 1.19.233: solve the complete phased excitation as ONE complex RHS.
        // A linear solve of the summed RHS is mathematically equivalent to summing
        // source-by-source solutions, but using one solve guarantees that impedance,
        // exported currents and the 2D/3D far field all come from the exact same
        // numerical current vector, with no second coherent-combination stage.
        val solved = gaussianSolve(ar, ai, vr, vi, n, cancel) { q ->
            progress(80 + (18.0 * q).roundToInt(), if (drives.size > 1) "phased common RHS" else "solve")
        }
        val ir: DoubleArray = solved.first
        val ii: DoubleArray = solved.second
        if (drives.size > 1) resolvedSourceInfo += "commonRhs=${drives.size}"

        var residualNum2 = 0.0
        var rhsNorm2 = 0.0
        for (row in 0 until n) {
            var sr = 0.0
            var si = 0.0
            for (col in 0 until n) {
                val q = row * n + col
                sr += arCheck[q] * ir[col] - aiCheck[q] * ii[col]
                si += arCheck[q] * ii[col] + aiCheck[q] * ir[col]
            }
            val dr = sr - vrCheck[row]
            val di = si - viCheck[row]
            residualNum2 += dr * dr + di * di
            rhsNorm2 += vrCheck[row] * vrCheck[row] + viCheck[row] * viCheck[row]
        }
        val matrixResidual = sqrt(residualNum2 / max(rhsNorm2, 1e-300))
        val isrc = C(ir[primarySeg], ii[primarySeg])
        val zin = if (isrc.mag() > 1e-14) primaryV / isrc else C(1e12, 0.0)
        progress(100, "Zin")
        val minLr = segs.minOf { it.length / max(it.radius, 1e-12) }
        val sourceHostSegments = model.sources.map { it.wireIndex }.distinct().joinToString(";") { wi ->
            "W${wi + 1}=" + segs.count { it.wireIndex == wi }
        }
        val loadHostSegments = model.loads.map { it.wireIndex }.distinct().joinToString(";") { wi ->
            "W${wi + 1}=" + segs.count { it.wireIndex == wi }
        }

        // Export the FINAL adaptive FULL-WAVE current solution for all visualization
        // subsystems.  These are the exact complex segment currents that produced Zin.
        val localSegmentNumber = IntArray(model.wires.size)
        val fieldSegments = segs.mapIndexed { gi, sg ->
            val local = ++localSegmentNumber[sg.wireIndex]
            AntennaSolveTypes.SegmentCurrent(
                globalIndex = gi,
                tag = sg.wireIndex + 1,
                segment = local,
                xM = sg.x,
                yM = sg.y,
                zM = sg.z,
                lengthM = sg.length,
                radiusM = sg.radius,
                ux = sg.ux,
                uy = sg.uy,
                uz = sg.uz,
                currentReA = ir[gi],
                currentImA = ii[gi]
            )
        }

        return Pass(
            zin.re,
            zin.im,
            n,
            minLr,
            matrixResidual,
            junctionCount,
            resolvedSourceInfo.joinToString(";"),
            resolvedLoadInfo.joinToString(";"),
            skippedInsulators,
            groundTerminalCount,
            endpointSensitiveWires.size,
            sourceHostSegments,
            loadHostSegments,
            fieldSegments
        )
    }

    private fun gaussianSolve(
        ar: DoubleArray, ai: DoubleArray,
        br: DoubleArray, bi: DoubleArray,
        n: Int,
        cancel: AtomicBoolean,
        progress: (Double) -> Unit
    ): Pair<DoubleArray, DoubleArray> {
        fun id(i: Int, j: Int) = i * n + j

        // Scale every equation to O(1). EFIE rows can differ by many orders of
        // magnitude on mixed-length / loaded / close-wire geometries. Absolute
        // pivot thresholds are therefore unsafe.
        for (i in 0 until n) {
            var rowMax = 0.0
            for (j in 0 until n) {
                val q = id(i, j)
                rowMax = max(rowMax, kotlin.math.hypot(ar[q], ai[q]))
            }
            if (!rowMax.isFinite() || rowMax <= 1e-300) {
                throw ArithmeticException("FULL-WAVE singular matrix: empty/non-finite row $i")
            }
            val inv = 1.0 / rowMax
            for (j in 0 until n) {
                val q = id(i, j)
                ar[q] *= inv
                ai[q] *= inv
            }
            br[i] *= inv
            bi[i] *= inv
        }

        // Scaled partial pivoting. Since rows are already normalized, pivot
        // magnitude is directly comparable across rows.
        val relativePivotFloor = 1e-12
        for (k in 0 until n) {
            if ((k and 3) == 0) {
                if (cancel.get()) throw InterruptedException("EFIE v5 cancelled")
                progress(k.toDouble() / max(1, n))
            }

            var p = k
            var best = -1.0
            for (i in k until n) {
                val q = id(i, k)
                val mm = kotlin.math.hypot(ar[q], ai[q])
                if (mm > best) {
                    best = mm
                    p = i
                }
            }

            if (!best.isFinite() || best < relativePivotFloor) {
                throw ArithmeticException(
                    "FULL-WAVE ill-conditioned matrix: pivot $k = $best"
                )
            }

            if (p != k) {
                for (j in 0 until n) {
                    val a = id(k, j)
                    val b = id(p, j)
                    var t = ar[a]; ar[a] = ar[b]; ar[b] = t
                    t = ai[a]; ai[a] = ai[b]; ai[b] = t
                }
                var t = br[k]; br[k] = br[p]; br[p] = t
                t = bi[k]; bi[k] = bi[p]; bi[p] = t
            }

            val akkR = ar[id(k, k)]
            val akkI = ai[id(k, k)]
            val den = akkR * akkR + akkI * akkI
            if (!den.isFinite() || den < relativePivotFloor * relativePivotFloor) {
                throw ArithmeticException(
                    "FULL-WAVE ill-conditioned matrix at diagonal $k"
                )
            }

            for (i in k + 1 until n) {
                val qik = id(i, k)
                val xr0 = ar[qik]
                val xi0 = ai[qik]
                val fr = (xr0 * akkR + xi0 * akkI) / den
                val fi = (xi0 * akkR - xr0 * akkI) / den
                ar[qik] = 0.0
                ai[qik] = 0.0

                for (j in k + 1 until n) {
                    val qij = id(i, j)
                    val qkj = id(k, j)
                    val mr = fr * ar[qkj] - fi * ai[qkj]
                    val mi = fr * ai[qkj] + fi * ar[qkj]
                    ar[qij] -= mr
                    ai[qij] -= mi
                }

                val mbr = fr * br[k] - fi * bi[k]
                val mbi = fr * bi[k] + fi * br[k]
                br[i] -= mbr
                bi[i] -= mbi
            }
        }

        val xr = DoubleArray(n)
        val xi = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            var sr = br[i]
            var si = bi[i]
            for (j in i + 1 until n) {
                val q = id(i, j)
                sr -= ar[q] * xr[j] - ai[q] * xi[j]
                si -= ar[q] * xi[j] + ai[q] * xr[j]
            }

            val q = id(i, i)
            val dr = ar[q]
            val di = ai[q]
            val den = dr * dr + di * di
            if (!den.isFinite() || den < relativePivotFloor * relativePivotFloor) {
                throw ArithmeticException(
                    "FULL-WAVE ill-conditioned back-substitution at row $i"
                )
            }
            xr[i] = (sr * dr + si * di) / den
            xi[i] = (si * dr - sr * di) / den

            if (!xr[i].isFinite() || !xi[i].isFinite()) {
                throw ArithmeticException(
                    "FULL-WAVE non-finite current at row $i"
                )
            }
        }

        progress(1.0)
        return xr to xi
    }

    private fun delta(a: Pass, b: Pass): Double {
        val dr = b.r - a.r; val dx = b.x - a.x
        return 100.0 * sqrt(dr * dr + dx * dx) / max(1.0, sqrt(b.r * b.r + b.x * b.x))
    }

    private fun segmentationDensity(desc: String?): Int? {
        if (desc.isNullOrBlank()) return null
        val nums = Regex("[-+]?\\d+(?:[.,]\\d+)?").findAll(desc)
            .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }.toList()
        if (nums.size < 2) return null
        return nums[1].toInt().takeIf { it in 8..200 }
    }

    private fun sourcePosition(desc: String?): Char {
        val m = Regex("w\\s*\\d+\\s*([bce])", RegexOption.IGNORE_CASE).find(desc.orEmpty())
        return m?.groupValues?.getOrNull(1)?.firstOrNull() ?: 'C'
    }
    private fun loadImpedance(load: MaaLoad, omega: Double): C? = when (load.kind) {
        0 -> {
            val l = load.value1 * 1e-6
            val c = load.value2 * 1e-12
            val q = load.value3
            when {
                l <= 0.0 && c <= 0.0 -> C(0.0, 0.0)
                l > 0.0 && c <= 0.0 -> {
                    val x = omega * l; C(if (q > 0.0) abs(x) / q else 0.0, x)
                }
                l <= 0.0 && c > 0.0 -> {
                    val x = -1.0 / max(omega * c, 1e-30); C(if (q > 0.0) abs(x) / q else 0.0, x)
                }
                else -> {
                    val xl = omega * l; val rl = if (q > 0.0) abs(xl) / q else 0.0
                    val xc = -1.0 / max(omega * c, 1e-30); val rc = if (q > 0.0) abs(xc) / q else 0.0
                    val zl = C(rl, xl); val zc = C(rc, xc); val den = zl + zc
                    if (den.mag() < 1e-20) C(1e12, 0.0) else (zl * zc) / den
                }
            }
        }
        1 -> C(load.value1, load.value2)
        else -> null
    }
}
