package ua1cfm.cstffs

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.io.File

/**
 * Crash/restart-safe state for recursive MAA batch runs.
 *
 * A CSV row and its completed relative path are flushed after EVERY antenna.
 * This means a forced app restart loses at most the antenna that was being solved
 * at the moment of the restart.
 */
object BatchResumeStore {
    private const val PREFS = "maa_batch_resume"
    private const val KEY_ACTIVE = "active"
    private const val KEY_TREE_URI = "tree_uri"
    private const val KEY_TOTAL = "total"
    private const val KEY_PROCESSED = "processed"
    private const val KEY_LAST_PATH = "last_path"
    private const val CHECKPOINT_CSV = "maa_batch_checkpoint.csv"
    private const val DONE_FILE = "maa_batch_done.txt"

    data class Pending(
        val treeUri: Uri,
        val total: Int,
        val processed: Int,
        val lastPath: String?
    )

    fun begin(context: Context, treeUri: Uri, total: Int, csvHeader: String) {
        File(context.filesDir, CHECKPOINT_CSV).writeText(csvHeader, Charsets.UTF_8)
        File(context.filesDir, DONE_FILE).writeText("", Charsets.UTF_8)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, true)
            .putString(KEY_TREE_URI, treeUri.toString())
            .putInt(KEY_TOTAL, total)
            .putInt(KEY_PROCESSED, 0)
            .remove(KEY_LAST_PATH)
            .commit()
    }

    fun pending(context: Context): Pending? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVE, false)) return null
        val uriText = p.getString(KEY_TREE_URI, null)?.takeIf { it.isNotBlank() } ?: return null
        val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return null
        return Pending(
            treeUri = uri,
            total = p.getInt(KEY_TOTAL, 0),
            processed = p.getInt(KEY_PROCESSED, 0),
            lastPath = p.getString(KEY_LAST_PATH, null)
        )
    }

    @Synchronized
    fun appendRow(context: Context, relativePath: String, csvRowWithNewline: String, processed: Int) {
        File(context.filesDir, CHECKPOINT_CSV).appendText(csvRowWithNewline, Charsets.UTF_8)
        val encoded = Base64.encodeToString(relativePath.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        File(context.filesDir, DONE_FILE).appendText(encoded + "\n", Charsets.US_ASCII)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_PROCESSED, processed)
            .putString(KEY_LAST_PATH, relativePath)
            .commit()
    }

    fun completedPaths(context: Context): Set<String> {
        val f = File(context.filesDir, DONE_FILE)
        if (!f.exists()) return emptySet()
        return f.useLines { lines ->
            lines.mapNotNull { line ->
                val t = line.trim()
                if (t.isBlank()) null else runCatching {
                    String(Base64.decode(t, Base64.NO_WRAP), Charsets.UTF_8)
                }.getOrNull()
            }.toSet()
        }
    }

    fun checkpointText(context: Context): String {
        val f = File(context.filesDir, CHECKPOINT_CSV)
        return if (f.exists()) f.readText(Charsets.UTF_8) else ""
    }

    fun markInactive(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, false)
            .commit()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
        runCatching { File(context.filesDir, CHECKPOINT_CSV).delete() }
        runCatching { File(context.filesDir, DONE_FILE).delete() }
    }
}
