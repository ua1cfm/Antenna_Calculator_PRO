package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * MMANA-GAL compatible wire segmentation / pulse resolver.
 *
 * The rules implemented here are intentionally geometry-only and shared by
 * MMANA/MININEC:
 *
 *   SEG > 0 : manual uniform segment count
 *   SEG = 0 : automatic uniform segmentation, about lambda / DM2
 *   SEG = -1: tapered at BOTH ends
 *   SEG = -2: tapered at the START (B) end
 *   SEG = -3: tapered at the END (E) end
 *
 * DM1/DM2/SC/EC are read from the ***Segmentation*** record.
 * Endpoint taper starts with one lambda/DM1 piece, then grows by SC until
 * the coarse lambda/DM2 interval is reached.  MMANA files often carry EC > 1;
 * treating EC as a literal repetition on every expanded/connected wire piece
 * over-meshes matching networks and feeder structures, so the 1.19.255 MMANA
 * compatibility path does not duplicate the first fine interval per sub-wire.
 * The remaining straight middle is filled without exceeding the coarse interval.
 *
 * Pulse positions are segment indices, not percentages of wire length.
 * MaaParser already normalizes bare W#E3 to offset=-3, so B/C/E + offset can
 * be resolved with one common index function.
 */
object MmanaGalSegmentation {
    data class Params(
        val dm1: Int = 200,
        val dm2: Int = 20,
        val sc: Double = 2.0,
        val ec: Int = 1
    )

    data class Span(
        val f0: Double,
        val f1: Double
    ) {
        val center: Double get() = (f0 + f1) * 0.5
        val fractionLength: Double get() = f1 - f0
    }

    fun parse(desc: String?): Params? {
        if (desc.isNullOrBlank()) return null
        val nums = Regex("[-+]?\\d+(?:[.,]\\d+)?")
            .findAll(desc)
            .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
            .toList()
        if (nums.size < 4) return null
        var dm1 = nums[0].roundToInt()
        var dm2 = nums[1].roundToInt()
        var sc = nums[2]
        var ec = nums[3].roundToInt()
        if (dm1 <= 0) dm1 = 200
        if (dm2 <= 0) dm2 = 20
        if (dm1 < dm2) {
            val t = dm1
            dm1 = dm2
            dm2 = t
        }
        sc = sc.coerceIn(1.01, 3.0)
        ec = ec.coerceAtLeast(1)
        return Params(dm1, dm2, sc, ec)
    }

    /**
     * Coarser/finer adaptive pass preserving the original MMANA taper ratio.
     * The final pass uses original DM2, and therefore original DM1 as well.
     */
    fun scaled(params: Params, dm2: Int): Params {
        val d2 = dm2.coerceAtLeast(4)
        val ratio = params.dm1.toDouble() / params.dm2.coerceAtLeast(1).toDouble()
        val d1 = max(d2, (d2 * ratio).roundToInt())
        return params.copy(dm1 = d1, dm2 = d2)
    }

    fun minimumSegmentsForPulse(position: Char, offset: Int): Int = when (position.lowercaseChar()) {
        'b', 'e' -> 1 + abs(offset)
        else -> 1 + 2 * abs(offset)
    }.coerceAtLeast(1)

    /** 0-based pulse segment index. */
    fun pulseIndex(position: Char, count: Int, offset: Int = 0): Int {
        val n = count.coerceAtLeast(1)
        val base = when (position.lowercaseChar()) {
            'b' -> 0
            'e' -> n - 1
            else -> (n - 1) / 2
        }
        return (base + offset).coerceIn(0, n - 1)
    }

    fun pulseCenter(spans: List<Span>, position: Char, offset: Int = 0): Double {
        if (spans.isEmpty()) return 0.5
        return spans[pulseIndex(position, spans.size, offset)].center
    }

    fun segmentCount(
        wireLengthM: Double,
        wavelengthM: Double,
        segMode: Int,
        params: Params,
        compactShortTaper: Boolean = false
    ): Int = spans(wireLengthM, wavelengthM, segMode, params, compactShortTaper).size

    /**
     * Physical segmentation boundaries along one original MMANA wire.
     * Fractions are always monotonic 0..1 and sum exactly to the full wire.
     */
    fun spans(
        wireLengthM: Double,
        wavelengthM: Double,
        segMode: Int,
        params: Params,
        compactShortTaper: Boolean = false
    ): List<Span> {
        if (wireLengthM <= 1e-15 || wavelengthM <= 1e-15) return listOf(Span(0.0, 1.0))

        if (segMode > 0) return uniform(segMode)

        var fine = wavelengthM / params.dm1.coerceAtLeast(1).toDouble()
        var coarse = wavelengthM / params.dm2.coerceAtLeast(1).toDouble()

        // MMANA help warns that segments below about 0.001 lambda are unreliable.
        val floor = wavelengthM * 0.001
        fine = max(fine, floor)
        coarse = max(coarse, fine)

        if (segMode == 0 || segMode !in -3..-1) {
            return uniform(ceil(wireLengthM / coarse).toInt().coerceAtLeast(1))
        }

        // Lengths from a tapered physical endpoint moving inward.
        // Do not repeat the first fine interval EC times on every physical/sub-wire.
        // That interpretation caused systematic over-meshing of MMANA matching
        // and feeder structures.
        val end = ArrayList<Double>()
        end += fine
        var s = fine * params.sc.coerceIn(1.01, 3.0)
        var guard = 0
        while (s < coarse - 1e-12 && guard < 64) {
            end += s
            s *= params.sc.coerceIn(1.01, 3.0)
            guard++
        }

        val taperedEnds = if (segMode == -1) 2 else 1
        val endTotal = end.sum() * taperedEnds
        if (endTotal >= wireLengthM - 1e-12) {
            if (!compactShortTaper) {
                // Preserve the established MMANA count path for ordinary antennas.
                // Dense short-wire networks are handled below by the geometry-aware
                // compact mode selected by MmanaMininecSolver.
                return uniform(ceil(wireLengthM / fine).toInt().coerceAtLeast(1))
            }

            // MMANA dense-short-wire mode: keep endpoint fine zones and consume
            // the remaining length with a compact symmetric centre instead of
            // forcing the whole wire onto lambda/DM1. This avoids severe over-mesh
            // on fractal / fat-wire models made from many short connected pieces.
            val lengths = ArrayList<Double>()
            if (segMode == -1) {
                val left = ArrayList<Double>()
                var used = 0.0
                for (v in end) {
                    if (used + 2.0 * v >= wireLengthM - 1e-12) break
                    left += v
                    used += 2.0 * v
                }
                val centre = (wireLengthM - used).coerceAtLeast(0.0)
                lengths += left
                if (centre > 1e-12) {
                    if (left.size == 1 && centre > 2e-12) {
                        lengths += centre * 0.5
                        lengths += centre * 0.5
                    } else {
                        lengths += centre
                    }
                }
                lengths += left.asReversed()
            } else {
                val tapered = ArrayList<Double>()
                var used = 0.0
                for (v in end) {
                    if (used + v >= wireLengthM - 1e-12) break
                    tapered += v
                    used += v
                }
                val rest = (wireLengthM - used).coerceAtLeast(0.0)
                if (segMode == -2) {
                    lengths += tapered
                    if (rest > 1e-12) lengths += rest
                } else {
                    if (rest > 1e-12) lengths += rest
                    lengths += tapered.asReversed()
                }
            }
            if (lengths.isEmpty()) return listOf(Span(0.0, 1.0))
            val out = ArrayList<Span>(lengths.size)
            var acc = 0.0
            for (i in lengths.indices) {
                val f0 = (acc / wireLengthM).coerceIn(0.0, 1.0)
                acc += lengths[i]
                val f1 = if (i == lengths.lastIndex) 1.0 else (acc / wireLengthM).coerceIn(f0, 1.0)
                if (f1 > f0 + 1e-15) out += Span(f0, f1)
            }
            return out.ifEmpty { listOf(Span(0.0, 1.0)) }
        }

        val remain = (wireLengthM - endTotal).coerceAtLeast(0.0)
        val middleCount = if (remain > 1e-12) ceil(remain / coarse).toInt().coerceAtLeast(1) else 0
        val middleLen = if (middleCount > 0) remain / middleCount.toDouble() else 0.0
        val lengths = ArrayList<Double>()

        when (segMode) {
            -1 -> {
                lengths += end
                repeat(middleCount) { lengths += middleLen }
                lengths += end.asReversed()
            }
            -2 -> {
                // Taper only at the wire START / B endpoint.
                lengths += end
                repeat(middleCount) { lengths += middleLen }
            }
            -3 -> {
                // Taper only at the wire END / E endpoint.
                repeat(middleCount) { lengths += middleLen }
                lengths += end.asReversed()
            }
        }

        if (lengths.isEmpty()) return listOf(Span(0.0, 1.0))

        // Convert physical lengths to exact 0..1 fractions.  Last boundary is forced to 1.
        val out = ArrayList<Span>(lengths.size)
        var acc = 0.0
        for (i in lengths.indices) {
            val f0 = (acc / wireLengthM).coerceIn(0.0, 1.0)
            acc += lengths[i]
            val f1 = if (i == lengths.lastIndex) 1.0 else (acc / wireLengthM).coerceIn(f0, 1.0)
            if (f1 > f0 + 1e-15) out += Span(f0, f1)
        }
        return if (out.isEmpty()) listOf(Span(0.0, 1.0)) else out
    }

    fun uniform(count: Int): List<Span> {
        val n = count.coerceAtLeast(1)
        return List(n) { i -> Span(i / n.toDouble(), (i + 1.0) / n.toDouble()) }
    }

    /**
     * Reduce a span list to a safety count by grouping adjacent MMANA spans.
     * Endpoints and ordering remain exact; no source/load is silently moved to another wire.
     */
    fun coarsen(spans: List<Span>, targetCount: Int): List<Span> {
        val n = targetCount.coerceAtLeast(1)
        if (spans.size <= n) return spans
        val out = ArrayList<Span>(n)
        for (i in 0 until n) {
            val a = (i * spans.size) / n
            val bExclusive = ((i + 1) * spans.size + n - 1) / n
            val b = (bExclusive - 1).coerceIn(a, spans.lastIndex)
            out += Span(spans[a].f0, spans[b].f1)
        }
        // Remove accidental duplicate/zero spans from integer grouping.
        return out.filter { it.f1 > it.f0 + 1e-15 }.ifEmpty { listOf(Span(0.0, 1.0)) }
    }
}
