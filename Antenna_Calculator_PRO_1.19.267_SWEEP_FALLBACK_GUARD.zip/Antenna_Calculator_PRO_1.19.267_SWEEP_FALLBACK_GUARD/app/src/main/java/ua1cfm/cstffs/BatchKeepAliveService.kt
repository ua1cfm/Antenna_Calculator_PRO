package ua1cfm.cstffs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Keeps long recursive MAA batch calculations alive with the screen off.
 *
 * The solver still runs in the app process, but a foreground service raises process
 * importance and PARTIAL_WAKE_LOCK keeps the CPU awake.  If Android nevertheless
 * kills the process, BatchResumeStore keeps a row-by-row checkpoint so the next app
 * start resumes from the first unfinished file.
 */
class BatchKeepAliveService : Service() {
    companion object {
        private const val CHANNEL_ID = "maa_batch"
        private const val NOTIFICATION_ID = 119210
        private const val ACTION_START = "ua1cfm.cstffs.batch.START"
        private const val ACTION_UPDATE = "ua1cfm.cstffs.batch.UPDATE"
        private const val ACTION_STOP = "ua1cfm.cstffs.batch.STOP"
        private const val EXTRA_TEXT = "text"
        private const val EXTRA_PROGRESS = "progress"

        fun start(context: Context, text: String = "Preparing antenna batch…", progress: Int = 0) {
            val i = Intent(context, BatchKeepAliveService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_TEXT, text)
                .putExtra(EXTRA_PROGRESS, progress.coerceIn(0, 100))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i)
            else context.startService(i)
        }

        fun update(context: Context, text: String, progress: Int) {
            val i = Intent(context, BatchKeepAliveService::class.java)
                .setAction(ACTION_UPDATE)
                .putExtra(EXTRA_TEXT, text)
                .putExtra(EXTRA_PROGRESS, progress.coerceIn(0, 100))
            context.startService(i)
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, BatchKeepAliveService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, ACTION_UPDATE, null -> {
                val text = intent?.getStringExtra(EXTRA_TEXT) ?: "Antenna batch is running"
                val progress = intent?.getIntExtra(EXTRA_PROGRESS, 0) ?: 0
                val notification = notification(text, progress)
                if (intent?.action == ACTION_START || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                    startForeground(NOTIFICATION_ID, notification)
                } else {
                    val nm = getSystemService(NotificationManager::class.java)
                    nm.notify(NOTIFICATION_ID, notification)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "AntennaCalculator:RecursiveBatch"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Antenna batch calculation",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps recursive MAA solver batch active while the screen is off."
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String, progress: Int): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pending = launchIntent?.let {
            PendingIntent.getActivity(
                this, 0, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Antenna Calculator PRO — Batch")
            .setContentText(text.take(120))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
        pending?.let { builder.setContentIntent(it) }
        return builder.build()
    }
}
