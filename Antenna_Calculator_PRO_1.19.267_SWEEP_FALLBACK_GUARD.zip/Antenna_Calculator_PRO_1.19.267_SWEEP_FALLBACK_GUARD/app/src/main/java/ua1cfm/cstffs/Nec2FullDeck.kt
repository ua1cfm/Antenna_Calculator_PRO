package ua1cfm.cstffs

import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acosh
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Builds a clean, standard NEC-2 deck from our already parsed MaaModel.
 *
 * This deliberately bypasses OpenNEC's third-party MAA importer.  MMANA files in the
 * 722-model corpus use several localized/legacy section syntaxes; our MaaParser already
 * normalizes those semantics more reliably.  OpenNEC therefore receives only NEC cards.
 */
object Nec2FullDeck {
    data class SourcePort(
        val tag: Int,
        val segment: Int,
        val voltageRe: Double,
        val voltageIm: Double
    )

    data class BuildResult(
        val deck: String,
        val sourceCount: Int,
        val sourcePorts: List<SourcePort> = emptyList(),
        val appliedLoads: Int,
        val unsupportedLoads: Int,
        val segmentCount: Int,
        val warning: String?
    )

    /**
     * NEC-2 real-earth endpoint adapter classification.
     *
     * We deliberately do NOT apply it to every grounded vertical.  The automatic
     * adapter is limited to the class that caused the Beverage error: REAL EARTH
     * plus a B/E source/load exactly at z=0, and either a travelling-wave profile
     * or a grounded termination load.  This also catches related terminated
     * long-wire / EWE/K9AY-like topologies without perturbing ordinary source-only
     * grounded monopoles that NEC-2 already handles reasonably.
     */
    fun groundEndpointAdapterKind(model: MaaModel): String {
        if (model.groundType != 2) return "NONE"
        val zShift = model.addHeightM
        fun isGroundEndpoint(wi: Int, pos: Char): Boolean {
            val w = model.wires.getOrNull(wi) ?: return false
            val z = when (pos.lowercaseChar()) {
                'b' -> w.z1 + zShift
                'e' -> w.z2 + zShift
                else -> return false
            }
            return kotlin.math.abs(z) <= 1e-7
        }

        val groundedSource = model.sources.any {
            isGroundEndpoint(it.wireIndex, it.position)
        }
        val groundedLoad = model.loads.any {
            isGroundEndpoint(it.wireIndex, it.position)
        }
        val traveling = model.analysisProfile == "TRAVELING_WAVE"
        return if ((groundedSource || groundedLoad) && (traveling || groundedLoad)) {
            "ELEVATED_4_RADIAL"
        } else "NONE"
    }

    fun fromMaa(model: MaaModel, config: Nec2Core.SegmentationConfig): BuildResult {
        require(model.frequencyMHz > 0.0 && model.wires.isNotEmpty()) { "Invalid MAA model." }
        val normalizedHint = model.fileNameHint.orEmpty().replace('\\', '/')
        val isMatchCorpus = normalizedHint.contains("/Match/", ignoreCase = true) || normalizedHint.startsWith("Match/", ignoreCase = true)

        // Classical LPDA/Log-Yagi needs a balanced non-radiating crossed transmission-line model.
        // Treating the two very close booms and the tiny feed bridge as ordinary GW radiators can
        // violate NEC thin-wire assumptions and, in practice, produced non-physical negative R.
        // NEC-2 Example 5 uses full dipoles plus crossed TL cards for exactly this topology.
        if (isExplicitLpda(model) && model.sources.size <= 1 && model.loads.isEmpty()) {
            buildLpdaTlDeck(model, config)?.let { return it }
        }
        val plan = Nec2Core.planSegmentation(model, config)
        // 1.19.173: restore the known-good 1.19.121 solver routing for two legacy
        // MMANA families that regressed after later generic heuristics were introduced.
        val semanticName = (model.title + " " + (model.fileNameHint ?: "")).lowercase(Locale.ROOT)
        val legacyBigStar = model.groundType == 0 && ("big star" in semanticName)
        val legacyJAntenna = listOf("j-antenna", "j antenna", "j-ant", "j pole", "j-pole", "j_pole", "jpole", "mod j")
            .any { it in semanticName } || model.antennaKind.contains("J-pole", ignoreCase = true)
        // 1.19.124: MMANA Beverage / traveling-wave files often place the feed and
        // terminating resistor on B/E pulses of short vertical end wires.  A regular
        // lambda/DM2 mesh can collapse a 3 m end wire to ONE NEC segment, moving an
        // endpoint pulse to the segment centre and destroying the traveling-wave current.
        // Preserve normal segmentation on the long wire but apply the fine MMANA end
        // density lambda/(DM1*EC) to wires that actually carry endpoint sources/loads.
        val pulseSensitiveSeg = if (
            config.mode == Nec2Core.SegmentationMode.AUTO && isTravelingWavePulseSensitive(model)
        ) {
            mmanaPulseSensitiveSegmentation(model, config)
        } else null
        // 1.19.137: do NOT emulate an endpoint pulse by uniformly over-segmenting the whole
        // source wire.  MMANA documentation explicitly recommends a separate short wire for
        // sources/loads when converting MAA to NEC, because pulse positions otherwise shift.
        // A dedicated grounded endpoint stub is emitted below; the remaining original wire
        // therefore keeps the ordinary MMANA/OpenNEC segmentation.
        val groundedEndpointSeg: DenseSegPlan? = null
        val verticalSeg = if (
            pulseSensitiveSeg == null && groundedEndpointSeg == null && config.mode == Nec2Core.SegmentationMode.AUTO &&
                !isGroundedEndpointFeed(model) && isVerticalSensitive(model)
        ) {
            mmanaDenseSegmentation(model, config)
        } else null
        val counts = (pulseSensitiveSeg?.counts ?: groundedEndpointSeg?.counts ?: verticalSeg?.counts ?: plan.countsPerWire).toMutableList()

        // 1.19.199: preserve MMANA pulse offsets exactly. Older builds let segmentAt() clamp
        // W#B+n / W#C±n / W#E-n onto the first/last available NEC segment when the host
        // wire was too coarsely segmented. That silently moved generators and lumped loads
        // and is a direct cause of large artificial reactance. Increase ONLY the affected
        // host wire enough to represent the requested pulse location.
        fun minimumSegmentsForPulse(position: Char, offset: Int): Int =
            MmanaGalSegmentation.minimumSegmentsForPulse(position, offset)
        val pulseRecords = buildList {
            model.sources.forEach { add(Triple(it.wireIndex, it.position, it.segmentOffset)) }
            model.loads.forEach { add(Triple(it.wireIndex, it.position, it.segmentOffset)) }
        }
        pulseRecords.forEach { (wi, pos, off) ->
            if (wi in counts.indices) {
                val need = minimumSegmentsForPulse(pos, off)
                if (counts[wi] < need) counts[wi] = need
            }
        }
        val zShift = if (model.groundType != 0) model.addHeightM else 0.0

        // 1.19.219 NEC-2 REAL-EARTH ground-endpoint adapter.
        //
        // NEC-2/Sommerfeld can be unreliable when the MAA model drives or terminates a
        // wire exactly at the lossy-earth interface.  For Beverage-like topologies we
        // replace ONLY that mathematical ground contact with a small elevated 4-radial
        // counterpoise.  The original wire tag, source/load pulse and all upper geometry
        // remain unchanged; only endpoint z and a synthetic local radial set are added.
        data class GroundHub(
            val x: Double,
            val y: Double,
            val originalZ: Double,
            val hubZ: Double,
            val radialLength: Double,
            val radialRadius: Double
        )

        val groundAdapterKind = groundEndpointAdapterKind(model)
        val groundHubs = LinkedHashMap<String, GroundHub>()
        val groundHubTol = 1e-7

        fun hubKey(x: Double, y: Double): String {
            val qx = kotlin.math.round(x / groundHubTol).toLong()
            val qy = kotlin.math.round(y / groundHubTol).toLong()
            return "$qx:$qy"
        }

        if (groundAdapterKind != "NONE") {
            val lambda = model.wavelengthM.coerceAtLeast(1e-6)
            val hubHeight = (0.0025 * lambda).coerceIn(0.02, 0.25)
            val radialLength = (0.05 * lambda).coerceIn(0.50, 5.0)

            fun consider(wi: Int, pos: Char) {
                val w = model.wires.getOrNull(wi) ?: return
                if (w.radiusM <= 0.0) return
                val p = pos.lowercaseChar()
                val x: Double
                val y: Double
                val z: Double
                when (p) {
                    'b' -> { x = w.x1; y = w.y1; z = w.z1 + zShift }
                    'e' -> { x = w.x2; y = w.y2; z = w.z2 + zShift }
                    else -> return
                }
                if (kotlin.math.abs(z) > groundHubTol) return
                val key = hubKey(x, y)
                val rr = maxOf(w.radiusM, 0.001)
                val old = groundHubs[key]
                groundHubs[key] = if (old == null) {
                    GroundHub(x, y, z, hubHeight, radialLength, rr)
                } else {
                    old.copy(radialRadius = maxOf(old.radialRadius, rr))
                }
            }

            model.sources.forEach { consider(it.wireIndex, it.position) }
            model.loads.forEach { consider(it.wireIndex, it.position) }
        }

        fun adaptedEndpointZ(x: Double, y: Double, z: Double): Double {
            if (groundHubs.isEmpty() || kotlin.math.abs(z) > groundHubTol) return z
            return groundHubs[hubKey(x, y)]?.hubZ ?: z
        }

        require(model.invalidSourceRecords == 0) {
            "MAA model contains ${model.invalidSourceRecords} source record(s) referencing nonexistent wire(s)."
        }
        require(model.invalidLoadRecords == 0) {
            "MAA model contains ${model.invalidLoadRecords} load record(s) referencing nonexistent wire(s)."
        }
        // 1.19.199: never invent a default W1 generator. A physical Zin requires an actual
        // active source explicitly present in the MAA file.
        val declaredSources = model.sources
        // MMANA-GAL allows source records with exactly 0 V.  They are disabled generator
        // positions (used by switched/multiband models), not active excitations.  Emitting an
        // NEC EX card with V=0 at that pulse changes the network boundary condition and can
        // move Zin by orders of magnitude.  Only non-zero MMANA generators become NEC EX cards.
        // Keep a very small relative/absolute threshold only for textual round-off; normal
        // phased arrays with small but intentional amplitudes remain active.
        val maxDeclaredAmplitude = declaredSources.maxOfOrNull { kotlin.math.abs(it.amplitude) } ?: 0.0
        val sourceEps = maxOf(1e-12, maxDeclaredAmplitude * 1e-12)
        val srcs = declaredSources.filter { kotlin.math.abs(it.amplitude) > sourceEps }
        require(srcs.isNotEmpty()) {
            "MAA model has no active source (all declared source amplitudes are zero)."
        }
        val disabledZeroSources = declaredSources.size - srcs.size
        // Keep the native NEC-2 voltage source (EX 0) for B/C/E.
        // MMANA endpoint pulses do not map directly to NEC-2 EX 5; the previous EX 5
        // experiment produced large reactance errors on grounded vertical/collinear models.
        // B/E are therefore represented by the first/last ordinary NEC segment.
        var appliedLoads = 0
        var unsupportedLoads = 0
        val sb = StringBuilder()
        sb.appendLine("CM ${sanitizeComment(model.title).take(70)}")
        sb.appendLine("CM Generated by Antenna Calculator PRO for OpenNEC FULL")
        sb.appendLine("CE")

        // IMPORTANT: OpenNEC v2.2.0's MAA importer uses DM1/DM2/SC/EC only to
        // compute the FINAL SEGMENT COUNT for an auto-segmented original wire.  It then
        // keeps that wire as ONE GW card.  1.19.31/1.19.32 incorrectly expanded SEG=-1
        // into several contiguous GW cards.  That changed the NEC junction/current basis
        // and visibly broke coherent summation on some Yagi/Quad models (6EL6MW, 3DQ6).
        // Keep the computed MMANA/OpenNEC count from Nec2Core, but preserve one original
        // MAA wire == one NEC GW card.
        val mmanaAuto = if (
            config.mode == Nec2Core.SegmentationMode.AUTO &&
            verticalSeg == null && !plan.capApplied &&
            isOrdinaryParasiticYagi(model)
        ) parseMmanaSegmentation(model.segmentationDescription) else null

        data class EndpointStub(
            val wireIndex: Int,
            val position: Char,
            val tag: Int,
            val sx: Double, val sy: Double, val sz: Double,
            val ex: Double, val ey: Double, val ez: Double
        )

        // Build MMANA-compatible short feed/load wires only for grounded B/E pulses outside
        // the traveling-wave Beverage path.  The short-wire length is the MMANA end interval
        // lambda/(DM1*EC), clipped so it cannot consume a large fraction of the host wire.
        val endpointStubs = mutableMapOf<Int, EndpointStub>()
        // 1.19.139: synthetic endpoint stubs are disabled.  They changed the actual
        // electrical geometry and made the 160 m grounded-tower reference worse.
        // Endpoint accuracy is now obtained from the MMANA-derived host-wire count.
        if (false && pulseSensitiveSeg == null && model.groundType != 0) {
            val mm = parseMmanaSegmentation(model.segmentationDescription)
            if (mm != null) {
                val endInterval = model.wavelengthM /
                    (mm.dm1.toDouble().coerceAtLeast(1.0) * mm.ec.coerceAtLeast(1).toDouble())
                val usedTags = model.wires.size
                model.wires.forEachIndexed { i, w ->
                    val positions = buildList {
                        model.sources.filter { it.wireIndex == i && (it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e') }
                            .forEach { add(it.position.lowercaseChar()) }
                        model.loads.filter { it.wireIndex == i && (it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e') }
                            .forEach { add(it.position.lowercaseChar()) }
                    }.distinct()
                    if (positions.size != 1 || w.lengthM <= 1e-8) return@forEachIndexed
                    val pos = positions.first()
                    val endpointZ = if (pos == 'b') w.z1 + zShift else w.z2 + zShift
                    if (kotlin.math.abs(endpointZ) > 1e-7) return@forEachIndexed
                    val d = minOf(endInterval, w.lengthM * 0.10).coerceAtLeast(minOf(w.lengthM * 0.01, 1e-6))
                    val f = (d / w.lengthM).coerceIn(1e-6, 0.25)
                    val tag = usedTags + i + 1
                    if (pos == 'b') {
                        val ex = w.x1 + w.dx * f; val ey = w.y1 + w.dy * f; val ez = w.z1 + w.dz * f
                        endpointStubs[i] = EndpointStub(i, pos, tag, w.x1, w.y1, w.z1 + zShift, ex, ey, ez + zShift)
                    } else {
                        val sx = w.x2 - w.dx * f; val sy = w.y2 - w.dy * f; val sz = w.z2 - w.dz * f
                        endpointStubs[i] = EndpointStub(i, pos, tag, sx, sy, sz + zShift, w.x2, w.y2, w.z2 + zShift)
                    }
                }
            }
        }

        model.wires.forEachIndexed { i, w ->
            // MMANA-GAL semantics: R=0 is a wire-insulator, not a conducting wire.
            // Do NOT convert it to an ultra-thin NEC wire; omit it from the NEC geometry
            // while preserving the original MAA wire numbering through the GW tag (i+1).
            if (w.radiusM <= 0.0) return@forEachIndexed
            val tag = i + 1
            val n = counts.getOrElse(i) { 1 }.coerceAtLeast(1)
            // Negative MMANA radii are special combined/taper-wire references. MaaParser currently
            // retains only a positive effective radius; keep that limitation explicit in warning.
            // 1.19.154: NEC EK is a GLOBAL switch and therefore cannot safely be enabled for only
            // one pathological matching-network wire.  Keep every endpoint, tag, source and load
            // unchanged and regularize ONLY the NEC surrogate radius of a local short/thick segment.
            //
            // 1.19.153 used a hard cap r=Delta/4.  On very thick matching-network pieces that was
            // intentionally conservative but could over-thin the wire and drive the solved R too low.
            // Use a C1-smooth transition instead: no correction at Delta/r >= 2, growing smoothly
            // toward the conservative Delta/4 cap as Delta/r approaches 0.5.  This avoids a hard
            // discontinuity and preserves more of the physical MAA radius for borderline cases.
            val rawRadius = max(w.radiusM, 1e-7)
            val segLenForRadius = w.lengthM / n.toDouble().coerceAtLeast(1.0)
            val rawDeltaOverRadius = segLenForRadius / rawRadius.coerceAtLeast(1e-12)
            val radius = if (legacyBigStar || legacyJAntenna) {
                // 1.19.121 behavior: preserve the physical MAA wire radius. J antennas use
                // the legacy dense mesh/EK path when needed; Big Star stays on the ordinary mesh.
                rawRadius
            } else if (rawDeltaOverRadius < 2.0) {
                val targetRadius = minOf(rawRadius, (segLenForRadius / 4.0).coerceAtLeast(1e-7))
                val u = ((2.0 - rawDeltaOverRadius) / 1.5).coerceIn(0.0, 1.0)
                val smooth = u * u * (3.0 - 2.0 * u)
                rawRadius + (targetRadius - rawRadius) * smooth
            } else rawRadius
            val stub = endpointStubs[i]
            if (stub == null) {
                val z1Nec = adaptedEndpointZ(w.x1, w.y1, w.z1 + zShift)
                val z2Nec = adaptedEndpointZ(w.x2, w.y2, w.z2 + zShift)
                sb.appendLine(
                    "GW $tag $n ${fmt(w.x1)} ${fmt(w.y1)} ${fmt(z1Nec)} " +
                        "${fmt(w.x2)} ${fmt(w.y2)} ${fmt(z2Nec)} ${fmt(radius)}"
                )
            } else {
                // Keep the original tag on the long host wire so solved-current mapping remains
                // compatible with the rest of the application.  The synthetic tag carries only
                // the short grounded source/load stub.
                if (stub.position == 'b') {
                    sb.appendLine("GW $tag $n ${fmt(stub.ex)} ${fmt(stub.ey)} ${fmt(stub.ez)} ${fmt(w.x2)} ${fmt(w.y2)} ${fmt(w.z2 + zShift)} ${fmt(radius)}")
                } else {
                    sb.appendLine("GW $tag $n ${fmt(w.x1)} ${fmt(w.y1)} ${fmt(w.z1 + zShift)} ${fmt(stub.sx)} ${fmt(stub.sy)} ${fmt(stub.sz)} ${fmt(radius)}")
                }
                sb.appendLine("GW ${stub.tag} 1 ${fmt(stub.sx)} ${fmt(stub.sy)} ${fmt(stub.sz)} ${fmt(stub.ex)} ${fmt(stub.ey)} ${fmt(stub.ez)} ${fmt(radius)}")
            }
        }

        // Synthetic elevated counterpoise for each adapted real-earth endpoint.
        // Four horizontal radials are deliberately local and symmetric; they are a
        // NEC-2 compatibility surrogate, not a claim about the physical antenna.
        var groundAdapterAddedSegments = 0
        if (groundHubs.isNotEmpty()) {
            var nextTag = model.wires.size + 1
            for (hub in groundHubs.values) {
                val radialSegs = 5
                val dirs = arrayOf(
                    1.0 to 0.0,
                    -1.0 to 0.0,
                    0.0 to 1.0,
                    0.0 to -1.0
                )
                for ((dx, dy) in dirs) {
                    val ex = hub.x + dx * hub.radialLength
                    val ey = hub.y + dy * hub.radialLength
                    sb.appendLine(
                        "GW ${nextTag++} $radialSegs ${fmt(hub.x)} ${fmt(hub.y)} ${fmt(hub.hubZ)} " +
                            "${fmt(ex)} ${fmt(ey)} ${fmt(hub.hubZ)} ${fmt(hub.radialRadius)}"
                    )
                    groundAdapterAddedSegments += radialSegs
                }
            }
        }

        val epsGround = 1e-9
        val hasWireInGroundPlane = model.groundType != 0 && model.wires.any { w ->
            if (w.radiusM <= 0.0) false
            else {
                val z1Nec = adaptedEndpointZ(w.x1, w.y1, w.z1 + zShift)
                val z2Nec = adaptedEndpointZ(w.x2, w.y2, w.z2 + zShift)
                kotlin.math.abs(z1Nec) <= epsGround && kotlin.math.abs(z2Nec) <= epsGround
            }
        }
        // NEC-2 GE ground flag is independent from GN.  For a grounded vertical GE=1 is
        // essential: it connects a wire endpoint at z=0 to its image below the perfect ground
        // and uses the correct current expansion.  Earlier FULL versions incorrectly used GE 0
        // for every model, so grounded verticals were electrically left open at the earth plane.
        // A wire lying entirely in the ground plane is illegal with GE!=0 in NEC-2; keep that
        // exceptional legacy model in compatibility mode and report it explicitly.
        val geGroundFlag = if (model.groundType != 0 && !hasWireInGroundPlane) 1 else 0
        sb.appendLine("GE $geGroundFlag")
        // Ground Model v2: keep the boundary physics explicit.
        // G=1 is an infinite PEC plane. G=2 is a finite-conductivity half-space and must
        // participate in the current/Zin solve (Sommerfeld/Norton NEC ground), not only RP.
        // Explicit radial/ground-plane wires remain ordinary geometry and are never replaced.
        sb.appendLine(GroundModelV2.necGroundCard(model))
        sb.appendLine("FR 0 1 0 0 ${fmt(model.frequencyMHz)} 0")
        val minDeltaOverRadius = model.wires.indices
            .filter { model.wires[it].radiusM > 0.0 }
            .minOfOrNull { wi ->
                val w = model.wires[wi]
                (w.lengthM / counts[wi].coerceAtLeast(1)) / w.radiusM
            } ?: Double.POSITIVE_INFINITY
        val extendedKernel = verticalSeg != null && minDeltaOverRadius < 2.0
        if (extendedKernel) sb.appendLine("EK 0")

        // Convert MMANA loads to an explicit impedance at this frequency (LD type 4).
        // This avoids any ambiguity in MMANA's legacy load-line syntax inside third-party importers.
        model.loads.forEach { load ->
            val z = loadImpedance(load, model.frequencyMHz)
            if (z == null || load.wireIndex !in model.wires.indices || model.wires[load.wireIndex].radiusM <= 0.0) {
                unsupportedLoads++
            } else {
                val stub = endpointStubs[load.wireIndex]?.takeIf { it.position == load.position.lowercaseChar() && load.segmentOffset == 0 }
                val tag = stub?.tag ?: (load.wireIndex + 1)
                val ns = if (stub != null) 1 else counts.getOrElse(load.wireIndex) { 1 }.coerceAtLeast(1)
                val seg = if (stub != null) 1 else segmentAt(load.position, ns, load.segmentOffset)
                sb.appendLine("LD 4 $tag $seg $seg ${fmt(z.first)} ${fmt(z.second)} 0")
                appliedLoads++
            }
        }

        if (isMatchCorpus) {
            // Match-folder impedance must be a real NEC result from the exact MAA network.
            // Never silently drop an R/L/C element: one missing Gamma/Omega/T-match load can
            // move resonance by many MHz and make a plausible-looking but false Zin.
            require(unsupportedLoads == 0 && appliedLoads == model.loads.size) {
                "Match model load mapping incomplete: applied=$appliedLoads/${model.loads.size}, unsupported=$unsupportedLoads."
            }
        }

        val sourcePorts = ArrayList<SourcePort>(srcs.size)
        srcs.forEach { src ->
            require(src.wireIndex in model.wires.indices) { "MAA source references nonexistent wire W${src.wireIndex + 1}." }
            require(model.wires[src.wireIndex].radiusM > 0.0) {
                "MAA source references insulating R=0 wire W${src.wireIndex + 1}; MMANA R=0 is not a conductor."
            }
            val stub = endpointStubs[src.wireIndex]?.takeIf { it.position == src.position.lowercaseChar() && src.segmentOffset == 0 }
            val tag = stub?.tag ?: (src.wireIndex + 1)
            val ns = if (stub != null) 1 else counts.getOrElse(src.wireIndex) { 1 }.coerceAtLeast(1)
            val seg = if (stub != null) 1 else segmentAt(src.position, ns, src.segmentOffset)
            // MMANA/MININEC source phase is opposite to the internal OpenNEC/EFIE
            // exp(+jωt) phasor convention used by the radiation integral. Convert it once
            // at the excitation boundary; never compensate later in the far-field sum.
            val ph = Math.toRadians(-src.phaseDeg)
            val vr = src.amplitude * cos(ph)
            val vi = src.amplitude * sin(ph)
            // 1.19.199: keep the standard NEC delta-gap voltage source (EX 0) for ALL
            // MMANA B/C/E pulses, including a grounded endpoint. Earlier EX 5 experiments
            // produced systematic large-reactance errors on vertical/J/collinear models.
            // The physical endpoint position is preserved by MMANA-derived segmentation
            // and the pulse-offset guard above; changing source TYPE is not required.
            val exType = 0
            sb.appendLine("EX $exType $tag $seg 0 ${fmt(vr)} ${fmt(vi)}")
            sourcePorts += SourcePort(tag, seg, vr, vi)
        }
        if (isMatchCorpus) {
            require(sourcePorts.size == srcs.size && sourcePorts.isNotEmpty()) {
                "Match model source mapping incomplete: ${sourcePorts.size}/${srcs.size}."
            }
        }
        sb.appendLine("XQ 0")
        sb.appendLine("EN")

        val warningParts = mutableListOf<String>()
        if (unsupportedLoads > 0) warningParts += "unsupported MAA Loads: $unsupportedLoads"
        if (groundHubs.isNotEmpty()) warningParts +=
            "NEC2 real-earth endpoint adapter: ELEVATED_4_RADIAL, hubs=${groundHubs.size}, " +
            "height=${fmt(groundHubs.values.first().hubZ)} m, radial=${fmt(groundHubs.values.first().radialLength)} m"
        if (endpointStubs.isNotEmpty()) warningParts += "MMANA grounded endpoint pulse: separate short NEC source/load wire enabled"
        if (pulseSensitiveSeg?.capApplied == true) warningParts += "Beverage endpoint segmentation limited by MAX N=${pulseSensitiveSeg.maxSegments} (${pulseSensitiveSeg.requestedSegments}→${pulseSensitiveSeg.counts.sum()})"
        else if (groundedEndpointSeg?.capApplied == true) warningParts += "Grounded endpoint-feed segmentation limited by MAX N=${groundedEndpointSeg.maxSegments} (${groundedEndpointSeg.requestedSegments}→${groundedEndpointSeg.counts.sum()})"
        else if (verticalSeg?.capApplied == true) warningParts += "MMANA-compatible segmentation limited by MAX N=${verticalSeg.maxSegments} (${verticalSeg.requestedSegments}→${verticalSeg.counts.sum()})"
        else if (pulseSensitiveSeg == null && verticalSeg == null && plan.capApplied) warningParts += "segmentation limited by MAX N=${plan.maxSegments} (${plan.requestedSegments}→${plan.appliedSegments})"
        if (pulseSensitiveSeg != null) warningParts += "Beverage/traveling-wave: B/E source/load wires use MMANA fine end density λ/(DM1·EC); long radiator keeps λ/DM2 mesh; DM1=${pulseSensitiveSeg.dm1}, DM2=${pulseSensitiveSeg.dm2}, SC=${fmt(pulseSensitiveSeg.sc)}, EC=${pulseSensitiveSeg.ec}"
        if (groundedEndpointSeg != null) warningParts += "Grounded MMANA B/E pulse: source/load wire uses λ/(DM1·EC), other wires use λ/DM2; DM1=${groundedEndpointSeg.dm1}, DM2=${groundedEndpointSeg.dm2}, EC=${groundedEndpointSeg.ec}"
        if (verticalSeg != null) warningParts += "Vertical/J-pole: MMANA SEG -1/-2/-3 → dense NEC segmentation λ/(DM1·EC), DM1=${verticalSeg.dm1}, DM2=${verticalSeg.dm2}, SC=${fmt(verticalSeg.sc)}, EC=${verticalSeg.ec}"
        if (mmanaAuto != null && model.wires.any { it.tag <= 0 }) warningParts += "MMANA/OpenNEC auto-seg: SEG -1/-2/-3 → one original GW with computed N; DM1=${mmanaAuto.dm1}, DM2=${mmanaAuto.dm2}, SC=${fmt(mmanaAuto.sc)}, EC=${mmanaAuto.ec}"
        if (extendedKernel) warningParts += "NEC EK 0 enabled: min Δ/r=${"%.2f".format(Locale.US, minDeltaOverRadius)} < 2"
        val locallyRegularized = model.wires.indices.mapNotNull { wi ->
            val w = model.wires[wi]
            if (w.radiusM <= 0.0) return@mapNotNull null
            val ns = counts.getOrElse(wi) { 1 }.coerceAtLeast(1)
            val segLen = w.lengthM / ns.toDouble()
            val rawRatio = segLen / w.radiusM.coerceAtLeast(1e-12)
            if (rawRatio < 2.0) {
                val rawRadius = w.radiusM.coerceAtLeast(1e-12)
                val targetRadius = minOf(rawRadius, (segLen / 4.0).coerceAtLeast(1e-7))
                val u = ((2.0 - rawRatio) / 1.5).coerceIn(0.0, 1.0)
                val smooth = u * u * (3.0 - 2.0 * u)
                val effRadius = rawRadius + (targetRadius - rawRadius) * smooth
                Triple(wi + 1, rawRatio, effRadius)
            } else null
        }
        if (locallyRegularized.isNotEmpty() && !extendedKernel) {
            warningParts += "Local NEC thick-wire guard: " + locallyRegularized.joinToString(", ") { (tag, ratio, effRadius) ->
                "W$tag Δ/r=${"%.2f".format(Locale.US, ratio)} → rNEC=${fmt(effRadius)} m"
            }
        }
        val insulatingWireCount = model.wires.count { it.radiusM <= 0.0 }
        if (insulatingWireCount > 0) warningParts += "MMANA R=0 wire-insulator(s) omitted from NEC geometry: $insulatingWireCount"
        if (disabledZeroSources > 0) warningParts += "MMANA disabled source(s): $disabledZeroSources zero-voltage generator record(s) kept passive (no NEC EX card)"
        if (legacyBigStar) warningParts += "Big Star compatibility: restored 1.19.121 ordinary AUTO mesh + original MAA radii"
        if (legacyJAntenna) warningParts += "J-antenna compatibility: restored 1.19.121 dense MMANA mesh + original MAA radii/EK behavior"
        if (srcs.size > 1) warningParts += "multi-source model: ${srcs.size} active EX sources with original phases/amplitudes"
        val endpointSources = srcs.count { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }
        if (endpointSources > 0) warningParts += "MMANA endpoint source: $endpointSources B/E → standard NEC EX 0 with exact pulse-position mesh"
        val offsetPulseCount = model.sources.count { it.segmentOffset != 0 } + model.loads.count { it.segmentOffset != 0 }
        if (offsetPulseCount > 0) warningParts += "MMANA pulse offsets preserved without segment clamping: $offsetPulseCount"
        if (model.groundType != 0 && !hasWireInGroundPlane) warningParts += "NEC geometry ground: GE 1 + GN, connection of wires at z=0 to the ground image enabled"
        if (hasWireInGroundPlane) warningParts += "wire lies in the z=0 plane: NEC-2 does not allow it with GE 1; GE 0 compatibility is used, Z requires separate verification"
        val thinFeed = srcs.mapNotNull { s ->
            val w = model.wires.getOrNull(s.wireIndex) ?: return@mapNotNull null
            if (w.radiusM <= 0.0) return@mapNotNull null
            val ns = counts.getOrElse(s.wireIndex) { 1 }.coerceAtLeast(1)
            val segLen = w.lengthM / ns
            val ratio = segLen / w.radiusM.coerceAtLeast(1e-12)
            ratio.takeIf { it < 4.0 }
        }.minOrNull()
        if (thinFeed != null) warningParts += "short/thick feed segment L/r=${"%.2f".format(java.util.Locale.US, thinFeed)}: thin-wire NEC-2 limit"
        if (isMatchCorpus) warningParts += "Match audit: exact MAA source/load pulses mapped; Zin is native NEC V/I only (R0 is SWR reference, never substituted)"
        if (model.groundType == 2) warningParts += "Ground Model v2: real earth uses NEC GN 2 (Sommerfeld/Norton), epsr=13, sigma=0.005 S/m for currents, Zin and far field"
        if (model.groundType != 0 && kotlin.math.abs(model.addHeightM) > 1e-12) warningParts += "Add height=${fmt(model.addHeightM)} m applied"

        return BuildResult(
            deck = sb.toString(),
            sourceCount = srcs.size,
            sourcePorts = sourcePorts,
            appliedLoads = appliedLoads,
            unsupportedLoads = unsupportedLoads,
            segmentCount = model.wires.indices
                .filter { model.wires[it].radiusM > 0.0 }
                .sumOf { counts.getOrElse(it) { 1 }.coerceAtLeast(1) } +
                endpointStubs.size + groundAdapterAddedSegments,
            warning = warningParts.takeIf { it.isNotEmpty() }?.joinToString("; ")
        )
    }


    private data class MmanaSegParams(val dm1: Int, val dm2: Int, val sc: Double, val ec: Int)
    private data class DenseSegPlan(
        val counts: List<Int>,
        val requestedSegments: Int,
        val maxSegments: Int,
        val capApplied: Boolean,
        val dm1: Int,
        val dm2: Int,
        val sc: Double,
        val ec: Int
    )

    private fun isTravelingWavePulseSensitive(model: MaaModel): Boolean {
        if (model.analysisProfile != "TRAVELING_WAVE") return false
        return model.sources.any { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' } ||
            model.loads.any { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }
    }

    /**
     * Keep MMANA endpoint pulses spatially local on Beverage/traveling-wave terminations.
     * Only wires that carry B/E sources or loads use the fine end density; applying that
     * density to a 350 m Beverage wire would waste hundreds of segments and is unnecessary.
     */
    private fun mmanaPulseSensitiveSegmentation(
        model: MaaModel,
        config: Nec2Core.SegmentationConfig
    ): DenseSegPlan? {
        val mm = parseMmanaSegmentation(model.segmentationDescription) ?: return null
        val lambda = model.wavelengthM
        val fineDensity = (mm.dm1 * mm.ec.coerceAtLeast(1)).coerceIn(20, 1200)
        val regularDensity = mm.dm2.coerceIn(8, 400)
        val sensitive = mutableSetOf<Int>()
        model.sources.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }
            .forEach { sensitive += it.wireIndex }
        model.loads.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }
            .forEach { sensitive += it.wireIndex }
        if (sensitive.isEmpty()) return null

        val desired = model.wires.mapIndexed { i, w ->
            val density = if (i in sensitive) fineDensity else regularDensity
            var n = ceil(w.lengthM / (lambda / density.toDouble())).toInt().coerceAtLeast(1)
            // Endpoint offsets need enough real NEC segments so E2/B2 etc. do not clamp
            // onto the same segment.  Offset N means at least N+1 positions from that end.
            val maxOffset = (model.sources.filter { it.wireIndex == i }.map { kotlin.math.abs(it.segmentOffset) } +
                model.loads.filter { it.wireIndex == i }.map { kotlin.math.abs(it.segmentOffset) })
                .maxOrNull() ?: 0
            if (i in sensitive) n = max(n, maxOffset + 2)
            n
        }
        val requested = desired.sum()
        val cap = config.maxSegments.coerceIn(max(model.wires.size, 24), 600)
        val counts = desired.toMutableList()
        var total = counts.sum()
        if (total > cap) {
            // First reduce non-sensitive long radiator wires; never collapse the endpoint
            // source/load wires below their pulse-location minimum.
            val minima = counts.indices.map { i ->
                if (i in sensitive) {
                    val maxOffset = (model.sources.filter { it.wireIndex == i }.map { kotlin.math.abs(it.segmentOffset) } +
                        model.loads.filter { it.wireIndex == i }.map { kotlin.math.abs(it.segmentOffset) })
                        .maxOrNull() ?: 0
                    max(2, maxOffset + 2)
                } else 1
            }
            while (total > cap) {
                val k = counts.indices.filter { counts[it] > minima[it] }.maxByOrNull { counts[it] } ?: break
                counts[k]--
                total--
            }
        }
        return DenseSegPlan(counts, requested, cap, requested > cap, mm.dm1, mm.dm2, mm.sc, mm.ec)
    }

    /**
     * MMANA -1/-2/-3 are tapering modes, not a simple "DM2 segments per wavelength" hint.
     * A GW card cannot express non-uniform segment lengths.  The established NEC-for-MMANA
     * conversion is to use a uniform mesh at the finest MMANA end density lambda/(DM1*EC).
     * This is intentionally enabled only for vertical/J-pole style structures where close
     * parallel matching lines and short bends make the old lambda/DM2 mesh unreliable.
     */
    private fun mmanaDenseSegmentation(
        model: MaaModel,
        config: Nec2Core.SegmentationConfig
    ): DenseSegPlan? {
        val mm = parseMmanaSegmentation(model.segmentationDescription) ?: return null
        if (model.wires.none { it.tag <= 0 }) return null
        val lambda = model.wavelengthM
        val fineDensity = (mm.dm1 * mm.ec.coerceAtLeast(1)).coerceIn(20, 1200)
        val regularDensity = mm.dm2.coerceIn(8, 400)
        val centreSources = model.sources.filter { it.position.lowercaseChar() == 'c' }.map { it.wireIndex }.toSet()
        val endpointSources = model.sources.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }.map { it.wireIndex }.toSet()
        val desired = model.wires.mapIndexed { i, w ->
            var n = when {
                w.tag > 0 -> w.tag
                w.tag == 0 -> ceil(w.lengthM / (lambda / regularDensity.toDouble())).toInt().coerceAtLeast(1)
                else -> ceil(w.lengthM / (lambda / fineDensity.toDouble())).toInt().coerceAtLeast(1)
            }
            if (i in centreSources) {
                n = max(n, 3)
                if (n % 2 == 0) n++
            } else if (i in endpointSources) {
                n = max(n, 2)
            }
            n
        }
        val requested = desired.sum()
        val cap = config.maxSegments.coerceIn(max(model.wires.size, 24), 600)
        val counts = desired.toMutableList()
        if (requested > cap) {
            // Keep short/source wires well resolved and take most reductions from long wires.
            val minima = counts.indices.map { i ->
                when {
                    i in centreSources -> 3
                    i in endpointSources -> 2
                    else -> 1
                }
            }
            var total = counts.sum()
            while (total > cap) {
                val candidate = counts.indices
                    .filter { counts[it] > minima[it] }
                    .maxByOrNull { i ->
                        // Prefer reducing wires with the smallest electrical penalty per removed segment.
                        counts[i].toDouble() / model.wires[i].lengthM.coerceAtLeast(1e-9)
                    } ?: break
                counts[candidate]--
                total--
            }
            // Preserve exact centre feed on an odd segment count whenever budget allows.
            centreSources.filter { it in counts.indices }.forEach { i ->
                if (counts[i] % 2 == 0) {
                    if (counts.sum() < cap && counts[i] < desired[i]) counts[i]++
                    else if (counts[i] > 3) counts[i]--
                }
            }
        }
        return DenseSegPlan(counts, requested, cap, requested > counts.sum(), mm.dm1, mm.dm2, mm.sc, mm.ec)
    }


    /**
     * 1.19.137: MMANA/MININEC sources and loads live on pulses (segment junctions), while
     * NEC EX/LD cards live on segment centres.  This matters most when a B/E pulse is at
     * z=0 on a grounded vertical/shunt-feed wire.  Applying the finest MMANA spacing to
     * the whole antenna exhausts MAX N and still leaves the feed segment too long.
     *
     * Keep the rest of the antenna at the normal DM2 density, but use the true MMANA end
     * spacing lambda/(DM1*EC) on wires that carry a grounded B/E source or load.  The NEC
     * source/load centre then approaches the original MININEC pulse without distorting the
     * tower/radial mesh.
     */
    private fun isGroundedEndpointFeed(model: MaaModel): Boolean {
        if (model.groundType == 0) return false
        val endpointWireIndices = (model.sources.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }.map { it.wireIndex } +
            model.loads.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }.map { it.wireIndex }).toSet()
        if (endpointWireIndices.isEmpty()) return false
        return endpointWireIndices.any { i ->
            val w = model.wires.getOrNull(i) ?: return@any false
            val z = if (model.sources.any { it.wireIndex == i && it.position.lowercaseChar() == 'b' } ||
                model.loads.any { it.wireIndex == i && it.position.lowercaseChar() == 'b' }) w.z1 + model.addHeightM else w.z2 + model.addHeightM
            kotlin.math.abs(z) <= 1e-7
        }
    }

    private fun mmanaGroundedEndpointSegmentation(
        model: MaaModel,
        config: Nec2Core.SegmentationConfig
    ): DenseSegPlan? {
        val mm = parseMmanaSegmentation(model.segmentationDescription) ?: return null
        val lambda = model.wavelengthM.coerceAtLeast(1e-9)
        val fineDensity = (mm.dm1.toLong() * mm.ec.coerceAtLeast(1).toLong()).coerceIn(20L, 20000L).toInt()
        val regularDensity = mm.dm2.coerceIn(8, 400)
        val sensitive = mutableSetOf<Int>()
        model.sources.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }.forEach { src ->
            val w = model.wires.getOrNull(src.wireIndex) ?: return@forEach
            val z = if (src.position.lowercaseChar() == 'b') w.z1 + model.addHeightM else w.z2 + model.addHeightM
            if (kotlin.math.abs(z) <= 1e-7) sensitive += src.wireIndex
        }
        model.loads.filter { it.position.lowercaseChar() == 'b' || it.position.lowercaseChar() == 'e' }.forEach { load ->
            val w = model.wires.getOrNull(load.wireIndex) ?: return@forEach
            val z = if (load.position.lowercaseChar() == 'b') w.z1 + model.addHeightM else w.z2 + model.addHeightM
            if (kotlin.math.abs(z) <= 1e-7) sensitive += load.wireIndex
        }
        if (sensitive.isEmpty()) return null

        val desired = model.wires.mapIndexed { i, w ->
            var n = when {
                w.tag > 0 -> w.tag
                i in sensitive -> kotlin.math.ceil(w.lengthM / (lambda / fineDensity.toDouble())).toInt().coerceAtLeast(2)
                else -> kotlin.math.ceil(w.lengthM / (lambda / regularDensity.toDouble())).toInt().coerceAtLeast(1)
            }
            // Endpoint EX/LD should sit as close as practical to the MMANA pulse.
            if (i in sensitive) n = maxOf(n, 2)
            n
        }
        val requested = desired.sum()
        val cap = config.maxSegments.coerceIn(maxOf(model.wires.size, 24), 600)
        val counts = desired.toMutableList()
        if (requested > cap) {
            val minima = counts.indices.map { i -> if (i in sensitive) 2 else 1 }
            var total = counts.sum()
            // Preserve the endpoint-feed wire first; reduce ordinary wires before touching it.
            while (total > cap) {
                val candidate = counts.indices.filter { i -> i !in sensitive && counts[i] > minima[i] }
                    .maxByOrNull { i -> counts[i].toDouble() / model.wires[i].lengthM.coerceAtLeast(1e-9) }
                    ?: counts.indices.filter { i -> counts[i] > minima[i] }
                        .maxByOrNull { i -> counts[i].toDouble() / model.wires[i].lengthM.coerceAtLeast(1e-9) }
                    ?: break
                counts[candidate]--
                total--
            }
        }
        return DenseSegPlan(counts, requested, cap, requested > counts.sum(), mm.dm1, mm.dm2, mm.sc, mm.ec)
    }

    private fun parseMmanaSegmentation(desc: String?): MmanaSegParams? {
        if (desc.isNullOrBlank()) return null
        val nums = Regex("[-+]?\\d+(?:[.,]\\d+)?")
            .findAll(desc).mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }.toList()
        if (nums.size < 4) return null
        val dm1 = nums[0].toInt()
        val dm2 = nums[1].toInt()
        val sc = nums[2]
        val ec = nums[3].toInt()
        if (dm1 !in 20..5000 || dm2 !in 4..1000 || sc !in 1.0..3.0 || ec !in 1..20) return null
        return MmanaSegParams(dm1, dm2, sc, ec)
    }

    private fun isOrdinaryParasiticYagi(model: MaaModel): Boolean =
        model.analysisProfile == "PARASITIC_ARRAY"

    private fun isVerticalSensitive(model: MaaModel): Boolean {
        // 1.19.173: restore the legacy 1.19.121 explicit J-pole route before the newer
        // geometry-only heuristic. This is important for J matching stubs whose topology
        // may not satisfy the later overlap test even though MMANA needs the dense mesh.
        val semantic = (model.title + " " + (model.fileNameHint ?: "")).lowercase(Locale.ROOT)
        val legacyJ = listOf("j-antenna", "j antenna", "j-ant", "j pole", "j-pole", "j_pole", "jpole", "mod j")
            .any { it in semantic } || model.antennaKind.contains("J-pole", ignoreCase = true)
        if (legacyJ) return true

        // Loop/Yagi arrays can contain long parallel Z sides; that alone must not route them
        // through the dense shunt-fed-vertical segmentation path.
        if (model.analysisProfile == "PARASITIC_ARRAY" || model.analysisProfile == "CLOSED_LOOP") return false
        /* Keep the newer geometry-only detector as fallback for unnamed vertical/shunt models. */
        val lambda = model.wavelengthM.coerceAtLeast(1e-9)
        val maxSep = lambda * 0.03
        fun verticalFraction(w: MaaWire): Double {
            val dz = kotlin.math.abs(w.z2 - w.z1)
            return dz / w.lengthM.coerceAtLeast(1e-12)
        }
        for (i in 0 until model.wires.size) {
            val a = model.wires[i]
            if (a.lengthM < lambda * 0.08 || verticalFraction(a) < 0.85) continue
            val amin = minOf(a.z1, a.z2)
            val amax = maxOf(a.z1, a.z2)
            for (j in i + 1 until model.wires.size) {
                val b = model.wires[j]
                if (b.lengthM < lambda * 0.08 || verticalFraction(b) < 0.85) continue
                val bmin = minOf(b.z1, b.z2)
                val bmax = maxOf(b.z1, b.z2)
                val overlap = (minOf(amax, bmax) - maxOf(amin, bmin)).coerceAtLeast(0.0)
                if (overlap < minOf(a.lengthM, b.lengthM) * 0.45) continue
                val ax = (a.x1 + a.x2) * 0.5
                val ay = (a.y1 + a.y2) * 0.5
                val bx = (b.x1 + b.x2) * 0.5
                val by = (b.y1 + b.y2) * 0.5
                val sep = kotlin.math.hypot(ax - bx, ay - by)
                if (sep <= maxSep) return true
            }
        }
        return false
    }


    private data class LpdaStation(
        val axisM: Double,
        val x1: Double, val y1: Double, val z1: Double,
        val x2: Double, val y2: Double, val z2: Double,
        val radiusM: Double,
        val spanM: Double,
        val originalWireIndices: List<Int>,
        val lineConnected: Boolean
    )

    private data class LpdaLinePair(val distanceM: Double, val radiusM: Double)

    private fun isExplicitLpda(model: MaaModel): Boolean =
        model.analysisProfile == "LPDA_END_FIRE"

    /**
     * Build the classical NEC-2 LPDA representation used by NEC Example 5:
     * full radiating dipoles connected at their centre segments by a crossed, non-radiating TL.
     *
     * The MMANA corpus often draws the physical two-wire boom explicitly.  Some examples use an
     * 8 mm boom separation with 3 mm radius conductors and an equally tiny source bridge.  Those
     * dimensions are at/beyond the thin-wire junction limits of a raw GW model and can yield a
     * non-passive input impedance.  Replacing only the balanced boom by NEC's TL network keeps the
     * radiating dipoles in the MoM matrix while modelling the intended 180-degree phase line.
     */
    private fun buildLpdaTlDeck(model: MaaModel, config: Nec2Core.SegmentationConfig): BuildResult? {
        if (model.wires.size < 8 || model.frequencyMHz <= 0.0) return null
        val source = model.sources.firstOrNull() ?: model.sourceWireIndex?.let { wi ->
            MaaSource(wi, sourcePosition(model.sourceDescription), sourceOffset(model.sourceDescription), 0.0, 1.0, model.sourceDescription.orEmpty())
        } ?: return null
        if (source.wireIndex !in model.wires.indices) return null

        val lambda = model.wavelengthM
        val sourceX = model.wires[source.wireIndex].midX
        val quantum = max(max(model.spanX, lambda), 1.0) * 1e-5
        fun stationKey(x: Double): Long = kotlin.math.round(x / quantum).toLong()

        val transverse = model.wires.mapIndexedNotNull { index, w ->
            val l = w.lengthM
            if (l > 1e-8 && abs(w.dx) / l < 0.25) index to w else null
        }
        if (transverse.size < 8) return null

        val lineWires = model.wires.mapIndexedNotNull { index, w ->
            val l = w.lengthM
            if (l > 1e-8 && abs(w.dx) / l >= 0.25) index to w else null
        }
        if (lineWires.size < 2) return null

        val axialTol = max(quantum * 2.5, 1e-6)
        fun touchesAxialStation(w: MaaWire, x: Double): Boolean =
            abs(w.x1 - x) <= axialTol || abs(w.x2 - x) <= axialTol

        val grouped = transverse.groupBy { stationKey(it.second.midX) }
        val rawStations = grouped.values.mapNotNull { entries ->
            val ws = entries.map { it.second }
            val ids = entries.map { it.first }
            val axis = ws.map { it.midX }.average()
            val ys = ws.flatMap { listOf(it.y1, it.y2) }
            val zs = ws.flatMap { listOf(it.z1, it.z2) }
            val ySpan = (ys.maxOrNull() ?: 0.0) - (ys.minOrNull() ?: 0.0)
            val zSpan = (zs.maxOrNull() ?: 0.0) - (zs.minOrNull() ?: 0.0)
            val span = max(ySpan, zSpan)
            if (span < lambda * 0.075) return@mapNotNull null

            // Ignore tiny bridge/feed pieces when choosing the effective element radius.
            val significant = ws.filter { it.lengthM >= span * 0.12 && it.radiusM > 0.0 }
                .ifEmpty { ws.filter { it.radiusM > 0.0 } }
            val radius = median(significant.map { it.radiusM }).coerceAtLeast(1e-7)

            val cx = axis
            val cy = (ys.minOrNull()!! + ys.maxOrNull()!!) * 0.5
            val cz = (zs.minOrNull()!! + zs.maxOrNull()!!) * 0.5
            val lineConnected = lineWires.any { touchesAxialStation(it.second, axis) }
            if (ySpan >= zSpan) {
                LpdaStation(cx, cx, ys.minOrNull()!!, cz, cx, ys.maxOrNull()!!, cz, radius, ySpan, ids, lineConnected)
            } else {
                LpdaStation(cx, cx, cy, zs.minOrNull()!!, cx, cy, zs.maxOrNull()!!, radius, zSpan, ids, lineConnected)
            }
        }.sortedBy { it.axisM }
        if (rawStations.size < 5) return null

        val sourceStation = rawStations.minByOrNull { abs(it.axisM - sourceX) } ?: return null
        if (abs(sourceStation.axisM - sourceX) > max(model.spanX * 0.03, lambda * 0.03)) return null

        // A few MMANA LPDAs contain an additional parasitic director on the opposite side of the
        // feed.  Keep it as a GW dipole but do not connect it to the TL chain.
        val connected = rawStations.filter { it.lineConnected || it === sourceStation }
        val negative = connected.count { it.axisM < sourceStation.axisM - axialTol }
        val positive = connected.count { it.axisM > sourceStation.axisM + axialTol }
        val chainSign = if (negative >= positive) -1 else 1
        val chain = connected.filter {
            abs(it.axisM - sourceStation.axisM) <= axialTol ||
                (if (chainSign < 0) it.axisM < sourceStation.axisM else it.axisM > sourceStation.axisM)
        }.sortedBy { abs(it.axisM - sourceStation.axisM) }
        if (chain.size < 4) return null
        val parasitic = rawStations.filter { s -> chain.none { abs(it.axisM - s.axisM) <= axialTol } }
        val orderedStations = chain + parasitic

        // Infer physical two-wire boom Z0 from pairs of near-parallel phase-line pieces.
        // We use only the tightest repeated pair distance, so large unrelated longitudinal wires
        // do not contaminate the estimate.
        val pairs = mutableListOf<LpdaLinePair>()
        for (i in lineWires.indices) {
            val a = lineWires[i].second
            val al = a.lengthM
            if (al <= 1e-9) continue
            val aux = a.dx / al; val auy = a.dy / al; val auz = a.dz / al
            for (j in i + 1 until lineWires.size) {
                val b = lineWires[j].second
                val bl = b.lengthM
                if (bl <= 1e-9) continue
                val bux = b.dx / bl; val buy = b.dy / bl; val buz = b.dz / bl
                val parallel = abs(aux * bux + auy * buy + auz * buz)
                if (parallel < 0.94) continue
                if (abs(a.midX - b.midX) > max(0.02, 0.12 * max(al, bl))) continue
                val dx = a.midX - b.midX; val dy = a.midY - b.midY; val dz = a.midZ - b.midZ
                val d = sqrt(dx * dx + dy * dy + dz * dz)
                val r = (a.radiusM + b.radiusM) * 0.5
                if (r <= 0.0 || d <= 2.0 * r * 1.001) continue
                pairs += LpdaLinePair(d, r)
            }
        }
        if (pairs.isEmpty()) return null
        val minD = pairs.minOf { it.distanceM }
        val tight = pairs.filter { it.distanceM <= minD * 1.30 }
        if (tight.size < 2) return null
        val lineDistance = median(tight.map { it.distanceM })
        val lineRadius = median(tight.map { it.radiusM }).coerceAtLeast(1e-7)
        val ratio = lineDistance / (2.0 * lineRadius)
        if (!ratio.isFinite() || ratio <= 1.001) return null
        val lineZ0 = 120.0 * acosh(ratio)
        if (!lineZ0.isFinite() || lineZ0 !in 15.0..2000.0) return null

        val plan = Nec2Core.planSegmentation(model, config)
        val target = plan.targetSegmentLengthM.coerceAtLeast(lambda / 100.0)
        val counts = orderedStations.map { st ->
            var n = max(3, ceil(st.spanM / target).toInt())
            if (n % 2 == 0) n++
            n
        }.toMutableList()
        val cap = config.maxSegments.coerceIn(max(orderedStations.size * 3, 24), 600)
        var total = counts.sum()
        if (total > cap) {
            val scale = cap.toDouble() / total.toDouble()
            for (i in counts.indices) {
                var n = max(3, floor(counts[i] * scale).toInt())
                if (n % 2 == 0) n--
                counts[i] = max(3, n)
            }
            total = counts.sum()
            while (total > cap) {
                val k = counts.indices.filter { counts[it] > 3 }.maxByOrNull { counts[it] } ?: break
                counts[k] -= 2
                total -= 2
            }
        }

        val zShift = if (model.groundType != 0) model.addHeightM else 0.0
        val sb = StringBuilder()
        sb.appendLine("CM ${sanitizeComment(model.title).take(70)}")
        sb.appendLine("CM LPDA TL-equivalent generated by Antenna Calculator PRO")
        sb.appendLine("CM boom d=${fmt(lineDistance)} m a=${fmt(lineRadius)} m Z0=${fmt(lineZ0)} ohm crossed")
        sb.appendLine("CE")
        orderedStations.forEachIndexed { i, st ->
            sb.appendLine(
                "GW ${i + 1} ${counts[i]} ${fmt(st.x1)} ${fmt(st.y1)} ${fmt(st.z1 + zShift)} " +
                    "${fmt(st.x2)} ${fmt(st.y2)} ${fmt(st.z2 + zShift)} ${fmt(st.radiusM)}"
            )
        }

        val epsGround = 1e-9
        val anyInPlane = model.groundType != 0 && orderedStations.any { st ->
            abs(st.z1 + zShift) <= epsGround && abs(st.z2 + zShift) <= epsGround
        }
        val geGroundFlag = if (model.groundType != 0 && !anyInPlane) 1 else 0
        sb.appendLine("GE $geGroundFlag")
        sb.appendLine(GroundModelV2.necGroundCard(model))
        sb.appendLine("FR 0 1 0 0 ${fmt(model.frequencyMHz)} 0")

        fun stationTag(s: LpdaStation): Int = orderedStations.indexOfFirst { abs(it.axisM - s.axisM) <= axialTol } + 1
        fun centreSegment(tag: Int): Int = (counts[tag - 1] + 1) / 2
        chain.zipWithNext().forEach { (a, b) ->
            val ta = stationTag(a); val tb = stationTag(b)
            // Negative Z0 is the NEC-2 flag for a crossed line (180-degree phase reversal).
            sb.appendLine("TL $ta ${centreSegment(ta)} $tb ${centreSegment(tb)} ${fmt(-lineZ0)}")
        }

        val sourceTag = stationTag(sourceStation)
        val ph = Math.toRadians(-source.phaseDeg)
        val vr = source.amplitude * cos(ph)
        val vi = source.amplitude * sin(ph)
        sb.appendLine("EX 0 $sourceTag ${centreSegment(sourceTag)} 0 ${fmt(vr)} ${fmt(vi)}")
        sb.appendLine("XQ 0")
        sb.appendLine("EN")

        val warn = buildString {
            append("LPDA/Log-Yagi FULL: NEC-2 crossed-TL route; ")
            append("stations=${orderedStations.size}, TL=${chain.size - 1}, parasitic=${parasitic.size}; ")
            append("boom Z0=${String.format(Locale.US, "%.1f", lineZ0)} Ω (d=${String.format(Locale.US, "%.4f", lineDistance)} m, a=${String.format(Locale.US, "%.4f", lineRadius)} m). ")
            append("Physically close boom wires and feed bridge are excluded from MoM as radiators. ")
            append("FULL Current/Near Field for LPDA show dipole currents; current in the non-radiating TL is not drawn separately.")
        }
        return BuildResult(
            deck = sb.toString(),
            sourceCount = 1,
            sourcePorts = listOf(SourcePort(sourceTag, centreSegment(sourceTag), vr, vi)),
            appliedLoads = 0,
            unsupportedLoads = 0,
            segmentCount = counts.sum(),
            warning = warn
        )
    }

    private fun median(values: List<Double>): Double {
        if (values.isEmpty()) return Double.NaN
        val a = values.filter { it.isFinite() }.sorted()
        if (a.isEmpty()) return Double.NaN
        val m = a.size / 2
        return if (a.size % 2 == 1) a[m] else (a[m - 1] + a[m]) * 0.5
    }

    private fun segmentAt(position: Char, n: Int, offset: Int = 0): Int =
        MmanaGalSegmentation.pulseIndex(position, n, offset) + 1

    private fun sourcePosition(desc: String?): Char {
        val m = Regex("(?i)w\\s*\\d+\\s*([bce])").find(desc.orEmpty())
        return m?.groupValues?.getOrNull(1)?.lowercase()?.firstOrNull() ?: 'c'
    }

    private fun sourceOffset(desc: String?): Int {
        val m = Regex("(?i)w\\s*\\d+\\s*([bce])\\s*([+-]?\\s*\\d+)?").find(desc.orEmpty()) ?: return 0
        val pos = m.groupValues.getOrNull(1)?.lowercase()?.firstOrNull() ?: 'c'
        val text = m.groupValues.getOrNull(2).orEmpty().replace(" ", "")
        val value = text.toIntOrNull() ?: return 0
        return if (!text.startsWith("+") && !text.startsWith("-") && pos == 'e') -value else value
    }

    private fun loadImpedance(load: MaaLoad, frequencyMHz: Double): Pair<Double, Double>? {
        val omega = 2.0 * PI * frequencyMHz * 1e6
        return when (load.kind) {
            0 -> {
                val lH = load.value1 * 1e-6
                val cF = load.value2 * 1e-12
                val q = load.value3
                when {
                    lH <= 0.0 && cF <= 0.0 -> 0.0 to 0.0
                    lH <= 0.0 -> {
                        val x = -1.0 / (omega * cF).coerceAtLeast(1e-30)
                        (if (q > 0.0) abs(x) / q else 0.0) to x
                    }
                    cF <= 0.0 -> {
                        val x = omega * lH
                        (if (q > 0.0) abs(x) / q else 0.0) to x
                    }
                    else -> {
                        val xl = omega * lH
                        val rl = if (q > 0.0) abs(xl) / q else 0.0
                        val xc = -1.0 / (omega * cF).coerceAtLeast(1e-30)
                        val rc = if (q > 0.0) abs(xc) / q else 0.0
                        // Parallel of (rl+jxl) and (rc+jxc).
                        val ar = rl; val ai = xl; val br = rc; val bi = xc
                        val nr = ar * br - ai * bi
                        val ni = ar * bi + ai * br
                        val dr = ar + br
                        val di = ai + bi
                        val d2 = dr * dr + di * di
                        if (d2 < 1e-24) 1e9 to 0.0
                        else ((nr * dr + ni * di) / d2) to ((ni * dr - nr * di) / d2)
                    }
                }
            }
            1 -> load.value1 to load.value2
            else -> null
        }
    }

    private fun sanitizeComment(s: String): String = s.replace('\n', ' ').replace('\r', ' ')
    private fun fmt(v: Double): String = String.format(Locale.US, "%.12g", v)
}
