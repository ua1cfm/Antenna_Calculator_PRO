package ua1cfm.cstffs

import java.io.InputStream
import kotlin.math.roundToInt

/**
 * 1.19.194 geometry-only solver-profile classifier.
 *
 * Training set:
 *  - 722 known/validated MAA geometries with profile labels;
 *  - 1713 user-supplied MAA geometries used semi-supervised after teacher prediction.
 *
 * Inference receives ONLY MaaGeometryFingerprint.vector(model): 44 numeric geometry / topology /
 * source / load / ground features. File name, MAA title and comments are never inputs.
 */
object MaaGeometryForestV2 {
    data class Prediction(
        val profile: String,
        val confidencePercent: Int,
        val runnerUp: String?,
        val runnerUpPercent: Int,
        val trees: Int
    )

    private data class Tree(
        val feature: IntArray,
        val threshold: DoubleArray,
        val left: IntArray,
        val right: IntArray,
        val leafProb: Array<FloatArray?>
    )

    @Volatile private var classes: Array<String> = emptyArray()
    @Volatile private var trees: List<Tree> = emptyList()

    val isReady: Boolean get() = classes.isNotEmpty() && trees.isNotEmpty()
    val trainingSize: Int get() = 2435
    val knownSize: Int get() = 722
    val learnedGeometrySize: Int get() = 1713
    val treeCount: Int get() = trees.size

    @Synchronized
    fun install(input: InputStream) {
        if (isReady) return
        var classNames: Array<String> = emptyArray()
        val built = ArrayList<Tree>(128)

        var feature: IntArray? = null
        var threshold: DoubleArray? = null
        var left: IntArray? = null
        var right: IntArray? = null
        var leaf: Array<FloatArray?>? = null

        fun finishTree() {
            val f = feature ?: return
            val th = threshold ?: return
            val l = left ?: return
            val r = right ?: return
            val lp = leaf ?: return
            built += Tree(f, th, l, r, lp)
            feature = null; threshold = null; left = null; right = null; leaf = null
        }

        input.bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { line ->
                when {
                    line.startsWith("# classes\t") -> {
                        classNames = line.split('\t').drop(1).filter { it.isNotBlank() }.toTypedArray()
                    }
                    line.startsWith("T\t") -> {
                        finishTree()
                        val p = line.split('\t')
                        val n = p.getOrNull(2)?.toIntOrNull() ?: 0
                        if (n > 0) {
                            feature = IntArray(n) { -2 }
                            threshold = DoubleArray(n)
                            left = IntArray(n) { -1 }
                            right = IntArray(n) { -1 }
                            leaf = arrayOfNulls(n)
                        }
                    }
                    line.startsWith("N\t") -> {
                        val p = line.split('\t')
                        val id = p.getOrNull(1)?.toIntOrNull() ?: return@forEach
                        val f = feature ?: return@forEach
                        if (id !in f.indices) return@forEach
                        f[id] = p.getOrNull(2)?.toIntOrNull() ?: -2
                        threshold!![id] = p.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                        left!![id] = p.getOrNull(4)?.toIntOrNull() ?: -1
                        right!![id] = p.getOrNull(5)?.toIntOrNull() ?: -1
                    }
                    line.startsWith("L\t") -> {
                        val p = line.split('\t')
                        val id = p.getOrNull(1)?.toIntOrNull() ?: return@forEach
                        val f = feature ?: return@forEach
                        if (id !in f.indices) return@forEach
                        f[id] = -2
                        val probs = p.getOrNull(2).orEmpty().split(',').mapNotNull { it.toFloatOrNull() }.toFloatArray()
                        if (probs.size == classNames.size) leaf!![id] = probs
                    }
                }
            }
        }
        finishTree()
        if (classNames.isEmpty() || built.isEmpty()) return
        classes = classNames
        trees = built
    }

    fun predict(model: MaaModel): Prediction? {
        val localClasses = classes
        val localTrees = trees
        if (localClasses.isEmpty() || localTrees.isEmpty()) return null
        val x = MaaGeometryFingerprint.vector(model)
        if (x.size != MaaGeometryFingerprint.SIZE) return null

        val sum = DoubleArray(localClasses.size)
        var used = 0
        for (tree in localTrees) {
            var node = 0
            var guard = 0
            while (node in tree.feature.indices && guard++ < 64) {
                val fi = tree.feature[node]
                if (fi < 0) {
                    val p = tree.leafProb[node] ?: break
                    for (i in sum.indices) sum[i] += p[i].toDouble()
                    used++
                    break
                }
                val v = x.getOrElse(fi) { 0.0 }
                node = if (v <= tree.threshold[node]) tree.left[node] else tree.right[node]
            }
        }
        if (used == 0) return null
        for (i in sum.indices) sum[i] /= used.toDouble()
        val order = sum.indices.sortedByDescending { sum[it] }
        val best = order.firstOrNull() ?: return null
        val second = order.getOrNull(1)
        return Prediction(
            profile = localClasses[best],
            confidencePercent = (sum[best] * 100.0).roundToInt().coerceIn(0, 100),
            runnerUp = second?.let { localClasses[it] },
            runnerUpPercent = second?.let { (sum[it] * 100.0).roundToInt().coerceIn(0, 100) } ?: 0,
            trees = used
        )
    }
}
