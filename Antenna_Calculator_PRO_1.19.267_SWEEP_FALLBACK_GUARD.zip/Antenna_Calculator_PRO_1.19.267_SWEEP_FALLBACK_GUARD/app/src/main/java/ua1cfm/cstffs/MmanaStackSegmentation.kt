package ua1cfm.cstffs

/** Literal MMANA-GAL ComLib.cpp TeiAvg/Tei/TeiB/TeiE segmentation for compact Make Stack models. */
object MmanaStackSegmentation {
    private const val DM2DEF = 0.85

    fun spans(
        wireLengthM: Double,
        wavelengthM: Double,
        segMode: Int,
        params: MmanaGalSegmentation.Params
    ): List<MmanaGalSegmentation.Span> {
        if (wireLengthM <= 1e-15 || wavelengthM <= 1e-15) return listOf(MmanaGalSegmentation.Span(0.0, 1.0))
        if (segMode > 0) return MmanaGalSegmentation.uniform(segMode)
        return when (segMode) {
            0 -> mmanaUniform(wireLengthM, wavelengthM, params.dm2)
            -1 -> mmanaTaper(wireLengthM, wavelengthM, params, 0)
            -2 -> mmanaTaper(wireLengthM, wavelengthM, params, -1)
            -3 -> mmanaTaper(wireLengthM, wavelengthM, params, +1)
            else -> mmanaTaper(wireLengthM, wavelengthM, params, 0, -segMode)
        }
    }

    private fun mmanaUniform(length: Double, lambda: Double, dm: Int): List<MmanaGalSegmentation.Span> {
        val dmv = dm.coerceAtLeast(1).toDouble()
        var n = (length / (lambda / dmv)).toInt()
        n = n and 0x0000fffe
        if (n == 0) n += 2
        if (n <= 4 && ((length / n.toDouble()) * DM2DEF > lambda / dmv)) n += 2
        return MmanaGalSegmentation.uniform(n.coerceAtLeast(2))
    }

    /** side: 0=both (Tei), -1=start/B only (TeiB), +1=end/E only (TeiE). */
    private fun mmanaTaper(
        length: Double,
        lambda: Double,
        p: MmanaGalSegmentation.Params,
        side: Int,
        dm1Override: Int? = null
    ): List<MmanaGalSegmentation.Span> {
        val dm1 = (dm1Override?.takeIf { it > 1 } ?: p.dm1).coerceAtLeast(1).toDouble()
        var dm2 = p.dm2.coerceAtLeast(1).toDouble()
        val sc = p.sc.coerceAtLeast(1.0000001)
        val ec = p.ec.coerceAtLeast(1)
        while (dm2 < dm1) {
            var dm = dm1
            var taperTotal = 0.0
            var nt = 0
            while (dm > dm2 && nt < 256) {
                taperTotal += lambda * (if (nt == 0) ec else 1) / dm
                dm /= sc
                nt++
            }
            val ends = if (side == 0) 2 else 1
            val remaining = length - taperTotal * ends
            var n = (remaining / (lambda / dm2)).toInt()
            if (side == 0) n = n and 0x0000fffe
            val acceptable = if (side == 0) remaining > 0.0 && n >= 2 else remaining > 0.0 && n != 0
            if (acceptable) {
                val lengths = ArrayList<Double>()
                fun startTaper(): List<Double> {
                    val a = ArrayList<Double>()
                    var dmx = dm1
                    var k = 0
                    while (dmx > dm2 && k < 256) {
                        if (k == 0) repeat(ec) { a += lambda / dmx } else a += lambda / dmx
                        dmx /= sc
                        k++
                    }
                    return a
                }
                if (side <= 0) lengths += startTaper()
                var middleN = n
                if (side == 0) {
                    val middleEach = remaining / middleN.toDouble()
                    if (middleN <= 4 && ((middleEach / middleN.toDouble()) * DM2DEF > lambda / dm2)) middleN += 2
                } else {
                    if (((remaining / middleN.toDouble()) * DM2DEF) > lambda / p.dm2.coerceAtLeast(1).toDouble()) middleN++
                }
                repeat(middleN) { lengths += remaining / middleN.toDouble() }
                if (side >= 0) lengths += startTaper().asReversed()
                return lengthsToSpans(lengths, length)
            }
            dm2 *= if (side == 0) 2.0 else 1.25
        }
        return mmanaUniform(length, lambda, dm1.toInt())
    }

    private fun lengthsToSpans(lengths0: List<Double>, total: Double): List<MmanaGalSegmentation.Span> {
        val lengths = lengths0.filter { it > 1e-15 }
        if (lengths.isEmpty()) return listOf(MmanaGalSegmentation.Span(0.0, 1.0))
        val sum = lengths.sum()
        val scale = if (sum > 1e-15) total / sum else 1.0
        val out = ArrayList<MmanaGalSegmentation.Span>(lengths.size)
        var acc = 0.0
        for (i in lengths.indices) {
            val f0 = (acc / total).coerceIn(0.0, 1.0)
            acc += lengths[i] * scale
            val f1 = if (i == lengths.lastIndex) 1.0 else (acc / total).coerceIn(f0, 1.0)
            if (f1 > f0 + 1e-15) out += MmanaGalSegmentation.Span(f0, f1)
        }
        return out.ifEmpty { listOf(MmanaGalSegmentation.Span(0.0, 1.0)) }
    }
}
