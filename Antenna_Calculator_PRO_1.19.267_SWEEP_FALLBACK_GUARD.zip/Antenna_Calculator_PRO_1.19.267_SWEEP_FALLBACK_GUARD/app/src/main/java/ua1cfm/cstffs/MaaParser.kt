package ua1cfm.cstffs

import java.io.BufferedReader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class MaaWire(
    val x1: Double, val y1: Double, val z1: Double,
    val x2: Double, val y2: Double, val z2: Double,
    val radiusM: Double,
    val tag: Int,
    /** Negative MMANA wire radius refers to a $$$ Taper wire set $$$ key. */
    val taperRef: Double? = null
) {
    val midX get() = (x1 + x2) * 0.5
    val midY get() = (y1 + y2) * 0.5
    val midZ get() = (z1 + z2) * 0.5
    val dx get() = x2 - x1
    val dy get() = y2 - y1
    val dz get() = z2 - z1
    val lengthM get() = sqrt(dx * dx + dy * dy + dz * dz)
    val axialFractionX get() = if (lengthM > 1e-12) abs(dx) / lengthM else 0.0
    val transverseFraction get() = if (lengthM > 1e-12) sqrt(dy * dy + dz * dz) / lengthM else 0.0
}

data class MaaTaperStage(val totalLengthM: Double, val radiusM: Double)
data class MaaTaperSet(val key: Double, val mode: Int, val stages: List<MaaTaperStage>)

data class MaaLoad(
    val wireIndex: Int,
    val position: Char,
    /** Pulse offset relative to B/C/E, e.g. w1c+1 / w1c-1. */
    val segmentOffset: Int = 0,
    /** MMANA: 0 = LC(Q), 1 = fixed R+jX, 2 = Laplace S load. */
    val kind: Int,
    /** kind 0: L in uH; kind 1: R in ohms. */
    val value1: Double,
    /** kind 0: C in pF; kind 1: X in ohms. */
    val value2: Double,
    /** kind 0: Q. */
    val value3: Double,
    val raw: String
)

data class MaaSource(
    val wireIndex: Int,
    val position: Char,
    /** Pulse offset relative to B/C/E. MMANA compact B1/C1/E2 syntax is normalized here. */
    val segmentOffset: Int = 0,
    /** MMANA source phase in degrees. */
    val phaseDeg: Double = 0.0,
    /** MMANA relative source voltage amplitude. */
    val amplitude: Double = 1.0,
    val raw: String = ""
)

data class MaaModel(
    val title: String,
    val frequencyMHz: Double,
    val wires: List<MaaWire>,
    val sourceWireIndex: Int?,
    val sourceDescription: String?,
    val loads: List<MaaLoad>,
    val segmentationDescription: String?,
    val rawWireCount: Int,
    val referenceImpedanceOhms: Double? = null,
    val fileNameHint: String? = null,
    /** All MMANA excitation sources. Legacy sourceWireIndex/sourceDescription mirror sources.firstOrNull(). */
    val sources: List<MaaSource> = emptyList(),
    /** MMANA G field: 0=free space, 1=perfect ground, 2=real ground. */
    val groundType: Int = 0,
    /** MMANA H field: Add height in metres. */
    val addHeightM: Double = 0.0,
    /** MMANA M field: material selector. */
    val materialCode: Int = 0,
    /** True when one or more negative-radius MMANA wires were expanded from $$$ Taper wire set $$$. */
    val hasTaperWireExpansion: Boolean = false,
    /** Source records that referenced a nonexistent wire and therefore cannot be solved physically. */
    val invalidSourceRecords: Int = 0,
    /** Load records that referenced a nonexistent wire and therefore cannot be solved physically. */
    val invalidLoadRecords: Int = 0,
    /** Number of physical copies encoded by MMANA Make Stack compact header; 1 for ordinary models. */
    val legacyStackCopies: Int = 1
) {
    val wavelengthM: Double get() = 299.792458 / frequencyMHz
    val totalWireLengthM: Double get() = wires.sumOf { it.lengthM }

    val minX get() = wires.minOfOrNull { min(it.x1, it.x2) } ?: 0.0
    val maxX get() = wires.maxOfOrNull { max(it.x1, it.x2) } ?: 0.0
    val minY get() = wires.minOfOrNull { min(it.y1, it.y2) } ?: 0.0
    val maxY get() = wires.maxOfOrNull { max(it.y1, it.y2) } ?: 0.0
    val minZ get() = wires.minOfOrNull { min(it.z1, it.z2) } ?: 0.0
    val maxZ get() = wires.maxOfOrNull { max(it.z1, it.z2) } ?: 0.0

    val spanX get() = maxX - minX
    val spanY get() = maxY - minY
    val spanZ get() = maxZ - minZ
    val boomLengthM get() = spanX
    val transverseSizeM get() = max(spanY, spanZ)

    /** Main geometric axis. Yagi/LPDA are normally X; axial-mode helices are normally Z. */
    val mainAxis: Char get() = when {
        spanZ > spanX * 1.35 && spanZ > spanY * 1.35 -> 'Z'
        spanY > spanX * 1.35 && spanY > spanZ * 1.35 -> 'Y'
        else -> 'X'
    }

    val isPlanar: Boolean get() {
        val largest = maxOf(spanX, spanY, spanZ)
        val smallest = minOf(spanX, spanY, spanZ)
        return largest > 1e-6 && smallest <= largest * 0.02
    }

    /** Normal to a clearly planar antenna. Useful for loop/delta/halo broadside preview. */
    val planeNormalAxis: Char? get() {
        if (!isPlanar) return null
        return when {
            spanX <= spanY && spanX <= spanZ -> 'X'
            spanY <= spanX && spanY <= spanZ -> 'Y'
            else -> 'Z'
        }
    }


    /** Dominant axis of the driven wire, if the source is a nearly straight axial segment. */
    val sourceAxis: Char? get() {
        val idx = sourceWireIndex ?: return null
        val w = wires.getOrNull(idx) ?: return null
        val len = w.lengthM
        if (len <= 1e-9) return null
        val fx = abs(w.dx) / len
        val fy = abs(w.dy) / len
        val fz = abs(w.dz) / len
        val best = maxOf(fx, fy, fz)
        if (best < 0.92) return null
        return when (best) {
            fx -> 'X'
            fy -> 'Y'
            else -> 'Z'
        }
    }

    /**
     * Axis of rotationally symmetric omni structures such as a discone.
     * Strong title evidence is accepted, otherwise require a driven axial wire and
     * comparable transverse spans so ordinary Yagis/loops are not captured.
     */
    val omniSymmetryAxis: Char? get() {
        val titleHint = title.contains("discon", ignoreCase = true) ||
            title.contains("diskon", ignoreCase = true) ||
            title.contains("дискон", ignoreCase = true)
        val a = sourceAxis ?: return null
        fun span(axis: Char): Double = when (axis) {
            'X' -> spanX
            'Y' -> spanY
            else -> spanZ
        }
        val transverse = listOf('X','Y','Z').filter { it != a }.map(::span)
        val tMax = transverse.maxOrNull() ?: 0.0
        val tMin = transverse.minOrNull() ?: 0.0
        val radialEnough = wires.size >= 8 && tMax > 1e-6 && tMin / tMax >= 0.70
        val sourceShort = sourceWireIndex?.let { wires.getOrNull(it)?.lengthM }?.let {
            it <= maxOf(spanX, spanY, spanZ) * 0.35
        } ?: false
        // 1.17.8: generic radial heuristics produced false positives for Hentenna, Twin-Delta
        // and Split-J models.  Discone-specific field handling is now deliberately conservative:
        // use explicit title evidence; other omni families are classified separately.
        return if (titleHint) a else null
    }

    private fun axialDelta(w: MaaWire): Double = when (mainAxis) { 'Y' -> w.dy; 'Z' -> w.dz; else -> w.dx }
    private fun stationCoord(w: MaaWire): Double = when (mainAxis) { 'Y' -> w.midY; 'Z' -> w.midZ; else -> w.midX }
    private fun axisSpan(): Double = when (mainAxis) { 'Y' -> spanY; 'Z' -> spanZ; else -> spanX }

    /**
     * Geometry stations along the actual main axis. For Yagi/LPDA this remains X. For a helix
     * the larger Z extent is detected and the turns are sampled along Z, so the preview does not
     * disappear or point along the wrong axis.
     */
    val elementStationsM: List<Double> get() {
        val candidate = wires.filter { w ->
            val len = w.lengthM
            len > 1e-6 && (if (len > 1e-12) abs(axialDelta(w)) / len else 0.0) < 0.92
        }.ifEmpty { wires }
        val quantum = max(axisSpan(), 1.0) * 1e-4
        return candidate.map { kotlin.math.round(stationCoord(it) / quantum) * quantum }
            .distinct().sorted()
    }

    val transverseWireCount get() = wires.count { w ->
        val len=w.lengthM; len>1e-12 && abs(axialDelta(w))/len < 0.72
    }
    val longitudinalWireCount get() = wires.count { w ->
        val len=w.lengthM; len>1e-12 && abs(axialDelta(w))/len >= 0.72
    }

    /**
     * Purely structural topology test: one connected, non-planar, closed wire path.
     *
     * This intentionally uses ONLY coordinates/connectivity.  Titles such as "spiral",
     * "torus" or a filename are not consulted.  It is used where the physical solver
     * needs to preserve an explicitly modelled closed 3-D path (for example a toroidal
     * winding made from hundreds of short MAA wires).
     */
    val isSingleClosed3DWirePath: Boolean get() {
        val nonZero = wires.filter { it.lengthM > 1e-10 && it.radiusM > 0.0 }
        if (nonZero.size < 4 || isPlanar) return false

        val scale = maxOf(spanX, spanY, spanZ, 1.0)
        val eps = maxOf(1e-9, scale * 1e-7)
        data class NodeKey(val x: Long, val y: Long, val z: Long)
        fun key(x: Double, y: Double, z: Double): NodeKey = NodeKey(
            kotlin.math.round(x / eps).toLong(),
            kotlin.math.round(y / eps).toLong(),
            kotlin.math.round(z / eps).toLong()
        )

        val adjacency = linkedMapOf<NodeKey, MutableSet<NodeKey>>()
        for (w in nonZero) {
            val a = key(w.x1, w.y1, w.z1)
            val b = key(w.x2, w.y2, w.z2)
            if (a == b) return false
            adjacency.getOrPut(a) { linkedSetOf() }.add(b)
            adjacency.getOrPut(b) { linkedSetOf() }.add(a)
        }
        // A single closed wire path is a connected graph in which every node has degree 2.
        if (adjacency.isEmpty() || adjacency.values.any { it.size != 2 }) return false
        val start = adjacency.keys.first()
        val seen = linkedSetOf<NodeKey>()
        val queue = java.util.ArrayDeque<NodeKey>()
        queue.add(start)
        while (!queue.isEmpty()) {
            val n = queue.removeFirst()
            if (!seen.add(n)) continue
            adjacency[n].orEmpty().forEach { if (it !in seen) queue.add(it) }
        }
        return seen.size == adjacency.size
    }

    /** Physical solver family derived from geometry/topology only. */
    val structuralKind: String get() = MaaGeometryClassifier.structuralKind(this)
    val isStructuralBeverageLike: Boolean get() = MaaGeometryClassifier.isBeverageLike(this)

    /** Human-readable family label. It may still use title/filename as a UI hint. */
    val antennaKind: String get() = MaaGeometryClassifier.classify(this)
    /** Solver routing MUST NOT depend on title/filename. */
    val analysisProfile: String get() = MaaGeometryClassifier.analysisProfile(this)
}

private object MaaGeometryClassifier {
    private fun semanticText(m: MaaModel): String = (m.title + " " + (m.fileNameHint ?: "")).lowercase()

    fun analysisProfile(m: MaaModel): String {
        // 1.19.194: primary routing is learned from geometry only.  The forest was trained on
        // all 722 known profiles plus 1713 user-supplied geometries.  No title/filename/comment
        // is an inference feature.  This replaces the old brittle hand-written routing rules.
        // Exact geometry from either known corpus gets deterministic routing.  This is an
        // exact 44-feature geometry/topology match, not a filename lookup.
        MaaGeometryPolicyIndexV2.match(m)?.takeIf { it.exactGeometry }?.let { exact ->
            return exact.profile
        }
        MaaGeometryForestV2.predict(m)?.let { learned ->
            return learned.profile
        }

        // Safe fallback before the assets are installed (preview/tests/headless use).
        val k = structuralKind(m)
        return when {
            k.contains("Log-periodic", true) -> "LPDA_END_FIRE"
            k.contains("Yagi", true) || k.contains("parasitic", true) -> "PARASITIC_ARRAY"
            k.contains("Traveling-wave", true) -> "TRAVELING_WAVE"
            k.contains("Helical", true) -> "HELIX_3D"
            k.contains("Vertical", true) || k.contains("Ground-plane", true) || k.contains("omni", true) -> "OMNI_VERTICAL"
            k.contains("Closed", true) || k.contains("loop", true) -> "CLOSED_LOOP"
            k.contains("Dipole", true) -> "DIPOLE_FAMILY"
            else -> "GENERAL_WIRE"
        }
    }

    /**
     * 1.19.146: physical family from coordinates/connectivity/source/load/ground ONLY.
     * No title or filename is consulted here.  This is intentionally conservative: if
     * topology is ambiguous, GENERAL_WIRE is safer than forcing a special solver path.
     */
    fun structuralKind(m: MaaModel): String {
        if (m.wires.isEmpty()) return "Wire antenna"
        if (m.isSingleClosed3DWirePath) return "Closed 3D wire loop"
        if (isHelixGeometry(m)) return "Helical / axial-mode wire antenna"
        if (isLpdaGeometry(m)) return "Log-periodic / LPDA wire antenna"
        // A grounded driven Z radiator with radials must not be mistaken for a Yagi merely
        // because radial midpoints occupy several X/Y coordinates.
        if (isVerticalGeometry(m)) return "Vertical / ground-plane omni"

        // 1.19.160: detect a real parasitic array before the generic source/load-separation
        // travelling-wave heuristic.  Loaded Yagis may have one C load on every element; the
        // old ordering interpreted the distance from the driven element to the far director
        // load as a travelling-wave termination and routed the whole antenna incorrectly.
        val yagi = structuralYagiKind(m)
        if (yagi != null) return yagi
        if (isTravelingWave(m)) return "Traveling-wave wire antenna"
        if (isClosedPath(m)) return if (m.isPlanar) "Closed planar loop" else "Closed wire loop"
        if (isLinearDipoleGeometry(m)) return "Dipole / wire radiator"
        return "General MMANA wire antenna"
    }

    private fun endpointPoint(m: MaaModel, wireIndex: Int, pos: Char): DoubleArray? {
        val w = m.wires.getOrNull(wireIndex) ?: return null
        return when (pos.lowercaseChar()) {
            'b' -> doubleArrayOf(w.x1, w.y1, w.z1)
            'e' -> doubleArrayOf(w.x2, w.y2, w.z2)
            else -> doubleArrayOf(w.midX, w.midY, w.midZ)
        }
    }

    private fun distance(a: DoubleArray, b: DoubleArray): Double {
        val dx=a[0]-b[0]; val dy=a[1]-b[1]; val dz=a[2]-b[2]
        return sqrt(dx*dx+dy*dy+dz*dz)
    }

    private fun isTravelingWave(m: MaaModel): Boolean {
        if (m.sources.isEmpty() || m.loads.isEmpty()) return false
        val span = maxOf(m.spanX, m.spanY, m.spanZ)
        if (span <= 1e-6) return false
        val sourcePts = m.sources.mapNotNull { endpointPoint(m, it.wireIndex, it.position) }
        val loadPts = m.loads.mapNotNull { endpointPoint(m, it.wireIndex, it.position) }
        if (sourcePts.isEmpty() || loadPts.isEmpty()) return false
        val separation = sourcePts.maxOf { sp -> loadPts.maxOf { lp -> distance(sp, lp) } }
        if (separation < span * 0.45) return false
        // A real terminated travelling-wave structure must be electrically extended.
        if (m.totalWireLengthM < m.wavelengthM * 0.35 && span < m.wavelengthM * 0.25) return false
        return true
    }

    fun isBeverageLike(m: MaaModel): Boolean {
        if (!isTravelingWave(m) || m.groundType == 0) return false
        val main = m.wires.maxByOrNull { it.lengthM } ?: return false
        val horizontal = kotlin.math.hypot(main.dx, main.dy)
        if (horizontal < main.lengthM * 0.90) return false
        val second = listOf(m.spanX, m.spanY).sortedDescending().getOrElse(1) { 0.0 }
        val horizSpan = max(m.spanX, m.spanY)
        // One dominant horizontal run with relatively small transverse/vertical dimensions.
        return horizSpan > 1e-6 && horizSpan >= max(second, m.spanZ) * 2.5 &&
            main.lengthM >= m.totalWireLengthM * 0.45
    }

    private fun isHelixGeometry(m: MaaModel): Boolean {
        val conducting = m.wires.filter { it.radiusM > 0.0 }
        if (m.isPlanar || conducting.size < 8) return false
        val spans = listOf('X' to m.spanX, 'Y' to m.spanY, 'Z' to m.spanZ).sortedByDescending { it.second }
        val axis = spans[0].first
        val axial = spans[0].second
        val transverse = max(spans[1].second, spans[2].second)
        if (transverse <= 1e-9 || axial < transverse * 2.2) return false

        // A real helix is not merely an elongated 3-D antenna.  Most of its short wire pieces
        // live away from the axis and wind around it.  Radial/star structures such as Big star
        // contain many on-axis / hub-connected pieces and were previously misclassified HELIX_3D.
        val short = conducting.count { it.lengthM <= axial * 0.25 }
        if (short < (conducting.size * 0.70).toInt()) return false

        fun transverseMidRadius(w: MaaWire): Double = when (axis) {
            'X' -> kotlin.math.hypot(w.midY, w.midZ)
            'Y' -> kotlin.math.hypot(w.midX, w.midZ)
            else -> kotlin.math.hypot(w.midX, w.midY)
        }
        val offAxis = conducting.count { transverseMidRadius(it) >= transverse * 0.20 }
        if (offAxis < kotlin.math.ceil(conducting.size * 0.65).toInt()) return false

        // Reject central-hub stars/radial trees.  A helix path may have small feed branches, but
        // it must not have a node where many independent arms meet.
        val scale = maxOf(m.spanX, m.spanY, m.spanZ, 1.0)
        val eps = maxOf(1e-9, scale * 1e-7)
        data class K(val x: Long, val y: Long, val z: Long)
        fun key(x: Double, y: Double, z: Double) = K(
            kotlin.math.round(x / eps).toLong(),
            kotlin.math.round(y / eps).toLong(),
            kotlin.math.round(z / eps).toLong()
        )
        val degree = mutableMapOf<K, Int>()
        for (w in conducting) {
            val a = key(w.x1, w.y1, w.z1)
            val b = key(w.x2, w.y2, w.z2)
            degree[a] = (degree[a] ?: 0) + 1
            degree[b] = (degree[b] ?: 0) + 1
        }
        if ((degree.values.maxOrNull() ?: 0) >= 5) return false
        return true
    }

    private fun isLpdaGeometry(m: MaaModel): Boolean {
        if (m.wires.size < 8) return false
        val scale=maxOf(m.spanX,m.spanY,m.spanZ,1.0)
        val q=scale*1e-4
        fun comp(w:MaaWire,a:Char)=when(a){'X'->abs(w.dx);'Y'->abs(w.dy);else->abs(w.dz)}
        fun mid(w:MaaWire,a:Char)=when(a){'X'->w.midX;'Y'->w.midY;else->w.midZ}
        for(a in listOf('X','Y','Z')) {
            val span=when(a){'X'->m.spanX;'Y'->m.spanY;else->m.spanZ}
            if(span<scale*0.15) continue
            val elems=m.wires.filter { w ->
                w.lengthM>scale*0.03 && comp(w,a)/w.lengthM.coerceAtLeast(1e-12)<=0.20
            }
            val grouped=elems.groupBy { kotlin.math.round(mid(it,a)/q).toLong() }.toSortedMap()
            if(grouped.size<5 || elems.size<8) continue
            val lengths=grouped.values.map { ws -> ws.sumOf { it.lengthM } }
            val unique=lengths.map { kotlin.math.round(it*1000.0)/1000.0 }.distinct().size
            if(unique<4) continue
            var inc=0; var dec=0; var pairs=0
            for(i in 1 until lengths.size){
                val prev=lengths[i-1]; val cur=lengths[i]
                val tol=max(prev,cur)*0.04
                val d=cur-prev
                if(abs(d)<=tol) continue
                pairs++; if(d>0) inc++ else dec++
            }
            if(pairs<3 || max(inc,dec).toDouble()/pairs.toDouble()<0.70) continue
            val boomish=m.wires.count { w ->
                w.lengthM>1e-9 && comp(w,a)/w.lengthM>=0.45 && w.lengthM<=span*0.35
            }
            if(boomish>=4) return true
        }
        return false
    }

    private fun structuralYagiKind(m: MaaModel): String? {
        val conducting = m.wires.filter { it.radiusM > 0.0 }
        if (conducting.size < 3 || conducting.size >= 150) return null
        val scale = maxOf(m.spanX, m.spanY, m.spanZ, 1.0)
        val q = scale * 1e-4
        fun axisSpan(a: Char) = when(a){ 'X'->m.spanX; 'Y'->m.spanY; else->m.spanZ }
        fun component(w:MaaWire,a:Char)=when(a){'X'->abs(w.dx);'Y'->abs(w.dy);else->abs(w.dz)}
        fun mid(w:MaaWire,a:Char)=when(a){'X'->w.midX;'Y'->w.midY;else->w.midZ}
        data class Candidate(val axis:Char,val wires:List<MaaWire>,val stations:Int,val span:Double)
        val candidates=listOf('X','Y','Z').mapNotNull { a ->
            val aspan=axisSpan(a)
            if(aspan<=scale*0.05) return@mapNotNull null
            // Real Yagi/LPDA elements are nearly perpendicular to the boom.
            val tw=conducting.filter { w -> w.lengthM>scale*0.002 && component(w,a)/w.lengthM.coerceAtLeast(1e-12) <= 0.28 }
            val st=tw.map { kotlin.math.round(mid(it,a)/q).toLong() }.distinct().size
            if(tw.size>=3 && st>=3) Candidate(a,tw,st,aspan) else null
        }
        val c=candidates.maxByOrNull { it.stations*10.0 + it.span/scale } ?: return null

        // Reject radial/star structures: in a Yagi the element centres are spread along the boom
        // but the individual transverse elements are not all joined to one common hub.
        val eps=scale*1e-6
        fun near(a:Double,b:Double)=abs(a-b)<=eps
        data class K(val x:Long,val y:Long,val z:Long)
        fun key(x:Double,y:Double,z:Double)=K(kotlin.math.round(x/eps).toLong(),kotlin.math.round(y/eps).toLong(),kotlin.math.round(z/eps).toLong())
        val endpointUse=mutableMapOf<K,Int>()
        for(w in conducting){ endpointUse[key(w.x1,w.y1,w.z1)]=(endpointUse[key(w.x1,w.y1,w.z1)]?:0)+1; endpointUse[key(w.x2,w.y2,w.z2)]=(endpointUse[key(w.x2,w.y2,w.z2)]?:0)+1 }
        // A parasitic Yagi may have ordinary 3-way matching junctions, but a high-degree
        // central hub is characteristic of star/radial structures rather than a boom array.
        if ((endpointUse.values.maxOrNull() ?: 0) >= 5) return null

        val perStation=c.wires.size.toDouble()/c.stations.toDouble()
        return when {
            perStation >= 5.0 -> "Loop / quad / multi-wire Yagi"
            perStation >= 2.2 -> "Folded / quad-element Yagi"
            else -> "Linear Yagi / parasitic wire array"
        }
    }

    private fun isVerticalGeometry(m: MaaModel): Boolean {
        val src = m.sourceWireIndex?.let { m.wires.getOrNull(it) }
        if (src != null && src.lengthM > 1e-9) {
            val vz = abs(src.dz) / src.lengthM
            val horiz = max(m.spanX, m.spanY)
            if (vz >= 0.80 && m.spanZ >= horiz * 0.45) return true
        }
        if (m.groundType != 0 && m.spanZ > 0.0 && m.spanZ >= max(m.spanX,m.spanY)*0.75) {
            // Real/perfect ground is also used for elevated horizontal/loop antennas.
            // Do not route every tall model to the vertical solver merely because G!=0.
            // Require an actual CONDUCTING wire endpoint to touch the shifted ground plane.
            val touchesGround = m.wires.any { w ->
                w.radiusM > 0.0 && (
                    kotlin.math.abs(w.z1 + m.addHeightM) <= 1e-7 ||
                    kotlin.math.abs(w.z2 + m.addHeightM) <= 1e-7
                )
            }
            if (touchesGround) return true
        }
        return false
    }

    private fun isClosedPath(m: MaaModel): Boolean {
        val nonZero=m.wires.filter { it.lengthM>1e-10 && it.radiusM>0.0 }
        if (nonZero.size<3) return false
        val scale=maxOf(m.spanX,m.spanY,m.spanZ,1.0); val eps=maxOf(1e-9,scale*1e-7)
        data class K(val x:Long,val y:Long,val z:Long)
        fun k(x:Double,y:Double,z:Double)=K(kotlin.math.round(x/eps).toLong(),kotlin.math.round(y/eps).toLong(),kotlin.math.round(z/eps).toLong())
        val deg=mutableMapOf<K,Int>()
        for(w in nonZero){ val a=k(w.x1,w.y1,w.z1); val b=k(w.x2,w.y2,w.z2); if(a==b)return false; deg[a]=(deg[a]?:0)+1; deg[b]=(deg[b]?:0)+1 }
        return deg.isNotEmpty() && deg.values.all { it==2 }
    }

    private fun isLinearDipoleGeometry(m:MaaModel):Boolean {
        if(m.sources.isEmpty() || m.loads.isNotEmpty() || m.wires.size>4) return false
        val span=maxOf(m.spanX,m.spanY,m.spanZ)
        if(span<=1e-9) return false
        return m.totalWireLengthM <= span*1.20
    }

    fun classify(m: MaaModel): String {
        if (m.wires.isEmpty()) return "Wire antenna"
        // 1.19.145: physical family from geometry first.  A single connected closed
        // non-planar path is a closed 3-D loop regardless of filename/title text.
        if (m.isSingleClosed3DWirePath) return "Closed 3D wire loop"
        val title = semanticText(m)
        // MMANA filenames often encode element count compactly: 4el6m, 15EL23CM, etc.
        // Keep this hint ahead of matching-network words so a T-match Yagi is not reduced to a
        // generic matched wire antenna (which would rotate its principal cuts to the longest span).
        val elementArrayHint = Regex("""\b\d{1,2}\s*el(?:e)?(?:\d+[a-z]*)?\b""").containsMatchIn(title)
        val yagiSemanticHint = "yagi" in title || elementArrayHint

        // Kotlin when-conditions must be Boolean expressions.  The previous 1.19.105
        // implementation put a nullable Regex MatchResult?.let block directly in `when`,
        // which caused compile errors.  Detect explicit forms such as 2x6el / 2×6el
        // before entering the Boolean `when` table.
        val explicitStackMatch = Regex(
            """\b(\d+)\s*[x×х]\s*(\d+)\s*el(?:e)?""",
            RegexOption.IGNORE_CASE
        ).find(title)
        if (explicitStackMatch != null) {
            val stackCount = explicitStackMatch.groupValues[1].toIntOrNull() ?: 0
            val elementsPerYagi = explicitStackMatch.groupValues[2].toIntOrNull() ?: 0
            if (stackCount >= 2 && elementsPerYagi >= 2) {
                return "$stackCount × $elementsPerYagi-element Yagi stack"
            }
        }

        // 1.17.9: extended semantic taxonomy trained/validated on the complete 722-file ANT corpus.
        // Filename is used as a hint in addition to the MAA title. Geometry still remains the fallback.
        // More specific families MUST precede generic words such as dipole/vertical/loop.
        when {
            "t2fd" in title -> return "T2FD / terminated folded traveling-wave antenna"
            "beverage" in title || "tbev" in title || "bev" in title && "beverage" in title -> return "Beverage / traveling-wave receiving antenna"
            "pennant" in title -> return "Pennant receiving loop"
            Regex("(^|[^a-z])flag([^a-z]|$)").containsMatchIn(title) -> return "Flag receiving loop"
            "rhombic" in title || "rhomb" in title -> return "Rhombic / traveling-wave wire antenna"
            "pyram" in title -> return "Pyramid / aperiodic wire antenna"
            "aperiod" in title -> return "Aperiodic / terminated wire antenna"
            "balun" in title -> return "Balun / feeder-current model"
            "feeder" in title || "trans" in title && ("ohm" in title || "stub" in title || "lambda" in title) -> return "Feeder / impedance-transformer model"
            "hb9cv" in title -> return "HB9CV / phased two-element array"
            "phas" in title || "phased" in title -> return "Phased wire array"
            // Explicit stacked-Yagi names are handled by the pre-check above.
            "stack" in title || "syack" in title -> return "Stacked Yagi / antenna array"
            "ddrr" in title -> return "DDRR / electrically-short loop radiator"
            "magloop" in title || "magn loop" in title || "magnetic loop" in title || "multiturnloop" in title -> return "Magnetic loop antenna"
            "fractal" in title || "piramida" in title -> return "Fractal / folded electrically-short antenna"
            "trap" in title -> return "Trap-loaded multiband antenna"
            "sleeve" in title || "sleve" in title -> return "Open-sleeve / sleeve multiband antenna"
            "g5rv" in title -> return "G5RV multiband dipole"
            "zs6bkw" in title -> return "ZS6BKW multiband dipole"
            "windom" in title || "ocf" in title -> return "Windom / off-center-fed dipole"
            "inverted v" in title || "inv v" in title || "invv" in title -> return "Inverted-V dipole"
            "folded dipole" in title || "fold dipole" in title || "fold. dipole" in title -> return "Folded dipole"
            "hairpin" in title -> return "Hairpin-matched wire antenna"
            ("t-match" in title || "t match" in title) && yagiSemanticHint -> return "T-matched Yagi / parasitic wire array"
            "t-match" in title || "t match" in title -> return "T-matched wire antenna"
            "inverted l" in title || "inv l" in title -> return "Inverted-L antenna"
            "end fed" in title || "end-fed" in title -> return "End-fed wire antenna"
            "top load" in title || "top-load" in title -> return "Top-loaded short antenna"
            "sloper" in title || "slope dip" in title -> return "Sloper / inclined dipole"
            "long wire" in title || "longwire" in title -> return "Long-wire antenna"
            "gamma" in title && ("quad" in title || "yagi" in title) -> return "Gamma-matched parasitic/loop array"
            "gamma" in title -> return "Gamma-matched wire antenna"
            "omega" in title -> return "Omega-matched wire antenna"
            "j-antenna" in title || "j-ant" in title || "j pole" in title || "j-pole" in title || "mod j" in title -> return if ("yagi" in title) "J-fed Yagi / matched array" else "J-pole / J antenna"
            "henten" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Hentenna Yagi / loop array" else "Hentenna loop antenna"
            "twin delta" in title || "twind" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Twin-delta-loop Yagi / loop array" else "Twin-delta loop antenna"
            "twin loop" in title -> return if (Regex("""\b[235]el|yagi""").containsMatchIn(title)) "Twin-loop Yagi / loop array" else "Twin-loop antenna"
            "delta loop" in title || "delta6" in title || Regex("(^|[^a-z])delta([^a-z]|$)").containsMatchIn(title) -> return if (Regex("""\b[2-9]el|yagi""").containsMatchIn(title)) "Delta-loop Yagi / loop array" else "Delta loop antenna"
            "swiss-quad" in title || "swiss quad" in title -> return "Swiss-Quad / closed-loop array"
            "quad" in title || Regex("""\bcq\b""").containsMatchIn(title) -> if (Regex("""\b[2-9]el|\b1[0-9]el|yagi""").containsMatchIn(title)) return "Quad-loop Yagi / closed-loop array"
            "discon" in title || "diskon" in title || "дискон" in title -> return "Discone / rotationally symmetric omni"
            "helix" in title || "спирал" in title -> return "Helical / axial-mode wire antenna"
            "collinear" in title -> return "Collinear vertical array"
            "ground plane" in title || Regex("(^|[^a-z])gp([^a-z]|$)").containsMatchIn(title) -> return "Ground-plane / monopole antenna"
            "vertical" in title || "vert" in title && !"invert".let { it in title } -> return "Vertical / monopole wire antenna"
            "crosspol" in title || "cross-pol" in title -> return "Cross-polarized Yagi / crossed wire array"
            "corner reflector" in title || "coner reflector" in title || title.startsWith("cr2") -> return "Corner-reflector wire antenna"
            "mirror" in title -> return "Wire-grid reflector antenna"
            "plane-reflector" in title || "plane reflector" in title -> return "Wire-grid reflector antenna"
            "horn yagi" in title -> return "Horn-Yagi / hybrid parasitic array"
            "log" in title && ("yagi" in title || "period" in title || "lpda" in title || "tv" in title) -> return "Log-periodic / LPDA wire antenna"
            "lpda" in title -> return "Log-periodic / LPDA wire antenna"
            yagiSemanticHint &&
                listOf("loop","quad","delta","twin","hent","rhomb","gp").none { it in title } -> return "Linear Yagi / parasitic wire array"
            "dipole" in title || "dipol" in title || ("dp" in title && m.wires.size <= 8) -> return "Dipole / wire radiator"
            "isotrop" in title -> return "Reference test radiator"
            "skydoor" in title -> return "Skydoor loop antenna"
            "big star" in title -> return "Star / radial wire antenna"
        }

        // 1.17.8 topology knowledge distilled from the earlier ANT.ZIP subset.
        when {
            "discon" in title || "diskon" in title || "дискон" in title -> return "Discone / rotationally symmetric omni"
            "log" in title && ("yagi" in title || "period" in title || "tv" in title) -> return "Log-periodic / LPDA wire antenna"
            "helix" in title || "спирал" in title -> return "Helical / axial-mode wire antenna"
            "crosspol" in title || "cross-pol" in title -> return "Cross-polarized Yagi / crossed wire array"
            "corner reflector" in title || "coner reflector" in title || title.startsWith("cr2") -> return "Corner-reflector wire antenna"
            "mirror" in title -> return "Wire-grid reflector antenna"
            "plane-reflector" in title || "plane reflector" in title || "rhomb" in title -> return "Rhomb / wire-reflector antenna"
            "henten" in title -> return if (title.trim().startsWith("3ele")) "Hentenna Yagi / loop array" else "Hentenna loop antenna"
            "twin delta" in title || "twind" in title -> return if ("5ele" in title) "Twin-delta-loop Yagi / loop array" else "Twin-delta loop antenna"
            "twin loop" in title -> return if ("5ele" in title) "Twin-loop Yagi / loop array" else "Twin-loop antenna"
            "delta loop" in title || "delta6" in title -> return "Delta-loop Yagi / loop array"
            "collinear" in title -> return "Collinear vertical array"
            "omni dipol" in title || "gamma-match" in title -> return "Gamma-matched omni dipole"
            "skydoor" in title -> return "Skydoor loop antenna"
            title.startsWith("gp") || " gp " in title || title.endsWith(" gp") || " ground plane" in title -> return "Ground-plane / monopole antenna"
            "j-antenna" in title || "j-ant" in title || "j-yagi" in title -> return if ("yagi" in title) "J-fed Yagi / matched array" else "J-pole / J antenna"
            "big star" in title -> return "Star / radial wire antenna"
            "isotrop" in title -> return "Reference test radiator"
            "horn yagi" in title -> return "Horn-Yagi / hybrid parasitic array"
            "swiss-quad" in title -> return "Swiss-Quad / closed-loop array"
            Regex("(^|\\s)\\d*\\s*el.*quad|\\bcq\\b").containsMatchIn(title) -> return "Quad-loop Yagi / closed-loop array"
        }

        val eps = maxOf(m.spanX, m.spanY, m.spanZ, 1.0) * 0.002

        // Rotationally symmetric vertical omni (for example discone). Detect before Yagi rules:
        // a discone can have X/Y/Z spans of similar size and would otherwise look like a Yagi.
        if (m.omniSymmetryAxis != null) {
            return "Discone / rotationally symmetric omni"
        }

        // Axial helix: one dimension is clearly the axis and many short connected segments wind
        // around it. Detect before Yagi-specific X-axis rules.
        if (!m.isPlanar && m.mainAxis == 'Z' && m.spanZ > max(m.spanX, m.spanY) * 2.2 && m.wires.size >= 8) {
            return "Helical / axial-mode wire antenna"
        }
        if (!m.isPlanar && m.mainAxis == 'Y' && m.spanY > max(m.spanX, m.spanZ) * 2.2 && m.wires.size >= 8) {
            return "Helical / axial-mode wire antenna"
        }

        val tx = m.wires.filter { it.transverseFraction >= 0.72 && it.lengthM > eps }
        val longitudinal = m.wires.filter { it.axialFractionX >= 0.72 && it.lengthM > eps }
        val stations = m.elementStationsM

        val perStation = if (stations.isNotEmpty()) m.wires.size.toDouble() / stations.size else 0.0

        // Closed polygon elements: 4 wires = square/quad, 6+ = polygon/ring approximation.
        // Treat both as the same connected closed-loop family so the dedicated loop-array
        // impedance and pattern paths are available.  This fixes classic Cubical Quad MAA files
        // such as 12CQ430 where every element is exactly four wires.
        if (stations.size >= 3 && longitudinal.isEmpty() && perStation >= 3.5 && m.mainAxis == 'X') {
            return if (perStation >= 6.0) {
                "Ring-loop Yagi / closed-loop array"
            } else {
                "Quad-loop Yagi / closed-loop array"
            }
        }

        // Very dense MMANA wire meshes (e.g. mirror.maa) are reflector/grid structures,
        // not crossed radiators.  Detect before the Cross-Yagi station heuristic.
        if (m.wires.size >= 150) return "Wire-grid reflector antenna"

        // Cross-polarized arrays have sizeable Y- and Z-directed radiators at several common X stations.
        val yRadiators = tx.filter { abs(it.dy) >= abs(it.dz) * 2.0 }
        val zRadiators = tx.filter { abs(it.dz) >= abs(it.dy) * 2.0 }
        val yXs = stationSet(yRadiators, m)
        val zXs = stationSet(zRadiators, m)
        val sharedCrossStations = yXs.intersect(zXs).size
        if (sharedCrossStations >= 2 && yRadiators.size >= 2 && zRadiators.size >= 2) {
            return "Cross-polarized Yagi / crossed wire array"
        }

        // LPDA: many transverse elements of progressively changing length plus one/two long boom chains.
        if (tx.size >= 6 && longitudinal.size >= 4 && stations.size >= 5) {
            val stationLengths = tx.groupBy { stationKey(it.midX, m) }
                .map { (k, ws) -> k to ws.sumOf { it.lengthM } }
                .sortedBy { it.first }
                .map { it.second }
            if (stationLengths.size >= 5) {
                var trendPairs = 0
                var monotonicPairs = 0
                for (i in 1 until stationLengths.size) {
                    val a = stationLengths[i - 1]
                    val b = stationLengths[i]
                    if (max(a, b) > 1e-9) {
                        trendPairs++
                        if (b <= a * 1.10 || a <= b * 1.10) monotonicPairs++
                    }
                }
                val uniqueLengths = stationLengths.map { kotlin.math.round(it * 1000.0) / 1000.0 }.distinct().size
                if (uniqueLengths >= 4 && trendPairs >= 4 && longitudinal.size >= stations.size / 2) {
                    return "Log-periodic / LPDA wire antenna"
                }
            }
        }

        // Conventional Yagi files are often perfectly planar too (for example all elements in XZ).
        // Keep those on the old station-array path instead of treating them as generic planar loops.
        if (m.mainAxis == 'X' && stations.size >= 3 && tx.size >= 3 && m.spanX > 1e-6) {
            return "Linear Yagi / parasitic wire array"
        }

        // Truly planar wire antennas (delta loops, halo, omni loops, planar dipoles).
        // IMPORTANT: check this only AFTER LPDA detection. A real two-boom LPDA can be almost
        // planar (very small Z spacing between booms), and classifying it as a generic planar
        // antenna sends it into the full-wire fallback and distorts the end-fire preview.
        if (m.isPlanar && m.wires.size >= 2) {
            return "Planar loop / dipole / omni wire antenna"
        }

        // Multi-wire closed/folded elements: several wires per X station.
        if (perStation >= 5.0) return "Loop / quad / multi-wire Yagi"
        if (perStation >= 2.2) return "Folded / quad-element Yagi"

        if (stations.size >= 3 && tx.size >= 3) return "Linear Yagi / parasitic wire array"

        return "General MMANA wire antenna"
    }

    private fun stationKey(x: Double, m: MaaModel): Long {
        val q = max(m.spanX, 1.0) * 1e-4
        return kotlin.math.round(x / q).toLong()
    }

    private fun stationSet(ws: List<MaaWire>, m: MaaModel): Set<Long> = ws.map { stationKey(it.midX, m) }.toSet()
}

private data class LegacyStackHeader(
    val horizontalCount: Int,
    val verticalCount: Int,
    val horizontalSpacingM: Double,
    val verticalSpacingM: Double,
    val positionMode: Int
)

object MaaParser {
    fun parse(reader: BufferedReader, fileNameHint: String? = null): MaaModel {
        val lines = reader.readLines()
        require(lines.isNotEmpty()) { "Empty MAA file." }

        val title = lines.firstOrNull { it.trim().isNotEmpty() && !it.trim().startsWith("*") }
            ?.trim().orEmpty().ifBlank { "MMANA antenna" }

        val wiresHeader = findWiresHeader(lines)
        require(wiresHeader >= 0) { "MAA wire section not found (Wires)." }

        val frequencyMHz = lines.subList(0, wiresHeader)
            .mapNotNull { parseNumber(it.trim()) }
            .lastOrNull() ?: error("Failed to determine the MAA frequency.")

        val countLine = nextNonEmpty(lines, wiresHeader + 1)
        // MMANA variants may store extra combined-wire metadata on the same line:
        // "6, 1, 2, 8.0, 8.0, 0". The first field is the actual wire count.
        val wireCountText = lines.getOrNull(countLine)?.trim().orEmpty()
        val wireCountFields = wireCountText.split(',', ';', ' ', '\t').filter { it.isNotBlank() }
        val wireCount = wireCountFields.firstOrNull()?.toIntOrNull()
            ?: error("Invalid wire count after the Wires section: '$wireCountText'.")
        require(wireCount in 1..100000) { "Invalid wire count: $wireCount." }

        // Legacy MMANA compact stack header used by the ANT/Stacks corpus:
        //   baseWires, horizontalCount, verticalCount, horizontalSpacing, verticalSpacing, positionMode
        // Example 4X12.MAA: 17,4,1,0.689195,0.689195,0.
        // Older parser versions intentionally accepted only the first field, which made the model
        // look like ONE Yagi and NEC-2 therefore calculated ONE-Yagi radiation. Preserve the header
        // semantics here and expand the physical geometry/sources/loads before building the NEC deck.
        val stackHeader = if (wireCountFields.size >= 6) {
            val h = wireCountFields.getOrNull(1)?.toIntOrNull() ?: 1
            val v = wireCountFields.getOrNull(2)?.toIntOrNull() ?: 1
            val hs = parseNumber(wireCountFields.getOrNull(3).orEmpty()) ?: 0.0
            val vs = parseNumber(wireCountFields.getOrNull(4).orEmpty()) ?: 0.0
            val mode = wireCountFields.getOrNull(5)?.toIntOrNull() ?: 0
            if (h in 1..8 && v in 1..8 && h * v in 2..64 && hs >= 0.0 && vs >= 0.0)
                LegacyStackHeader(h, v, hs, vs, mode) else null
        } else null

        val wires = ArrayList<MaaWire>(wireCount)
        var i = countLine + 1
        var firstBadWireLine: String? = null
        while (i < lines.size && wires.size < wireCount) {
            val s = lines[i].trim().removePrefix("\uFEFF")
            if (s.isNotEmpty()) {
                if (looksLikeSection(s)) break
                val w = parseWireRecord(s)
                if (w != null) wires += w else if (firstBadWireLine == null) firstBadWireLine = s
            }
            i++
        }
        require(wires.size == wireCount) {
            val tail = firstBadWireLine?.let { " First unrecognized line: '$it'." } ?: ""
            "Expected $wireCount wires, read ${wires.size}.$tail"
        }

        var sourceWire: Int? = null
        var sourceDesc: String? = null
        var invalidSourceRecords = 0
        var invalidLoadRecords = 0
        val sources = ArrayList<MaaSource>()
        val sourceHeader = lines.indexOfFirst { isSection(it, "source", "источ", "feed", "generator") }
        if (sourceHeader >= 0) {
            var j = sourceHeader + 1
            while (j < lines.size && !looksLikeSection(lines[j])) {
                val raw = lines[j].trim()
                // MMANA pulse syntax: W#B(#), W#C(#), W#E(#).
                // Unsigned Bn/Cn means n pulses forward from B/C; unsigned En means n pulses
                // backward from E (e.g. W5E3).  Older builds stopped at the B/C/E letter,
                // accidentally reading the compact offset as source phase and could even set
                // the source amplitude to zero.
                val m = Regex("(?i)w\\s*(\\d+)\\s*([bceвсeе])\\s*([+-]?\\s*\\d+)?").find(raw)
                if (m != null) {
                    val wi = m.groupValues[1].toIntOrNull()?.minus(1)
                    val pos = when (m.groupValues[2].lowercase().firstOrNull()) { 'в' -> 'b'; 'с' -> 'c'; 'е' -> 'e'; 'b' -> 'b'; 'e' -> 'e'; else -> 'c' }
                    val offsetText = m.groupValues.getOrNull(3).orEmpty().replace(" ", "")
                    val rawOffset = offsetText.toIntOrNull() ?: 0
                    val segmentOffset = if (offsetText.isNotEmpty() &&
                        !offsetText.startsWith("+") && !offsetText.startsWith("-") && pos == 'e'
                    ) -rawOffset else rawOffset
                    val nums = raw.substring(m.range.last + 1)
                        .trimStart(' ', '\t', ',', ';')
                        .split(',', ';', ' ', '\t')
                        .mapNotNull { parseNumber(it) }
                    if (wi != null && wi in wires.indices) {
                        val phaseDeg = nums.getOrNull(0) ?: 0.0
                        val amplitude = nums.getOrNull(1) ?: 1.0
                        sources += MaaSource(wi, pos, segmentOffset, phaseDeg, amplitude, raw)
                    } else if (wi != null) {
                        invalidSourceRecords++
                    }
                }
                j++
            }
            sources.firstOrNull()?.let { first ->
                sourceWire = first.wireIndex
                sourceDesc = first.raw
            }
        }


        val loads = ArrayList<MaaLoad>()
        val loadHeader = lines.indexOfFirst { isSection(it, "load", "нагруз") }
        if (loadHeader >= 0) {
            var j = loadHeader + 1
            while (j < lines.size && !looksLikeSection(lines[j])) {
                val raw = lines[j].trim()
                val lm = Regex("(?i)w\\s*(\\d+)\\s*([bceвсeе])\\s*([+-]?\\s*\\d+)?\\s*[,;]\\s*(-?\\d+)").find(raw)
                if (lm != null) {
                    val wi = lm.groupValues[1].toIntOrNull()?.minus(1)
                    val pos = when (lm.groupValues[2].lowercase().firstOrNull()) { 'в' -> 'b'; 'с' -> 'c'; 'е' -> 'e'; 'b' -> 'b'; 'e' -> 'e'; else -> 'c' }
                    val offsetText = lm.groupValues[3].replace(" ", "")
                    val rawOffset = offsetText.toIntOrNull() ?: 0
                    // W#E3 = three pulses back from the end; B3/C3 = forward from base.
                    // An explicit + / - keeps its literal sign.
                    val segmentOffset = if (offsetText.isNotEmpty() &&
                        !offsetText.startsWith("+") && !offsetText.startsWith("-") && pos == 'e'
                    ) -rawOffset else rawOffset
                    val kind = lm.groupValues[4].toIntOrNull() ?: 0
                    val nums = raw.substring(lm.range.last + 1)
                        .split(',', ';', ' ', '\t')
                        .mapNotNull { parseNumber(it) }
                    if (wi != null && wi in wires.indices) {
                        // MMANA load encoding:
                        // kind=0 -> LC load: L[uH], C[pF], Q (L and C form a parallel trap; either may be zero).
                        // kind=1 -> fixed R+jX load: R[ohm], X[ohm].
                        val v1 = nums.getOrNull(0) ?: 0.0
                        val v2 = nums.getOrNull(1) ?: 0.0
                        val v3 = nums.getOrNull(2) ?: 0.0
                        loads += MaaLoad(wi, pos, segmentOffset, kind, v1, v2, v3, raw)
                    } else if (wi != null) {
                        invalidLoadRecords++
                    }
                }
                j++
            }
        }

        var segDesc: String? = null
        val segHeader = lines.indexOfFirst { isSection(it, "segmentation", "автосегм", "сегм", "auto seg") }
        if (segHeader >= 0) {
            val j = nextNonEmpty(lines, segHeader + 1)
            if (j in lines.indices && !looksLikeSection(lines[j])) segDesc = lines[j].trim()
        }

        // MMANA taper-wire sets.  A negative radius in a wire record is a reference key,
        // not a physical negative/ultra-thin radius.  Each set is stored as:
        // key, mode, total-length-1, radius-1, total-length-2, radius-2, ...
        // Lengths are symmetric about the original wire centre.  This is the convention used
        // by MMANA telescopic elements (e.g. 20 mm centre tube + 16 mm outer tubes).
        val taperSets = LinkedHashMap<Double, MaaTaperSet>()
        // MMANA Russian files use "Установки комб. пров." for the same
        // CombWire table as English "Taper wire set".  This section is valid for
        // ordinary antennas too, not only Make Stack models (DL2KQ40/80/20/15 etc.).
        var russianCombWireHeader = false
        val taperHeader = lines.indexOfFirst { line ->
            val t = line.lowercase()
            val english = t.contains("taper wire set")
            val russian = t.contains("установки комб. пров") ||
                t.contains("установки комб пров") ||
                (t.contains("комб") && t.contains("пров"))
            if (russian) russianCombWireHeader = true
            english || russian
        }
        if (taperHeader >= 0) {
            val countAt = nextNonEmpty(lines, taperHeader + 1)
            val taperCount = lines.getOrNull(countAt)?.trim()?.split(',', ';', ' ', '\t')
                ?.firstOrNull { it.isNotBlank() }?.toIntOrNull() ?: 0
            var tj = countAt + 1
            repeat(taperCount.coerceAtLeast(0)) {
                tj = nextNonEmpty(lines, tj)
                val raw = lines.getOrNull(tj).orEmpty().trim()
                val nums = raw.split(',', ';', ' ', '\t').mapNotNull { parseNumber(it) }
                if (nums.size >= 4) {
                    val key = abs(nums[0])
                    val stages = ArrayList<MaaTaperStage>()
                    var k = 2
                    while (k + 1 < nums.size) {
                        val len = nums[k]
                        val rad = abs(nums[k + 1])
                        if (len > 0.0 && rad > 0.0) stages += MaaTaperStage(len, rad)
                        k += 2
                    }
                    if (key > 0.0 && stages.isNotEmpty()) taperSets[key] = MaaTaperSet(key, nums.getOrNull(1)?.toInt() ?: 0, stages)
                }
                tj++
            }
        }

        // MMANA project line: G/H/M/R/AzEl/X
        // G = ground selector, H = Add height [m], M = material selector,
        // R = reference impedance used only for SWR.
        var referenceOhms: Double? = null
        var groundType = 0
        var addHeightM = 0.0
        var materialCode = 0
        for (i in lines.indices) {
            val key = lines[i].lowercase()
            if (key.contains("g/h") || key.contains("azel") || key.contains("az/el")) {
                val j = nextNonEmpty(lines, i + 1)
                if (j in lines.indices) {
                    val nums = lines[j].split(',', ';', ' ', '\t').mapNotNull { parseNumber(it) }
                    groundType = nums.getOrNull(0)?.toInt()?.coerceIn(-1, 2) ?: 0
                    addHeightM = nums.getOrNull(1) ?: 0.0
                    materialCode = nums.getOrNull(2)?.toInt() ?: 0
                    val r0 = nums.getOrNull(3)
                    if (r0 != null && r0 in 5.0..1000.0) referenceOhms = r0
                }
                break
            }
        }

        // Expand the four legacy compact stack files exactly as MMANA's Make Stack tool does.
        // Horizontal spacing is perpendicular to the boom in Y; vertical spacing is Z.
        // positionMode=0 means centred around the original location.  The ANT corpus compact-stack
        // files all use mode 0. Each copy gets its own identical-phase source at V/N, matching the
        // MMANA stack rule; lumped loads are duplicated together with their parent antenna.
        // Expand taper-wire references BEFORE legacy stack replication, so every physical copy
        // receives the same stepped telescopic geometry and the B/C/E source/load locations remain
        // tied to the original MMANA wire semantics.
        // Russian "комб. пров." is MMANA CombWire.  Its L0/L1/... lengths must
        // follow exact MMANA semantics (centre or start referenced according to Type).
        // Keep the legacy English taper path unchanged to avoid changing historical
        // imported models that were already regression-tested with that convention.
        val tapered = if (stackHeader != null || russianCombWireHeader)
            expandTaperWiresExact(wires, sources, loads, taperSets)
        else
            expandTaperWiresLegacy(wires, sources, loads, taperSets)
        val expanded = stackHeader?.let { sh ->
            expandLegacyStack(tapered.first, tapered.second, tapered.third, sh)
        }
        val finalWires = expanded?.first ?: tapered.first
        val finalSources = expanded?.second ?: tapered.second
        val finalLoads = expanded?.third ?: tapered.third
        val finalSourceWire = finalSources.firstOrNull()?.wireIndex ?: sourceWire?.takeIf { it in finalWires.indices }

        return MaaModel(
            title = title,
            frequencyMHz = frequencyMHz,
            wires = finalWires,
            sourceWireIndex = finalSourceWire,
            sourceDescription = finalSources.firstOrNull()?.raw ?: sourceDesc,
            loads = finalLoads,
            segmentationDescription = segDesc,
            rawWireCount = finalWires.size,
            referenceImpedanceOhms = referenceOhms,
            fileNameHint = fileNameHint,
            sources = finalSources,
            groundType = groundType,
            addHeightM = addHeightM,
            materialCode = materialCode,
            hasTaperWireExpansion = wires.any { it.taperRef != null },
            invalidSourceRecords = invalidSourceRecords,
            invalidLoadRecords = invalidLoadRecords,
            legacyStackCopies = stackHeader?.let { it.horizontalCount * it.verticalCount } ?: 1
        )
    }

    /** 1.19.259-compatible taper handling for non-stack models. */
    private fun expandTaperWiresLegacy(
        baseWires: List<MaaWire>,
        baseSources: List<MaaSource>,
        baseLoads: List<MaaLoad>,
        taperSets: Map<Double, MaaTaperSet>
    ): Triple<List<MaaWire>, List<MaaSource>, List<MaaLoad>> {
        if (baseWires.none { it.taperRef != null }) return Triple(baseWires, baseSources, baseLoads)

        data class WireMap(val indices: List<Int>, val centerIndex: Int)
        val outWires = ArrayList<MaaWire>()
        val maps = ArrayList<WireMap>(baseWires.size)

        fun sameKey(a: Double, b: Double): Boolean = abs(a - b) <= maxOf(1e-9, maxOf(a, b) * 1e-6)

        baseWires.forEach { w ->
            val ref = w.taperRef
            val set = if (ref == null) null else taperSets.entries.firstOrNull { sameKey(it.key, ref) }?.value
            if (set == null || w.lengthM <= 1e-10) {
                val idx = outWires.size
                outWires += w.copy(taperRef = null)
                maps += WireMap(listOf(idx), idx)
                return@forEach
            }

            val half = w.lengthM * 0.5
            val widths = ArrayList<Double>()
            val radii = ArrayList<Double>()
            var remaining = half
            for ((stageIndex, st) in set.stages.withIndex()) {
                if (remaining <= 1e-10) break
                val requestedHalf = if (stageIndex == set.stages.lastIndex || st.totalLengthM >= 9999.0) remaining else st.totalLengthM * 0.5
                val use = minOf(remaining, requestedHalf.coerceAtLeast(0.0))
                if (use > 1e-10) {
                    widths += use
                    radii += st.radiusM
                    remaining -= use
                }
            }
            if (remaining > 1e-10) {
                widths += remaining
                radii += set.stages.last().radiusM
                remaining = 0.0
            }
            if (widths.isEmpty()) {
                val idx = outWires.size
                outWires += w.copy(taperRef = null)
                maps += WireMap(listOf(idx), idx)
                return@forEach
            }

            // stage 0 spans the centre (2*width[0]); stages 1..N are mirrored left/right.
            val intervals = ArrayList<Triple<Double, Double, Double>>() // s0,s1,r
            var left = half - widths[0]
            var right = half + widths[0]
            // left outer pieces, ordered B -> centre
            var cursor = left
            for (stage in 1..widths.lastIndex) {
                val s0 = cursor - widths[stage]
                intervals += Triple(s0.coerceAtLeast(0.0), cursor, radii[stage])
                cursor = s0
            }
            intervals.sortBy { it.first }
            intervals += Triple(left.coerceAtLeast(0.0), right.coerceAtMost(w.lengthM), radii[0])
            cursor = right
            for (stage in 1..widths.lastIndex) {
                val s1 = (cursor + widths[stage]).coerceAtMost(w.lengthM)
                intervals += Triple(cursor, s1, radii[stage])
                cursor = s1
            }
            // Cover numerical crumbs at B/E with the outermost radius.
            if (intervals.first().first > 1e-9) intervals.add(0, Triple(0.0, intervals.first().first, radii.last()))
            if (intervals.last().second < w.lengthM - 1e-9) intervals += Triple(intervals.last().second, w.lengthM, radii.last())

            val created = ArrayList<Int>()
            var centreIdx = -1
            intervals.forEach { (s0, s1, rad) ->
                if (s1 - s0 <= 1e-10) return@forEach
                fun point(s: Double): Triple<Double, Double, Double> {
                    val t = (s / w.lengthM).coerceIn(0.0, 1.0)
                    return Triple(w.x1 + w.dx * t, w.y1 + w.dy * t, w.z1 + w.dz * t)
                }
                val a = point(s0); val b = point(s1)
                val idx = outWires.size
                outWires += MaaWire(a.first, a.second, a.third, b.first, b.second, b.third, rad, w.tag, null)
                created += idx
                if (half >= s0 - 1e-9 && half <= s1 + 1e-9) centreIdx = idx
            }
            if (centreIdx < 0) centreIdx = created[created.size / 2]
            maps += WireMap(created, centreIdx)
        }

        fun mapPosition(wireIndex: Int, pos: Char): Pair<Int, Char>? {
            val m = maps.getOrNull(wireIndex) ?: return null
            return when (pos.lowercaseChar()) {
                'b' -> m.indices.first() to 'b'
                'e' -> m.indices.last() to 'e'
                else -> m.centerIndex to 'c'
            }
        }
        val outSources = baseSources.mapNotNull { src ->
            mapPosition(src.wireIndex, src.position)?.let { (wi, pos) -> src.copy(wireIndex = wi, position = pos) }
        }
        val outLoads = baseLoads.mapNotNull { ld ->
            mapPosition(ld.wireIndex, ld.position)?.let { (wi, pos) -> ld.copy(wireIndex = wi, position = pos) }
        }
        return Triple(outWires, outSources, outLoads)
    }


    /** Expand MMANA negative-radius taper references into stepped physical wires. */
    private fun expandTaperWiresExact(
        baseWires: List<MaaWire>,
        baseSources: List<MaaSource>,
        baseLoads: List<MaaLoad>,
        taperSets: Map<Double, MaaTaperSet>
    ): Triple<List<MaaWire>, List<MaaSource>, List<MaaLoad>> {
        if (baseWires.none { it.taperRef != null }) return Triple(baseWires, baseSources, baseLoads)

        data class WireMap(val indices: List<Int>, val centerIndex: Int)
        val outWires = ArrayList<MaaWire>()
        val maps = ArrayList<WireMap>(baseWires.size)

        fun sameKey(a: Double, b: Double): Boolean = abs(a - b) <= maxOf(1e-9, maxOf(a, b) * 1e-6)

        baseWires.forEach { w ->
            val ref = w.taperRef
            val set = if (ref == null) null else taperSets.entries.firstOrNull { sameKey(it.key, ref) }?.value
            if (set == null || w.lengthM <= 1e-10) {
                val idx = outWires.size
                outWires += w.copy(taperRef = null)
                maps += WireMap(listOf(idx), idx)
                return@forEach
            }

            val intervals = ArrayList<Triple<Double, Double, Double>>() // s0,s1,r
            val stages = set.stages
            val mode = set.mode
            val total = w.lengthM

            if ((mode and 1) == 0) {
                // MMANA CombWire Type 0/2: centre expansion.
                // L[0] is the FULL centre length. L[1], L[2]... are the length
                // of EACH mirrored side section, not cumulative/full diameters.
                val centreLen = minOf(total, stages[0].totalLengthM.coerceAtLeast(0.0))
                val sideAvail = ((total - centreLen) * 0.5).coerceAtLeast(0.0)
                val left = ArrayList<Pair<Double, Double>>() // length,radius centre->out
                var rem = sideAvail
                var k = 1
                while (rem > 1e-10) {
                    val st = stages.getOrNull(k) ?: stages.last()
                    val sentinel = st.totalLengthM >= 9999.0 || k >= stages.lastIndex
                    val use = if (sentinel) rem else minOf(rem, st.totalLengthM.coerceAtLeast(0.0))
                    if (use <= 1e-10) break
                    left += use to st.radiusM
                    rem -= use
                    k++
                }
                // B -> centre: outer sections in reverse order.
                var cur = 0.0
                for ((len, rad) in left.asReversed()) {
                    intervals += Triple(cur, cur + len, rad); cur += len
                }
                if (centreLen > 1e-10) {
                    intervals += Triple(cur, cur + centreLen, stages[0].radiusM); cur += centreLen
                }
                for ((len, rad) in left) {
                    intervals += Triple(cur, minOf(total, cur + len), rad); cur += len
                }
                if (cur < total - 1e-9) intervals += Triple(cur, total, stages.last().radiusM)
            } else {
                // MMANA CombWire Type 1/3: expand from B toward E.
                var cur = 0.0
                var k = 0
                while (cur < total - 1e-10) {
                    val st = stages.getOrNull(k) ?: stages.last()
                    val sentinel = st.totalLengthM >= 9999.0 || k >= stages.lastIndex
                    val use = if (sentinel) total - cur else minOf(total - cur, st.totalLengthM.coerceAtLeast(0.0))
                    if (use <= 1e-10) break
                    intervals += Triple(cur, cur + use, st.radiusM)
                    cur += use
                    k++
                }
            }

            val created = ArrayList<Int>()
            var centreIdx = -1
            intervals.forEach { (s0, s1, rad) ->
                if (s1 - s0 <= 1e-10) return@forEach
                fun point(s: Double): Triple<Double, Double, Double> {
                    val t = (s / w.lengthM).coerceIn(0.0, 1.0)
                    return Triple(w.x1 + w.dx * t, w.y1 + w.dy * t, w.z1 + w.dz * t)
                }
                val a = point(s0); val b = point(s1)
                val idx = outWires.size
                val expandedTag = if ((set.mode and 2) != 0) {
                    if (w.tag >= 0) w.tag else 0
                } else {
                    if (w.tag == -2 || w.tag == -3) 0 else w.tag
                }
                outWires += MaaWire(a.first, a.second, a.third, b.first, b.second, b.third, rad, expandedTag, null)
                created += idx
                if (total * 0.5 >= s0 - 1e-9 && total * 0.5 <= s1 + 1e-9) centreIdx = idx
            }
            if (centreIdx < 0) centreIdx = created[created.size / 2]
            maps += WireMap(created, centreIdx)
        }

        fun mapPosition(wireIndex: Int, pos: Char): Pair<Int, Char>? {
            val m = maps.getOrNull(wireIndex) ?: return null
            return when (pos.lowercaseChar()) {
                'b' -> m.indices.first() to 'b'
                'e' -> m.indices.last() to 'e'
                else -> m.centerIndex to 'c'
            }
        }
        val outSources = baseSources.mapNotNull { src ->
            mapPosition(src.wireIndex, src.position)?.let { (wi, pos) -> src.copy(wireIndex = wi, position = pos) }
        }
        val outLoads = baseLoads.mapNotNull { ld ->
            mapPosition(ld.wireIndex, ld.position)?.let { (wi, pos) -> ld.copy(wireIndex = wi, position = pos) }
        }
        return Triple(outWires, outSources, outLoads)
    }

    private fun expandLegacyStack(
        baseWires: List<MaaWire>,
        baseSources: List<MaaSource>,
        baseLoads: List<MaaLoad>,
        sh: LegacyStackHeader
    ): Triple<List<MaaWire>, List<MaaSource>, List<MaaLoad>> {
        val nCopies = sh.horizontalCount * sh.verticalCount
        if (nCopies <= 1 || baseWires.isEmpty()) return Triple(baseWires, baseSources, baseLoads)

        val outWires = ArrayList<MaaWire>(baseWires.size * nCopies)
        val outSources = ArrayList<MaaSource>(maxOf(1, baseSources.size) * nCopies)
        val outLoads = ArrayList<MaaLoad>(baseLoads.size * nCopies)

        fun verticalOffset(vi: Int): Double = when (sh.positionMode) {
            1 -> vi * sh.verticalSpacingM                       // original + above
            2 -> -vi * sh.verticalSpacingM                      // original + below
            else -> (vi - (sh.verticalCount - 1) / 2.0) * sh.verticalSpacingM
        }
        fun horizontalOffset(hi: Int): Double =
            (hi - (sh.horizontalCount - 1) / 2.0) * sh.horizontalSpacingM

        var copy = 0
        for (vi in 0 until sh.verticalCount) {
            val dz = verticalOffset(vi)
            for (hi in 0 until sh.horizontalCount) {
                val dy = horizontalOffset(hi)
                val wireBase = copy * baseWires.size
                baseWires.forEach { w ->
                    outWires += w.copy(
                        y1 = w.y1 + dy, z1 = w.z1 + dz,
                        y2 = w.y2 + dy, z2 = w.z2 + dz
                    )
                }
                baseSources.forEach { src ->
                    outSources += src.copy(
                        wireIndex = wireBase + src.wireIndex,
                        amplitude = src.amplitude / nCopies.toDouble(),
                        raw = src.raw + " [stack ${copy + 1}/$nCopies]"
                    )
                }
                baseLoads.forEach { ld ->
                    outLoads += ld.copy(
                        wireIndex = wireBase + ld.wireIndex,
                        raw = ld.raw + " [stack ${copy + 1}/$nCopies]"
                    )
                }
                copy++
            }
        }
        return Triple(outWires, outSources, outLoads)
    }

    private fun parseWireRecord(s: String): MaaWire? {
        // Classic MMANA usually uses commas between fields, but some exports use tabs/spaces.
        // Support both without confusing a decimal comma with the field separator.
        val cleaned = s.trim().removePrefix("\uFEFF")
        val p = if (cleaned.contains(',')) {
            cleaned.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            cleaned.split(Regex("\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        }
        if (p.size < 7) return null
        val n = p.take(7).map { parseNumber(it) }
        if (n.any { it == null }) return null
        val rawRadius = n[6]!!
        return MaaWire(
            n[0]!!, n[1]!!, n[2]!!,
            n[3]!!, n[4]!!, n[5]!!,
            abs(rawRadius),
            p.getOrNull(7)?.trim()?.toIntOrNull() ?: -1,
            taperRef = if (rawRadius < 0.0) abs(rawRadius) else null
        )
    }

    private fun parseNumber(s: String): Double? {
        var t = s.trim().removePrefix("\uFEFF")
        if (t.isEmpty()) return null
        t = t.replace('D', 'E').replace('d', 'e')
        return t.toDoubleOrNull() ?: t.replace(',', '.').toDoubleOrNull()
    }

    private fun findWiresHeader(lines: List<String>): Int {
        val named = lines.indexOfFirst { isSection(it, "wires", "провода", "wire") }
        if (named >= 0) return named

        // Localization-independent structural fallback: section line -> integer count -> valid wire record.
        for (h in lines.indices) {
            if (!looksLikeSection(lines[h])) continue
            val c = nextNonEmpty(lines, h + 1)
            val countText = lines.getOrNull(c)?.trim().orEmpty()
            val count = countText.split(',', ';', ' ', '\t').firstOrNull { it.isNotBlank() }?.toIntOrNull() ?: continue
            if (count <= 0) continue
            val w = nextNonEmpty(lines, c + 1)
            if (parseWireRecord(lines.getOrNull(w)?.trim().orEmpty()) != null) return h
        }
        return -1
    }

    private fun isSection(line: String, vararg names: String): Boolean {
        val t = line.trim().lowercase()
        if (!looksLikeSection(t)) return false
        return names.any { t.contains(it.lowercase()) }
    }

    private fun looksLikeSection(line: String): Boolean = line.trim().startsWith("*")

    private fun nextNonEmpty(lines: List<String>, start: Int): Int {
        var i = start
        while (i < lines.size && lines[i].trim().isEmpty()) i++
        return i
    }
}

data class MaaPatternPoint(val angleDeg: Double, val db: Double)

data class MaaPatternPreview(
    val points: List<MaaPatternPoint>,
    val hpbwDeg: Double?,
    val frontBackDb: Double?,
    val maxSideLobeDb: Double?,
    val absolutePeakDbi: Double? = null
)
