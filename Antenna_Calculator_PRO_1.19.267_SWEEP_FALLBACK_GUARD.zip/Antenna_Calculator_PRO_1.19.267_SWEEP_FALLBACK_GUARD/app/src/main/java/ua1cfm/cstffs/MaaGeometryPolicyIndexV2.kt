package ua1cfm.cstffs

import java.io.InputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt
import kotlin.math.roundToInt

/**
 * Geometry-only experience memory for all 2435 known models.
 * 722 rows carry supervised solver-profile labels, 1713 rows carry semi-supervised labels.
 * No path, filename, title or comment is stored.
 */
object MaaGeometryPolicyIndexV2 {
    data class Match(
        val profile: String,
        val confidencePercent: Int,
        val similarityPercent: Int,
        val nearestDistance: Double,
        val exactGeometry: Boolean,
        val origin: String,
        val neighborsUsed: Int
    )

    private data class Row(
        val origin: String,
        val profile: String,
        val sourceConfidence: Double,
        val z: DoubleArray
    )

    @Volatile private var rows: List<Row> = emptyList()
    @Volatile private var mean: DoubleArray = DoubleArray(0)
    @Volatile private var scale: DoubleArray = DoubleArray(0)

    val size: Int get() = rows.size
    val isReady: Boolean get() = rows.size == 2435 && mean.size == MaaGeometryFingerprint.SIZE

    @Synchronized
    fun install(input: InputStream) {
        if (isReady) return
        var mu: DoubleArray? = null
        var sd: DoubleArray? = null
        val raw = ArrayList<Row>(2435)
        input.bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { line ->
                when {
                    line.startsWith("# mean\t") -> mu = line.split('\t').drop(1).mapNotNull { it.toDoubleOrNull() }.toDoubleArray()
                    line.startsWith("# scale\t") -> sd = line.split('\t').drop(1).mapNotNull { it.toDoubleOrNull() }.toDoubleArray()
                    line.startsWith("#") || line.isBlank() -> Unit
                    else -> {
                        val p = line.split('\t')
                        // hash, origin, profile, source confidence, 44 raw geometry features
                        if (p.size >= 4 + MaaGeometryFingerprint.SIZE) {
                            val v = DoubleArray(MaaGeometryFingerprint.SIZE)
                            var ok = true
                            for (i in v.indices) {
                                val x = p[4 + i].toDoubleOrNull()
                                if (x == null || !x.isFinite()) { ok = false; break }
                                v[i] = x
                            }
                            val c = p[3].toDoubleOrNull()?.coerceIn(0.0, 1.0) ?: 0.0
                            if (ok) raw += Row(p[1], p[2], c, v)
                        }
                    }
                }
            }
        }
        val m = mu ?: return
        val s = sd ?: return
        if (m.size != MaaGeometryFingerprint.SIZE || s.size != MaaGeometryFingerprint.SIZE) return
        mean = m
        scale = s
        rows = raw.map { it.copy(z = standardize(it.z, m, s)) }
    }

    fun match(model: MaaModel, k: Int = 7): Match? {
        val localRows = rows
        val mu = mean
        val sd = scale
        if (localRows.isEmpty() || mu.size != MaaGeometryFingerprint.SIZE || sd.size != MaaGeometryFingerprint.SIZE) return null
        val q = standardize(MaaGeometryFingerprint.vector(model), mu, sd)
        val nearest = localRows.asSequence().map { row ->
            var sum = 0.0
            for (i in q.indices) {
                val d = q[i] - row.z[i]
                sum += d * d
            }
            row to sqrt(sum / q.size.toDouble())
        }.sortedBy { it.second }.take(k.coerceIn(1, 15)).toList()
        if (nearest.isEmpty()) return null

        val first = nearest.first()
        val exact = first.second < 1e-8
        if (exact) {
            val row = first.first
            return Match(
                profile = row.profile,
                confidencePercent = if (row.origin == "KNOWN") 100 else (row.sourceConfidence * 100.0).roundToInt().coerceIn(1, 100),
                similarityPercent = 100,
                nearestDistance = first.second,
                exactGeometry = true,
                origin = row.origin,
                neighborsUsed = 1
            )
        }

        val votes = linkedMapOf<String, Double>()
        var total = 0.0
        for ((row, d) in nearest) {
            // Supervised rows retain full weight. Semi-supervised rows are weighted by teacher confidence.
            val sourceWeight = if (row.origin == "KNOWN") 1.0 else row.sourceConfidence.coerceIn(0.15, 0.85)
            val w = exp(-2.4 * d) * sourceWeight
            votes[row.profile] = (votes[row.profile] ?: 0.0) + w
            total += w
        }
        val best = votes.maxByOrNull { it.value } ?: return null
        val sim = exp(-nearest.first().second).coerceIn(0.0, 1.0)
        val consensus = if (total > 0.0) best.value / total else 0.0
        val conf = (100.0 * sim * (0.50 + 0.50 * consensus)).roundToInt().coerceIn(0, 100)
        return Match(
            profile = best.key,
            confidencePercent = conf,
            similarityPercent = (100.0 * sim).roundToInt().coerceIn(0, 100),
            nearestDistance = nearest.first().second,
            exactGeometry = false,
            origin = nearest.first().first.origin,
            neighborsUsed = nearest.size
        )
    }

    private fun standardize(raw: DoubleArray, mu: DoubleArray, sd: DoubleArray): DoubleArray =
        DoubleArray(MaaGeometryFingerprint.SIZE) { i ->
            val den = sd[i].let { if (abs(it) < 1e-9) 1.0 else it }
            ((raw.getOrElse(i) { 0.0 } - mu[i]) / den).coerceIn(-6.0, 6.0)
        }
}
