package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Common electromagnetic result data carriers for the MMANA/MININEC solver and UI.
 *
 * IMPORTANT: this object is NOT an electromagnetic solver anymore.  The former
 * JNI/OpenNEC solve path, native library loading, sweep solver and all fallback
 * calculations were removed in 1.19.250; 1.19.252 keeps the same single-solver architecture.  MAA calculations are performed only
 * by [MmanaMininecSolver].
 *
 * These classes contain data only; they do not execute any alternate solver.
 */
object AntennaSolveTypes {
    data class InputImpedance(
        val tag: Int,
        val segment: Int,
        val rOhm: Double,
        val xOhm: Double
    ) {
        fun swr(z0Ohm: Double): Double {
            val z0 = z0Ohm.coerceAtLeast(1e-9)
            val den = (rOhm + z0) * (rOhm + z0) + xOhm * xOhm
            if (den <= 1e-30) return Double.POSITIVE_INFINITY
            val gamma2 = (((rOhm - z0) * (rOhm - z0) + xOhm * xOhm) / den).coerceAtLeast(0.0)
            val gamma = sqrt(gamma2)
            if (!gamma.isFinite() || gamma >= 1.0) return Double.POSITIVE_INFINITY
            return (1.0 + gamma) / (1.0 - gamma)
        }

        fun formattedZ(): String = "%.2f %s j%.2f Ω".format(rOhm, if (xOhm >= 0.0) "+" else "−", abs(xOhm))
    }

    data class SegmentCurrent(
        val globalIndex: Int,
        val tag: Int,
        val segment: Int,
        val xM: Double,
        val yM: Double,
        val zM: Double,
        val lengthM: Double,
        val radiusM: Double,
        val ux: Double,
        val uy: Double,
        val uz: Double,
        val currentReA: Double,
        val currentImA: Double,
        val basisARe: Double = Double.NaN,
        val basisAIm: Double = Double.NaN,
        val basisBRe: Double = Double.NaN,
        val basisBIm: Double = Double.NaN,
        val basisCRe: Double = Double.NaN,
        val basisCIm: Double = Double.NaN
    ) {
        val hasNecCurrentBasis: Boolean get() =
            basisARe.isFinite() && basisAIm.isFinite() &&
                basisBRe.isFinite() && basisBIm.isFinite() &&
                basisCRe.isFinite() && basisCIm.isFinite()
        val amplitudeA: Double get() = sqrt(currentReA * currentReA + currentImA * currentImA)
    }

    data class NativePatternPoint(
        val thetaDeg: Double,
        val phiDeg: Double,
        val gainDb: Double
    )

    data class Result(
        val engineVersion: String,
        val frequencyMHz: Double,
        val inputs: List<InputImpedance>,
        val segments: List<SegmentCurrent>,
        val warning: String?,
        val nativePattern: List<NativePatternPoint> = emptyList()
    ) {
        val primary: InputImpedance get() = inputs.first()
        val currentPeakA: Double get() = segments.maxOfOrNull { it.amplitudeA } ?: 0.0
        val primarySegmentIndex: Int
            get() = segments.indexOfFirst { it.tag == primary.tag && it.segment == primary.segment }

        val nearFieldSegments: List<Nec2Core.NearFieldSegment>
            get() {
                if (segments.isEmpty()) return emptyList()
                val countByTag = segments.groupingBy { it.tag }.eachCount()
                return segments.map { s ->
                    val count = countByTag[s.tag]?.coerceAtLeast(1) ?: 1
                    Nec2Core.NearFieldSegment(
                        x = s.xM, y = s.yM, z = s.zM,
                        ux = s.ux, uy = s.uy, uz = s.uz,
                        lengthM = s.lengthM, radiusM = s.radiusM,
                        currentReA = s.currentReA, currentImA = s.currentImA,
                        wireIndex = s.tag - 1,
                        alongWire = ((s.segment - 0.5) / count.toDouble()).coerceIn(0.0, 1.0)
                    )
                }
            }
    }

    data class SweepPoint(
        val frequencyMHz: Double,
        val inputs: List<InputImpedance>
    ) {
        val primary: InputImpedance get() = inputs.first()
    }
}
