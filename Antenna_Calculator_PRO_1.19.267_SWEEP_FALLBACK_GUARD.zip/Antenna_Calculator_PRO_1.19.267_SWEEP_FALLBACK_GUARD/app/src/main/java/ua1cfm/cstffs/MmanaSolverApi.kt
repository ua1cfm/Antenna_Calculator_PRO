package ua1cfm.cstffs

import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Single MMANA/MININEC solver API used by every MAA calculation path.
 * There is no alternate PEEC/EFIE/NEC/FDTD/FEM impedance fallback.
 */
object MmanaSolverApi {
    data class Progress(val percent: Int, val stage: String)

    /** Explicit MMANA material selection. MAA itself does not store this choice. */
    enum class WireMaterial(val conductivitySPerM: Double?) {
        PERFECT(null),
        COPPER(5.8e7)
    }

    data class Result(
        val rOhm: Double,
        val xOhm: Double,
        val segments: Int,
        val passCount: Int,
        val deltaPercent: Double?,
        val confidence: String,
        val minSegmentRadiusRatio: Double,
        val matrixResidual: Double,
        val junctionCount: Int,
        val resolvedSources: String,
        val resolvedLoads: String,
        val skippedInsulatorWires: Int,
        val groundTerminalCount: Int,
        val endpointFineWireCount: Int,
        val sourceHostSegments: String,
        val loadHostSegments: String,
        val fieldSegments: List<AntennaSolveTypes.SegmentCurrent>
    ) {
        fun formattedZ(): String = "%.2f %s j%.2f Ω".format(
            rOhm,
            if (xOhm >= 0.0) "+" else "−",
            abs(xOhm)
        )
    }

    @Suppress("UNUSED_PARAMETER")
    fun solveAdaptive(
        model: MaaModel,
        cancel: AtomicBoolean = AtomicBoolean(false),
        maxPasses: Int = 1,
        wireMaterial: WireMaterial = WireMaterial.COPPER,
        segmentationReferenceMHz: Double? = null,
        onProgress: (Progress) -> Unit = {}
    ): Result {
        val primary = MmanaMininecSolver.solve(model, cancel, onProgress, wireMaterial.conductivitySPerM, segmentationReferenceMHz)
        val activeSources = model.sources.count { kotlin.math.abs(it.amplitude) > 1e-15 }
        val needsMultiSourceReference =
            activeSources >= 2 && model.groundType == 2 && primary.rOhm < -1e-6
        if (!needsMultiSourceReference) return primary

        // Frequency sweeps freeze the pulse grid at f0. The multi-source EFIE
        // fallback currently regenerates its own frequency-dependent grid.
        // Never splice that different discretisation into the same Z(f) trace.
        // Surface the unstable primary point as an explicit error instead of
        // drawing a plausible but numerically inconsistent Smith trajectory.
        if (segmentationReferenceMHz != null) {
            throw IllegalStateException(
                "Fixed-grid sweep: primary MININEC produced negative R at " +
                    "${model.frequencyMHz} MHz for a multi-source real-ground model. " +
                    "Reference fallback uses a different grid; sweep halted."
            )
        }

        val ref = MmanaMultiSourceReference.solveAdaptive(model, cancel, 5) { p ->
            onProgress(Progress(p.percent, "MMANA multi-source reference • ${p.stage}"))
        }
        if (!ref.rOhm.isFinite() || !ref.xOhm.isFinite() || ref.rOhm <= 0.0) return primary
        return Result(
            rOhm = ref.rOhm, xOhm = ref.xOhm, segments = ref.segments,
            passCount = ref.passCount, deltaPercent = ref.deltaPercent,
            confidence = "MMANA/MININEC fallback • conductor material not applied",
            minSegmentRadiusRatio = ref.minSegmentRadiusRatio, matrixResidual = ref.matrixResidual,
            junctionCount = ref.junctionCount, resolvedSources = ref.resolvedSources,
            resolvedLoads = ref.resolvedLoads, skippedInsulatorWires = ref.skippedInsulatorWires,
            groundTerminalCount = ref.groundTerminalCount, endpointFineWireCount = ref.endpointFineWireCount,
            sourceHostSegments = ref.sourceHostSegments, loadHostSegments = ref.loadHostSegments,
            fieldSegments = ref.fieldSegments
        )
    }
}
