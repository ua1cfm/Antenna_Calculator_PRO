package ua1cfm.cstffs

import kotlin.math.*

/**
 * Geometry/electrical-topology fingerprint for MAA models.
 * Deliberately ignores title, filename and comments.
 */
object MaaGeometryFingerprint {
    const val SIZE = 44

    private data class Node(val x: Long, val y: Long, val z: Long)

    fun vector(m: MaaModel): DoubleArray {
        val lambda = m.wavelengthM.coerceAtLeast(1e-12)
        val wires = m.wires.filter { it.lengthM > 1e-10 && it.radiusM > 0.0 }
        if (wires.isEmpty()) return DoubleArray(SIZE)

        val spans = doubleArrayOf(m.spanX / lambda, m.spanY / lambda, m.spanZ / lambda)
        val sortedSpans = spans.sortedDescending()
        val total = wires.sumOf { it.lengthM } / lambda
        val lens = wires.map { it.lengthM / lambda }.sorted()
        val radii = wires.map { abs(it.radiusM) / lambda }.sorted()

        fun quantile(xs: List<Double>, q: Double): Double {
            if (xs.isEmpty()) return 0.0
            val p = (xs.size - 1) * q.coerceIn(0.0, 1.0)
            val i = floor(p).toInt(); val j = ceil(p).toInt()
            if (i == j) return xs[i]
            val t = p - i
            return xs[i] * (1.0 - t) + xs[j] * t
        }

        var nx = 0; var ny = 0; var nz = 0
        val ori = ArrayList<DoubleArray>(wires.size)
        wires.forEach { w ->
            val l = w.lengthM
            val a = doubleArrayOf(abs(w.dx)/l, abs(w.dy)/l, abs(w.dz)/l)
            ori += a
            if (a[0] > 0.92) nx++
            if (a[1] > 0.92) ny++
            if (a[2] > 0.92) nz++
        }
        val fx = nx.toDouble()/wires.size; val fy = ny.toDouble()/wires.size; val fz = nz.toDouble()/wires.size
        val fob = (1.0 - fx - fy - fz).coerceAtLeast(0.0)

        val scaleM = maxOf(m.spanX, m.spanY, m.spanZ, 1.0)
        val eps = max(1e-9, scaleM * 1e-7)
        fun node(x: Double,y: Double,z: Double) = Node(round(x/eps).toLong(),round(y/eps).toLong(),round(z/eps).toLong())
        val adj = linkedMapOf<Node, MutableSet<Node>>()
        wires.forEach { w ->
            val a=node(w.x1,w.y1,w.z1); val b=node(w.x2,w.y2,w.z2)
            if (a != b) { adj.getOrPut(a){linkedSetOf()}.add(b); adj.getOrPut(b){linkedSetOf()}.add(a) }
        }
        val degrees = adj.values.map { it.size }
        var components=0
        val seen=hashSetOf<Node>()
        for (start in adj.keys) {
            if (!seen.add(start)) continue
            components++
            val q=java.util.ArrayDeque<Node>(); q.add(start)
            while(!q.isEmpty()) {
                val u=q.removeFirst()
                adj[u].orEmpty().forEach { if(seen.add(it)) q.add(it) }
            }
        }
        val vCount=adj.size
        val eCount=degrees.sum()/2
        val cycles=max(0,eCount-vCount+components)
        val endpoints=degrees.count{it==1}; val branches=degrees.count{it>=3}; val maxDegree=degrees.maxOrNull()?:0

        val src = m.sources.firstOrNull()
        var srcL=0.0; var sox=0.0; var soy=0.0; var soz=0.0
        var spx=.5; var spy=.5; var spz=.5
        if (src != null) m.wires.getOrNull(src.wireIndex)?.let { w ->
            val l=w.lengthM; srcL=l/lambda
            if(l>1e-12){sox=abs(w.dx)/l;soy=abs(w.dy)/l;soz=abs(w.dz)/l}
            val px=w.midX; val py=w.midY; val pz=w.midZ
            if(m.spanX>1e-12) spx=(px-m.minX)/m.spanX
            if(m.spanY>1e-12) spy=(py-m.minY)/m.spanY
            if(m.spanZ>1e-12) spz=(pz-m.minZ)/m.spanZ
        }

        val pts = ArrayList<Triple<Double,Double,Double>>(wires.size*2)
        wires.forEach { pts += Triple(it.x1,it.y1,it.z1); pts += Triple(it.x2,it.y2,it.z2) }
        val cx=(m.minX+m.maxX)*.5; val cy=(m.minY+m.maxY)*.5; val cz=(m.minZ+m.maxZ)*.5
        val seps=eps*3
        fun key(p: Triple<Double,Double,Double>)=Node(round(p.first/seps).toLong(),round(p.second/seps).toLong(),round(p.third/seps).toLong())
        val pset=pts.map(::key).toHashSet()
        fun symmetry(axis:Int):Double {
            var hit=0
            pts.forEach { p ->
                val r=when(axis){0->Triple(2*cx-p.first,p.second,p.third);1->Triple(p.first,2*cy-p.second,p.third);else->Triple(p.first,p.second,2*cz-p.third)}
                if(key(r) in pset) hit++
            }
            return hit.toDouble()/pts.size.coerceAtLeast(1)
        }

        var parallel=0; var pairs=0
        val lim=min(80,ori.size)
        for(i in 0 until lim) for(j in i+1 until lim) {
            pairs++
            val a=ori[i]; val b=ori[j]
            val dot=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
            if(abs(dot)>0.95) parallel++
        }
        val parfrac=parallel.toDouble()/pairs.coerceAtLeast(1)

        val nload=m.loads.size
        val lc=m.loads.count{it.kind==0}; val fixed=m.loads.count{it.kind==1}; val lap=m.loads.count{it.kind==2}
        val lr=wires.map { it.lengthM / max(abs(it.radiusM),1e-12) }.sorted()

        val segNums = Regex("[-+]?\\d+(?:[.,]\\d+)?").findAll(m.segmentationDescription.orEmpty())
            .mapNotNull { it.value.replace(',','.').toDoubleOrNull() }.toList()
        val dm2=segNums.getOrNull(1)?:0.0; val sc=segNums.getOrNull(2)?:0.0; val ec=segNums.getOrNull(3)?:0.0

        val out=doubleArrayOf(
            ln(1.0+wires.size)/5.0, ln(1.0+total)/5.0,
            spans[0].coerceIn(0.0,10.0)/10.0, spans[1].coerceIn(0.0,10.0)/10.0, spans[2].coerceIn(0.0,10.0)/10.0,
            sortedSpans.getOrElse(1){0.0}/max(sortedSpans.getOrElse(0){0.0},1e-9),
            sortedSpans.getOrElse(2){0.0}/max(sortedSpans.getOrElse(0){0.0},1e-9),
            fx,fy,fz,fob,
            ln(1.0+vCount)/6.0, endpoints.toDouble()/vCount.coerceAtLeast(1), branches.toDouble()/vCount.coerceAtLeast(1), min(maxDegree,8)/8.0,
            min(cycles,10)/10.0, min(components,10)/10.0,
            quantile(lens,.1),quantile(lens,.5),quantile(lens,.9),
            log10(max(quantile(radii,.5),1e-8))+8.0,
            min(quantile(lr,.1),1000.0)/1000.0,min(quantile(lr,.5),2000.0)/2000.0,
            min(m.sources.size,4)/4.0,min(nload,8)/8.0,
            lc.toDouble()/nload.coerceAtLeast(1), fixed.toDouble()/nload.coerceAtLeast(1), lap.toDouble()/nload.coerceAtLeast(1),
            m.groundType/2.0,min(abs(m.addHeightM/lambda),5.0)/5.0,
            min(srcL,2.0)/2.0,sox,soy,soz,spx,spy,spz,
            symmetry(0),symmetry(1),symmetry(2),parfrac,
            min(dm2,100.0)/100.0,min(sc,3.0)/3.0,min(ec,20.0)/20.0
        )
        return if(out.size==SIZE) out else DoubleArray(SIZE)
    }
}
