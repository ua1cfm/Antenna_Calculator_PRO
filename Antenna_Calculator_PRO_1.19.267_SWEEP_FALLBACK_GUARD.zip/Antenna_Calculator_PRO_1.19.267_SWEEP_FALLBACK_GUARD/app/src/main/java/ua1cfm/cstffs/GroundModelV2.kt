package ua1cfm.cstffs

import kotlin.math.abs
import kotlin.math.max

/**
 * Ground Model v2.
 *
 * Keeps three physically different cases separate:
 *  - FREE_SPACE: no boundary at z=0.
 *  - PEC_PLANE: an infinite perfect electric conductor (MMANA G=1).
 *  - REAL_EARTH: finite-conductivity half-space (MMANA G=2).
 *
 * Explicit radials / ground-plane wires are always kept as ordinary MaaWire geometry;
 * this object never replaces them with an infinite ground boundary.
 */
object GroundModelV2 {
    enum class Mode { FREE_SPACE, PEC_PLANE, REAL_EARTH }

    const val DEFAULT_EPS_R = 13.0
    const val DEFAULT_SIGMA_S_M = 0.005

    data class Spec(
        val mode: Mode,
        val addHeightM: Double,
        val epsR: Double = DEFAULT_EPS_R,
        val sigmaSM: Double = DEFAULT_SIGMA_S_M,
        val wiresInPlane: Int = 0,
        val wiresTouchingPlane: Int = 0
    ) {
        val hasGround: Boolean get() = mode != Mode.FREE_SPACE
        val label: String get() = when (mode) {
            Mode.FREE_SPACE -> "FREE SPACE"
            Mode.PEC_PLANE -> "PEC PLANE"
            Mode.REAL_EARTH -> "REAL EARTH εr=%.0f σ=%.3f".format(epsR, sigmaSM)
        }
    }

    fun spec(model: MaaModel): Spec {
        val mode = when (model.groundType) {
            1 -> Mode.PEC_PLANE
            2, -1 -> Mode.REAL_EARTH
            else -> Mode.FREE_SPACE
        }
        val shift = if (mode == Mode.FREE_SPACE) 0.0 else model.addHeightM
        val tol = max(1e-8, model.wavelengthM * 1e-8)
        var inPlane = 0
        var touching = 0
        if (mode != Mode.FREE_SPACE) {
            model.wires.forEach { w ->
                val z1 = w.z1 + shift
                val z2 = w.z2 + shift
                val a = abs(z1) <= tol
                val b = abs(z2) <= tol
                if (a && b) inPlane++
                if (a || b) touching++
            }
        }
        return Spec(mode, shift, wiresInPlane = inPlane, wiresTouchingPlane = touching)
    }

    /** NEC card for the physical boundary. G=2 is a real finite-conductivity earth, not PEC. */
    fun necGroundCard(model: MaaModel): String = when (spec(model).mode) {
        Mode.FREE_SPACE -> "GN -1"
        Mode.PEC_PLANE -> "GN 1"
        Mode.REAL_EARTH -> "GN 2 0 0 0 %.6f %.6f".format(DEFAULT_EPS_R, DEFAULT_SIGMA_S_M)
    }
}
