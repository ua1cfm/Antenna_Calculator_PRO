import ua1cfm.cstffs.MmanaGalSegmentation
import ua1cfm.cstffs.MmanaStackSegmentation

fun main() {
    val p1 = MmanaGalSegmentation.Params(dm1=200,dm2=20,sc=2.0,ec=1)
    val p2 = p1.copy(ec=2)
    val compact = true
    check(compact && p1.ec<=1 && -1 in -3..-1)
    check(!(compact && p2.ec<=1 && -1 in -3..-1))
    check(!(false && p1.ec<=1 && -1 in -3..-1))
    check(!(compact && p1.ec<=1 && 3 in -3..-1))
    for (p in listOf(p1,p2)) for(tag in -3..-1) {
      val a = MmanaStackSegmentation.spans(0.2,21.2,tag,p)
      check(a.size>=2)
      check(kotlin.math.abs(a.first().f0) < 1e-9)
      check(kotlin.math.abs(a.last().f1-1.0) < 1e-9)
      check(a.zipWithNext().all{(u,v)-> kotlin.math.abs(u.f1-v.f0)<1e-9})
    }
    println("PASS: EC guard, compact guard, tag guard, Tei contiguous spans for EC=1/2")
}
