package ua1cfm.cstffs

import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.io.BufferedReader
import java.io.StringReader

private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
private fun decodeMaa(bytes: ByteArray): String = try {
    StandardCharsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
        .decode(ByteBuffer.wrap(bytes)).toString()
} catch (_: Exception) {
    String(bytes, Charset.forName("windows-1251"))
}

fun main(args: Array<String>) {
    require(args.size >= 2) { "usage: AuditHarness <root> <out.csv> [list.txt]" }
    val root = File(args[0])
    val out = File(args[1])
    val wanted = if (args.size >= 3) {
        File(args[2]).readLines().map { it.trim().replace('\\', '/') }.filter { it.isNotEmpty() }.toSet()
    } else null
    val files = root.walkTopDown()
        .filter { it.isFile && it.extension.equals("maa", true) }
        .filter { f -> wanted == null || f.relativeTo(root).path.replace('\\', '/') in wanted }
        .sortedBy { it.relativeTo(root).path.lowercase() }
        .toList()

    out.bufferedWriter().use { w ->
        w.appendLine("file,freq_mhz,wires,sources,loads,ground,R_ohm,X_ohm,pass_count,delta_pct,confidence,residual,segments,junctions,status,error,resolved_sources,resolved_loads")
        for ((i, f) in files.withIndex()) {
            val rel = f.relativeTo(root).path.replace('\\', '/')
            try {
                val text = decodeMaa(f.readBytes())
                val model = BufferedReader(StringReader(text)).use { MaaParser.parse(it, rel) }
                val t0 = System.nanoTime()
                val token = AtomicBoolean(false)
                val watchdog = Thread {
                    try { Thread.sleep(8000) } catch (_: InterruptedException) { return@Thread }
                    token.set(true)
                }
                watchdog.isDaemon = true
                watchdog.start()
                val r = try { FullWaveLabSolver.solveAdaptive(model, token, 2) { } } finally { watchdog.interrupt() }
                val ms = (System.nanoTime() - t0) / 1e6
                w.appendLine(listOf(
                    csv(rel), model.frequencyMHz, model.wires.size, model.sources.size, model.loads.size, model.groundType,
                    r.rOhm, r.xOhm, r.passCount, r.deltaPercent ?: Double.NaN, csv(r.confidence), r.matrixResidual,
                    r.segments, r.junctionCount, "OK", csv(""), csv(r.resolvedSources), csv(r.resolvedLoads)
                ).joinToString(","))
                w.flush()
                System.err.println("[${i+1}/${files.size}] OK $rel R=${r.rOhm} X=${r.xOhm} ${"%.0f".format(ms)}ms")
            } catch (e: Throwable) {
                val msg = "${e::class.simpleName}: ${e.message ?: ""}".replace('\n', ' ')
                w.appendLine(listOf(csv(rel), "", "", "", "", "", "", "", "", "", "", "", "", "", "ERROR", csv(msg), "", "").joinToString(","))
                w.flush()
                System.err.println("[${i+1}/${files.size}] ERROR $rel $msg")
            }
        }
    }
}
